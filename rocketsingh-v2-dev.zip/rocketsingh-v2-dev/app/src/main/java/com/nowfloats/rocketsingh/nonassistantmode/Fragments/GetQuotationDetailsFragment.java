package com.nowfloats.rocketsingh.nonassistantmode.Fragments;

import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import android.widget.TextView;


import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.CheckIfFpHasLeadResponse;
import com.nowfloats.rocketsingh.models.SingleProductModel;
import com.nowfloats.rocketsingh.nonassistantmode.Adapter.ProductAdapter;

import java.util.List;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class GetQuotationDetailsFragment extends Fragment implements ProductAdapter.OnProductSelectedInterface {


    //private Spinner spinner;
    private OnQuotationSubmittedInterface mListener;
    private List<SingleProductModel> singleProductModelList;
    private CheckIfFpHasLeadResponse checkIfFpHasLeadResponse;
    //private List<String> productList = new ArrayList<>();
    private boolean visibility;
    private EditText et_discountPercentage , et_discountReason;
    private SingleProductModel selectedProduct = null ;
    private TextView tv_productSelected;
    private ImageView im_downArrowForProduct;
    private RecyclerView rv_productList;

    public GetQuotationDetailsFragment() {
        // Required empty public constructor
    }



    public static GetQuotationDetailsFragment newInstance(OnQuotationSubmittedInterface onQuotationSubmittedInterface) {
        GetQuotationDetailsFragment fragment = new GetQuotationDetailsFragment();
        fragment.mListener = onQuotationSubmittedInterface;
        return fragment;
    }

    public GetQuotationDetailsFragment populateObjects(List<SingleProductModel> singleProductModels , CheckIfFpHasLeadResponse checkIfFpHasLeadResponse){
        this.checkIfFpHasLeadResponse = checkIfFpHasLeadResponse;
        this.singleProductModelList = singleProductModels;
        return this;
    }


    private void initialiseProductView(){
        ProductAdapter productAdapter = new ProductAdapter(singleProductModelList, this);
        rv_productList.setLayoutManager(new LinearLayoutManager(getContext()));
        rv_productList.setAdapter(productAdapter);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =  inflater.inflate(R.layout.fragment_get_quotation_details, container, false);
        View circularProgressButton = v.findViewById(R.id.bt_proceedFurther);
        et_discountPercentage = v.findViewById(R.id.et_discountPercentage);
        et_discountReason = v.findViewById(R.id.et_discountReason);
        rv_productList = v.findViewById(R.id.rv_productList);
        im_downArrowForProduct = v.findViewById(R.id.im_arrow);
        LinearLayout ll_productLayout = v.findViewById(R.id.ll_productSelected);
        tv_productSelected = v.findViewById(R.id.tv_productSelected);
        changeHeight(rv_productList , 0);
        initialiseProductView();
        initiateCustomerDetailCard(v);
        ll_productLayout.setOnClickListener(view -> im_downArrowForProduct.performClick());
        im_downArrowForProduct.setOnClickListener((view)->{
            changeHeight(rv_productList ,visibility ? 0 : 50 * singleProductModelList.size());
            visibility = !visibility;
        });
        circularProgressButton.setOnClickListener(view ->
                mListener.onQuotationSubmitted(selectedProduct ,
                        et_discountPercentage.getText().toString() , et_discountReason.getText().toString()));
        return v;
    }

    private void changeHeight(View view , int height){

        ValueAnimator anim = ValueAnimator.ofInt(view.getMeasuredHeight(), height);
        anim.addUpdateListener(valueAnimator -> {
            int val = (Integer) valueAnimator.getAnimatedValue();
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            layoutParams.height = val;
            view.setLayoutParams(layoutParams);
        });
        anim.setDuration(600);
        anim.start();


    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnQuotationSubmittedInterface) {
            mListener = (OnQuotationSubmittedInterface) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement onInvoiceUpdated");
        }
    }

    private void initiateCustomerDetailCard(View v){

        TextView tv_customerName = v.findViewById(R.id.tv_customerName);
        TextView tv_customerMobile = v.findViewById(R.id.tv_primaryNumber);
        TextView tv_customerNumber = v.findViewById(R.id.tv_customerNumber);
        TextView tv_businessName = v.findViewById(R.id.tv_businessName);

        tv_customerNumber.setText("Customer number: " + checkIfFpHasLeadResponse.getLeadNumber());
        tv_customerMobile.setText("Customer primary number: "+checkIfFpHasLeadResponse.getMobile());
        tv_customerName.setText("Customer name: "+checkIfFpHasLeadResponse.getName());
        tv_businessName.setText("Customer business name: "+checkIfFpHasLeadResponse.getBusinessName());

    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onProductSelected(SingleProductModel singleProductModel) {
        selectedProduct = singleProductModel;
        tv_productSelected.setText(selectedProduct.getName());
        visibility = !visibility;
        changeHeight(rv_productList , 0);
    }

    public interface OnQuotationSubmittedInterface {
        // TODO: Update argument type and name
        void onQuotationSubmitted(SingleProductModel selectedProduct , String discountPercentage , String discountReason);
    }


}
