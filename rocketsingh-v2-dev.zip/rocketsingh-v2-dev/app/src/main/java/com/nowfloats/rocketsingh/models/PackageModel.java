package com.nowfloats.rocketsingh.models;

import android.os.Parcel;
import android.os.Parcelable;

public class PackageModel  implements Parcelable{
    private String packageName;
    public boolean selected = false;
    public PackageModel(Parcel in) {
        packageName = in.readString();
    }

    public PackageModel(String packageName){
        this.packageName = packageName;
    }

    public void setPackageName(String packageName)
    {
        this.packageName = packageName;
    }

    public String getPackageName(){
        return packageName;
    }
    public static final Creator<PackageModel> CREATOR = new Creator<PackageModel>() {
        @Override
        public PackageModel createFromParcel(Parcel in) {
            return new PackageModel(in);
        }

        @Override
        public PackageModel[] newArray(int size) {
            return new PackageModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(packageName);
    }
}
