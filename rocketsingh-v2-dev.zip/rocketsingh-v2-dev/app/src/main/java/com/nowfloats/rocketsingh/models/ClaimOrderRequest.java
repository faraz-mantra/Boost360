package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ClaimOrderRequest {

    @SerializedName("claimId")
    @Expose
    private String claimId;
    @SerializedName("emailId")
    @Expose
    private String emailId;
    @SerializedName("hotProspect")
    @Expose
    private String hotProspect;

    public String getClaimId() {
        return claimId;
    }

    public void setClaimId(String claimId) {
        this.claimId = claimId;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getHotProspect() {
        return hotProspect;
    }

    public void setHotProspect(String hotProspect) {
        this.hotProspect = hotProspect;
    }

}