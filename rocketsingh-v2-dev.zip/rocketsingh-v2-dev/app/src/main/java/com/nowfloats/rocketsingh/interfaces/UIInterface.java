package com.nowfloats.rocketsingh.interfaces;

public interface UIInterface {
    void showProgressDialog();
    void hideProgressDialog();
}
