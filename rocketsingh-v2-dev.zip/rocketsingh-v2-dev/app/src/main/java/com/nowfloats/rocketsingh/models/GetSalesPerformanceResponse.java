package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 15-Feb-18.
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetSalesPerformanceResponse {

    @SerializedName("lastDayPerformance")
    @Expose
    private String lastDayPerformance;
    @SerializedName("NetRevenueTillDate")
    @Expose
    private Double netRevenueTillDate;
    @SerializedName("NumOfOrderTillDate")
    @Expose
    private Integer numOfOrderTillDate;
    @SerializedName("lastDayFolloupMeetingNum")
    @Expose
    private Integer lastDayFolloupMeetingNum;
    @SerializedName("lastDayNewMeetingNum")
    @Expose
    private Integer lastDayNewMeetingNum;
    @SerializedName("lastMeetingDate")
    @Expose
    private String lastMeetingDate;

    public String getLastDayPerformance() {
        return lastDayPerformance;
    }

    public void setLastDayPerformance(String lastDayPerformance) {
        this.lastDayPerformance = lastDayPerformance;
    }

    public Double getNetRevenueTillDate() {
        return netRevenueTillDate;
    }

    public void setNetRevenueTillDate(Double netRevenueTillDate) {
        this.netRevenueTillDate = netRevenueTillDate;
    }

    public Integer getNumOfOrderTillDate() {
        return numOfOrderTillDate;
    }

    public void setNumOfOrderTillDate(Integer numOfOrderTillDate) {
        this.numOfOrderTillDate = numOfOrderTillDate;
    }

    public Integer getLastDayFolloupMeetingNum() {
        return lastDayFolloupMeetingNum;
    }

    public void setLastDayFolloupMeetingNum(Integer lastDayFolloupMeetingNum) {
        this.lastDayFolloupMeetingNum = lastDayFolloupMeetingNum;
    }

    public Integer getLastDayNewMeetingNum() {
        return lastDayNewMeetingNum;
    }

    public void setLastDayNewMeetingNum(Integer lastDayNewMeetingNum) {
        this.lastDayNewMeetingNum = lastDayNewMeetingNum;
    }

    public String getLastMeetingDate() {
        return lastMeetingDate;
    }

    public void setLastMeetingDate(String lastMeetingDate) {
        this.lastMeetingDate = lastMeetingDate;
    }

}