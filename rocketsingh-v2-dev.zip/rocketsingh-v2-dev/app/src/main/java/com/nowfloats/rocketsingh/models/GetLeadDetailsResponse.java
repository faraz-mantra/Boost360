package com.nowfloats.rocketsingh.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by NowFloats on 17-Dec-17.
 */

public class GetLeadDetailsResponse {

    @SerializedName("jsonrpc")
    @Expose
    private String jsonrpc;
    @SerializedName("id")
    @Expose
    private Object id;
    @SerializedName("result")
    @Expose
    private List<Result> result = null;

    public String getJsonrpc() {
        return jsonrpc;
    }

    public void setJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
    }

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public List<Result> getResult() {
        return result;
    }

    public void setResult(List<Result> result) {
        this.result = result;
    }

    public class Result {

        @SerializedName("business_category")
        @Expose
        private String businessCategory;
        @SerializedName("city")
        @Expose
        private String city;
        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("fptag")
        @Expose
        private String fptag;
        @SerializedName("mobile")
        @Expose
        private String mobile;

        @SerializedName("lc_email")
        @Expose
        private String lc_email;

        @SerializedName("country")
        @Expose
        private String country;
        @SerializedName("street2")
        @Expose
        private String street2;
        @SerializedName("pincode")
        @Expose
        private String pincode;
        @SerializedName("state")
        @Expose
        private String state;
        @SerializedName("street")
        @Expose
        private String street;
        @SerializedName("company_name")
        @Expose
        private String companyName;
        @SerializedName("type")
        @Expose
        private String type;
        @SerializedName("company_email")
        @Expose
        private String companyEmail;

        public String getBusinessCategory() {
            return businessCategory;
        }

        public void setBusinessCategory(String businessCategory) {
            this.businessCategory = businessCategory;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getFptag() {
            return fptag;
        }

        public void setFptag(String fptag) {
            this.fptag = fptag;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getStreet2() {
            return street2;
        }

        public void setStreet2(String street2) {
            this.street2 = street2;
        }

        public String getPincode() {
            return pincode;
        }

        public void setPincode(String pincode) {
            this.pincode = pincode;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getStreet() {
            return street;
        }

        public void setStreet(String street) {
            this.street = street;
        }

        public String getCompanyName() {
            return companyName;
        }

        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getCompanyEmail() {
            return companyEmail;
        }

        public void setCompanyEmail(String companyEmail) {
            this.companyEmail = companyEmail;
        }

        public String getLc_email() {
            return lc_email;
        }

        public void setLc_email(String lc_email) {
            this.lc_email = lc_email;
        }
    }

}