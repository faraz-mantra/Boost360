package com.nowfloats.rocketsingh.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.nowfloats.rocketsingh.R;

public class MeetingDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meeting_details);
    }
}
