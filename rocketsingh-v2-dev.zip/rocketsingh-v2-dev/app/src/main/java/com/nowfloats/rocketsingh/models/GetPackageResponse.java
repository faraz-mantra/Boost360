package com.nowfloats.rocketsingh.models;



import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetPackageResponse {

    @SerializedName("AllPackages")
    @Expose
    private List<AllPackage> allPackages = null;

    public List<AllPackage> getAllPackages() {
        return allPackages;
    }

    public void setAllPackages(List<AllPackage> allPackages) {
        this.allPackages = allPackages;
    }


    public class AllPackage {

        @SerializedName("Key")
        @Expose
        private String key;
        @SerializedName("Value")
        @Expose
        private List<Value> value = null;

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public List<Value> getValue() {
            return value;
        }

        public void setValue(List<Value> value) {
            this.value = value;
        }

    }

    public class Value {

        @SerializedName("_id")
        @Expose
        private String id;
        @SerializedName("productClassification")
        @Expose
        private ProductClassification productClassification;
        @SerializedName("Identifier")
        @Expose
        private String identifier;
        @SerializedName("IsArchived")
        @Expose
        private Boolean isArchived;
        @SerializedName("SupportedPaymentMethods")
        @Expose
        private List<SupportedPaymentMethod> supportedPaymentMethods = null;
        @SerializedName("Taxes")
        @Expose
        private List<Tax> taxes = null;
        @SerializedName("revenueShare")
        @Expose
        private Object revenueShare;
        @SerializedName("CreatedOn")
        @Expose
        private String createdOn;
        @SerializedName("packageCategory")
        @Expose
        private List<String> packageCategory = null;
        @SerializedName("ExternalApplicationDetails")
        @Expose
        private List<ExternalApplicationDetail> externalApplicationDetails = null;
        @SerializedName("Price")
        @Expose
        private Double price;
        @SerializedName("ExpiryInMths")
        @Expose
        private Double expiryInMths;
        @SerializedName("CurrencyCode")
        @Expose
        private String currencyCode;
        @SerializedName("Name")
        @Expose
        private String name;
        @SerializedName("Desc")
        @Expose
        private Object desc;
        @SerializedName("Type")
        @Expose
        private Double type;
        @SerializedName("ValidCountry")
        @Expose
        private List<String> validCountry = null;
        @SerializedName("ValidCity")
        @Expose
        private Object validCity;
        @SerializedName("Priority")
        @Expose
        private Double priority;
        @SerializedName("ValidityInMths")
        @Expose
        private Double validityInMths;
        @SerializedName("Screenshots")
        @Expose
        private Object screenshots;
        @SerializedName("PrimaryImageUri")
        @Expose
        private String primaryImageUri;
        @SerializedName("maxDiscount")
        @Expose
        private MaxDiscount maxDiscount;
        @SerializedName("renewalChannelId")
        @Expose
        private Object renewalChannelId;
        @SerializedName("upSellChannelId")
        @Expose
        private Object upSellChannelId;
        @SerializedName("supportChannelId")
        @Expose
        private Object supportChannelId;
        @SerializedName("NetAmount")
        @Expose
        private Object netAmount;
        @SerializedName("packageVisibilityType")
        @Expose
        private Double packageVisibilityType;
        @SerializedName("WidgetPacks")
        @Expose
        private List<WidgetPack> widgetPacks = null;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public ProductClassification getProductClassification() {
            return productClassification;
        }

        public void setProductClassification(ProductClassification productClassification) {
            this.productClassification = productClassification;
        }

        public String getIdentifier() {
            return identifier;
        }

        public void setIdentifier(String identifier) {
            this.identifier = identifier;
        }

        public Boolean getIsArchived() {
            return isArchived;
        }

        public void setIsArchived(Boolean isArchived) {
            this.isArchived = isArchived;
        }

        public List<SupportedPaymentMethod> getSupportedPaymentMethods() {
            return supportedPaymentMethods;
        }

        public void setSupportedPaymentMethods(List<SupportedPaymentMethod> supportedPaymentMethods) {
            this.supportedPaymentMethods = supportedPaymentMethods;
        }

        public List<Tax> getTaxes() {
            return taxes;
        }

        public void setTaxes(List<Tax> taxes) {
            this.taxes = taxes;
        }

        public Object getRevenueShare() {
            return revenueShare;
        }

        public void setRevenueShare(Object revenueShare) {
            this.revenueShare = revenueShare;
        }

        public String getCreatedOn() {
            return createdOn;
        }

        public void setCreatedOn(String createdOn) {
            this.createdOn = createdOn;
        }

        public List<String> getPackageCategory() {
            return packageCategory;
        }

        public void setPackageCategory(List<String> packageCategory) {
            this.packageCategory = packageCategory;
        }

        public List<ExternalApplicationDetail> getExternalApplicationDetails() {
            return externalApplicationDetails;
        }

        public void setExternalApplicationDetails(List<ExternalApplicationDetail> externalApplicationDetails) {
            this.externalApplicationDetails = externalApplicationDetails;
        }

        public Double getPrice() {
            return price;
        }

        public void setPrice(Double price) {
            this.price = price;
        }

        public Double getExpiryInMths() {
            return expiryInMths;
        }

        public void setExpiryInMths(Double expiryInMths) {
            this.expiryInMths = expiryInMths;
        }

        public String getCurrencyCode() {
            return currencyCode;
        }

        public void setCurrencyCode(String currencyCode) {
            this.currencyCode = currencyCode;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Object getDesc() {
            return desc;
        }

        public void setDesc(Object desc) {
            this.desc = desc;
        }

        public Double getType() {
            return type;
        }

        public void setType(Double type) {
            this.type = type;
        }

        public List<String> getValidCountry() {
            return validCountry;
        }

        public void setValidCountry(List<String> validCountry) {
            this.validCountry = validCountry;
        }

        public Object getValidCity() {
            return validCity;
        }

        public void setValidCity(Object validCity) {
            this.validCity = validCity;
        }

        public Double getPriority() {
            return priority;
        }

        public void setPriority(Double priority) {
            this.priority = priority;
        }

        public Double getValidityInMths() {
            return validityInMths;
        }

        public void setValidityInMths(Double validityInMths) {
            this.validityInMths = validityInMths;
        }

        public Object getScreenshots() {
            return screenshots;
        }

        public void setScreenshots(Object screenshots) {
            this.screenshots = screenshots;
        }

        public String getPrimaryImageUri() {
            return primaryImageUri;
        }

        public void setPrimaryImageUri(String primaryImageUri) {
            this.primaryImageUri = primaryImageUri;
        }

        public MaxDiscount getMaxDiscount() {
            return maxDiscount;
        }

        public void setMaxDiscount(MaxDiscount maxDiscount) {
            this.maxDiscount = maxDiscount;
        }

        public Object getRenewalChannelId() {
            return renewalChannelId;
        }

        public void setRenewalChannelId(Object renewalChannelId) {
            this.renewalChannelId = renewalChannelId;
        }

        public Object getUpSellChannelId() {
            return upSellChannelId;
        }

        public void setUpSellChannelId(Object upSellChannelId) {
            this.upSellChannelId = upSellChannelId;
        }

        public Object getSupportChannelId() {
            return supportChannelId;
        }

        public void setSupportChannelId(Object supportChannelId) {
            this.supportChannelId = supportChannelId;
        }

        public Object getNetAmount() {
            return netAmount;
        }

        public void setNetAmount(Object netAmount) {
            this.netAmount = netAmount;
        }

        public Double getPackageVisibilityType() {
            return packageVisibilityType;
        }

        public void setPackageVisibilityType(Double packageVisibilityType) {
            this.packageVisibilityType = packageVisibilityType;
        }

        public List<WidgetPack> getWidgetPacks() {
            return widgetPacks;
        }

        public void setWidgetPacks(List<WidgetPack> widgetPacks) {
            this.widgetPacks = widgetPacks;
        }

    }


    public class WidgetPack {

        @SerializedName("Name")
        @Expose
        private String name;
        @SerializedName("Desc")
        @Expose
        private String desc;
        @SerializedName("WidgetKey")
        @Expose
        private String widgetKey;
        @SerializedName("Group")
        @Expose
        private String group;
        @SerializedName("Priority")
        @Expose
        private Double priority;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public String getWidgetKey() {
            return widgetKey;
        }

        public void setWidgetKey(String widgetKey) {
            this.widgetKey = widgetKey;
        }

        public String getGroup() {
            return group;
        }

        public void setGroup(String group) {
            this.group = group;
        }

        public Double getPriority() {
            return priority;
        }

        public void setPriority(Double priority) {
            this.priority = priority;
        }

    }

    public class Tax {

        @SerializedName("Value")
        @Expose
        private Double value;
        @SerializedName("Key")
        @Expose
        private String key;
        @SerializedName("AmountType")
        @Expose
        private Double amountType;

        public Double getValue() {
            return value;
        }

        public void setValue(Double value) {
            this.value = value;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public Double getAmountType() {
            return amountType;
        }

        public void setAmountType(Double amountType) {
            this.amountType = amountType;
        }

        public class SupportedPaymentMethod {

            @SerializedName("PaymentSource")
            @Expose
            private String paymentSource;
            @SerializedName("Type")
            @Expose
            private Double type;
            @SerializedName("TargetPaymentUri")
            @Expose
            private Object targetPaymentUri;
            @SerializedName("Key")
            @Expose
            private String key;
            @SerializedName("Secret")
            @Expose
            private String secret;
            @SerializedName("RedirectUri")
            @Expose
            private String redirectUri;
            @SerializedName("WebHookUri")
            @Expose
            private String webHookUri;
            @SerializedName("PaddleCoupon")
            @Expose
            private Object paddleCoupon;

            public String getPaymentSource() {
                return paymentSource;
            }

            public void setPaymentSource(String paymentSource) {
                this.paymentSource = paymentSource;
            }

            public Double getType() {
                return type;
            }

            public void setType(Double type) {
                this.type = type;
            }

            public Object getTargetPaymentUri() {
                return targetPaymentUri;
            }

            public void setTargetPaymentUri(Object targetPaymentUri) {
                this.targetPaymentUri = targetPaymentUri;
            }

            public String getKey() {
                return key;
            }

            public void setKey(String key) {
                this.key = key;
            }

            public String getSecret() {
                return secret;
            }

            public void setSecret(String secret) {
                this.secret = secret;
            }

            public String getRedirectUri() {
                return redirectUri;
            }

            public void setRedirectUri(String redirectUri) {
                this.redirectUri = redirectUri;
            }

            public String getWebHookUri() {
                return webHookUri;
            }

            public void setWebHookUri(String webHookUri) {
                this.webHookUri = webHookUri;
            }

            public Object getPaddleCoupon() {
                return paddleCoupon;
            }

            public void setPaddleCoupon(Object paddleCoupon) {
                this.paddleCoupon = paddleCoupon;
            }

        }


    }


    public class MaxDiscount {

        @SerializedName("discountType")
        @Expose
        private Double discountType;
        @SerializedName("value")
        @Expose
        private Double value;

        public Double getDiscountType() {
            return discountType;
        }

        public void setDiscountType(Double discountType) {
            this.discountType = discountType;
        }

        public Double getValue() {
            return value;
        }

        public void setValue(Double value) {
            this.value = value;
        }

    }


    public class ProductClassification {

        @SerializedName("packType")
        @Expose
        private Double packType;
        @SerializedName("productLine")
        @Expose
        private List<Double> productLine = null;

        public Double getPackType() {
            return packType;
        }

        public void setPackType(Double packType) {
            this.packType = packType;
        }

        public List<Double> getProductLine() {
            return productLine;
        }

        public void setProductLine(List<Double> productLine) {
            this.productLine = productLine;
        }

    }



    public class SupportedPaymentMethod {

        @SerializedName("PaymentSource")
        @Expose
        private String paymentSource;
        @SerializedName("Type")
        @Expose
        private Double type;
        @SerializedName("TargetPaymentUri")
        @Expose
        private Object targetPaymentUri;
        @SerializedName("Key")
        @Expose
        private String key;
        @SerializedName("Secret")
        @Expose
        private String secret;
        @SerializedName("RedirectUri")
        @Expose
        private String redirectUri;
        @SerializedName("WebHookUri")
        @Expose
        private String webHookUri;
        @SerializedName("PaddleCoupon")
        @Expose
        private Object paddleCoupon;

        public String getPaymentSource() {
            return paymentSource;
        }

        public void setPaymentSource(String paymentSource) {
            this.paymentSource = paymentSource;
        }

        public Double getType() {
            return type;
        }

        public void setType(Double type) {
            this.type = type;
        }

        public Object getTargetPaymentUri() {
            return targetPaymentUri;
        }

        public void setTargetPaymentUri(Object targetPaymentUri) {
            this.targetPaymentUri = targetPaymentUri;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getSecret() {
            return secret;
        }

        public void setSecret(String secret) {
            this.secret = secret;
        }

        public String getRedirectUri() {
            return redirectUri;
        }

        public void setRedirectUri(String redirectUri) {
            this.redirectUri = redirectUri;
        }

        public String getWebHookUri() {
            return webHookUri;
        }

        public void setWebHookUri(String webHookUri) {
            this.webHookUri = webHookUri;
        }

        public Object getPaddleCoupon() {
            return paddleCoupon;
        }

        public void setPaddleCoupon(Object paddleCoupon) {
            this.paddleCoupon = paddleCoupon;
        }

    }

    public class ExternalApplicationDetail {

        @SerializedName("Type")
        @Expose
        private Double type;
        @SerializedName("ExternalSourceId")
        @Expose
        private String externalSourceId;

        public Double getType() {
            return type;
        }

        public void setType(Double type) {
            this.type = type;
        }

        public String getExternalSourceId() {
            return externalSourceId;
        }

        public void setExternalSourceId(String externalSourceId) {
            this.externalSourceId = externalSourceId;
        }

    }


}