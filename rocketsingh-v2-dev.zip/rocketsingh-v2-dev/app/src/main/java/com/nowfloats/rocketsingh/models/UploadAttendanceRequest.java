package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class UploadAttendanceRequest     {

    @SerializedName("method")
    @Expose
    private String method;
    @SerializedName("jsonrpc")
    @Expose
    private String jsonrpc;
    @SerializedName("params")
    @Expose
    private Params params;

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public String getJsonrpc() {
        return jsonrpc;
    }

    public void setJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
    }

    public Params getParams() {
        return params;
    }

    public void setParams(Params params) {
        this.params = params;
    }

    public static class Params {

        @SerializedName("service")
        @Expose
        private String service;
        @SerializedName("method")
        @Expose
        private String method;
        @SerializedName("args")
        @Expose
        private List<Object> args = null;

        public String getService() {
            return service;
        }

        public void setService(String service) {
            this.service = service;
        }

        public String getMethod() {
            return method;
        }

        public void setMethod(String method) {
            this.method = method;
        }

        public List<Object> getArgs() {
            return args;
        }

        public void setArgs(List<Object> args) {
            this.args = args;
        }

    }

    public static class RequestObject {

        @SerializedName("swipeNW")
        @Expose
        private boolean swipeNW;

        @SerializedName("emailId")
        @Expose
        private String emailId;
        @SerializedName("inOut")
        @Expose
        private Integer inOut;
        @SerializedName("latitude")
        @Expose
        private double latitude;
        @SerializedName("longitude")
        @Expose
        private double longitude;

        public String getEmailId() {
            return emailId;
        }

        public void setEmailId(String emailId) {
            this.emailId = emailId;
        }

        public Integer getInOut() {
            return inOut;
        }

        public void setInOut(Integer inOut) {
            this.inOut = inOut;
        }

        public double getLatitude() {
            return latitude;
        }

        public void setLatitude(double latitude) {
            this.latitude = latitude;
        }

        public double getLongitude() {
            return longitude;
        }

        public void setLongitude(double longitude) {
            this.longitude = longitude;
        }

        public boolean isSwipeNW() {
            return swipeNW;
        }

        public void setSwipeNW(boolean swipeNW) {
            this.swipeNW = swipeNW;
        }
    }

}