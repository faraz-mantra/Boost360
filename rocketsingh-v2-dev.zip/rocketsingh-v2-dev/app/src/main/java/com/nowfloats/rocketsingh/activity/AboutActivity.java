package com.nowfloats.rocketsingh.activity;

/**
 * Created by NowFloats on 27-11-2017.
 */

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.nowfloats.rocketsingh.R;
import com.vansuita.materialabout.builder.AboutBuilder;
import com.vansuita.materialabout.views.AboutView;

public class AboutActivity extends AppCompatActivity {
    FrameLayout flHolder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_about);
        flHolder = findViewById(R.id.about);
        AboutView view = AboutBuilder.with(this)
                .setPhoto(R.mipmap.profile_picture)
                .setCover(R.drawable.cover)
                .setName("Conversation based sales force assistant")
                .setSubTitle("powered by ANA")
                .setBrief(
                        "helps you do your job faster, while guiding you at every step of the way through a chat bot.\n" +
                        " daily report of your performance via persistent notifications.\n" +
                        "\n" +
                        "know how well your customers are performing with ROI snapshots\n" +
                        "\n" +
                        "Setup and reschedule meetings on the go, just by chatting.\n" +
                        "\n" +
                        "Stop going through the troubles of logging in to manage, by just using Rocket Singh to log your sales.\n" +
                        "\n" +
                        "Ever feeling clueless about a process? Just use Shiksha in Rocket Singh to learn about everything.\n" +
                        "\n" +
                        "You can help your customers by raising their tickets yourself.\n" +
                        "\n" +
                        "Check your ticket status via Rocket Singh. \n ")
                .setAppIcon(R.drawable.app_logo)
                .setAppName(R.string.app_name)
                .setVersionNameAsAppSubTitle()
                .setWrapScrollView(true)
                .setLinksAnimated(true)
                .setShowAsCard(true)
                .build();

        flHolder.addView(view);
    }
}
