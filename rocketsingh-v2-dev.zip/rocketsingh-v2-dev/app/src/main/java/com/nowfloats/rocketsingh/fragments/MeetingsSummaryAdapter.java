package com.nowfloats.rocketsingh.fragments;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.utils.MeetingSummaryUtils;


import java.util.List;

public class MeetingsSummaryAdapter extends RecyclerView.Adapter <MeetingsSummaryAdapter.MeetingSummaryViiewHolder>{

    private List<Object> fpTags;
    private MeetingSummaryUtils.MeetingSummaryInterface meetingSummaryInterface;
    public MeetingsSummaryAdapter(List<Object> fpTags , MeetingSummaryUtils.MeetingSummaryInterface meetingSummaryInterface) {
        this.meetingSummaryInterface = meetingSummaryInterface;
        setData(fpTags);
    }

    public void setData(List<Object> fpTags) {
        this.fpTags = fpTags;
        if(fpTags.size() > 0) {
            meetingSummaryInterface.onEmptyMeetingsData(false);
            meetingSummaryInterface.setRecyclerViewAdapter();
            notifyDataSetChanged();
        }else{
            meetingSummaryInterface.onEmptyMeetingsData(true);
        }

    }

    @NonNull
    @Override
    public MeetingSummaryViiewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.meeting_summary_row , parent,false);
        return new MeetingSummaryViiewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MeetingSummaryViiewHolder holder, int position) {
        holder.tv_count.setText((holder.getAdapterPosition()+1)+"");
        holder.tv_fptag.setText(fpTags.get(holder.getAdapterPosition()).toString());
    }

    @Override
    public int getItemCount() {
        return fpTags.size();
    }

    protected class MeetingSummaryViiewHolder extends RecyclerView.ViewHolder{

        TextView tv_fptag , tv_count;

        public MeetingSummaryViiewHolder(View itemView) {
            super(itemView);
            tv_fptag = itemView.findViewById(R.id.tv_Fptag);
            tv_count = itemView.findViewById(R.id.tv_count);
        }

    }
}
