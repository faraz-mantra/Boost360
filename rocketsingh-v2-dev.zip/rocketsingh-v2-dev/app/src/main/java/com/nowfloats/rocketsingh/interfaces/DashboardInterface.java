package com.nowfloats.rocketsingh.interfaces;

import com.nowfloats.rocketsingh.models.GetCFPerformaceStatus;
import com.nowfloats.rocketsingh.models.GetPerformaceStatusFOS;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;

public interface DashboardInterface {

    @GET("/api/Dashboard/GetMeetingsStatsForCf")
    void getMeetingsStatsForCf(@Query("salesId") String salesId , Callback<GetCFPerformaceStatus> getCFPerformaceStatusCallback);

    @GET("/api/Dashboard/GetMeetingsStatsForFOS")
    void getMeetingsStatsForFOS(@Query("salesId") String salesId , Callback<GetPerformaceStatusFOS> getPerformaceStatusFOSCallback);

}
