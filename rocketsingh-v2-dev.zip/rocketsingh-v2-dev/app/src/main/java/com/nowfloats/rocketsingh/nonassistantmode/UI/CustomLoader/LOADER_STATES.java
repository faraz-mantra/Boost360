package com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader;

public enum LOADER_STATES {
    LOADING,
    SUCCESS ,
    FAIL
}
