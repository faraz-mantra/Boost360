package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by NowFloats on 22-Mar-18.
 */

public class QuesResponse {

    @SerializedName("_id")
    @Expose
    private String id;
    @SerializedName("Name")
    @Expose
    private String name;
    @SerializedName("Description")
    @Expose
    private String description;
    @SerializedName("MeetingType")
    @Expose
    private String meetingType;
    @SerializedName("EngagementDay")
    @Expose
    private Integer engagementDay;
    @SerializedName("Items")
    @Expose
    private List<Item> items = null;
    @SerializedName("CreatedOn")
    @Expose
    private String createdOn;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMeetingType() {
        return meetingType;
    }

    public void setMeetingType(String meetingType) {
        this.meetingType = meetingType;
    }

    public Integer getEngagementDay() {
        return engagementDay;
    }

    public void setEngagementDay(Integer engagementDay) {
        this.engagementDay = engagementDay;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public class Item {

        @SerializedName("DisplayText")
        @Expose
        private String displayText;
        @SerializedName("IdTag")
        @Expose
        private String idTag;
        @SerializedName("res")
        @Expose
        private String res;

        public String getDisplayText() {
            return displayText;
        }

        public void setDisplayText(String displayText) {
            this.displayText = displayText;
        }

        public String getIdTag() {
            return idTag;
        }

        public void setIdTag(String idTag) {
            this.idTag = idTag;
        }

        public String getRes() {
            return res;
        }

        public void setRes(String res) {
            this.res = res;
        }

    }

}
