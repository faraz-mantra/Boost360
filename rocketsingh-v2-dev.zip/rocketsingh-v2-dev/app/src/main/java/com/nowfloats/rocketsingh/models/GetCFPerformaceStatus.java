package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetCFPerformaceStatus {

    @SerializedName("meetingStatisticsCFResponse")
    @Expose
    private MeetingStatisticsCFResponse meetingStatisticsCFResponse;
    @SerializedName("totalTickets")
    @Expose
    private Integer totalTickets;

    private String totalRevenue;

    public MeetingStatisticsCFResponse getMeetingStatisticsCFResponse() {
        return meetingStatisticsCFResponse;
    }


    public Integer getTotalTickets() {
        return totalTickets;
    }

    public void setTotalTickets(Integer totalTickets) {
        this.totalTickets = totalTickets;
    }

    public String getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(String totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public class MeetingStatisticsCFResponse {

        @SerializedName("meetingsLogged")
        @Expose
        private Integer meetingsLogged;
        @SerializedName("meetingsPending")
        @Expose
        private Integer meetingsPending;

        public Integer getMeetingsLogged() {
            return meetingsLogged;
        }

        public void setMeetingsLogged(Integer meetingsLogged) {
            this.meetingsLogged = meetingsLogged;
        }

        public Integer getMeetingsPending() {
            return meetingsPending;
        }

        public void setMeetingsPending(Integer meetingsPending) {
            this.meetingsPending = meetingsPending;
        }

    }

}
