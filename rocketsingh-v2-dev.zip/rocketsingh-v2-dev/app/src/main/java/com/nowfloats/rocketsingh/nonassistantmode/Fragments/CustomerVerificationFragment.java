package com.nowfloats.rocketsingh.nonassistantmode.Fragments;

import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.NetworkResultInterface;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomEditText;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader.CustomLoaderDialog;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.FLOW_SESSIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NetworkHandler;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.tfb.fbtoast.FBToast;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;

import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.INITIATE_MISSED_CALL_VERFICATION;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.SEND_OTP_REQUEST;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.VERIFY_MISSED_CALL_REQUEST;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.VERIFY_OTP_REQUEST;

public class CustomerVerificationFragment extends DialogFragment implements NetworkResultInterface {

    private CustomLoaderDialog customLoaderDialog;
    private NetworkHandler networkHandler;
    private String phoneNumber = "7077855182";
    private EditText et_otp;
    String transactionId = "";
    private boolean missedCallStarted = false;
    private CustomEditText et_phoneNumber;
    private LinearLayout ll_otpVerification;
    private CustomerverficationInterface customerverficationInterface;
    private Button bt_sendOtp , bt_verifyOtp , bt_missedCall;

    public static CustomerVerificationFragment getInstance(CustomerverficationInterface customerverficationInterface)
    {
        CustomerVerificationFragment customerVerificationFragment = new CustomerVerificationFragment();
        customerVerificationFragment.customerverficationInterface = customerverficationInterface;
        return customerVerificationFragment;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_customer_verification , container , false);
        ll_otpVerification = v.findViewById(R.id.ll_otpVerification);
        bt_sendOtp = v.findViewById(R.id.bt_sendOtp);
        bt_verifyOtp = v.findViewById(R.id.bt_verifyOtp);
        et_phoneNumber = v.findViewById(R.id.et_phoneNumber);
        bt_missedCall = v.findViewById(R.id.bt_missedCall);
        et_otp = v.findViewById(R.id.et_otp);
        allTheOnClickListener();
        return v;
    }

    private void allTheOnClickListener(){
        bt_sendOtp.setOnClickListener(view -> {
            phoneNumber = et_phoneNumber.getText().toString();
            if(ExternalProcessManager.stringIsNull(phoneNumber) && ! et_phoneNumber.inputIsValid)
                showSnackbarMessage("Phone number is invalid" , false);
            else
                startNetworkOperation(FLOW_SESSIONS.CUSTOMER_VERIFICATION.SEND_OTP);
        });

        bt_verifyOtp.setOnClickListener(view -> {
            if(ExternalProcessManager.stringIsNull(et_otp.getText().toString()))
                showSnackbarMessage("Please enter a OTP first" , false);
            else
                startNetworkOperation(FLOW_SESSIONS.CUSTOMER_VERIFICATION.VERIFY_OTP);
        });

        bt_missedCall.setOnClickListener(view -> {
            phoneNumber = et_phoneNumber.getText().toString();
            if(ExternalProcessManager.stringIsNull(phoneNumber) && !et_phoneNumber.inputIsValid) {
                showSnackbarMessage("Phone number is invalid", false);
                return;
            }

            if(! missedCallStarted) {
                startNetworkOperation(FLOW_SESSIONS.CUSTOMER_VERIFICATION.REQUEST_MISSED_CALL);

            }else
                startNetworkOperation(FLOW_SESSIONS.CUSTOMER_VERIFICATION.CHECK_MISSED_CALL);
        });
    }

    private void startNetworkOperation(short session ){
        Queue<NETWORK_OPERATIONS> networkOperations = new LinkedList<>();
        switch (session) {
            case FLOW_SESSIONS.CUSTOMER_VERIFICATION.CHECK_MISSED_CALL:
                networkOperations.add(NETWORK_OPERATIONS.VERIFY_MISSED_CALL_REQUEST);
                break;
             case FLOW_SESSIONS.CUSTOMER_VERIFICATION.REQUEST_MISSED_CALL:
                 networkOperations.add(INITIATE_MISSED_CALL_VERFICATION);
                 break;
            case FLOW_SESSIONS.CUSTOMER_VERIFICATION.SEND_OTP:
                 networkOperations.add(SEND_OTP_REQUEST);
                 break;
            case FLOW_SESSIONS.CUSTOMER_VERIFICATION.VERIFY_OTP:
                 networkOperations.add(VERIFY_OTP_REQUEST);
                  break;

        }

        networkHandler = new NetworkHandler(getContext() , this)
                .setOrUpdateSession(session)
                .setNetworkOperationQueue(networkOperations)
                .startThread();
    }

    @Override
    public void onApiRequestStarted(NETWORK_OPERATIONS network_operations) {
        initiateApiState(network_operations);
    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, String message) {
        updateApiStateInFpFragment(operationKey , message , true);
        switch (operationKey) {
            case SEND_OTP_REQUEST:
                ll_otpVerification.setVisibility(View.VISIBLE);
                break;
        }
        networkHandler.executeNext();
    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, Object model, String message) {
        updateApiStateInFpFragment(operationKey , message , true);

        switch (operationKey) {
            case INITIATE_MISSED_CALL_VERFICATION:
                showLongToast(getString(R.string.customer_verfication_request));
                missedCallStarted = true;
                transactionId = model.toString();
                bt_missedCall.setText(getString(R.string.click_here_after_giving_a_missed_call));
                break;
        }

        networkHandler.executeNext();
    }

    @Override
    public void onApiFail(NETWORK_OPERATIONS operationKey, String errorMessage) {
        updateApiStateInFpFragment(operationKey , errorMessage , false);
        if(operationKey == VERIFY_MISSED_CALL_REQUEST)
            showLongToast(getString(R.string.customer_verfication_request));
    }

    @Override
    public void networkOperationsFinished(boolean success, short session) {
        if(session == FLOW_SESSIONS.CUSTOMER_VERIFICATION.CHECK_MISSED_CALL
                || session == FLOW_SESSIONS.CUSTOMER_VERIFICATION.VERIFY_OTP) {
            if(getDialog() != null ) {
                new Handler().postDelayed(() -> getDialog().dismiss() , 2500);
            }
            finishApiProcessAnimation("Customer verified succesfully");
            customerverficationInterface.onCustomerVerified(et_phoneNumber.getText().toString());
        }
        else
            hideDialog(true);
    }

    @Override
    public void prepareRequestBody(NETWORK_OPERATIONS network_operations, NetworkHandler networkHandler) {
        Pair<NETWORK_OPERATIONS , Object> pair = null;
        switch (network_operations) {
            case SEND_OTP_REQUEST:
                pair = new Pair<>(network_operations , phoneNumber);
                break;

            case VERIFY_OTP_REQUEST:
                HashMap userData = new HashMap();
                userData.put("mobileNumber" , phoneNumber);
                userData.put("otp" , et_otp.getText().toString());
                userData.put("clientId" , Constants.FOSClientId);
                pair = new Pair<>(network_operations , userData);
                break;

            case INITIATE_MISSED_CALL_VERFICATION:
                userData = new HashMap();
                userData.put("ClientId" , Constants.FOSClientId);
                userData.put("PhoneNumber" , phoneNumber);
                pair = new Pair<>(network_operations , userData);
                break;
            case VERIFY_MISSED_CALL_REQUEST:
                userData = new HashMap();
                userData.put("ClientId" , Constants.FOSClientId);
                userData.put("RequestId" , transactionId);
                pair = new Pair<>(network_operations , userData);
                break;
        }

        networkHandler.updateRequestBody(network_operations , pair != null ? pair.second : null);
    }

    private void initiateApiState(NETWORK_OPERATIONS network_operations) {
        if(dialogIsValid()) {
            customLoaderDialog.initiateApiState(network_operations);
            return;
        }else {
            showDialog();
            new Handler().postDelayed(() -> {customLoaderDialog.initiateApiState(network_operations);} , 0);
        }

    }


    public boolean dialogIsValid(){
        return customLoaderDialog != null  && customLoaderDialog.isVisible();
    }

    private void showDialog() {
        if (customLoaderDialog == null) {
            customLoaderDialog = new CustomLoaderDialog();
        }

        if(customLoaderDialog.isVisible())
            return;
        // Create and show the dialog.
        customLoaderDialog = CustomLoaderDialog.newInstance();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.executePendingTransactions();
        customLoaderDialog.show(fragmentManager.beginTransaction(), "dialog");
    }


    public void updateApiStateInFpFragment(NETWORK_OPERATIONS network_operations , String message , boolean success) {
        if (success) {
            updateApiForSuccess(network_operations, message);

        } else {
            updateApiForFailure(network_operations, message);
        }
    }

    private void hideDialog(boolean delay){
        // delay is just for the effect

        if(customLoaderDialog == null )
            return;
        if(! customLoaderDialog.isVisible())
            return;

        new Handler().postDelayed(() -> {customLoaderDialog.closeDialog();} , delay ? 2500: 0);


    }

    private void updateApiForSuccess(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForSuccess(network_operations , message);
        }
    }

    public void finishApiProcessAnimation(String message){
        if(customLoaderDialog != null ){
            if(customLoaderDialog.isVisible()) {
                customLoaderDialog.showSuccessfulDialog(message);
            }
            hideDialog(true);
        }
    }

    private void updateApiForFailure(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForFailure(network_operations, message);
            hideDialog(true);
        }
    }

    private void showSnackbarMessage(String message , boolean success){
        if(success)
            FBToast.successToast(getContext() , message , FBToast.LENGTH_LONG);
        else
            FBToast.errorToast(getContext() , message , FBToast.LENGTH_SHORT);
    }

    private void showLongToast(String message) {
        FBToast.infoToast(getContext() , message , 10000);
    }

    public interface CustomerverficationInterface{
        void onCustomerVerified(String number);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null)
        {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
        }

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getDialog() != null) {
            getDialog().setCancelable(false);
            getDialog().getWindow()
                    .getAttributes().windowAnimations = R.style.DialogAnimation;
        }
    }
}
