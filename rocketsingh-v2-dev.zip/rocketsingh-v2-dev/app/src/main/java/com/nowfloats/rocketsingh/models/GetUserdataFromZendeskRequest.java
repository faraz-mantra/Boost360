package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetUserdataFromZendeskRequest {

    @SerializedName("salesId")
    @Expose
    private String salesId;

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public GetUserdataFromZendeskRequest withSalesId(String salesId) {
        this.salesId = salesId;
        return this;
    }

}