package com.nowfloats.rocketsingh.fragments;

import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.text.Html;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.QuesResponse;
import com.nowfloats.rocketsingh.utils.ListenersManager;

import java.util.List;

/**
 * Created by NowFloats on 28-Dec-17.
 */

public class CustomDialogQuestionsFragment extends DialogFragment {

    private ImageView ivNext, ivPrev, ivMandatory;
    private Button btnSubmit;
    private RadioGroup rgRes;
    private TextView tvQues;
    private EditText etRes;
    private Context mContext;
    int anim, enter, exit;
    List<String> deepLinkValues;
    QuesResponse.Item b;
    List<QuesResponse.Item> itemQuestion;

    public CustomDialogQuestionsFragment() {
        // Empty constructor is required for DialogFragment
        // Make sure not to add arguments to the constructor
        // Use `newInstance` instead as shown below
    }

    public static CustomDialogQuestionsFragment newInstance(QuesResponse.Item b, List<QuesResponse.Item> itemQuestion, Context context, int anim, int enter, int exit, List<String> deepLinkValues) {
        CustomDialogQuestionsFragment frag = new CustomDialogQuestionsFragment();
        frag.setQuesData(b);
        frag.setQuesDataList(itemQuestion, deepLinkValues);
        frag.setContext(context);
        frag.setAnimation(anim, enter, exit);
        return frag;
    }

    public void setQuesData(QuesResponse.Item b) {
        this.b = b;
    }

    public void setQuesDataList(List<QuesResponse.Item> itemQuestion, List<String> deepLinkValues) {
        this.itemQuestion = itemQuestion;
        this.deepLinkValues = deepLinkValues;
    }

    public void setContext(Context context) {
        mContext = context;
    }

    public void setAnimation(int animation, int enter, int exit) {
        this.anim = animation;
        this.enter = enter;
        this.exit = exit;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_show_question, container);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getDialog().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setCancelable(true);
        getDialog().getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        getDialog().getWindow().getAttributes().windowAnimations = anim;
        btnSubmit = view.findViewById(R.id.btn_submit);
        ivNext = view.findViewById(R.id.iv_next);
        ivPrev = view.findViewById(R.id.iv_prev);
        tvQues = view.findViewById(R.id.tv_ques);
        rgRes = view.findViewById(R.id.rg_res);
        etRes = view.findViewById(R.id.et_res);
        ivMandatory = view.findViewById(R.id.iv_mandatory);
        final int index = itemQuestion.indexOf(b);
        int lastIndex = itemQuestion.size() - 1;
        tvQues.setText(index+1 + ". " + b.getDisplayText());
        if(index == 0) {
            ivPrev.setVisibility(View.INVISIBLE);
            ivPrev.setClickable(false);
            btnSubmit.setVisibility(View.GONE);
        }
        else if(index == lastIndex) {
            ivPrev.setVisibility(View.VISIBLE);
            ivPrev.setClickable(true);
            btnSubmit.setVisibility(View.VISIBLE);
        }
        else {
            ivPrev.setVisibility(View.VISIBLE);
            ivPrev.setClickable(true);
            btnSubmit.setVisibility(View.GONE);
        }
        if(b.getIdTag().equals("MEETING_REMARKS")) {
            rgRes.setVisibility(View.GONE);
            etRes.setVisibility(View.VISIBLE);
            etRes.setHint("Minimum 140 characters required!");
            String text = "<font color=#000000>" + tvQues.getText().toString() + "</font> <font color=#FF0000>*</font>";
            tvQues.setText(Html.fromHtml(text));
            if(!TextUtils.isEmpty(b.getRes()))
                etRes.setText(b.getRes());
            else
                etRes.setText("");
            if(index == lastIndex) {
                btnSubmit.setVisibility(View.VISIBLE);
                ivNext.setVisibility(View.INVISIBLE);
                ivNext.setClickable(false);
            }
            else {
                ivNext.setVisibility(View.VISIBLE);
                ivNext.setClickable(true);
                btnSubmit.setVisibility(View.GONE);
            }

        }
        else if(!b.getIdTag().equals("CUSTOMER_NEEDS_LOAN")&&!b.getIdTag().equals("CUSTOMER_DAILY_FOOTFALL")&&!b.getIdTag().equals("CUSTOMER_BUISNESS_SERVICE_PRICE")&&!b.getIdTag().equals("CUSTOMER_ANNUAL_TURNOVER")&&!b.getIdTag().equals("GET_ANY_LEADS")) {
            rgRes.setVisibility(View.VISIBLE);
            etRes.setVisibility(View.GONE);
            String text = "<font color=#000000>" + tvQues.getText().toString() + "</font> <font color=#FF0000>*</font>";
            tvQues.setText(Html.fromHtml(text));
            if(!TextUtils.isEmpty(b.getRes())) {
                if(b.getRes().equals("Yes"))
                    rgRes.check(R.id.rb_yes);
                else if(b.getRes().equals("No"))
                    rgRes.check(R.id.rb_no);
                ivNext.setVisibility(View.VISIBLE);
                ivNext.setClickable(true);
            }
            else
                rgRes.clearCheck();
            rgRes.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    if (checkedId == R.id.rb_yes) {
                        b.setRes("Yes");
                    } else if (checkedId == R.id.rb_no) {
                        b.setRes("No");
                    }
                    ivNext.setVisibility(View.VISIBLE);
                    ivNext.setClickable(true);
                }
            });
        }
        else {
            rgRes.setVisibility(View.GONE);
            etRes.setVisibility(View.VISIBLE);
            ivMandatory.setVisibility(View.GONE);
            ivNext.setVisibility(View.VISIBLE);
            ivNext.setClickable(true);
            if(!TextUtils.isEmpty(b.getRes()))
                etRes.setText(b.getRes());
            else
                etRes.setText("");
        }
        ivNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*getDialog().getWindow().setWindowAnimations(R.style.CustomDialogNextTheme);*/
                if(b.getIdTag().equals("MEETING_REMARKS")) {
                    b.setRes(etRes.getText().toString());
                    if(b.getRes().length()<140)
                        Toast.makeText(mContext,"Remarks must have minimum of 140 characters!", Toast.LENGTH_SHORT).show();
                    else {
                        dismiss();
                        ListenersManager.getInstance().callQuestionFragmentDialogAction(index+1, 1, deepLinkValues, mContext);
                    }
                }
                else if(!b.getIdTag().equals("CUSTOMER_NEEDS_LOAN")&&!b.getIdTag().equals("CUSTOMER_DAILY_FOOTFALL")&&!b.getIdTag().equals("CUSTOMER_BUISNESS_SERVICE_PRICE")&&!b.getIdTag().equals("CUSTOMER_ANNUAL_TURNOVER")&&!b.getIdTag().equals("GET_ANY_LEADS")) {
                    dismiss();
                    ListenersManager.getInstance().callQuestionFragmentDialogAction(index+1, 1, deepLinkValues, mContext);
                }
                else {
                    b.setRes(etRes.getText().toString());
                    dismiss();
                    ListenersManager.getInstance().callQuestionFragmentDialogAction(index+1, 1, deepLinkValues, mContext);
                }
            }
        });

        ivPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*getDialog().getWindow().setWindowAnimations(R.style.CustomDialogPrevTheme);*/
                if(b.getIdTag().equals("MEETING_REMARKS")) {
                    b.setRes(etRes.getText().toString());
                    dismiss();
                    /*if(b.getRes().length()<140)
                        Toast.makeText(ChatViewActivity.this,"Remarks must have minimum of 140 characters!",Toast.LENGTH_SHORT).show();
                    else {
                        mCustomDialog.dismiss();
                    }*/
                }
                else if(!b.getIdTag().equals("CUSTOMER_NEEDS_LOAN")&&!b.getIdTag().equals("CUSTOMER_DAILY_FOOTFALL")&&!b.getIdTag().equals("CUSTOMER_BUISNESS_SERVICE_PRICE")&&!b.getIdTag().equals("CUSTOMER_ANNUAL_TURNOVER")&&!b.getIdTag().equals("GET_ANY_LEADS")) {
                    dismiss();
                }
                else {
                    b.setRes(etRes.getText().toString());
                    dismiss();
                }
                ListenersManager.getInstance().callQuestionFragmentDialogAction(index-1, 0, deepLinkValues, mContext);
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(b.getIdTag().equals("MEETING_REMARKS")) {
                    b.setRes(etRes.getText().toString());
                    if(b.getRes().length()<140)
                        Toast.makeText(mContext,"Remarks must have minimum of 140 characters!", Toast.LENGTH_SHORT).show();
                    else {
                        dismiss();
                        ListenersManager.getInstance().callQuestionFragmentDialogAction(index, 2, deepLinkValues, mContext);
                    }
                }
                else if(!b.getIdTag().equals("CUSTOMER_NEEDS_LOAN")&&!b.getIdTag().equals("CUSTOMER_DAILY_FOOTFALL")&&!b.getIdTag().equals("CUSTOMER_BUISNESS_SERVICE_PRICE")&&!b.getIdTag().equals("CUSTOMER_ANNUAL_TURNOVER")&&!b.getIdTag().equals("GET_ANY_LEADS")) {
                    dismiss();
                    ListenersManager.getInstance().callQuestionFragmentDialogAction(index, 2, deepLinkValues, mContext);
                }
                else {
                    b.setRes(etRes.getText().toString());
                    dismiss();
                    ListenersManager.getInstance().callQuestionFragmentDialogAction(index, 2, deepLinkValues, mContext);
                }
            }
        });

        getDialog().setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK
                        && event.getAction() == KeyEvent.ACTION_UP) {
                    // TODO do the "back pressed" work here
                    showDialog("Warning!", "All the progress will be lost. Do you want to proceed?");
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void onCancel(DialogInterface dialog) {
    }

    private void showDialog(String title, String msg){
        androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(mContext);
        builder.setTitle(title).setMessage(msg).setPositiveButton("Proceed", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                dismiss();
            }
        })
        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }


}
