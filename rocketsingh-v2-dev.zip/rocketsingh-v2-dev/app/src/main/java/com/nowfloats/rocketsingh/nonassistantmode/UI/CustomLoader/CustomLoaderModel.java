package com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader;

import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;

import java.util.EnumMap;

public class CustomLoaderModel {

   private LOADER_STATES loader_states;
   private EnumMap<LOADER_STATES , String> loader_statesStringEnumMap = new EnumMap<LOADER_STATES, String>(LOADER_STATES.class);
   private NETWORK_OPERATIONS network_operations;

    public LOADER_STATES getLoader_states() {
        return loader_states;
    }

    public CustomLoaderModel setLoader_states(LOADER_STATES loader_states) {
        this.loader_states = loader_states;
        return this;
    }


    public void setErrorMessage(String errorMessage) {
        loader_statesStringEnumMap.put(LOADER_STATES.FAIL , errorMessage);
    }


    public void setSuccessMessage(String successMessage) {
        loader_statesStringEnumMap.put(LOADER_STATES.SUCCESS , successMessage);
    }

    public EnumMap<LOADER_STATES, String> getLoader_statesStringEnumMap() {
        loader_statesStringEnumMap.put(LOADER_STATES.LOADING , "Please wait ...");
        return loader_statesStringEnumMap;
    }

    public NETWORK_OPERATIONS getNetwork_operations() {
        return network_operations;
    }

    public void setNetwork_operations(NETWORK_OPERATIONS network_operations) {
        this.network_operations = network_operations;
    }
}
