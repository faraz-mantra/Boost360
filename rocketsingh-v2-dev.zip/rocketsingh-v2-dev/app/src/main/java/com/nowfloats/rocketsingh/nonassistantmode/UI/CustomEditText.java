package com.nowfloats.rocketsingh.nonassistantmode.UI;

import android.animation.ValueAnimator;
import android.app.ActionBar;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.os.Build;
import android.text.InputType;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ViewAnimator;

import com.nowfloats.rocketsingh.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

public class CustomEditText extends androidx.appcompat.widget.AppCompatEditText{

    private final String TEXT_MODE = getContext().getString(R.string.textMode);
    private final String PHONE_MODE = getContext().getString(R.string.phoneMode);
    private final String EMAIL_MODE = getContext().getString(R.string.emailMode);
    private final String NUMBER_MODE = getContext().getString(R.string.numberMode);
    private final String DECIMAL_MODE = getContext().getString(R.string.decimalNumber);
    private String currentMode = "";
    private boolean animate;
    private int baseMargin = 0;
    private boolean drawn = false;
    public boolean inputIsValid ;

    public CustomEditText(Context context) {
        super(context);
    }

    public CustomEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray typedArray  = context.obtainStyledAttributes(attrs , R.styleable.CustomEditText , 0 , 0);
        setAttributes(typedArray);
        typedArray.recycle();

    }

    private void enableTextMode(){
        inputIsValid = true;
    }

    private void setAttributes(TypedArray attributes){
        setCurrentMode(attributes.hasValue(R.styleable.CustomEditText_textMode)
        ? attributes.getString(R.styleable.CustomEditText_textMode) : TEXT_MODE);
        setAnimateMode(attributes);
        invokeProperKeyboard();
       // setupFocusAnimation();
    }

    private void setAnimateMode(TypedArray attributes){
        animate = attributes.getBoolean(R.styleable.CustomEditText_animate , false);
    }

    private void setCurrentMode(String currentMode){
        this.currentMode = currentMode;
    }

    private void enablePhoneMode(){

        String REGEX_MOBILE = "\\d{10}";
        String text = getText().toString().trim();
        inputIsValid = text.matches(REGEX_MOBILE);

    }

    private void invokeProperKeyboard(){
       if(currentMode != null ){
           if(currentMode.equals(TEXT_MODE))
               invokeTextKeyboard();
           else if(currentMode.equals(NUMBER_MODE))
               invokeNumberKeyboard();
           else if (currentMode.equals(PHONE_MODE))
               invokeMobileKeyboard();
           else if(currentMode.equals(EMAIL_MODE))
               invokeEmailMode();
           else if(currentMode.equals(DECIMAL_MODE))
               invokeDecimalKeyboard();
           else
               invokeTextKeyboard();
       }
    }

    @Override
    protected void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter);
        Log.i(CustomEditText.class.getSimpleName() , text +" , "+getText().toString());
      if(currentMode != null ){
          if(currentMode.equals(TEXT_MODE))
              enableTextMode();
          else if(currentMode.equals(NUMBER_MODE) || currentMode.equals(DECIMAL_MODE))
              enableValidNumber();
          else if (currentMode.equals(PHONE_MODE))
              enablePhoneMode();
          else if(currentMode.equals(EMAIL_MODE))
              enableEmailMode();
          else
              invokeTextKeyboard();
      }

    }

    private void invokeTextKeyboard(){
        setInputType(InputType.TYPE_CLASS_TEXT);
    }

    private void invokeNumberKeyboard(){
        setInputType(InputType.TYPE_CLASS_NUMBER );
    }

    private void invokeDecimalKeyboard(){
        setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_CLASS_NUMBER);
    }

    private void invokeMobileKeyboard(){
        setInputType(InputType.TYPE_CLASS_PHONE);
    }

    private void invokeEmailMode(){
        setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
    }

    private void enableEmailMode(){

        String text = getText().toString().trim();

        Pattern VALID_EMAIL_ADDRESS_REGEX =
                Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX .matcher(text);

        inputIsValid = matcher.find();

    }

    private void enableValidNumber(){

        String text  = getText().toString().trim();
        String VALID_NUMBER_REGEX = "\\d{1,}\\.?\\d{0,}";
        inputIsValid = VALID_NUMBER_REGEX.matches(text);
    }

    private void changeRadius(boolean hasFocus){

        int from = hasFocus ? 0 : 100;
        int to  = hasFocus ? 100 : 0;



        ValueAnimator anim = ValueAnimator.ofInt(from, to);
        anim.addUpdateListener(animation -> {
            int val = (int) animation.getAnimatedValue();

            GradientDrawable drawable = new GradientDrawable();
            if(drawable != null ){
                drawable.setColor(Color.WHITE);
                drawable.setStroke(3, ContextCompat.getColor(getContext() , R.color.colorPrimary));
                drawable.setCornerRadius(val);
                setBackground(drawable);
            }
        });
        anim.setDuration(200);
        anim.start();

           if(! drawn) {
               drawn = true;
               baseMargin  = getMeasuredWidth();
           }

           from = hasFocus ? baseMargin : baseMargin +50 ;
           to = hasFocus ? baseMargin + 50 : baseMargin;

           ValueAnimator valueAnimator = ValueAnimator.ofInt(from , to);
           valueAnimator.addUpdateListener(animation -> {
               int val = (int) animation.getAnimatedValue();
               ViewGroup.LayoutParams layoutParams = getLayoutParams();
               layoutParams.width = val;
               setLayoutParams(layoutParams);
           });

           valueAnimator.setDuration(100);
           valueAnimator.start();


    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        setupFocusAnimation();
    }

    private void setupFocusAnimation(){
        setOnFocusChangeListener((v, hasFocus) -> { if(animate) changeRadius(hasFocus) ;});
    }


}
