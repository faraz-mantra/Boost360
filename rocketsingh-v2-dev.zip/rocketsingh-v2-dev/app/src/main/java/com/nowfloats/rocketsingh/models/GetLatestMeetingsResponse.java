package com.nowfloats.rocketsingh.models;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetLatestMeetingsResponse {
    private long lastMetDifference;
    @SerializedName("_id")
    @Expose
    private String id;
    @SerializedName("MeetingId")
    @Expose
    private String meetingId;
    @SerializedName("MeetingCustomId")
    @Expose
    private String meetingCustomId;
    @SerializedName("FPTag")
    @Expose
    private String fPTag;
    @SerializedName("RIATeamMemberEmail")
    @Expose
    private Object rIATeamMemberEmail;
    @SerializedName("CreatedOn")
    @Expose
    private String createdOn;
    @SerializedName("InfoDateTime")
    @Expose
    private Object infoDateTime;
    @SerializedName("EventType")
    @Expose
    private String eventType;
    @SerializedName("MeetingType")
    @Expose
    private String meetingType;
    @SerializedName("EngageDay")
    @Expose
    private Object engageDay;
    @SerializedName("Outcome")
    @Expose
    private String outcome;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public GetLatestMeetingsResponse withId(String id) {
        this.id = id;
        return this;
    }

    public String getMeetingId() {
        return meetingId;
    }

    public void setMeetingId(String meetingId) {
        this.meetingId = meetingId;
    }

    public GetLatestMeetingsResponse withMeetingId(String meetingId) {
        this.meetingId = meetingId;
        return this;
    }

    public String getMeetingCustomId() {
        return meetingCustomId;
    }

    public void setMeetingCustomId(String meetingCustomId) {
        this.meetingCustomId = meetingCustomId;
    }

    public GetLatestMeetingsResponse withMeetingCustomId(String meetingCustomId) {
        this.meetingCustomId = meetingCustomId;
        return this;
    }

    public String getFPTag() {
        return fPTag;
    }

    public void setFPTag(String fPTag) {
        this.fPTag = fPTag;
    }

    public GetLatestMeetingsResponse withFPTag(String fPTag) {
        this.fPTag = fPTag;
        return this;
    }

    public Object getRIATeamMemberEmail() {
        return rIATeamMemberEmail;
    }

    public void setRIATeamMemberEmail(Object rIATeamMemberEmail) {
        this.rIATeamMemberEmail = rIATeamMemberEmail;
    }

    public GetLatestMeetingsResponse withRIATeamMemberEmail(Object rIATeamMemberEmail) {
        this.rIATeamMemberEmail = rIATeamMemberEmail;
        return this;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public GetLatestMeetingsResponse withCreatedOn(String createdOn) {
        this.createdOn = createdOn;
        return this;
    }

    public Object getInfoDateTime() {
        return infoDateTime;
    }

    public void setInfoDateTime(Object infoDateTime) {
        this.infoDateTime = infoDateTime;
    }

    public GetLatestMeetingsResponse withInfoDateTime(Object infoDateTime) {
        this.infoDateTime = infoDateTime;
        return this;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public GetLatestMeetingsResponse withEventType(String eventType) {
        this.eventType = eventType;
        return this;
    }

    public String getMeetingType() {
        return meetingType;
    }

    public void setMeetingType(String meetingType) {
        this.meetingType = meetingType;
    }

    public GetLatestMeetingsResponse withMeetingType(String meetingType) {
        this.meetingType = meetingType;
        return this;
    }

    public Object getEngageDay() {
        return engageDay;
    }

    public void setEngageDay(Object engageDay) {
        this.engageDay = engageDay;
    }

    public GetLatestMeetingsResponse withEngageDay(Object engageDay) {
        this.engageDay = engageDay;
        return this;
    }

    public String getOutcome() {
        return outcome;
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

    public GetLatestMeetingsResponse withOutcome(String outcome) {
        this.outcome = outcome;
        return this;
    }

    public long getLastMetDifference() {
        return lastMetDifference;
    }

    public void setLastMetDifference(long lastMetDifference) {
        this.lastMetDifference = lastMetDifference;
    }
}