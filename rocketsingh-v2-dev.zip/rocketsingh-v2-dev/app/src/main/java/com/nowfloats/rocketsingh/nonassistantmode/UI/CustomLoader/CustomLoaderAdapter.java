package com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader;

import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CustomLoaderAdapter extends RecyclerView.Adapter<CustomLoaderAdapter.CustomLoaderViewHolder>{

    HashMap<NETWORK_OPERATIONS , CustomLoaderModel> hashMap = new HashMap<>() ;
    List<CustomLoaderModel> customLoaderModels = new ArrayList<>();



    public void changeData(HashMap<NETWORK_OPERATIONS , CustomLoaderModel> hashMap , List<CustomLoaderModel> customLoaderModels) {
        this.hashMap = hashMap;
        this.customLoaderModels = customLoaderModels;
        notifyDataSetChanged();
        //return this;
    }


    @NonNull
    @Override
    public CustomLoaderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_switcher , parent , false);
        return new CustomLoaderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomLoaderViewHolder holder, int position) {
        CustomLoaderModel customLoaderModel = customLoaderModels.get(holder.getAdapterPosition());
        holder.tv_state.setText(customLoaderModel.getLoader_statesStringEnumMap().get(customLoaderModel.getLoader_states()));
        handleViewFlipper(holder , customLoaderModel.getLoader_states());


    }

    public void handleViewFlipper(CustomLoaderViewHolder customLoaderViewHolder , LOADER_STATES loader_states){



       if(loader_states.equals(LOADER_STATES.LOADING))
           customLoaderViewHolder.showProgressbarOnly();
       else {

           customLoaderViewHolder.showApiState(loader_states , customLoaderViewHolder);
       }

    }

    @Override
    public int getItemCount() {
        return hashMap.size();
    }



    protected class CustomLoaderViewHolder extends RecyclerView.ViewHolder {



        private LottieAnimationView im_state;
        private TextView tv_state ;

        public CustomLoaderViewHolder(View itemView) {
            super(itemView);
            //viewSwitcher = itemView.findViewById(R.id.customLoader_viewFilpper);

            im_state = itemView.findViewById(R.id.im_status);
            tv_state = itemView.findViewById(R.id.tv_apiState);
        }

        public void showProgressbarOnly(){
            im_state.setVisibility(View.VISIBLE);
            im_state.setAnimation("loading.json");
            im_state.playAnimation();
            im_state.setRepeatCount(LottieDrawable.INFINITE);
        }

        public void showApiState(LOADER_STATES loader_states , CustomLoaderViewHolder holder){


            holder.im_state.setVisibility(View.VISIBLE);

            switch (loader_states) {
                case SUCCESS:
                    im_state.setAnimation("checked_done_.json");
                    im_state.playAnimation();
                   // im_state.loop(true);
                    break;
                case FAIL:
                    //im_state.setImageDrawable(ContextCompat.getDrawable(im_state.getContext() ,R.drawable.animated_vector_check));
                    im_state.setAnimation("cloud_disconnection.json");
                    im_state.playAnimation();
                   // im_state.loop(true);
                    break;
            }

            im_state.setRepeatCount(0);

//            Drawable drawable = im_state.getDrawable();
//            ((Animatable) drawable).start();
        }
    }
}
