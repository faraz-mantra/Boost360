package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetLeadModelResponse {

    @SerializedName("business_category")
    @Expose
    private Object businessCategory;
    @SerializedName("city")
    @Expose
    private String city;
    @SerializedName("sp_email")
    @Expose
    private String spEmail;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("c_quotation_created")
    @Expose
    private Boolean cQuotationCreated;
    @SerializedName("fptag")
    @Expose
    private Object fptag;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("country")
    @Expose
    private Object country;
    @SerializedName("street2")
    @Expose
    private String street2;
    @SerializedName("opp_id")
    @Expose
    private Integer oppId;
    @SerializedName("lc_email")
    @Expose
    private String lcEmail;
    @SerializedName("pincode")
    @Expose
    private String pincode;
    @SerializedName("new_quote_created")
    @Expose
    private Boolean newQuoteCreated;
    @SerializedName("state")
    @Expose
    private Object state;
    @SerializedName("street")
    @Expose
    private String street;
    @SerializedName("company_name")
    @Expose
    private String companyName;
    @SerializedName("type")
    @Expose
    private String type;
    @SerializedName("partner_id")
    @Expose
    private Integer partnerId;
    @SerializedName("company_email")
    @Expose
    private String companyEmail;

    public Object getBusinessCategory() {
        return businessCategory;
    }

    public void setBusinessCategory(Object businessCategory) {
        this.businessCategory = businessCategory;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getSpEmail() {
        return spEmail;
    }

    public void setSpEmail(String spEmail) {
        this.spEmail = spEmail;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getCQuotationCreated() {
        return cQuotationCreated;
    }

    public void setCQuotationCreated(Boolean cQuotationCreated) {
        this.cQuotationCreated = cQuotationCreated;
    }

    public Object getFptag() {
        return fptag;
    }

    public void setFptag(Object fptag) {
        this.fptag = fptag;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Object getCountry() {
        return country;
    }

    public void setCountry(Object country) {
        this.country = country;
    }

    public String getStreet2() {
        return street2;
    }

    public void setStreet2(String street2) {
        this.street2 = street2;
    }

    public Integer getOppId() {
        return oppId;
    }

    public void setOppId(Integer oppId) {
        this.oppId = oppId;
    }

    public String getLcEmail() {
        return lcEmail;
    }

    public void setLcEmail(String lcEmail) {
        this.lcEmail = lcEmail;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public Boolean getNewQuoteCreated() {
        return newQuoteCreated;
    }

    public void setNewQuoteCreated(Boolean newQuoteCreated) {
        this.newQuoteCreated = newQuoteCreated;
    }

    public Object getState() {
        return state;
    }

    public void setState(Object state) {
        this.state = state;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(Integer partnerId) {
        this.partnerId = partnerId;
    }

    public String getCompanyEmail() {
        return companyEmail;
    }

    public void setCompanyEmail(String companyEmail) {
        this.companyEmail = companyEmail;
    }

}