package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 17-Oct-17.
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AddFCMDataRequest {

    @SerializedName("ActionData")
    @Expose
    private ActionData actionData;
    @SerializedName("WebsiteId")
    @Expose
    private String websiteId;

    public ActionData getActionData() {
        return actionData;
    }

    public void setActionData(ActionData actionData) {
        this.actionData = actionData;
    }

    public String getWebsiteId() {
        return websiteId;
    }

    public void setWebsiteId(String websiteId) {
        this.websiteId = websiteId;
    }

    public static class ActionData {

        @SerializedName("emailID")
        @Expose
        private String emailID;
        @SerializedName("fcmID")
        @Expose
        private String fcmID;
        @SerializedName("deviceID")
        @Expose
        private String deviceID;
        @SerializedName("version")
        @Expose
        private String version;

        public String getEmailID() {
            return emailID;
        }

        public void setEmailID(String emailID) {
            this.emailID = emailID;
        }

        public String getFcmID() {
            return fcmID;
        }

        public void setFcmID(String fcmID) {
            this.fcmID = fcmID;
        }

        public String getDeviceID() {
            return deviceID;
        }

        public void setDeviceID(String deviceID) {
            this.deviceID = deviceID;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

    }

}