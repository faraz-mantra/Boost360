package com.nowfloats.rocketsingh.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetSwipeStatusResponse {

    @SerializedName("jsonrpc")
    @Expose
    private String jsonrpc;
    @SerializedName("id")
    @Expose
    private Object id;
    @SerializedName("result")
    @Expose
    private List<Result> result = null;

    public String getJsonrpc() {
        return jsonrpc;
    }

    public void setJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
    }

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public List<Result> getResult() {
        return result;
    }

    public void setResult(List<Result> result) {
        this.result = result;
    }

    public class Result {

        @SerializedName("address")
        @Expose
        private String address;

        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("io_type")
        @Expose
        private Integer ioType;
        @SerializedName("device_name")
        @Expose
        private String deviceName;
        @SerializedName("branch")
        @Expose
        private String branch;
        @SerializedName("attendance_date")
        @Expose
        private String attendanceDate;
        @SerializedName("biometric_branch")
        @Expose
        private Boolean biometricBranch;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getIoType() {
            return ioType;
        }

        public void setIoType(Integer ioType) {
            this.ioType = ioType;
        }

        public String getDeviceName() {
            return deviceName;
        }

        public void setDeviceName(String deviceName) {
            this.deviceName = deviceName;
        }

        public String getBranch() {
            return branch;
        }

        public void setBranch(String branch) {
            this.branch = branch;
        }

        public String getAttendanceDate() {
            return attendanceDate;
        }

        public void setAttendanceDate(String attendanceDate) {
            this.attendanceDate = attendanceDate;
        }

        public Boolean getBiometricBranch() {
            return biometricBranch;
        }

        public void setBiometricBranch(Boolean biometricBranch) {
            this.biometricBranch = biometricBranch;
        }


        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }
    }
}