package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 26-Mar-18.
 */
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MeetingsStatsForCFResponse {

    @SerializedName("AlreadyCompletedMeetingsCount")
    @Expose
    private AlreadyCompletedMeetingsCount alreadyCompletedMeetingsCount;
    @SerializedName("ScheduledMeetingsCount")
    @Expose
    private ScheduledMeetingsCount scheduledMeetingsCount;
    @SerializedName("RescheduledMeetingsCount")
    @Expose
    private RescheduledMeetingsCount rescheduledMeetingsCount;
    @SerializedName("UpdatedMeetingsCount")
    @Expose
    private UpdatedMeetingsCount updatedMeetingsCount;
    @SerializedName("MissedMeetingsCount")
    @Expose
    private MissedMeetingsCount missedMeetingsCount;
    @SerializedName("OverdueCustomerMeetings")
    @Expose
    private Integer overdueCustomerMeetings;
    @SerializedName("ScheduledMeetingsFpTags")
    @Expose
    private List<Object> scheduledMeetingsFpTags = null;
    @SerializedName("MissedMeetingsFpTags")
    @Expose
    private List<Object> missedMeetingsFpTags = null;
    @SerializedName("RescheduledMeetingsFpTags")
    @Expose
    private List<Object> rescheduledMeetingsFpTags = null;
    @SerializedName("UpdatedMeetingsFpTags")
    @Expose
    private List<Object> updatedMeetingsFpTags = null;
    @SerializedName("OverdueCustomerMeetingsFpTags")
    @Expose
    private List<String> overdueCustomerMeetingsFpTags = null;
    @SerializedName("AlreadyCompletedMeetingsFpTags")
    @Expose
    private List<Object> alreadyCompletedMeetingsFpTags = null;

    public AlreadyCompletedMeetingsCount getAlreadyCompletedMeetingsCount() {
        return alreadyCompletedMeetingsCount;
    }

    public void setAlreadyCompletedMeetingsCount(AlreadyCompletedMeetingsCount alreadyCompletedMeetingsCount) {
        this.alreadyCompletedMeetingsCount = alreadyCompletedMeetingsCount;
    }

    public ScheduledMeetingsCount getScheduledMeetingsCount() {
        return scheduledMeetingsCount;
    }

    public void setScheduledMeetingsCount(ScheduledMeetingsCount scheduledMeetingsCount) {
        this.scheduledMeetingsCount = scheduledMeetingsCount;
    }

    public RescheduledMeetingsCount getRescheduledMeetingsCount() {
        return rescheduledMeetingsCount;
    }

    public void setRescheduledMeetingsCount(RescheduledMeetingsCount rescheduledMeetingsCount) {
        this.rescheduledMeetingsCount = rescheduledMeetingsCount;
    }

    public UpdatedMeetingsCount getUpdatedMeetingsCount() {
        return updatedMeetingsCount;
    }

    public void setUpdatedMeetingsCount(UpdatedMeetingsCount updatedMeetingsCount) {
        this.updatedMeetingsCount = updatedMeetingsCount;
    }

    public MissedMeetingsCount getMissedMeetingsCount() {
        return missedMeetingsCount;
    }

    public void setMissedMeetingsCount(MissedMeetingsCount missedMeetingsCount) {
        this.missedMeetingsCount = missedMeetingsCount;
    }

    public Integer getOverdueCustomerMeetings() {
        return overdueCustomerMeetings;
    }

    public void setOverdueCustomerMeetings(Integer overdueCustomerMeetings) {
        this.overdueCustomerMeetings = overdueCustomerMeetings;
    }

    public List<Object> getScheduledMeetingsFpTags() {
        return scheduledMeetingsFpTags;
    }

    public void setScheduledMeetingsFpTags(List<Object> scheduledMeetingsFpTags) {
        this.scheduledMeetingsFpTags = scheduledMeetingsFpTags;
    }

    public List<Object> getMissedMeetingsFpTags() {
        return missedMeetingsFpTags;
    }

    public void setMissedMeetingsFpTags(List<Object> missedMeetingsFpTags) {
        this.missedMeetingsFpTags = missedMeetingsFpTags;
    }

    public List<Object> getRescheduledMeetingsFpTags() {
        return rescheduledMeetingsFpTags;
    }

    public void setRescheduledMeetingsFpTags(List<Object> rescheduledMeetingsFpTags) {
        this.rescheduledMeetingsFpTags = rescheduledMeetingsFpTags;
    }

    public List<Object> getUpdatedMeetingsFpTags() {
        return updatedMeetingsFpTags;
    }

    public void setUpdatedMeetingsFpTags(List<Object> updatedMeetingsFpTags) {
        this.updatedMeetingsFpTags = updatedMeetingsFpTags;
    }

    public List<String> getOverdueCustomerMeetingsFpTags() {
        return overdueCustomerMeetingsFpTags;
    }

    public void setOverdueCustomerMeetingsFpTags(List<String> overdueCustomerMeetingsFpTags) {
        this.overdueCustomerMeetingsFpTags = overdueCustomerMeetingsFpTags;
    }

    public List<Object> getAlreadyCompletedMeetingsFpTags() {
        return alreadyCompletedMeetingsFpTags;
    }

    public void setAlreadyCompletedMeetingsFpTags(List<Object> alreadyCompletedMeetingsFpTags) {
        this.alreadyCompletedMeetingsFpTags = alreadyCompletedMeetingsFpTags;
    }

    public class AlreadyCompletedMeetingsCount {

        @SerializedName("count")
        @Expose
        private Integer count;
        @SerializedName("uniqueCount")
        @Expose
        private Integer uniqueCount;

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public Integer getUniqueCount() {
            return uniqueCount;
        }

        public void setUniqueCount(Integer uniqueCount) {
            this.uniqueCount = uniqueCount;
        }

    }

    public class MissedMeetingsCount {

        @SerializedName("count")
        @Expose
        private Integer count;
        @SerializedName("uniqueCount")
        @Expose
        private Integer uniqueCount;

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public Integer getUniqueCount() {
            return uniqueCount;
        }

        public void setUniqueCount(Integer uniqueCount) {
            this.uniqueCount = uniqueCount;
        }

    }

    public class RescheduledMeetingsCount {

        @SerializedName("count")
        @Expose
        private Integer count;
        @SerializedName("uniqueCount")
        @Expose
        private Integer uniqueCount;

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public Integer getUniqueCount() {
            return uniqueCount;
        }

        public void setUniqueCount(Integer uniqueCount) {
            this.uniqueCount = uniqueCount;
        }

    }

    public class ScheduledMeetingsCount {

        @SerializedName("count")
        @Expose
        private Integer count;
        @SerializedName("uniqueCount")
        @Expose
        private Integer uniqueCount;

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public Integer getUniqueCount() {
            return uniqueCount;
        }

        public void setUniqueCount(Integer uniqueCount) {
            this.uniqueCount = uniqueCount;
        }

    }

    public class UpdatedMeetingsCount {

        @SerializedName("count")
        @Expose
        private Integer count;
        @SerializedName("uniqueCount")
        @Expose
        private Integer uniqueCount;

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }

        public Integer getUniqueCount() {
            return uniqueCount;
        }

        public void setUniqueCount(Integer uniqueCount) {
            this.uniqueCount = uniqueCount;
        }

    }

}
