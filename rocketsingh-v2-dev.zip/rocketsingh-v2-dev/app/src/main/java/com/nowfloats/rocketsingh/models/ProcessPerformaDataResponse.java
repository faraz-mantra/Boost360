package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProcessPerformaDataResponse {

    @SerializedName("packagesInfo")
    @Expose
    private String packagesInfo;
    @SerializedName("solIds")
    @Expose
    private String solIds;
    @SerializedName("fetchRequestFlag")
    @Expose
    private Integer fetchRequestFlag;
    @SerializedName("lastYearSaleDetails")
    @Expose
    private String lastYearSaleDetails;

    public String getPackagesInfo() {
        return packagesInfo;
    }

    public void setPackagesInfo(String packagesInfo) {
        this.packagesInfo = packagesInfo;
    }

    public String getSolIds() {
        return solIds;
    }

    public void setSolIds(String solIds) {
        this.solIds = solIds;
    }

    public Integer getFetchRequestFlag() {
        return fetchRequestFlag;
    }

    public void setFetchRequestFlag(Integer fetchRequestFlag) {
        this.fetchRequestFlag = fetchRequestFlag;
    }

    public String getLastYearSaleDetails() {
        return lastYearSaleDetails;
    }

    public void setLastYearSaleDetails(String lastYearSaleDetails) {
        this.lastYearSaleDetails = lastYearSaleDetails;
    }

}