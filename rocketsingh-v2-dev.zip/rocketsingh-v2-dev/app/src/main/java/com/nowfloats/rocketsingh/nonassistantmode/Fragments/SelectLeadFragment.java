package com.nowfloats.rocketsingh.nonassistantmode.Fragments;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.GetLeadDetailsResponse;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.NetworkResultInterface;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader.CustomLoaderDialog;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NetworkHandler;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class SelectLeadFragment extends Fragment implements NetworkResultInterface {

    private LinearLayout ll_leadSelect;
    private SelectLeadInterface selectLeadInterface;
    private String customerNumber;
    GetLeadDetailsResponse dataResponse;
    private CardView cv_customerLayout;
    private GetLeadDetailsResponse.Result selecttedLead;
    private CustomLoaderDialog customLoaderDialog;
    TextView tv_businessName , tv_phoneNumber , tv_name , tv_leadNumber;
    private NetworkHandler networkHandler;

    public static SelectLeadFragment getInstance(String number , SelectLeadInterface selectLeadInterface){
        SelectLeadFragment selectLeadFragment = new SelectLeadFragment() ;
        selectLeadFragment.customerNumber = number;
        selectLeadFragment.selectLeadInterface = selectLeadInterface;
        return selectLeadFragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.select_lead_layout , container , false);
        ll_leadSelect = v.findViewById(R.id.ll_leadSelect);
        ll_leadSelect.setOnClickListener(view -> {
            startNetworkOperation();
        });
        initialiseCustomerDetailsPanel(v , false);
        return v;
    }

    private void initialiseCustomerDetailsPanel(View v , boolean visible){

        if(v != null ){
            tv_businessName = v.findViewById(R.id.tv_businessName);
            tv_name = v.findViewById(R.id.tv_customerName);
            tv_leadNumber = v.findViewById(R.id.tv_customerNumber);
            tv_phoneNumber = v.findViewById(R.id.tv_primaryNumber);
            cv_customerLayout = v.findViewById(R.id.cv_leadDetails);
        }

        cv_customerLayout.setVisibility(visible ? View.VISIBLE : View.GONE);
    }


    @Override
    public void onApiRequestStarted(NETWORK_OPERATIONS network_operations) {
        initiateApiState(network_operations);
    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, String message) {
        updateApiStateInFpFragment(operationKey , message , true);

        networkHandler.executeNext();
    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, Object model, String message) {
        updateApiStateInFpFragment(operationKey , message , true);
        dataResponse = (GetLeadDetailsResponse)model;
        networkHandler.executeNext();

    }

    @Override
    public void onApiFail(NETWORK_OPERATIONS operationKey, String errorMessage) {
        updateApiStateInFpFragment(operationKey , errorMessage , false);
    }

    @Override
    public void networkOperationsFinished(boolean success, short session) {
        hideDialog(false);
        if(success) {

            List<String> leadList  = new ArrayList<>();
            List<GetLeadDetailsResponse.Result> newResults = new ArrayList<>();

            for (GetLeadDetailsResponse.Result item : dataResponse.getResult()) {
                item.setCompanyName(TextUtils.isEmpty(item.getCompanyName())?" NA " : item.getCompanyName());

                if(item.getMobile() != null ){
                    //if( item.getMobile().equalsIgnoreCase(customerNumber)) {
                        leadList.add(item.getName() + "\n" + item.getCompanyName()+"\n"+item.getMobile()+"\n"+item.getCompanyEmail());
                        newResults.add(item);
                    //}
                }
            }

            showListLeadsDialog(leadList , getContext() , newResults);
        }
    }

    @Override
    public void prepareRequestBody(NETWORK_OPERATIONS network_operations, NetworkHandler networkHandler) {

    }

    private void initiateApiState(NETWORK_OPERATIONS network_operations) {
        if(dialogIsValid()) {
            customLoaderDialog.initiateApiState(network_operations);
            return;
        }else {
            showDialog();
            new Handler().postDelayed(() -> {customLoaderDialog.initiateApiState(network_operations);} , 0);
        }

    }


    public boolean dialogIsValid(){
        return customLoaderDialog != null  && customLoaderDialog.isVisible();
    }

    private void showDialog() {
        if (customLoaderDialog == null) {
            customLoaderDialog = new CustomLoaderDialog();
        }

        if(customLoaderDialog.isVisible())
            return;

        customLoaderDialog = CustomLoaderDialog.newInstance();
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        fragmentManager.executePendingTransactions();
        customLoaderDialog.show(fragmentManager.beginTransaction(), "dialog");
    }

    public void startNetworkOperation(){
        Queue<NETWORK_OPERATIONS> queue = new LinkedList<>();
        queue.add(NETWORK_OPERATIONS.GET_ALL_LEADS);
        networkHandler = new NetworkHandler(getContext() , this)
                .setNetworkOperationQueue(queue)
                .startThread();
    }


    public void updateApiStateInFpFragment(NETWORK_OPERATIONS network_operations , String message , boolean success) {
        if (success) {
            updateApiForSuccess(network_operations, message);

        } else {
            updateApiForFailure(network_operations, message);
        }
    }

    private void hideDialog(boolean delay){
        // delay is just for the effect

        if(customLoaderDialog == null )
            return;
        if(! customLoaderDialog.isVisible())
            return;

        new Handler().postDelayed(() -> {customLoaderDialog.closeDialog();} , delay ? 2500: 0);


    }

    private void updateApiForSuccess(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForSuccess(network_operations , message);
        }
    }



    private void updateApiForFailure(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForFailure(network_operations, message);
            hideDialog(true);
        }
    }

    public interface SelectLeadInterface{
        void onLeadSelected(GetLeadDetailsResponse.Result result);
    }

    private void showListLeadsDialog(List<String> mAutoComplRes, Context context, List<GetLeadDetailsResponse.Result> results) {
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(context,
                R.layout.search_list_item_layout, mAutoComplRes);
        AlertDialog.Builder mBuilderSingle = new AlertDialog.Builder(context);
        mBuilderSingle.setTitle("Select customer");
        View view = LayoutInflater.from(context).inflate(R.layout.search_list_layout, null);
        mBuilderSingle.setView(view);
        EditText edtSearch = view.findViewById(R.id.edtSearch);
        ListView lvItems = view.findViewById(R.id.lvItems);
        lvItems.setAdapter(adapter);
        final Dialog dialog = mBuilderSingle.show();
        dialog.show();
        lvItems.setOnItemClickListener((parent, view1, position, id) -> {
            String strVal = adapter.getItem(position);
            int pos = mAutoComplRes.indexOf(strVal);
            selecttedLead = results.get(pos);
            cv_customerLayout.setVisibility(View.VISIBLE);
            tv_businessName.append(selecttedLead.getCompanyName());
            tv_leadNumber.append(selecttedLead.getName());
            tv_phoneNumber.append(selecttedLead.getMobile());
            tv_name.setVisibility(View.GONE);
            selectLeadInterface.onLeadSelected(results.get(pos));
            dialog.dismiss();
        });
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                adapter.getFilter().filter(s.toString().toLowerCase());
            }
        });
        dialog.setCancelable(false);
    }
}