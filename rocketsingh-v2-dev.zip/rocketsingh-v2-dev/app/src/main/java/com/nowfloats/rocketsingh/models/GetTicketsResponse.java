package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetTicketsResponse {

    @SerializedName("tickets")
    @Expose
    private List<Ticket> tickets = null;
    @SerializedName("next_page")
    @Expose
    private Object nextPage;
    @SerializedName("previous_page")
    @Expose
    private Object previousPage;
    @SerializedName("count")
    @Expose
    private long count;

    public List<Ticket> getTickets() {
        return tickets;
    }

    public void setTickets(List<Ticket> tickets) {
        this.tickets = tickets;
    }

    public GetTicketsResponse withTickets(List<Ticket> tickets) {
        this.tickets = tickets;
        return this;
    }

    public Object getNextPage() {
        return nextPage;
    }

    public void setNextPage(Object nextPage) {
        this.nextPage = nextPage;
    }

    public GetTicketsResponse withNextPage(Object nextPage) {
        this.nextPage = nextPage;
        return this;
    }

    public Object getPreviousPage() {
        return previousPage;
    }

    public void setPreviousPage(Object previousPage) {
        this.previousPage = previousPage;
    }

    public GetTicketsResponse withPreviousPage(Object previousPage) {
        this.previousPage = previousPage;
        return this;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public GetTicketsResponse withCount(long count) {
        this.count = count;
        return this;
    }

    public class Ticket {

        @SerializedName("url")
        @Expose
        private String url;
        @SerializedName("id")
        @Expose
        private long id;
        @SerializedName("external_id")
        @Expose
        private String externalId;
        @SerializedName("via")
        @Expose
        private Field.Via via;
        @SerializedName("created_at")
        @Expose
        private String createdAt;
        @SerializedName("updated_at")
        @Expose
        private String updatedAt;
        @SerializedName("type")
        @Expose
        private Object type;
        @SerializedName("subject")
        @Expose
        private String subject;
        @SerializedName("raw_subject")
        @Expose
        private String rawSubject;
        @SerializedName("description")
        @Expose
        private String description;
        @SerializedName("priority")
        @Expose
        private String priority;
        @SerializedName("status")
        @Expose
        private String status;
        @SerializedName("recipient")
        @Expose
        private Object recipient;
        @SerializedName("requester_id")
        @Expose
        private long requesterId;
        @SerializedName("submitter_id")
        @Expose
        private long submitterId;
        @SerializedName("assignee_id")
        @Expose
        private Object assigneeId;
        @SerializedName("organization_id")
        @Expose
        private long organizationId;
        @SerializedName("group_id")
        @Expose
        private long groupId;
        @SerializedName("collaborator_ids")
        @Expose
        private List<Object> collaboratorIds = null;
        @SerializedName("follower_ids")
        @Expose
        private List<Object> followerIds = null;
        @SerializedName("email_cc_ids")
        @Expose
        private List<Object> emailCcIds = null;
        @SerializedName("forum_topic_id")
        @Expose
        private Object forumTopicId;
        @SerializedName("problem_id")
        @Expose
        private Object problemId;
        @SerializedName("has_incidents")
        @Expose
        private Boolean hasIncidents;
        @SerializedName("is_public")
        @Expose
        private Boolean isPublic;
        @SerializedName("due_at")
        @Expose
        private Object dueAt;
        @SerializedName("tags")
        @Expose
        private List<String> tags = null;
        @SerializedName("custom_fields")
        @Expose
        private List<Field.CustomField> customFields = null;
        @SerializedName("satisfaction_rating")
        @Expose
        private Field.SatisfactionRating satisfactionRating;
        @SerializedName("sharing_agreement_ids")
        @Expose
        private List<Object> sharingAgreementIds = null;
        @SerializedName("fields")
        @Expose
        private List<Field> fields = null;
        @SerializedName("followup_ids")
        @Expose
        private List<Object> followupIds = null;
        @SerializedName("brand_id")
        @Expose
        private long brandId;
        @SerializedName("allow_channelback")
        @Expose
        private Boolean allowChannelback;
        @SerializedName("allow_attachments")
        @Expose
        private Boolean allowAttachments;

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public Ticket withUrl(String url) {
            this.url = url;
            return this;
        }

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public Ticket withId(long id) {
            this.id = id;
            return this;
        }

        public String getExternalId() {
            return externalId;
        }

        public void setExternalId(String externalId) {
            this.externalId = externalId;
        }

        public Ticket withExternalId(String externalId) {
            this.externalId = externalId;
            return this;
        }

        public Field.Via getVia() {
            return via;
        }

        public void setVia(Field.Via via) {
            this.via = via;
        }

        public Ticket withVia(Field.Via via) {
            this.via = via;
            return this;
        }

        public String getCreatedAt() {
            return createdAt;
        }

        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }

        public Ticket withCreatedAt(String createdAt) {
            this.createdAt = createdAt;
            return this;
        }

        public String getUpdatedAt() {
            return updatedAt;
        }

        public void setUpdatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
        }

        public Ticket withUpdatedAt(String updatedAt) {
            this.updatedAt = updatedAt;
            return this;
        }

        public Object getType() {
            return type;
        }

        public void setType(Object type) {
            this.type = type;
        }

        public Ticket withType(Object type) {
            this.type = type;
            return this;
        }

        public String getSubject() {
            return subject;
        }

        public void setSubject(String subject) {
            this.subject = subject;
        }

        public Ticket withSubject(String subject) {
            this.subject = subject;
            return this;
        }

        public String getRawSubject() {
            return rawSubject;
        }

        public void setRawSubject(String rawSubject) {
            this.rawSubject = rawSubject;
        }

        public Ticket withRawSubject(String rawSubject) {
            this.rawSubject = rawSubject;
            return this;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public Ticket withDescription(String description) {
            this.description = description;
            return this;
        }

        public String getPriority() {
            return priority;
        }

        public void setPriority(String priority) {
            this.priority = priority;
        }

        public Ticket withPriority(String priority) {
            this.priority = priority;
            return this;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public Ticket withStatus(String status) {
            this.status = status;
            return this;
        }

        public Object getRecipient() {
            return recipient;
        }

        public void setRecipient(Object recipient) {
            this.recipient = recipient;
        }

        public Ticket withRecipient(Object recipient) {
            this.recipient = recipient;
            return this;
        }

        public long getRequesterId() {
            return requesterId;
        }

        public void setRequesterId(long requesterId) {
            this.requesterId = requesterId;
        }

        public Ticket withRequesterId(long requesterId) {
            this.requesterId = requesterId;
            return this;
        }

        public long getSubmitterId() {
            return submitterId;
        }

        public void setSubmitterId(long submitterId) {
            this.submitterId = submitterId;
        }

        public Ticket withSubmitterId(long submitterId) {
            this.submitterId = submitterId;
            return this;
        }

        public Object getAssigneeId() {
            return assigneeId;
        }

        public void setAssigneeId(Object assigneeId) {
            this.assigneeId = assigneeId;
        }

        public Ticket withAssigneeId(Object assigneeId) {
            this.assigneeId = assigneeId;
            return this;
        }

        public long getOrganizationId() {
            return organizationId;
        }

        public void setOrganizationId(long organizationId) {
            this.organizationId = organizationId;
        }

        public Ticket withOrganizationId(long organizationId) {
            this.organizationId = organizationId;
            return this;
        }

        public long getGroupId() {
            return groupId;
        }

        public void setGroupId(long groupId) {
            this.groupId = groupId;
        }

        public Ticket withGroupId(long groupId) {
            this.groupId = groupId;
            return this;
        }

        public List<Object> getCollaboratorIds() {
            return collaboratorIds;
        }

        public void setCollaboratorIds(List<Object> collaboratorIds) {
            this.collaboratorIds = collaboratorIds;
        }

        public Ticket withCollaboratorIds(List<Object> collaboratorIds) {
            this.collaboratorIds = collaboratorIds;
            return this;
        }

        public List<Object> getFollowerIds() {
            return followerIds;
        }

        public void setFollowerIds(List<Object> followerIds) {
            this.followerIds = followerIds;
        }

        public Ticket withFollowerIds(List<Object> followerIds) {
            this.followerIds = followerIds;
            return this;
        }

        public List<Object> getEmailCcIds() {
            return emailCcIds;
        }

        public void setEmailCcIds(List<Object> emailCcIds) {
            this.emailCcIds = emailCcIds;
        }

        public Ticket withEmailCcIds(List<Object> emailCcIds) {
            this.emailCcIds = emailCcIds;
            return this;
        }

        public Object getForumTopicId() {
            return forumTopicId;
        }

        public void setForumTopicId(Object forumTopicId) {
            this.forumTopicId = forumTopicId;
        }

        public Ticket withForumTopicId(Object forumTopicId) {
            this.forumTopicId = forumTopicId;
            return this;
        }

        public Object getProblemId() {
            return problemId;
        }

        public void setProblemId(Object problemId) {
            this.problemId = problemId;
        }

        public Ticket withProblemId(Object problemId) {
            this.problemId = problemId;
            return this;
        }

        public Boolean getHasIncidents() {
            return hasIncidents;
        }

        public void setHasIncidents(Boolean hasIncidents) {
            this.hasIncidents = hasIncidents;
        }

        public Ticket withHasIncidents(Boolean hasIncidents) {
            this.hasIncidents = hasIncidents;
            return this;
        }

        public Boolean getIsPublic() {
            return isPublic;
        }

        public void setIsPublic(Boolean isPublic) {
            this.isPublic = isPublic;
        }

        public Ticket withIsPublic(Boolean isPublic) {
            this.isPublic = isPublic;
            return this;
        }

        public Object getDueAt() {
            return dueAt;
        }

        public void setDueAt(Object dueAt) {
            this.dueAt = dueAt;
        }

        public Ticket withDueAt(Object dueAt) {
            this.dueAt = dueAt;
            return this;
        }

        public List<String> getTags() {
            return tags;
        }

        public void setTags(List<String> tags) {
            this.tags = tags;
        }

        public Ticket withTags(List<String> tags) {
            this.tags = tags;
            return this;
        }

        public List<Field.CustomField> getCustomFields() {
            return customFields;
        }

        public void setCustomFields(List<Field.CustomField> customFields) {
            this.customFields = customFields;
        }

        public Ticket withCustomFields(List<Field.CustomField> customFields) {
            this.customFields = customFields;
            return this;
        }

        public Field.SatisfactionRating getSatisfactionRating() {
            return satisfactionRating;
        }

        public void setSatisfactionRating(Field.SatisfactionRating satisfactionRating) {
            this.satisfactionRating = satisfactionRating;
        }

        public Ticket withSatisfactionRating(Field.SatisfactionRating satisfactionRating) {
            this.satisfactionRating = satisfactionRating;
            return this;
        }

        public List<Object> getSharingAgreementIds() {
            return sharingAgreementIds;
        }

        public void setSharingAgreementIds(List<Object> sharingAgreementIds) {
            this.sharingAgreementIds = sharingAgreementIds;
        }

        public Ticket withSharingAgreementIds(List<Object> sharingAgreementIds) {
            this.sharingAgreementIds = sharingAgreementIds;
            return this;
        }

        public List<Field> getFields() {
            return fields;
        }

        public void setFields(List<Field> fields) {
            this.fields = fields;
        }

        public Ticket withFields(List<Field> fields) {
            this.fields = fields;
            return this;
        }

        public List<Object> getFollowupIds() {
            return followupIds;
        }

        public void setFollowupIds(List<Object> followupIds) {
            this.followupIds = followupIds;
        }

        public Ticket withFollowupIds(List<Object> followupIds) {
            this.followupIds = followupIds;
            return this;
        }

        public long getBrandId() {
            return brandId;
        }

        public void setBrandId(long brandId) {
            this.brandId = brandId;
        }

        public Ticket withBrandId(long brandId) {
            this.brandId = brandId;
            return this;
        }

        public Boolean getAllowChannelback() {
            return allowChannelback;
        }

        public void setAllowChannelback(Boolean allowChannelback) {
            this.allowChannelback = allowChannelback;
        }

        public Ticket withAllowChannelback(Boolean allowChannelback) {
            this.allowChannelback = allowChannelback;
            return this;
        }

        public Boolean getAllowAttachments() {
            return allowAttachments;
        }

        public void setAllowAttachments(Boolean allowAttachments) {
            this.allowAttachments = allowAttachments;
        }

        public Ticket withAllowAttachments(Boolean allowAttachments) {
            this.allowAttachments = allowAttachments;
            return this;
        }

    }

    public class Field {

        @SerializedName("id")
        @Expose
        private long id;
        @SerializedName("value")
        @Expose
        private Object value;

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public Field withId(long id) {
            this.id = id;
            return this;
        }

        public Object getValue() {
            return value;
        }

        public void setValue(Object value) {
            this.value = value;
        }

        public Field withValue(Object value) {
            this.value = value;
            return this;
        }


        public class SatisfactionRating {

            @SerializedName("score")
            @Expose
            private String score;

            public String getScore() {
                return score;
            }

            public void setScore(String score) {
                this.score = score;
            }

            public SatisfactionRating withScore(String score) {
                this.score = score;
                return this;
            }

        }

        public class Via {

            @SerializedName("channel")
            @Expose
            private String channel;
            @SerializedName("source")
            @Expose
            private Source source;

            public String getChannel() {
                return channel;
            }

            public void setChannel(String channel) {
                this.channel = channel;
            }

            public Via withChannel(String channel) {
                this.channel = channel;
                return this;
            }

            public Source getSource() {
                return source;
            }

            public void setSource(Source source) {
                this.source = source;
            }

            public Via withSource(Source source) {
                this.source = source;
                return this;
            }

            public class Source {

                @SerializedName("from")
                @Expose
                private From from;
                @SerializedName("to")
                @Expose
                private To to;
                @SerializedName("rel")
                @Expose
                private Object rel;

                public From getFrom() {
                    return from;
                }

                public void setFrom(From from) {
                    this.from = from;
                }

                public Source withFrom(From from) {
                    this.from = from;
                    return this;
                }

                public To getTo() {
                    return to;
                }

                public void setTo(To to) {
                    this.to = to;
                }

                public Source withTo(To to) {
                    this.to = to;
                    return this;
                }

                public Object getRel() {
                    return rel;
                }

                public void setRel(Object rel) {
                    this.rel = rel;
                }

                public Source withRel(Object rel) {
                    this.rel = rel;
                    return this;
                }

            }

        }

        public class To {


        }

        public class From {


        }

        public class CustomField {

            @SerializedName("id")
            @Expose
            private long id;
            @SerializedName("value")
            @Expose
            private Object value;

            public long getId() {
                return id;
            }

            public void setId(long id) {
                this.id = id;
            }

            public CustomField withId(long id) {
                this.id = id;
                return this;
            }

            public Object getValue() {
                return value;
            }

            public void setValue(Object value) {
                this.value = value;
            }

            public CustomField withValue(Object value) {
                this.value = value;
                return this;
            }

        }

    }

}