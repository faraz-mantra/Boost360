package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 26-Mar-18.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetAssignedCHCForPartnerResponse {

    @SerializedName("Error")
    @Expose
    private Error error;
    @SerializedName("Result")
    @Expose
    private Result result;
    @SerializedName("StatusCode")
    @Expose
    private Integer statusCode;

    public Error getError() {
        return error;
    }

    public void setError(Error error) {
        this.error = error;
    }

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public class Result {

        @SerializedName("ActivityScoreCount")
        @Expose
        private ActivityScoreCount activityScoreCount;
        @SerializedName("CustomerStatusCount")
        @Expose
        private CustomerStatusCount customerStatusCount;
        @SerializedName("ExpriyStatusCount")
        @Expose
        private ExpriyStatusCount expriyStatusCount;
        @SerializedName("FloatingPointProperties")
        @Expose
        private List<FloatingPointProperty> floatingPointProperties = null;
        @SerializedName("FpTags")
        @Expose
        private List<String> fpTags = null;

        public ActivityScoreCount getActivityScoreCount() {
            return activityScoreCount;
        }

        public void setActivityScoreCount(ActivityScoreCount activityScoreCount) {
            this.activityScoreCount = activityScoreCount;
        }

        public CustomerStatusCount getCustomerStatusCount() {
            return customerStatusCount;
        }

        public void setCustomerStatusCount(CustomerStatusCount customerStatusCount) {
            this.customerStatusCount = customerStatusCount;
        }

        public ExpriyStatusCount getExpriyStatusCount() {
            return expriyStatusCount;
        }

        public void setExpriyStatusCount(ExpriyStatusCount expriyStatusCount) {
            this.expriyStatusCount = expriyStatusCount;
        }

        public List<FloatingPointProperty> getFloatingPointProperties() {
            return floatingPointProperties;
        }

        public void setFloatingPointProperties(List<FloatingPointProperty> floatingPointProperties) {
            this.floatingPointProperties = floatingPointProperties;
        }

        public List<String> getFpTags() {
            return fpTags;
        }

        public void setFpTags(List<String> fpTags) {
            this.fpTags = fpTags;
        }

    }

    public class FloatingPointProperty {

        @SerializedName("FPBaseProperties")
        @Expose
        private FPBaseProperties fPBaseProperties;
        @SerializedName("FPExtendedProperties")
        @Expose
        private FPExtendedProperties fPExtendedProperties;

        public FPBaseProperties getFPBaseProperties() {
            return fPBaseProperties;
        }

        public void setFPBaseProperties(FPBaseProperties fPBaseProperties) {
            this.fPBaseProperties = fPBaseProperties;
        }

        public FPExtendedProperties getFPExtendedProperties() {
            return fPExtendedProperties;
        }

        public void setFPExtendedProperties(FPExtendedProperties fPExtendedProperties) {
            this.fPExtendedProperties = fPExtendedProperties;
        }

    }

    public class FPExtendedProperties {

        @SerializedName("AccountManagers")
        @Expose
        private List<AccountManager> accountManagers = null;
        @SerializedName("AverageCustomerRating")
        @Expose
        private Double averageCustomerRating;
        @SerializedName("CustomerEngagementStatus")
        @Expose
        private Double customerEngagementStatus;
        @SerializedName("FpId")
        @Expose
        private String fpId;
        @SerializedName("_id")
        @Expose
        private String id;

        public List<AccountManager> getAccountManagers() {
            return accountManagers;
        }

        public void setAccountManagers(List<AccountManager> accountManagers) {
            this.accountManagers = accountManagers;
        }

        public Double getAverageCustomerRating() {
            return averageCustomerRating;
        }

        public void setAverageCustomerRating(Double averageCustomerRating) {
            this.averageCustomerRating = averageCustomerRating;
        }

        public Double getCustomerEngagementStatus() {
            return customerEngagementStatus;
        }

        public void setCustomerEngagementStatus(Double customerEngagementStatus) {
            this.customerEngagementStatus = customerEngagementStatus;
        }

        public String getFpId() {
            return fpId;
        }

        public void setFpId(String fpId) {
            this.fpId = fpId;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

    }

    public class FPBaseProperties {

        @SerializedName("AliasTag")
        @Expose
        private Object aliasTag;
        @SerializedName("City")
        @Expose
        private String city;
        @SerializedName("ExternalSourceId")
        @Expose
        private Object externalSourceId;
        @SerializedName("ImageUri")
        @Expose
        private Object imageUri;
        @SerializedName("Name")
        @Expose
        private String name;
        @SerializedName("Tag")
        @Expose
        private String tag;
        @SerializedName("TileImageUri")
        @Expose
        private Object tileImageUri;
        @SerializedName("_id")
        @Expose
        private String id;
        @SerializedName("Address")
        @Expose
        private Object address;
        @SerializedName("Category")
        @Expose
        private Object category;
        @SerializedName("Contact")
        @Expose
        private Object contact;
        @SerializedName("ContactName")
        @Expose
        private Object contactName;
        @SerializedName("Contacts")
        @Expose
        private Object contacts;
        @SerializedName("CountryPhoneCode")
        @Expose
        private String countryPhoneCode;
        @SerializedName("Description")
        @Expose
        private String description;
        @SerializedName("Email")
        @Expose
        private String email;
        @SerializedName("ExternalSourceName")
        @Expose
        private Object externalSourceName;
        @SerializedName("ExternalUrls")
        @Expose
        private Object externalUrls;
        @SerializedName("FBPageName")
        @Expose
        private Object fBPageName;
        @SerializedName("IsVerified")
        @Expose
        private Boolean isVerified;
        @SerializedName("OverallRating")
        @Expose
        private Double overallRating;
        @SerializedName("PanaromaId")
        @Expose
        private Object panaromaId;
        @SerializedName("ParentId")
        @Expose
        private Object parentId;
        @SerializedName("PrimaryNumber")
        @Expose
        private String primaryNumber;
        @SerializedName("Pwd")
        @Expose
        private Object pwd;
        @SerializedName("Ratings")
        @Expose
        private Object ratings;
        @SerializedName("SearchTags")
        @Expose
        private Object searchTags;
        @SerializedName("SecondaryImages")
        @Expose
        private Object secondaryImages;
        @SerializedName("SecondaryTileImages")
        @Expose
        private Object secondaryTileImages;
        @SerializedName("SystemGeneratedCategory")
        @Expose
        private Object systemGeneratedCategory;
        @SerializedName("Timings")
        @Expose
        private Object timings;
        @SerializedName("Uri")
        @Expose
        private Object uri;
        @SerializedName("UriDescription")
        @Expose
        private Object uriDescription;
        @SerializedName("errorRadius")
        @Expose
        private Double errorRadius;
        @SerializedName("height")
        @Expose
        private Double height;
        @SerializedName("lat")
        @Expose
        private Double lat;
        @SerializedName("lng")
        @Expose
        private Double lng;
        @SerializedName("EnterpriseEmailContact")
        @Expose
        private Object enterpriseEmailContact;
        @SerializedName("EnterpriseName")
        @Expose
        private Object enterpriseName;
        @SerializedName("FPLocalWidgets")
        @Expose
        private Object fPLocalWidgets;
        @SerializedName("FPWebWidgets")
        @Expose
        private List<String> fPWebWidgets = null;
        @SerializedName("IsStoreFront")
        @Expose
        private Boolean isStoreFront;
        @SerializedName("LogoUrl")
        @Expose
        private String logoUrl;
        @SerializedName("ParentPrimaryNumber")
        @Expose
        private Object parentPrimaryNumber;
        @SerializedName("RootAliasUri")
        @Expose
        private Object rootAliasUri;
        @SerializedName("TinyLogoUrl")
        @Expose
        private Object tinyLogoUrl;
        @SerializedName("WebKeywords")
        @Expose
        private Object webKeywords;
        @SerializedName("WebTemplateType")
        @Expose
        private Double webTemplateType;
        @SerializedName("ApplicationId")
        @Expose
        private Object applicationId;
        @SerializedName("Country")
        @Expose
        private Object country;
        @SerializedName("CreatedOn")
        @Expose
        private String createdOn;
        @SerializedName("FaviconUrl")
        @Expose
        private Object faviconUrl;
        @SerializedName("GADomain")
        @Expose
        private String gADomain;
        @SerializedName("GAToken")
        @Expose
        private String gAToken;
        @SerializedName("IsBulkSubscription")
        @Expose
        private Boolean isBulkSubscription;
        @SerializedName("LanguageCode")
        @Expose
        private String languageCode;
        @SerializedName("NFXAccessTokens")
        @Expose
        private Object nFXAccessTokens;
        @SerializedName("PackageIds")
        @Expose
        private Object packageIds;
        @SerializedName("PaymentLevel")
        @Expose
        private Double paymentLevel;
        @SerializedName("PaymentState")
        @Expose
        private Double paymentState;
        @SerializedName("PinCode")
        @Expose
        private Object pinCode;
        @SerializedName("SMSGatewayUri")
        @Expose
        private Object sMSGatewayUri;
        @SerializedName("AccountManagerId")
        @Expose
        private Object accountManagerId;
        @SerializedName("AccountManagerLocationId")
        @Expose
        private Object accountManagerLocationId;
        @SerializedName("ExpiryDate")
        @Expose
        private String expiryDate;
        @SerializedName("ExpiryType")
        @Expose
        private Double expiryType;
        @SerializedName("FPEngagementIndex")
        @Expose
        private Double fPEngagementIndex;
        @SerializedName("IsEmailSubscriptionEnabled")
        @Expose
        private Boolean isEmailSubscriptionEnabled;
        @SerializedName("IsOnboardingbyRiaTeamComplete")
        @Expose
        private Boolean isOnboardingbyRiaTeamComplete;
        @SerializedName("IsPrivateForApplication")
        @Expose
        private Boolean isPrivateForApplication;
        @SerializedName("IsSMSSubscriptionEnabled")
        @Expose
        private Boolean isSMSSubscriptionEnabled;
        @SerializedName("IsSiteHealthCritical")
        @Expose
        private Boolean isSiteHealthCritical;
        @SerializedName("OnboardingbyRiaTeamCompletedOn")
        @Expose
        private String onboardingbyRiaTeamCompletedOn;
        @SerializedName("PrimaryCategory")
        @Expose
        private Object primaryCategory;
        @SerializedName("ProductCategoryVerb")
        @Expose
        private Object productCategoryVerb;
        @SerializedName("RIANotificationType")
        @Expose
        private String rIANotificationType;
        @SerializedName("ReportsNotificationType")
        @Expose
        private String reportsNotificationType;
        @SerializedName("RootAliasUriStatusUpdate")
        @Expose
        private Double rootAliasUriStatusUpdate;
        @SerializedName("RootAliasUriStatusUpdatedOn")
        @Expose
        private String rootAliasUriStatusUpdatedOn;
        @SerializedName("SearchTrafficNotificationType")
        @Expose
        private String searchTrafficNotificationType;
        @SerializedName("SitemapUrl")
        @Expose
        private Object sitemapUrl;
        @SerializedName("SubscriberNotificationType")
        @Expose
        private String subscriberNotificationType;
        @SerializedName("UpdatedOn")
        @Expose
        private String updatedOn;
        @SerializedName("UserMessageNotificationType")
        @Expose
        private String userMessageNotificationType;
        @SerializedName("WebTemplateId")
        @Expose
        private Object webTemplateId;
        @SerializedName("location")
        @Expose
        private Object location;

        public Object getAliasTag() {
            return aliasTag;
        }

        public void setAliasTag(Object aliasTag) {
            this.aliasTag = aliasTag;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public Object getExternalSourceId() {
            return externalSourceId;
        }

        public void setExternalSourceId(Object externalSourceId) {
            this.externalSourceId = externalSourceId;
        }

        public Object getImageUri() {
            return imageUri;
        }

        public void setImageUri(Object imageUri) {
            this.imageUri = imageUri;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getTag() {
            return tag;
        }

        public void setTag(String tag) {
            this.tag = tag;
        }

        public Object getTileImageUri() {
            return tileImageUri;
        }

        public void setTileImageUri(Object tileImageUri) {
            this.tileImageUri = tileImageUri;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public Object getAddress() {
            return address;
        }

        public void setAddress(Object address) {
            this.address = address;
        }

        public Object getCategory() {
            return category;
        }

        public void setCategory(Object category) {
            this.category = category;
        }

        public Object getContact() {
            return contact;
        }

        public void setContact(Object contact) {
            this.contact = contact;
        }

        public Object getContactName() {
            return contactName;
        }

        public void setContactName(Object contactName) {
            this.contactName = contactName;
        }

        public Object getContacts() {
            return contacts;
        }

        public void setContacts(Object contacts) {
            this.contacts = contacts;
        }

        public String getCountryPhoneCode() {
            return countryPhoneCode;
        }

        public void setCountryPhoneCode(String countryPhoneCode) {
            this.countryPhoneCode = countryPhoneCode;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public Object getExternalSourceName() {
            return externalSourceName;
        }

        public void setExternalSourceName(Object externalSourceName) {
            this.externalSourceName = externalSourceName;
        }

        public Object getExternalUrls() {
            return externalUrls;
        }

        public void setExternalUrls(Object externalUrls) {
            this.externalUrls = externalUrls;
        }

        public Object getFBPageName() {
            return fBPageName;
        }

        public void setFBPageName(Object fBPageName) {
            this.fBPageName = fBPageName;
        }

        public Boolean getIsVerified() {
            return isVerified;
        }

        public void setIsVerified(Boolean isVerified) {
            this.isVerified = isVerified;
        }

        public Double getOverallRating() {
            return overallRating;
        }

        public void setOverallRating(Double overallRating) {
            this.overallRating = overallRating;
        }

        public Object getPanaromaId() {
            return panaromaId;
        }

        public void setPanaromaId(Object panaromaId) {
            this.panaromaId = panaromaId;
        }

        public Object getParentId() {
            return parentId;
        }

        public void setParentId(Object parentId) {
            this.parentId = parentId;
        }

        public String getPrimaryNumber() {
            return primaryNumber;
        }

        public void setPrimaryNumber(String primaryNumber) {
            this.primaryNumber = primaryNumber;
        }

        public Object getPwd() {
            return pwd;
        }

        public void setPwd(Object pwd) {
            this.pwd = pwd;
        }

        public Object getRatings() {
            return ratings;
        }

        public void setRatings(Object ratings) {
            this.ratings = ratings;
        }

        public Object getSearchTags() {
            return searchTags;
        }

        public void setSearchTags(Object searchTags) {
            this.searchTags = searchTags;
        }

        public Object getSecondaryImages() {
            return secondaryImages;
        }

        public void setSecondaryImages(Object secondaryImages) {
            this.secondaryImages = secondaryImages;
        }

        public Object getSecondaryTileImages() {
            return secondaryTileImages;
        }

        public void setSecondaryTileImages(Object secondaryTileImages) {
            this.secondaryTileImages = secondaryTileImages;
        }

        public Object getSystemGeneratedCategory() {
            return systemGeneratedCategory;
        }

        public void setSystemGeneratedCategory(Object systemGeneratedCategory) {
            this.systemGeneratedCategory = systemGeneratedCategory;
        }

        public Object getTimings() {
            return timings;
        }

        public void setTimings(Object timings) {
            this.timings = timings;
        }

        public Object getUri() {
            return uri;
        }

        public void setUri(Object uri) {
            this.uri = uri;
        }

        public Object getUriDescription() {
            return uriDescription;
        }

        public void setUriDescription(Object uriDescription) {
            this.uriDescription = uriDescription;
        }

        public Double getErrorRadius() {
            return errorRadius;
        }

        public void setErrorRadius(Double errorRadius) {
            this.errorRadius = errorRadius;
        }

        public Double getHeight() {
            return height;
        }

        public void setHeight(Double height) {
            this.height = height;
        }

        public Double getLat() {
            return lat;
        }

        public void setLat(Double lat) {
            this.lat = lat;
        }

        public Double getLng() {
            return lng;
        }

        public void setLng(Double lng) {
            this.lng = lng;
        }

        public Object getEnterpriseEmailContact() {
            return enterpriseEmailContact;
        }

        public void setEnterpriseEmailContact(Object enterpriseEmailContact) {
            this.enterpriseEmailContact = enterpriseEmailContact;
        }

        public Object getEnterpriseName() {
            return enterpriseName;
        }

        public void setEnterpriseName(Object enterpriseName) {
            this.enterpriseName = enterpriseName;
        }

        public Object getFPLocalWidgets() {
            return fPLocalWidgets;
        }

        public void setFPLocalWidgets(Object fPLocalWidgets) {
            this.fPLocalWidgets = fPLocalWidgets;
        }

        public List<String> getFPWebWidgets() {
            return fPWebWidgets;
        }

        public void setFPWebWidgets(List<String> fPWebWidgets) {
            this.fPWebWidgets = fPWebWidgets;
        }

        public Boolean getIsStoreFront() {
            return isStoreFront;
        }

        public void setIsStoreFront(Boolean isStoreFront) {
            this.isStoreFront = isStoreFront;
        }

        public String getLogoUrl() {
            return logoUrl;
        }

        public void setLogoUrl(String logoUrl) {
            this.logoUrl = logoUrl;
        }

        public Object getParentPrimaryNumber() {
            return parentPrimaryNumber;
        }

        public void setParentPrimaryNumber(Object parentPrimaryNumber) {
            this.parentPrimaryNumber = parentPrimaryNumber;
        }

        public Object getRootAliasUri() {
            return rootAliasUri;
        }

        public void setRootAliasUri(Object rootAliasUri) {
            this.rootAliasUri = rootAliasUri;
        }

        public Object getTinyLogoUrl() {
            return tinyLogoUrl;
        }

        public void setTinyLogoUrl(Object tinyLogoUrl) {
            this.tinyLogoUrl = tinyLogoUrl;
        }

        public Object getWebKeywords() {
            return webKeywords;
        }

        public void setWebKeywords(Object webKeywords) {
            this.webKeywords = webKeywords;
        }

        public Double getWebTemplateType() {
            return webTemplateType;
        }

        public void setWebTemplateType(Double webTemplateType) {
            this.webTemplateType = webTemplateType;
        }

        public Object getApplicationId() {
            return applicationId;
        }

        public void setApplicationId(Object applicationId) {
            this.applicationId = applicationId;
        }

        public Object getCountry() {
            return country;
        }

        public void setCountry(Object country) {
            this.country = country;
        }

        public String getCreatedOn() {
            return createdOn;
        }

        public void setCreatedOn(String createdOn) {
            this.createdOn = createdOn;
        }

        public Object getFaviconUrl() {
            return faviconUrl;
        }

        public void setFaviconUrl(Object faviconUrl) {
            this.faviconUrl = faviconUrl;
        }

        public String getGADomain() {
            return gADomain;
        }

        public void setGADomain(String gADomain) {
            this.gADomain = gADomain;
        }

        public String getGAToken() {
            return gAToken;
        }

        public void setGAToken(String gAToken) {
            this.gAToken = gAToken;
        }

        public Boolean getIsBulkSubscription() {
            return isBulkSubscription;
        }

        public void setIsBulkSubscription(Boolean isBulkSubscription) {
            this.isBulkSubscription = isBulkSubscription;
        }

        public String getLanguageCode() {
            return languageCode;
        }

        public void setLanguageCode(String languageCode) {
            this.languageCode = languageCode;
        }

        public Object getNFXAccessTokens() {
            return nFXAccessTokens;
        }

        public void setNFXAccessTokens(Object nFXAccessTokens) {
            this.nFXAccessTokens = nFXAccessTokens;
        }

        public Object getPackageIds() {
            return packageIds;
        }

        public void setPackageIds(Object packageIds) {
            this.packageIds = packageIds;
        }

        public Double getPaymentLevel() {
            return paymentLevel;
        }

        public void setPaymentLevel(Double paymentLevel) {
            this.paymentLevel = paymentLevel;
        }

        public Double getPaymentState() {
            return paymentState;
        }

        public void setPaymentState(Double paymentState) {
            this.paymentState = paymentState;
        }

        public Object getPinCode() {
            return pinCode;
        }

        public void setPinCode(Object pinCode) {
            this.pinCode = pinCode;
        }

        public Object getSMSGatewayUri() {
            return sMSGatewayUri;
        }

        public void setSMSGatewayUri(Object sMSGatewayUri) {
            this.sMSGatewayUri = sMSGatewayUri;
        }

        public Object getAccountManagerId() {
            return accountManagerId;
        }

        public void setAccountManagerId(Object accountManagerId) {
            this.accountManagerId = accountManagerId;
        }

        public Object getAccountManagerLocationId() {
            return accountManagerLocationId;
        }

        public void setAccountManagerLocationId(Object accountManagerLocationId) {
            this.accountManagerLocationId = accountManagerLocationId;
        }

        public String getExpiryDate() {
            return expiryDate;
        }

        public void setExpiryDate(String expiryDate) {
            this.expiryDate = expiryDate;
        }

        public Double getExpiryType() {
            return expiryType;
        }

        public void setExpiryType(Double expiryType) {
            this.expiryType = expiryType;
        }

        public Double getFPEngagementIndex() {
            return fPEngagementIndex;
        }

        public void setFPEngagementIndex(Double fPEngagementIndex) {
            this.fPEngagementIndex = fPEngagementIndex;
        }

        public Boolean getIsEmailSubscriptionEnabled() {
            return isEmailSubscriptionEnabled;
        }

        public void setIsEmailSubscriptionEnabled(Boolean isEmailSubscriptionEnabled) {
            this.isEmailSubscriptionEnabled = isEmailSubscriptionEnabled;
        }

        public Boolean getIsOnboardingbyRiaTeamComplete() {
            return isOnboardingbyRiaTeamComplete;
        }

        public void setIsOnboardingbyRiaTeamComplete(Boolean isOnboardingbyRiaTeamComplete) {
            this.isOnboardingbyRiaTeamComplete = isOnboardingbyRiaTeamComplete;
        }

        public Boolean getIsPrivateForApplication() {
            return isPrivateForApplication;
        }

        public void setIsPrivateForApplication(Boolean isPrivateForApplication) {
            this.isPrivateForApplication = isPrivateForApplication;
        }

        public Boolean getIsSMSSubscriptionEnabled() {
            return isSMSSubscriptionEnabled;
        }

        public void setIsSMSSubscriptionEnabled(Boolean isSMSSubscriptionEnabled) {
            this.isSMSSubscriptionEnabled = isSMSSubscriptionEnabled;
        }

        public Boolean getIsSiteHealthCritical() {
            return isSiteHealthCritical;
        }

        public void setIsSiteHealthCritical(Boolean isSiteHealthCritical) {
            this.isSiteHealthCritical = isSiteHealthCritical;
        }

        public String getOnboardingbyRiaTeamCompletedOn() {
            return onboardingbyRiaTeamCompletedOn;
        }

        public void setOnboardingbyRiaTeamCompletedOn(String onboardingbyRiaTeamCompletedOn) {
            this.onboardingbyRiaTeamCompletedOn = onboardingbyRiaTeamCompletedOn;
        }

        public Object getPrimaryCategory() {
            return primaryCategory;
        }

        public void setPrimaryCategory(Object primaryCategory) {
            this.primaryCategory = primaryCategory;
        }

        public Object getProductCategoryVerb() {
            return productCategoryVerb;
        }

        public void setProductCategoryVerb(Object productCategoryVerb) {
            this.productCategoryVerb = productCategoryVerb;
        }

        public String getRIANotificationType() {
            return rIANotificationType;
        }

        public void setRIANotificationType(String rIANotificationType) {
            this.rIANotificationType = rIANotificationType;
        }

        public String getReportsNotificationType() {
            return reportsNotificationType;
        }

        public void setReportsNotificationType(String reportsNotificationType) {
            this.reportsNotificationType = reportsNotificationType;
        }

        public Double getRootAliasUriStatusUpdate() {
            return rootAliasUriStatusUpdate;
        }

        public void setRootAliasUriStatusUpdate(Double rootAliasUriStatusUpdate) {
            this.rootAliasUriStatusUpdate = rootAliasUriStatusUpdate;
        }

        public String getRootAliasUriStatusUpdatedOn() {
            return rootAliasUriStatusUpdatedOn;
        }

        public void setRootAliasUriStatusUpdatedOn(String rootAliasUriStatusUpdatedOn) {
            this.rootAliasUriStatusUpdatedOn = rootAliasUriStatusUpdatedOn;
        }

        public String getSearchTrafficNotificationType() {
            return searchTrafficNotificationType;
        }

        public void setSearchTrafficNotificationType(String searchTrafficNotificationType) {
            this.searchTrafficNotificationType = searchTrafficNotificationType;
        }

        public Object getSitemapUrl() {
            return sitemapUrl;
        }

        public void setSitemapUrl(Object sitemapUrl) {
            this.sitemapUrl = sitemapUrl;
        }

        public String getSubscriberNotificationType() {
            return subscriberNotificationType;
        }

        public void setSubscriberNotificationType(String subscriberNotificationType) {
            this.subscriberNotificationType = subscriberNotificationType;
        }

        public String getUpdatedOn() {
            return updatedOn;
        }

        public void setUpdatedOn(String updatedOn) {
            this.updatedOn = updatedOn;
        }

        public String getUserMessageNotificationType() {
            return userMessageNotificationType;
        }

        public void setUserMessageNotificationType(String userMessageNotificationType) {
            this.userMessageNotificationType = userMessageNotificationType;
        }

        public Object getWebTemplateId() {
            return webTemplateId;
        }

        public void setWebTemplateId(Object webTemplateId) {
            this.webTemplateId = webTemplateId;
        }

        public Object getLocation() {
            return location;
        }

        public void setLocation(Object location) {
            this.location = location;
        }

    }

    public class ExpriyStatusCount {

        @SerializedName("ActiveAccountsCount")
        @Expose
        private Double activeAccountsCount;
        @SerializedName("ExpiredAccountsCount")
        @Expose
        private Double expiredAccountsCount;
        @SerializedName("GraceAccountsCount")
        @Expose
        private Double graceAccountsCount;

        public Double getActiveAccountsCount() {
            return activeAccountsCount;
        }

        public void setActiveAccountsCount(Double activeAccountsCount) {
            this.activeAccountsCount = activeAccountsCount;
        }

        public Double getExpiredAccountsCount() {
            return expiredAccountsCount;
        }

        public void setExpiredAccountsCount(Double expiredAccountsCount) {
            this.expiredAccountsCount = expiredAccountsCount;
        }

        public Double getGraceAccountsCount() {
            return graceAccountsCount;
        }

        public void setGraceAccountsCount(Double graceAccountsCount) {
            this.graceAccountsCount = graceAccountsCount;
        }

    }

    public class Error {

        @SerializedName("ErrorCode")
        @Expose
        private Object errorCode;
        @SerializedName("ErrorList")
        @Expose
        private Object errorList;

        public Object getErrorCode() {
            return errorCode;
        }

        public void setErrorCode(Object errorCode) {
            this.errorCode = errorCode;
        }

        public Object getErrorList() {
            return errorList;
        }

        public void setErrorList(Object errorList) {
            this.errorList = errorList;
        }

    }

    public class CustomerStatusCount {

        @SerializedName("BusinessClosedCount")
        @Expose
        private Double businessClosedCount;
        @SerializedName("ColdCustomersCount")
        @Expose
        private Double coldCustomersCount;
        @SerializedName("InterestedCustomerCount")
        @Expose
        private Double interestedCustomerCount;
        @SerializedName("NotInterestedCustomerCount")
        @Expose
        private Double notInterestedCustomerCount;

        public Double getBusinessClosedCount() {
            return businessClosedCount;
        }

        public void setBusinessClosedCount(Double businessClosedCount) {
            this.businessClosedCount = businessClosedCount;
        }

        public Double getColdCustomersCount() {
            return coldCustomersCount;
        }

        public void setColdCustomersCount(Double coldCustomersCount) {
            this.coldCustomersCount = coldCustomersCount;
        }

        public Double getInterestedCustomerCount() {
            return interestedCustomerCount;
        }

        public void setInterestedCustomerCount(Double interestedCustomerCount) {
            this.interestedCustomerCount = interestedCustomerCount;
        }

        public Double getNotInterestedCustomerCount() {
            return notInterestedCustomerCount;
        }

        public void setNotInterestedCustomerCount(Double notInterestedCustomerCount) {
            this.notInterestedCustomerCount = notInterestedCustomerCount;
        }

    }

    public class ActivityScoreCount {

        @SerializedName("HighActivityScoreCount")
        @Expose
        private Double highActivityScoreCount;
        @SerializedName("LowActivityScoreCount")
        @Expose
        private Double lowActivityScoreCount;

        public Double getHighActivityScoreCount() {
            return highActivityScoreCount;
        }

        public void setHighActivityScoreCount(Double highActivityScoreCount) {
            this.highActivityScoreCount = highActivityScoreCount;
        }

        public Double getLowActivityScoreCount() {
            return lowActivityScoreCount;
        }

        public void setLowActivityScoreCount(Double lowActivityScoreCount) {
            this.lowActivityScoreCount = lowActivityScoreCount;
        }

    }

    public class AccountManager {

        @SerializedName("ProfileAccessType")
        @Expose
        private Double profileAccessType;
        @SerializedName("ProfileId")
        @Expose
        private String profileId;
        @SerializedName("ProfileRoleType")
        @Expose
        private Double profileRoleType;

        public Double getProfileAccessType() {
            return profileAccessType;
        }

        public void setProfileAccessType(Double profileAccessType) {
            this.profileAccessType = profileAccessType;
        }

        public String getProfileId() {
            return profileId;
        }

        public void setProfileId(String profileId) {
            this.profileId = profileId;
        }

        public Double getProfileRoleType() {
            return profileRoleType;
        }

        public void setProfileRoleType(Double profileRoleType) {
            this.profileRoleType = profileRoleType;
        }

    }
}
