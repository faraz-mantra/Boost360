package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CheckIfFpHasLeadResponse {

    @SerializedName("leadNumber")
    @Expose
    private String leadNumber;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("businessName")
    @Expose
    private String businessName;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("editQuote")
    @Expose
    private String editQuote;
    @SerializedName("convert")
    @Expose
    private String convert;

    public String getLeadNumber() {
        return leadNumber;
    }

    public void setLeadNumber(String leadNumber) {
        this.leadNumber = leadNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEditQuote() {
        return editQuote;
    }

    public void setEditQuote(String editQuote) {
        this.editQuote = editQuote;
    }

    public String getConvert() {
        return convert;
    }

    public void setConvert(String convert) {
        this.convert = convert;
    }

}
