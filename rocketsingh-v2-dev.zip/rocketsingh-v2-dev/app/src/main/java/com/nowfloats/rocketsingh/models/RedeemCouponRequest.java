package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RedeemCouponRequest {

    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("couponCode")
    @Expose
    private String couponCode;
    @SerializedName("toRedeem")
    @Expose
    private Boolean toRedeem;
    @SerializedName("externalSourceName")
    @Expose
    private String externalSourceName;
    @SerializedName("externalSourceId")
    @Expose
    private String externalSourceId;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public Boolean getToRedeem() {
        return toRedeem;
    }

    public void setToRedeem(Boolean toRedeem) {
        this.toRedeem = toRedeem;
    }

    public String getExternalSourceName() {
        return externalSourceName;
    }

    public void setExternalSourceName(String externalSourceName) {
        this.externalSourceName = externalSourceName;
    }

    public String getExternalSourceId() {
        return externalSourceId;
    }

    public void setExternalSourceId(String externalSourceId) {
        this.externalSourceId = externalSourceId;
    }

}