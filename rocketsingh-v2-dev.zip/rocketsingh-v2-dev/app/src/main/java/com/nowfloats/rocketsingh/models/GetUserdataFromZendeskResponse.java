package com.nowfloats.rocketsingh.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetUserdataFromZendeskResponse {

    @SerializedName("users")
    @Expose
    private List<User> users = null;
    @SerializedName("next_page")
    @Expose
    private Object nextPage;
    @SerializedName("previous_page")
    @Expose
    private Object previousPage;
    @SerializedName("count")
    @Expose
    private long count;

    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    public GetUserdataFromZendeskResponse withUsers(List<User> users) {
        this.users = users;
        return this;
    }

    public Object getNextPage() {
        return nextPage;
    }

    public void setNextPage(Object nextPage) {
        this.nextPage = nextPage;
    }

    public GetUserdataFromZendeskResponse withNextPage(Object nextPage) {
        this.nextPage = nextPage;
        return this;
    }

    public Object getPreviousPage() {
        return previousPage;
    }

    public void setPreviousPage(Object previousPage) {
        this.previousPage = previousPage;
    }

    public GetUserdataFromZendeskResponse withPreviousPage(Object previousPage) {
        this.previousPage = previousPage;
        return this;
    }

    public long getCount() {
        return count;
    }

    public void setCount(long count) {
        this.count = count;
    }

    public GetUserdataFromZendeskResponse withCount(long count) {
        this.count = count;
        return this;
    }


    public class User {

        @SerializedName("id")
        @Expose
        private long id;
        @SerializedName("email")
        @Expose
        private String email;
        @SerializedName("external_id")
        @Expose
        private Object externalId;

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public User withId(long id) {
            this.id = id;
            return this;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public User withEmail(String email) {
            this.email = email;
            return this;
        }

        public Object getExternalId() {
            return externalId;
        }

        public void setExternalId(Object externalId) {
            this.externalId = externalId;
        }

        public User withExternalId(Object externalId) {
            this.externalId = externalId;
            return this;
        }

    }

}