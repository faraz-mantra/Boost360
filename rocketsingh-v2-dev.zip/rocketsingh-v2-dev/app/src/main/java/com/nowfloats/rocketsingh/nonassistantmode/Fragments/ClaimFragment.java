package com.nowfloats.rocketsingh.nonassistantmode.Fragments;

import android.app.Dialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.CheckIfFpHasLeadResponse;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomEditText;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.tanmay.nf.rocketimagepicker.RocketImageInterface;
import com.tanmay.nf.rocketimagepicker.RocketImagePicker;
import com.tfb.fbtoast.FBToast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

public class ClaimFragment extends DialogFragment implements RocketImageInterface {

    private CheckIfFpHasLeadResponse checkIfFpHasLeadResponse;
    public static RocketImagePicker rocketImagePicker;
    private Bitmap receiptImage;
    private ImageView im_receipt;
    private String imageName;
    private CustomEditText et_claimId;
    private Button bt_upload , bt_claim;
    private final int UPLOAD_RECEIPT_IMAGE = 32;
    private ClaimInterface claimInterface;

    public static ClaimFragment getInstance(ClaimInterface claimInterface ,
                                            CheckIfFpHasLeadResponse checkIfFpHasLeadResponse){
        ClaimFragment claimFragment = new ClaimFragment();
        claimFragment.checkIfFpHasLeadResponse = checkIfFpHasLeadResponse;
        claimFragment.claimInterface = claimInterface;
        return claimFragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_claim , container ,false);
        initaliseViews(v);
        displayCustomerDetails(v);
        return v;
    }

    private void displayCustomerDetails(View v) {
        ((TextView)v.findViewById(R.id.tv_customerNumber)).append(checkIfFpHasLeadResponse.getLeadNumber());
        ((TextView)v.findViewById(R.id.tv_customerName)).append(checkIfFpHasLeadResponse.getName());
        ((TextView)v.findViewById(R.id.tv_businessName)).append(checkIfFpHasLeadResponse.getBusinessName());
        ((TextView)v.findViewById(R.id.tv_primaryNumber)).append(checkIfFpHasLeadResponse.getMobile());
    }

    private void initaliseViews(View v){

        bt_claim = v.findViewById(R.id.bt_claim);
        bt_upload = v.findViewById(R.id.bt_upload);
        im_receipt = v.findViewById(R.id.im_receipt);
        et_claimId = v.findViewById(R.id.et_claim);

        bt_upload.setOnClickListener( view -> {
            if(receiptImage == null ){
                uploadImage();
            }else{
                bt_upload.setText(getString(R.string.upload_receipt));
                im_receipt.setVisibility(View.GONE);
                receiptImage = null;
            }
        });

        bt_claim.setOnClickListener(view -> {
            if(ExternalProcessManager.stringIsNull(et_claimId.getText().toString())) {
                showSnackbarMessage("Please enter a claim ID");
            }else if(receiptImage == null){
                showSnackbarMessage("Please upload a receipt image");
            }else{
                claimInterface.getClaimId(et_claimId.getText().toString(),receiptImage , imageName);
            }
        });
    }

    private void uploadImage(){
        rocketImagePicker = new RocketImagePicker((AppCompatActivity) getActivity() , this);
        rocketImagePicker.invokeImagePicker(UPLOAD_RECEIPT_IMAGE);
    }

    @Override
    public void onImagePickerPermissionDenied(int imageRequestCode) {
        showSnackbarMessage("Sorry unable to fetch image. This permision is compulsary");
    }

    @Override
    public void onImageSupplied(Bitmap bitmap, int imageRequestCode, String imageName) {
       this.imageName = imageName;
       receiptImage = bitmap;
       im_receipt.setImageBitmap(bitmap);
       bt_upload.setText("Remove");
    }

    @Override
    public void onImagePickFail(int imageRequestCode) {
        showSnackbarMessage("Sorry unable to fetch image");
    }

    private void showSnackbarMessage(String message){
        FBToast.errorToast(getActivity(),message,FBToast.LENGTH_SHORT);
    }

    public interface ClaimInterface{
        void getClaimId(String claimId , Bitmap receiptImage , String imageName);
    }

    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null)
        {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
        }

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getDialog() != null)
            getDialog().getWindow()
                    .getAttributes().windowAnimations = R.style.DialogAnimation;
    }
}
