package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetFPIdRequest {

    @SerializedName("method")
    @Expose
    private String method;
    @SerializedName("jsonrpc")
    @Expose
    private String jsonrpc;
    @SerializedName("params")
    @Expose
    private Params params;

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public GetFPIdRequest withMethod(String method) {
        this.method = method;
        return this;
    }

    public String getJsonrpc() {
        return jsonrpc;
    }

    public void setJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
    }

    public GetFPIdRequest withJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
        return this;
    }

    public Params getParams() {
        return params;
    }

    public void setParams(Params params) {
        this.params = params;
    }

    public GetFPIdRequest withParams(Params params) {
        this.params = params;
        return this;
    }

    public static class Params {

        @SerializedName("service")
        @Expose
        private String service;
        @SerializedName("method")
        @Expose
        private String method;
        @SerializedName("args")
        @Expose
        private List<Object> args = null;

        public String getService() {
            return service;
        }

        public void setService(String service) {
            this.service = service;
        }

        public Params withService(String service) {
            this.service = service;
            return this;
        }

        public String getMethod() {
            return method;
        }

        public void setMethod(String method) {
            this.method = method;
        }

        public Params withMethod(String method) {
            this.method = method;
            return this;
        }

        public List<Object> getArgs() {
            return args;
        }

        public void setArgs(List<Object> args) {
            this.args = args;
        }

        public Params withArgs(List<Object> args) {
            this.args = args;
            return this;
        }

        public static class HotProspectId{
            @SerializedName("hotProspectId")
            @Expose
            private int hotProspectId;

            public int getHotProspectId() {
                return hotProspectId;
            }

            public void setHotProspectId(int hotProspectId) {
                this.hotProspectId = hotProspectId;
            }
        }

    }

}