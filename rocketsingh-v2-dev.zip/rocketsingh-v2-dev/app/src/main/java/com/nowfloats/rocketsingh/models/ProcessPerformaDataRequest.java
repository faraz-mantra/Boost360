package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ProcessPerformaDataRequest {

    @SerializedName("saleType")
    @Expose
    private String saleType;
    @SerializedName("packageName")
    @Expose
    private String packageName;
    @SerializedName("qty")
    @Expose
    private Double qty;
    @SerializedName("discountPercent")
    @Expose
    private Double discountPercent;
    @SerializedName("solId")
    @Expose
    private Integer solId;
    @SerializedName("spDivision")
    @Expose
    private String spDivision;
    @SerializedName("fpTag")
    @Expose
    private String fpTag;
    @SerializedName("packageId")
    @Expose
    private String packageId;

    public String getSaleType() {
        return saleType;
    }

    public void setSaleType(String saleType) {
        this.saleType = saleType;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public Double getQty() {
        return qty;
    }

    public void setQty(Double qty) {
        this.qty = qty;
    }

    public Double getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(Double discountPercent) {
        this.discountPercent = discountPercent;
    }

    public Integer getSolId() {
        return solId;
    }

    public void setSolId(Integer solId) {
        this.solId = solId;
    }

    public String getSpDivision() {
        return spDivision;
    }

    public void setSpDivision(String spDivision) {
        this.spDivision = spDivision;
    }

    public String getFpTag() {
        return fpTag;
    }

    public void setFpTag(String fpTag) {
        this.fpTag = fpTag;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

}