
        package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetQuotationNumberRequest {

    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("email")
    @Expose
    private String email;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public GetQuotationNumberRequest withClientId(String clientId) {
        this.clientId = clientId;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public GetQuotationNumberRequest withEmail(String email) {
        this.email = email;
        return this;
    }

}