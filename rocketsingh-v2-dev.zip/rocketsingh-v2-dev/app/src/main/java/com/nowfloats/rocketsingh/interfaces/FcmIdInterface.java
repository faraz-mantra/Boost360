package com.nowfloats.rocketsingh.interfaces;

import com.nowfloats.rocketsingh.models.AddFCMDataRequest;
import com.nowfloats.rocketsingh.models.GetFCMDataResponse;
import com.nowfloats.rocketsingh.models.UpdateFcmDataRequest;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.Headers;
import retrofit.http.POST;
import retrofit.http.Query;

/**
 * Created by NowFloats on 17-Oct-17.
 */

public interface FcmIdInterface {

    @Headers({"Authorization: 59a7d4ad20320013d43d041d"})
    @GET("/api/v1/rsfcmids/get-data")
    void getFCMData(@Query("query") String query, Callback<GetFCMDataResponse> callback);

    @Headers({"Content-Type: application/json","Authorization: 59a7d4ad20320013d43d041d"})
    @POST("/api/v1/rsfcmids/update-data")
    void updateFCMData(@Query("id") String id, @Body UpdateFcmDataRequest model, Callback<String> response);

    @Headers({"Content-Type: application/json","Authorization: 59a7d4ad20320013d43d041d"})
    @POST("/api/v1/rsfcmids/add-data")
    void postFCMData(@Body AddFCMDataRequest model, Callback<String> response);
}
