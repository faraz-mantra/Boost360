package com.nowfloats.rocketsingh.interfaces;

import com.nowfloats.rocketsingh.models.CfLoginRequest;
import com.nowfloats.rocketsingh.models.CfLoginResponse;
import com.nowfloats.rocketsingh.models.EmployeesRankResponse;
import com.nowfloats.rocketsingh.models.GetAssignedCHCForPartnerRequest;
import com.nowfloats.rocketsingh.models.GetAssignedCHCForPartnerResponse;
import com.nowfloats.rocketsingh.models.GetDafDataResponse;
import com.nowfloats.rocketsingh.models.GetEmployeeDetailsRequest;
import com.nowfloats.rocketsingh.models.GetEmployeeDetailsResponse;
import com.nowfloats.rocketsingh.models.GetSalesPerformanceResponse;
import com.nowfloats.rocketsingh.models.GetVersionData;
import com.nowfloats.rocketsingh.models.MeetingsStatsForCFResponse;
import com.nowfloats.rocketsingh.models.SendQuotationResponseModel;

import org.json.JSONObject;

import java.util.List;
import java.util.Map;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.Headers;
import retrofit.http.POST;
import retrofit.http.Query;
import retrofit.http.QueryMap;

/**
 * Created by NowFloats on 12-Jan-18.
 */

public interface SignupInterface {

    @Headers({"Authorization: 59a7d4ad20320013d43d041d"})
    @GET("/api/v1/discountapprovalform/get-data")
    void getDafData(@Query("query") String query, Callback<GetDafDataResponse> callback);

    @POST("/user/v1/partner/verify")
    void verifyCFLogin(@Body CfLoginRequest model, Callback<CfLoginResponse> response);

    @Headers({"Content-Type: application/json","Connection:close"})
    @POST("/v1/GetSpecificEmployees")
    void checkEmployeeDivision(@Body GetEmployeeDetailsRequest model, Callback<List<GetEmployeeDetailsResponse>> response);

    @Headers({"Authorization: 59a7d4ad20320013d43d041d"})
    @GET("/api/v1/rsVersionControl/get-data")
    void getVersionData(Callback<GetVersionData> callback);

    @GET("/api/DiscountApproval/GetPerformanceData")
    void getPerformanceData(@Query("emailId") String emailId, Callback<GetSalesPerformanceResponse> callback);

    @POST("/Support/v1/CHC/GetCHCDetailsForPartner?customerEngagementStatus=-1")
    void getAssignedCHC(@QueryMap Map<String,String> queryMap, @Body GetAssignedCHCForPartnerRequest model, Callback<GetAssignedCHCForPartnerResponse> callback);

    @GET("/api/SalesProcess/GetUpgradePackages")
    void getUpgradePackages(@Query("fpTag") String fpTag, Callback<JSONObject> callback);

    @GET("/boost-content-cdn/reporting_framework_15_May/category_list.txt")
    void getCategories(Callback<JSONObject> callback);

    @POST("/api/RIASupportTeam/ListMeetingStatisticsForMultipleFpTagsForCF")
    void getCFMeetingSummary(@QueryMap Map<String, String> queryMap, @Body List<String> fpTags, Callback<MeetingsStatsForCFResponse> callback);

    @Headers({"Content-Type: application/json"})
    @GET("/v1/FosRank")
    void getEmployeeRank(@QueryMap Map<String,String> queryMap, Callback<List<EmployeesRankResponse>> callback);

    @GET("/api/SalesProcess/SendQuotation")
    void sendQuotation(@QueryMap Map<String,String> queryMap  , Callback<SendQuotationResponseModel> callback);

    @GET("/api/User/CheckIfUserIsAdmin")
    void checkIfUserIsAdmin(@Query("email") String email , Callback<String> callback);
}
