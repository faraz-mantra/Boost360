package com.nowfloats.rocketsingh.nonassistantmode.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;

import com.anachat.chatsdk.AnaChatBuilder;
import com.anachat.chatsdk.LocationPickListener;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.models.AddDiscountRequest;
import com.nowfloats.rocketsingh.models.ProcessPerformaDataRequest;
import com.nowfloats.rocketsingh.models.WebActionRequestGenericModel;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.GetQuotationDetailsFragment;
import com.nowfloats.rocketsingh.models.CheckIfFpHasLeadResponse;
import com.nowfloats.rocketsingh.models.PIDetailsResponse;
import com.nowfloats.rocketsingh.models.SingleProductModel;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.GetFPDetailsFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.SidePanelFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.NetworkResultInterface;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomEditText;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader.CustomLoaderDialog;
import com.nowfloats.rocketsingh.nonassistantmode.UI.FinalResultDialog;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.FPSessionManager;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.FLOW_SESSIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NetworkHandler;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.UserSessionManager;
import com.tanmay.nf.rocketimagepicker.RocketImageInterface;
import com.tanmay.nf.rocketimagepicker.RocketImagePicker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class DiscountActivity extends AppCompatActivity implements
        NetworkResultInterface,GetFPDetailsFragment.onFPDetailsSubmittedInterface,
        GetQuotationDetailsFragment.OnQuotationSubmittedInterface  {

    private NetworkHandler networkHandler;
    private ViewGroup parentLayout;
    private GetFPDetailsFragment getFPDetailsFragment;
    private String discountReason;
    private List<SingleProductModel> singleProductModelList = new ArrayList<>();
    private String fpTag ;

    private PIDetailsResponse piDetailsResponse;
    private CheckIfFpHasLeadResponse checkIfFpHasLeadResponse ;
    private HashMap<NETWORK_OPERATIONS , Object> requestBodies = new HashMap<>();
    private String productName = "";
    private CustomLoaderDialog customLoaderDialog;

    private double discountPercentage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discount);
        setUpUIComponenets();
        setupDrawerLayout();

    }

    private void setupNetworkOperations(){
        Queue<NETWORK_OPERATIONS> networkOperations = new LinkedList<>();

        networkOperations.add(NETWORK_OPERATIONS.GET_FP_DETAILS);
        networkOperations.add(NETWORK_OPERATIONS.GET_PACKAGES);
        networkOperations.add(NETWORK_OPERATIONS.CHECK_IF_LEAD_HAS_FP);

        networkHandler = new NetworkHandler(this , this)
                .setNetworkOperationQueue(networkOperations)
                .setNetworkOperationRequestBody(requestBodies)
                .setOrUpdateSession(FLOW_SESSIONS.DISCOUNT.FP_DETAILS)
                .startThread();

        changeProgress(0 , false);
        changeProgress(10 , true);

    }

    private void continueNetworkOperations(short session){

        requestBodies.clear();
        if(session == FLOW_SESSIONS.DISCOUNT.QUOTATION_DETAILS) {
            Queue<NETWORK_OPERATIONS> networkOperations = new LinkedList<>();

            networkOperations.add(NETWORK_OPERATIONS.CREATE_EDIT_QUOTATION);
            networkOperations.add(NETWORK_OPERATIONS.PI_DETAILS);
            networkOperations.add(NETWORK_OPERATIONS.ADD_DISCOUNT_DATA);

            networkHandler = new NetworkHandler(this , this)
                        .setNetworkOperationQueue(networkOperations)
                        .setNetworkOperationRequestBody(requestBodies)
                        .setOrUpdateSession(FLOW_SESSIONS.DISCOUNT.QUOTATION_DETAILS)
                        .startThread();
        }
    }




    private void setUpUIComponenets(){
        parentLayout = findViewById(R.id.discount_parentLayout);

        getFpDetailsFragment();
    }

    private void getFpDetailsFragment(){
        getFPDetailsFragment  = GetFPDetailsFragment.newInstance(this);
        getSupportFragmentManager().beginTransaction().add(R.id.discount_parentLayout,  getFPDetailsFragment).commit();
    }

    @Override
    public void onApiRequestStarted(NETWORK_OPERATIONS network_operations) {
        initiateApiState(network_operations);
    }

    private void initiateApiState(NETWORK_OPERATIONS network_operations) {
        if(dialogIsValid()) {
            customLoaderDialog.initiateApiState(network_operations);
            return;
        }else {
            showDialog();
           new Handler().postDelayed(() -> {customLoaderDialog.initiateApiState(network_operations);} , 0);
        }

    }


    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey , String message) {
        // state of the last API call  should be changed in the UI before another api call is initiated
        handleUIOperations(operationKey , true , message);
        networkHandler.executeNext();

    }


    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, Object model , String message) {

      // state of the last API call  should be changed in the UI before another api call is initiated

        handleUIOperations(operationKey , true ,  message);

        if(operationKey == NETWORK_OPERATIONS.CHECK_IF_LEAD_HAS_FP && model instanceof CheckIfFpHasLeadResponse) {
            checkIfFpHasLeadResponse = (CheckIfFpHasLeadResponse)model;
        }else if(operationKey == NETWORK_OPERATIONS.GET_PACKAGES && model instanceof List) {
            singleProductModelList = (List<SingleProductModel>)model;
        }else if(operationKey == NETWORK_OPERATIONS.PI_DETAILS) {
            if(model instanceof PIDetailsResponse)
                piDetailsResponse = (PIDetailsResponse)model;
        }

        networkHandler.executeNext();
    }

    @Override
    public void onApiFail(NETWORK_OPERATIONS operationKey, String errorMessage) {
        getFPDetailsFragment.processFail("Please try again");
        networkHandler.clearNetworkQueue();
        handleUIOperations(operationKey , false , errorMessage);
        showSnackbarMessage(errorMessage , false);

    }


    @Override
    public void networkOperationsFinished(boolean success , short session) {
        if(session == FLOW_SESSIONS.DISCOUNT.FP_DETAILS) {
            showSnackbarMessage("Please proceed further " , success);
            endProgress(false , success , "Proceed further");
            hideDialog(false);
            goToQuotationsFragment(true);
        }else if (session == FLOW_SESSIONS.DISCOUNT.QUOTATION_DETAILS){
            String message = "Discount has been applied successfully\nYou can check your discount approval status from menu .";
            showSnackbarMessage("Discount applied" , success);
            endProgress(false , success , message);
            finishApiProcessAnimation(message);
            hideDialog(true);
        }
    }

    private void handleUIOperations(NETWORK_OPERATIONS operationKey , boolean success , String message){
        updateApiStateInFpFragment(operationKey , message , success);
        switch (operationKey) {
            case GET_FP_DETAILS:
                changeProgress(30 , false);
                break;
            case GET_PACKAGES:
                changeProgress(50 , false);
                break;
            case CHECK_IF_LEAD_HAS_FP:
                changeProgress(100 , true);
                break;

        }
    }

    public void changeProgress(int progress , boolean delay) {
        if(getFPDetailsFragment != null ){
            if(getFPDetailsFragment.isAttached) {
                if(!delay) {
                    getFPDetailsFragment.changeProgress(progress);
                }else{
                    new Handler().postDelayed(() -> getFPDetailsFragment.changeProgress(progress),400);
                }
            }
        }
    }

    public void endProgress(boolean delay , boolean success , String message){
        if(getFPDetailsFragment != null ){
            if(getFPDetailsFragment.isAttached) {
                if(! delay ){
                   if(success) {
                       getFPDetailsFragment.processSuccess(message);
                   }else{
                       getFPDetailsFragment.processFail(message);
                   }
                }else{
                    new Handler().postDelayed(() -> endProgress(false , success , message), 300);
                }
            }
        }
    }

    private void goToQuotationsFragment(boolean delay){

        GetQuotationDetailsFragment getQuotationDetailsFragment = GetQuotationDetailsFragment
                .newInstance(this)
                .populateObjects(singleProductModelList , checkIfFpHasLeadResponse);

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.setCustomAnimations(R.anim.slide_in_left_dialog , R.anim.slide_out_left_dialog);
        fragmentTransaction.replace(R.id.discount_parentLayout , getQuotationDetailsFragment);
        new Handler().postDelayed(() -> fragmentTransaction.commit() , delay ? 1000 : 0);


    }

    @Override
    public void onFpDetailsSubmitted(String fpTag) {
     if(TextUtils.isEmpty(fpTag)) {
         showSnackbarMessage("Customer tag can't be empty" , false);
         return;
     }
     this.fpTag = fpTag;
     setupNetworkOperations();

    }



    @Override
    public void hideKeyboard(CustomEditText customEditText) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert imm != null;
        imm.hideSoftInputFromWindow(customEditText.getApplicationWindowToken(), 0);
    }


    public void updateApiStateInFpFragment(NETWORK_OPERATIONS network_operations , String message , boolean success) {
        Log.i(DiscountActivity.class.getSimpleName() + " :" + network_operations.toString(), message);
        if (success) {
            updateApiForSuccess(network_operations, message);

        } else {
            updateApiForFailure(network_operations, message);
        }
    }

    private void updateApiForSuccess(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForSuccess(network_operations , message);
        }
    }

    private void updateApiForFailure(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForFailure(network_operations, message);
            hideDialog(true);
        }
    }


    private void showSnackbarMessage(String message , boolean success){
      Snackbar snackbar =   Snackbar.make(parentLayout , message , Snackbar.LENGTH_LONG);
      if( !success ) {
          snackbar.getView().setBackgroundColor(ContextCompat.getColor(this , R.color.red));
      }else{
          snackbar.getView().setBackgroundColor(ContextCompat.getColor(this , R.color.green));
      }
      snackbar.show();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(networkHandler != null ){
            networkHandler.stopNetworkExecution();
        }
    }


    @Override
    public void onQuotationSubmitted(SingleProductModel selectedProduct , String discountPercentage , String discountSubmitted) {

        if(selectedProduct == null ){
            showSnackbarMessage("Please select a product" , false);
            return ;
        }

        if(TextUtils.isEmpty(discountPercentage)) {
            showSnackbarMessage("Please enter a valid discount percentage" , false);
            return ;
        }

        if(TextUtils.isEmpty(discountSubmitted)) {
            showSnackbarMessage("Please enter a discount reason" , false);
            return;
        }

        if(discountSubmitted.trim().length() <= 140) {
            showSnackbarMessage("Please enter a valid discounr reason ( minimum 140 characters)" , false);
            return;
        }

        this.productName = selectedProduct.getName();
        this.discountReason = discountSubmitted;

        try{
            this.discountPercentage = Double.parseDouble(discountPercentage);
        }catch (Exception e){
            showSnackbarMessage("Please enter a valid discount percentage" , false);
            return ;
        }

        continueNetworkOperations(FLOW_SESSIONS.DISCOUNT.QUOTATION_DETAILS);

    }

    public void prepareRequestBody(NETWORK_OPERATIONS network_operations , NetworkHandler networkHandler){

        switch (network_operations) {
            case CREATE_EDIT_QUOTATION:
                HashMap<String,String> params = new HashMap<>();
                params.put("productName"  , productName);
                params.put("leadNumber" , checkIfFpHasLeadResponse.getLeadNumber());
                params.put("edit" , checkIfFpHasLeadResponse.getEditQuote());
                networkHandler.updateRequestBody(network_operations , params);
                break;
            case GET_FP_DETAILS:
                networkHandler.updateRequestBody(network_operations , fpTag);
                break;
            case PI_DETAILS:
                HashMap<String,String> userData = new HashMap<>();
                userData.put("clientId" , Constants.ERPClientId);
                userData.put("leadNumber" , checkIfFpHasLeadResponse.getLeadNumber());
                networkHandler.updateRequestBody(network_operations,userData);
                break;

            case PROCESS_PERFORMA_DATA:
                ProcessPerformaDataRequest processPerformaDataRequest = new ProcessPerformaDataRequest();
                processPerformaDataRequest.setSaleType(piDetailsResponse.getTypeOfSale());
                processPerformaDataRequest.setDiscountPercent(discountPercentage);
                processPerformaDataRequest.setPackageName(productName);
                processPerformaDataRequest.setQty(1.0);
                processPerformaDataRequest.setSolId(piDetailsResponse.getSolId());
                processPerformaDataRequest.setSpDivision(piDetailsResponse.getSpDivision());
                processPerformaDataRequest.setFpTag(new FPSessionManager(this).getFpTag());
                processPerformaDataRequest.setPackageId(piDetailsResponse.getPackageId());

                List<ProcessPerformaDataRequest> processPerformaDataRequests = new ArrayList<>();
                processPerformaDataRequests.add(processPerformaDataRequest);

                networkHandler.updateRequestBody(NETWORK_OPERATIONS.PROCESS_PERFORMA_DATA , processPerformaDataRequests);
                break;

            case ADD_DISCOUNT_DATA:
                WebActionRequestGenericModel<AddDiscountRequest> webActionRequestGenericModel = new WebActionRequestGenericModel<>() ;
                webActionRequestGenericModel.WebsiteId = Constants.WEBACTION_ID;

                AddDiscountRequest addDiscountRequest = new AddDiscountRequest() ;
                addDiscountRequest.setFcmId("c-wnz4x3n_M:APA91bHLn5fsEkGm19oQ30TZvf-_-rVItMbkVIR8IvPt1UrRP_FM4yVxW6UaSOVguPwlglb_AHxn5p1DoaVK8A5Fw4YtmqLbQKs1kwkQfU27W7kgH_uBZ7JdiOEHlrWbLaw1tf8fN9WE");
                addDiscountRequest.setSalesId(new UserSessionManager(this).getSalesId());
                addDiscountRequest.setCustomerSegment("-");
                addDiscountRequest.setPINumber(checkIfFpHasLeadResponse.getLeadNumber());
                addDiscountRequest.setFpTag(new FPSessionManager(this).getFpTag());
                addDiscountRequest.setCity(piDetailsResponse.getSpCity());
                addDiscountRequest.setSalesName(piDetailsResponse.getSpName());
                addDiscountRequest.setSalesChannel(piDetailsResponse.getSpDivision());
                addDiscountRequest.setSaleType(piDetailsResponse.getTypeOfSale());
                addDiscountRequest.setBizName(piDetailsResponse.getBusinessName());
                addDiscountRequest.setProductsQtyD(formattedProductName(discountPercentage , piDetailsResponse.getTypeOfSale() , productName));
                addDiscountRequest.setNetAmt(calculateDiscountAmount(discountPercentage , piDetailsResponse.getTaxPercentage() , piDetailsResponse.getPriceUntax())+"");
                addDiscountRequest.setNwRnwUpgr(piDetailsResponse.getTypeOfSale());
                addDiscountRequest.setReason(discountReason);
                addDiscountRequest.setLyson(" ");
                addDiscountRequest.setLyPrice("");
                addDiscountRequest.setApproval("Pending");
                addDiscountRequest.setSolNo(piDetailsResponse.getSolId()+",");
                addDiscountRequest.setFetchRequests(getManagerId(piDetailsResponse.getSpDivision() , piDetailsResponse.getTypeOfSale())+"");

                webActionRequestGenericModel.ActionData = addDiscountRequest;

                networkHandler.updateRequestBody(NETWORK_OPERATIONS.ADD_DISCOUNT_DATA , webActionRequestGenericModel);

                break;
        }




    }

    private static double calculateDiscountAmount(double discountPercentage , double taxPercentage , double unitPrice){

        double tempPrice = unitPrice - (discountPercentage / 100)*unitPrice;
        return tempPrice + ((taxPercentage / 100)*tempPrice);

    }

    private int getManagerId(String division , String saleType){

        int flag ;
        division = division.toUpperCase();

        if (division.contains("KIT"))
            flag = 3;
        else if ((division.contains("MLC")) || (division.contains("MLC")))
            flag = 0;
        else if ((division.contains("LA")) || (division.contains("LA")) || (division.contains("LOCAL ALLIANCE")) || (division.contains("RIL")) || (division.contains("TDI")))
            flag = 1;
        else if ((division.contains("NA")) || (division.contains("NA")) || (division.contains("NATIONAL ALLIANCE")))
            flag = 0;
        else if (division.contains("FOS"))
            flag = 2;
        else
            flag = 2;

        if(! saleType.toLowerCase().equals("new")) {
            flag = 5;
        }

        if(division.contains("HOSPITALITY") || division.contains("EDUCATION")) {
            flag = 10;
        }

        return flag;
    }

    private static String formattedProductName(double discountPercentage , String saleType , String productName){
        return saleType+"-"+productName+"(1)-"+discountPercentage+"%\n";
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(networkHandler != null ){
            networkHandler.stopNetworkExecution();
        }
    }

    private void showDialog() {
        if (customLoaderDialog == null) {
            customLoaderDialog = new CustomLoaderDialog();
        }

        if(customLoaderDialog.isVisible())
            return;
        // Create and show the dialog.
        customLoaderDialog = CustomLoaderDialog.newInstance();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.executePendingTransactions();
        customLoaderDialog.show(fragmentManager.beginTransaction(), "dialog");
    }

    private void hideDialog(boolean delay){
        // delay is just for the effect

        if(customLoaderDialog == null )
            return;
        if(! customLoaderDialog.isVisible())
            return;

        new Handler().postDelayed(() -> {customLoaderDialog.closeDialog();} , delay ? 2500: 0);


    }

    public boolean dialogIsValid(){
        return customLoaderDialog != null  && customLoaderDialog.isVisible();
    }


    public void finishApiProcessAnimation(String message){
        if(customLoaderDialog != null ){
            if(customLoaderDialog.isVisible()) {
                customLoaderDialog.showSuccessfulDialog(message);
            }
        }
    }

    private void setupDrawerLayout() {

        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        SidePanelFragment sidePanelFragment = new SidePanelFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.fm_fragment_navigation_drawer , sidePanelFragment).commitAllowingStateLoss();
        DrawerLayout mDrawerLayout = findViewById(R.id.drawer_layout);
        sidePanelFragment.setUp(findViewById(R.id.fm_fragment_navigation_drawer) , findViewById(R.id.drawer_layout) , toolbar);
        mDrawerLayout.closeDrawer(Gravity.LEFT);

        findViewById(R.id.im_selfMode).setOnClickListener(view -> {
            mDrawerLayout.openDrawer(findViewById(R.id.fm_fragment_navigation_drawer));
        });



        findViewById(R.id.im_startChat).setOnClickListener(view -> {
//            Intent i = new Intent(view.getContext() , GoogleLoginActivity.class);
//            i.putExtra("startChat" , true);
//            startActivity(i);

            UserSessionManager manager = new UserSessionManager(this);

            HashMap mDataMap = new HashMap();
            mDataMap.put("salesId", manager.getSalesId());//users email id
            mDataMap.put("fcmId", manager.getFcmId());
            mDataMap.put("division" , manager.getDivision());
            mDataMap.put("cfUsername", manager.getCFUsername());

            startActivity(new Intent(this , GoogleLoginActivity.class));
        });
    }


}
