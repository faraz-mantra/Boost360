package com.nowfloats.rocketsingh.models;

public class GetFPIdResponse {

    private String FPTag;
    private int FPId;

    public GetFPIdResponse(String FPTag,int FPId){
        this.FPTag = FPTag;
        this.FPId = FPId;
    }

    public String getFPTag() {
        return FPTag;
    }

    public void setFPTag(String FPTag) {
        this.FPTag = FPTag;
    }

    public int getFPId() {
        return FPId;
    }

    public void setFPId(int FPId) {
        this.FPId = FPId;
    }
}
