package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetProductByNameResponse {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("price")
    @Expose
    private Double price;
    @SerializedName("taxPercent")
    @Expose
    private Double taxPercent;
    @SerializedName("_id")
    @Expose
    private String id;
    @SerializedName("type")
    @Expose
    private Double type;
    @SerializedName("descrption")
    @Expose
    private String descrption;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public GetProductByNameResponse withName(String name) {
        this.name = name;
        return this;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public GetProductByNameResponse withPrice(Double price) {
        this.price = price;
        return this;
    }

    public Double getTaxPercent() {
        return taxPercent;
    }

    public void setTaxPercent(Double taxPercent) {
        this.taxPercent = taxPercent;
    }

    public GetProductByNameResponse withTaxPercent(Double taxPercent) {
        this.taxPercent = taxPercent;
        return this;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public GetProductByNameResponse withId(String id) {
        this.id = id;
        return this;
    }

    public Double getType() {
        return type;
    }

    public void setType(Double type) {
        this.type = type;
    }

    public GetProductByNameResponse withType(Double type) {
        this.type = type;
        return this;
    }

    public String getDescrption() {
        return descrption;
    }

    public void setDescrption(String descrption) {
        this.descrption = descrption;
    }

    public GetProductByNameResponse withDescrption(String descrption) {
        this.descrption = descrption;
        return this;
    }

}
