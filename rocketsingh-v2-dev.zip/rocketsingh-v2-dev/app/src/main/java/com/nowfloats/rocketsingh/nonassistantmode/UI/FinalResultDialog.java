package com.nowfloats.rocketsingh.nonassistantmode.UI;

import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.nowfloats.rocketsingh.R;

public class FinalResultDialog extends DialogFragment {

    private LottieAnimationView lv_status;
    private Button closeDialog;
    private boolean processStatus;
    private TextView tv_status;
    private String message ;

    public static FinalResultDialog newInstance(boolean status , String message) {
        FinalResultDialog dialog = new FinalResultDialog();
        dialog.processStatus = status;
        dialog.message = message;
        return dialog;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.finalresultdialog , container , false);
        tv_status = v.findViewById(R.id.tv_status);
        tv_status.setText(message);

        closeDialog = v.findViewById(R.id.bt_close);

        //lv_status.playAnimation();

        closeDialog.setOnClickListener((view) -> {
            if (getDialog() != null) {
                getDialog().dismiss();
            }
        });


        return v;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setCancelable(true);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null)
        {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

    }

}
