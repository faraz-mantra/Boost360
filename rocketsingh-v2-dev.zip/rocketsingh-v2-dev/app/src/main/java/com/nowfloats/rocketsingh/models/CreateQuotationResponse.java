package com.nowfloats.rocketsingh.models;

public class CreateQuotationResponse {
}
