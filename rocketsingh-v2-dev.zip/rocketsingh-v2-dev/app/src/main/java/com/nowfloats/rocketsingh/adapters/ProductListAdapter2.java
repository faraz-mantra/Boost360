package com.nowfloats.rocketsingh.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.utils.UI.AnimatedExpandedListView;

import java.util.HashMap;
import java.util.List;

public class ProductListAdapter2 extends AnimatedExpandedListView.AnimatedExpandableListAdapter {

    private List<String> parentTItles;
    private HashMap<String,List<String>> userData ;
    private int[] colorArray = {R.color.colorPrimary, R.color.colorPrimaryDark};

    public ProductListAdapter2( List<String> expandableListTitle,
                      HashMap<String, List<String>> expandableListDetail) {
        this.parentTItles = expandableListTitle;
        this.userData = expandableListDetail;
    }

    @Override
    public int getGroupCount() {
        return parentTItles.size();
    }

    @Override
    public Object getGroup(int i) {
        return parentTItles.get(i);
    }

    @Override
    public Object getChild(int i, int i1) {

        return userData.get(parentTItles.get(i)).get(i1);
    }



    @Override
    public long getGroupId(int i) {
        return i;
    }

    @Override
    public long getChildId(int i, int i1) {
        return i1;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int listPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {

        String listTitle = (String) getGroup(listPosition);

        if(convertView == null ){
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_layout_row ,parent , false);
        }

        TextView groupName = convertView.findViewById(R.id.tv_category);
        groupName.setText(listTitle);
        convertView.findViewById(R.id.ll_categoryRoot).setBackgroundResource(colorArray[listPosition % 2]);

        return  convertView;
    }



    @Override
    public View getRealChildView(int groupPosition, int childPosition, boolean isLastChild, View view, ViewGroup viewGroup) {
        if(view == null) {
            view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.package_list_row , viewGroup ,false);
        }

        TextView tv_child = view.findViewById(R.id.tv_package);
        String child = (String)getChild(groupPosition,childPosition);
        tv_child.setText(child);

        return view;
    }

    @Override
    public int getRealChildrenCount(int groupPosition) {
        return userData.get(parentTItles.get(groupPosition)).size();
    }


    @Override
    public boolean isChildSelectable(int i, int i1) {
        return true;
    }
}
