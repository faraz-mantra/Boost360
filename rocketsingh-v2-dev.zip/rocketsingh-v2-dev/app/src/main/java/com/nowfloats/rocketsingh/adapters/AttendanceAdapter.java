package com.nowfloats.rocketsingh.adapters;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.interfaces.AttendanceAdapterInterface;
import com.nowfloats.rocketsingh.models.GetDailyAttendanceResponse;

import java.util.List;

public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.AttendanceViewHolder>{

    List<GetDailyAttendanceResponse.Result> results;
    private AttendanceAdapterInterface attendanceAdapterInterface;
    public AttendanceAdapter (List<GetDailyAttendanceResponse.Result> result , AttendanceAdapterInterface adapterInterface) {
        this.results = result;
        this.attendanceAdapterInterface = adapterInterface;
    }

    @NonNull
    @Override
    public AttendanceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.attendance_adapter_row , parent , false);
        return new AttendanceViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AttendanceViewHolder holder, int position) {

        GetDailyAttendanceResponse.Result data = results.get(holder.getAdapterPosition());

        holder.tv_attendanceStatus.setText(getAttendaceStatus(formatString(data.getAttendanceStatus())));
        holder.tv_checkInAddress.setText(formatString(data.getCheckinAddress()));
        holder.tv_date.setText(formatString(data.getDate()));
        holder.tv_checkOutAddress.setText(formatString(data.getCheckoutAddress()));
        holder.tv_numberOfMeetings.setText(formatString(data.getNumberOfMeeting()));
        holder.tv_lastcheckOut.setText(formatString(data.getLastSwipeOut()));
        holder.tv_lastCheckIn.setText(formatString(data.getFirstCheckIn()));
        holder.tv_firstSwipeIn.setText(formatString(data.getFirstSwipeIn()));
//
//        holder.tv_attendanceStatus.setText("P");
//        holder.tv_checkInAddress.setText("Inorbit Mall Road, Mindspace Madhapur Road, Hyderabad, Telangana 500081");
//        holder.tv_date.setText(formatString(data.getDate()));
//        holder.tv_checkOutAddress.setText("Inorbit Mall Road, Mindspace Madhapur Road, Hyderabad, Telangana 500081");
//        holder.tv_numberOfMeetings.setText("3");
//        holder.tv_lastcheckOut.setText("NA");
//        holder.tv_lastCheckIn.setText("01-10-2018 08:02 AM");
//        holder.tv_firstSwipeIn.setText("01-10-2018 08:00 AM");

    }

    public String getAttendaceStatus(String erpStatus) {
        if(erpStatus.equalsIgnoreCase("h")) {
            return "Holiday";
        }else if(erpStatus.equalsIgnoreCase("l")){
            return "Leave";
        }else if(erpStatus.equalsIgnoreCase("p")){
            return "Present";
        }else if(erpStatus.equalsIgnoreCase("a")){
            return "Absent";
        }else{
            return erpStatus;
        }
    }

    public String formatString(String message){
        if(TextUtils.isEmpty(message)) {
            return "NA";
        }else{
            return message;
        }
    }

    @Override
    public int getItemCount() {
        return results.size();
    }

    public class AttendanceViewHolder extends RecyclerView.ViewHolder{

        public TextView tv_checkOutAddress , tv_checkInAddress , tv_date , tv_attendanceStatus , tv_lastCheckIn, tv_lastcheckOut, tv_numberOfMeetings , tv_firstSwipeIn;
        private Button bt_sendCheckoutAddress , bt_sendCheckInAddress;

        public AttendanceViewHolder(View itemView) {
            super(itemView);
            tv_attendanceStatus = itemView.findViewById(R.id.tv_attendance_status);
            tv_date = itemView.findViewById(R.id.tv_Date);
            tv_checkInAddress = itemView.findViewById(R.id.tv_checkin_address);
            tv_checkOutAddress = itemView.findViewById(R.id.tv_checkout_address);
            tv_firstSwipeIn = itemView.findViewById(R.id.tv_first_swipe_in);
            tv_numberOfMeetings = itemView.findViewById(R.id.tv_number_of_meeting);
            tv_lastCheckIn = itemView.findViewById(R.id.tv_last_swipe_in);
            tv_lastcheckOut = itemView.findViewById(R.id.tv_last_swipe_out);
            bt_sendCheckInAddress = itemView.findViewById(R.id.bt_checkInAddress);
            bt_sendCheckoutAddress = itemView.findViewById(R.id.bt_checkoutAddress);

            bt_sendCheckoutAddress.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(attendanceAdapterInterface != null ){
                        GetDailyAttendanceResponse.Result result = results.get(getAdapterPosition());
                        if(result.getCheckoutLatitude() != null  && result.getCheckoutLongitude()!= null){
                            attendanceAdapterInterface.onShowLocationOnMap(result.getCheckoutLatitude()  , result.getCheckoutLongitude());
                        }else{
                            attendanceAdapterInterface.displayToast("Sorry we dont have the location yet");
                        }
                    }else{
                        attendanceAdapterInterface.displayToast("Sorry we dont have the location yet");
                    }
                }
            });

            bt_sendCheckInAddress.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(attendanceAdapterInterface != null ){
                        GetDailyAttendanceResponse.Result result = results.get(getAdapterPosition());
                        if(result.getCheckinLatitude() != null  && result.getCheckoutLongitude()!= null){
                            attendanceAdapterInterface.onShowLocationOnMap(result.getCheckinLatitude()  , result.getCheckinLongitude());
                        }else{
                            attendanceAdapterInterface.displayToast("Sorry we dont have the location yet");
                        }
                    }else{
                        attendanceAdapterInterface.displayToast("Sorry we dont have the location yet");
                    }
                }
            });

        }
    }



}
