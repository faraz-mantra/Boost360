package com.nowfloats.rocketsingh.nonassistantmode.Interfaces;

import com.nowfloats.rocketsingh.models.FpDetailResponse;
import com.nowfloats.rocketsingh.models.GetPackageResponse;

import java.util.HashMap;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Path;
import retrofit.http.Query;
import retrofit.http.QueryMap;

public interface FPDetailsInterface {

    @GET("/discover/v2/floatingPoint/nf-web/{fpTag}")
    void getFpDetails(@Path("fpTag") String fpTag , @Query("clientId") String clientId , Callback<FpDetailResponse> detailResponseCallback);

    @GET("/Support/v5/floatingpoint/getpackages")
    void getPackages(@QueryMap HashMap<String,String> queries , Callback<GetPackageResponse> getPackageResponseCallback);

}
