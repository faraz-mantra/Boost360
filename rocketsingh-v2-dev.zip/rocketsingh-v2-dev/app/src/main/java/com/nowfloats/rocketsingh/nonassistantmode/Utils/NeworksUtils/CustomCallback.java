package com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils;


import android.text.TextUtils;
import android.util.Log;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class CustomCallback<T> implements Callback<T> {

    private Callback<T> callback;
    private final String CANCELLED_REQUEST = "Request is cancelled";
    private CustomCallback()  {}

    private boolean isCanceled;
    private NETWORK_OPERATIONS network_operations;

    public CustomCallback(Callback<T> callback , NETWORK_OPERATIONS network_operations) {
        this.callback = callback;
        isCanceled = false;
        this.network_operations = network_operations;
    }

    public void cancel(){
        isCanceled = true;
        callback = null ;
    }

    public void printLog(String message) {
        if(!TextUtils.isEmpty(message) && network_operations != null) {
            Log.e(network_operations.toString() , message);
        }
    }

    @Override
    public void success(T t, Response response) {
        if(! isCanceled ){
            callback.success(t , response);
        }else{
            printLog(CANCELLED_REQUEST);
        }
    }

    @Override
    public void failure(RetrofitError error) {
        if(! isCanceled) {
            callback.failure(error);
        }else{
            printLog(CANCELLED_REQUEST);
        }
    }
}
