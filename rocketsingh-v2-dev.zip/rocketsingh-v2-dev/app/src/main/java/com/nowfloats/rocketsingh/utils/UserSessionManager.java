package com.nowfloats.rocketsingh.utils;


import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by NowFloats on 15-Dec-17.
 */

public class
UserSessionManager {

    public static final String PROJECT_PREF = "PROJECT_PREF2";
    public static final List<String> ADMIN = new ArrayList<>();

    private SharedPreferences pref;


    public UserSessionManager(Context context) {
        pref = context.getApplicationContext().getSharedPreferences(PROJECT_PREF, Context.MODE_PRIVATE);
    }

    public void setAdmin(boolean isAdmin){
        pref.edit().putBoolean("ADMIN" , isAdmin).apply();
    }

//    public String getCfUsername(){
//        return pref.getString("cfUsername" , "");
//    }
//
//    public void setcfUsername(String s) {
//        pref.edit().putString("cfUsername" , s).apply();
//    }

    public boolean isAdmin(){
        return pref.getBoolean("ADMIN" , false);
    }

    public void setDivision(String division) {
        pref.edit().putString("division" , division).apply();
    }

    public String getDivision() {
        return pref.getString("division" , "");
    }

    public void setEmployeeId(String employeeId){
        pref.edit().putString("employeeId" , employeeId).apply();
    }

    public String getEmployeeId(){
        return pref.getString("employeeId" ,"NA");
    }

    public void setLatitude(double latitude){
        pref.edit().putFloat("lat" , (float) latitude).apply();
    }

    public void setLongitude(double longitude) {
        pref.edit().putFloat("lng" , (float) longitude).apply(); ;
    }

    public float getLatitude(){
        return pref.getFloat("lat",0);
    }

    public float getLongitude(){
        return pref.getFloat("lng",0);
    }



    public String getSalesId() {
        return pref.getString("SalesId","");
    }

    public void setSalesId(String salesId) {
        pref.edit().putString("SalesId", TextUtils.isEmpty(salesId)?"":salesId).apply();
    }

    public void setFcmId(String fcmId) {
        pref.edit().putString("fcmId", TextUtils.isEmpty(fcmId)?"":fcmId).apply();
    }

    public String getFcmId(){
        return pref.getString("fcmId","");
    }

    public String getCFUsername() {
        return pref.getString("CFUsername","");
    }

    public void setCFUsername(String cfUsername) {
        pref.edit().putString("CFUsername", TextUtils.isEmpty(cfUsername)?"":cfUsername).apply();
    }

    public String getBaseUrl() {
        return pref.getString("BaseUrl","");
    }

    public void setBaseUrl(String baseUrl) {
        pref.edit().putString("BaseUrl", TextUtils.isEmpty(baseUrl)?"":baseUrl).apply();
    }

    public void setApxorAnalyticsAppId(String appId){
        pref.edit().putString("AppxorId", TextUtils.isEmpty(appId)?"":appId).apply();
    }

    public String getApxorAnalyticsAppId(){
        return pref.getString("AppxorId","");
    }

    public String getBusinessId() {
        return pref.getString("BusinessId","");
    }

    public void setBusinessId(String businessId) {
        pref.edit().putString("BusinessId", TextUtils.isEmpty(businessId)?"":businessId).apply();
    }

    public String getFlowId() {
        return pref.getString("FlowId","");
    }

    public void setFlowId(String flowId) {
        pref.edit().putString("FlowId", TextUtils.isEmpty(flowId)?"":flowId).apply();
    }

    public Boolean getFirstOpen() {
        return pref.getBoolean("FirstOpen",true);
    }

    public void setFirstOpen(Boolean firstOpen) {
        pref.edit().putBoolean("FirstOpen", firstOpen).apply();
    }

    public Boolean getFirstChatOpen() {
        return pref.getBoolean("FirstChatOpen",true);
    }

    public void setFirstChatOpen(Boolean firstOpen) {
        pref.edit().putBoolean("FirstChatOpen", firstOpen).apply();
    }

    public long getLastRankNotifTime() {
        return pref.getLong("lastNotifTime",0);
    }

    public void setLastRankNotifTime(long lastNotifTime) {
        pref.edit().putLong("lastNotifTime",lastNotifTime).apply();
    }

    public Boolean getIsFOSLoggedIn() {
        return pref.getBoolean("fosLoggedIn",false);
    }

    public void setIsFOSLoggedIn(Boolean fosLoggedIn) {
        pref.edit().putBoolean("fosLoggedIn",fosLoggedIn).apply();
    }
}