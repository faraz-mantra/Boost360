package com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils;

import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.nowfloats.rocketsingh.interfaces.ERPApiInterface;
import com.nowfloats.rocketsingh.interfaces.InvoiceInterface;
import com.nowfloats.rocketsingh.interfaces.PaymentInterface;
import com.nowfloats.rocketsingh.interfaces.SignupInterface;
import com.nowfloats.rocketsingh.models.AddDiscountRequest;
import com.nowfloats.rocketsingh.models.CheckIfFpHasLeadResponse;
import com.nowfloats.rocketsingh.models.ClaimOrderRequest;
import com.nowfloats.rocketsingh.models.CreateQuotationRequest;
import com.nowfloats.rocketsingh.models.ERPErrorModel;
import com.nowfloats.rocketsingh.models.FinalPaymentRequest;
import com.nowfloats.rocketsingh.models.FinalisePaymentResponse;
import com.nowfloats.rocketsingh.models.FpDetailResponse;
import com.nowfloats.rocketsingh.models.GenericApiResponseModel;
import com.nowfloats.rocketsingh.models.GetEmployeeDetailsRequest;
import com.nowfloats.rocketsingh.models.GetEmployeeDetailsResponse;
import com.nowfloats.rocketsingh.models.GetLeadDetailsRequest;
import com.nowfloats.rocketsingh.models.GetLeadDetailsResponse;
import com.nowfloats.rocketsingh.models.GetPackageResponse;
import com.nowfloats.rocketsingh.models.IFSCPaymentResponse;
import com.nowfloats.rocketsingh.models.InitiatePaymentRequest;
import com.nowfloats.rocketsingh.models.LogMeetingRequest;
import com.nowfloats.rocketsingh.models.LogMeetingResponse;
import com.nowfloats.rocketsingh.models.PIDetailsRequest;
import com.nowfloats.rocketsingh.models.PIDetailsResponse;
import com.nowfloats.rocketsingh.models.ProcessPerformaDataRequest;
import com.nowfloats.rocketsingh.models.ProcessPerformaDataResponse;
import com.nowfloats.rocketsingh.models.RedeemCouponRequest;
import com.nowfloats.rocketsingh.models.RedeemCouponResponse;
import com.nowfloats.rocketsingh.models.ScheduleMeetingRequest;
import com.nowfloats.rocketsingh.models.ScheduleMeetingResponse;
import com.nowfloats.rocketsingh.models.SingleProductModel;
import com.nowfloats.rocketsingh.models.UpdateReceiptInSORequest;
import com.nowfloats.rocketsingh.models.WebActionRequestGenericModel;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.FPDetailsInterface;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.MeetingsInterface;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.NetworkResultInterface;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.FPSessionManager;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.nowfloats.rocketsingh.utils.UserSessionManager;
import com.squareup.okhttp.OkHttpClient;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;
import retrofit.client.OkClient;
import retrofit.client.Response;
import retrofit.converter.GsonConverter;

import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.ADD_DISCOUNT_DATA;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.CHECK_IF_LEAD_HAS_FP;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.CLAIM_SALE_REQUEST;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.CREATE_EDIT_QUOTATION;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.GET_ALL_LEADS;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.GET_FP_DETAILS;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.GET_PACKAGES;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.GET_QUOTATION_ID;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.INITIATE_PAYMENT;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.PI_DETAILS;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.PROCESS_PERFORMA_DATA;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.REDEEM_DISCOUNT_COUPON;
import static com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS.UPLOAD_CLAIM_RECEIPT;


public class NetworkHandler {

    private Context context;
    private NetworkResultInterface networkUI_Interface;
    private Queue<NETWORK_OPERATIONS> networkSequenceQueue = new LinkedList<>();
    private HashMap<NETWORK_OPERATIONS,Object> networkOperationRequestBody = new HashMap<>();
    private CustomCallback currentCallback ;
    private short session ;
    private final String TAG =  NetworkHandler.class.getName()+" : ";
    private NETWORK_OPERATIONS currentNetworkOperation ;
    private UserSessionManager manager;

    public NETWORK_OPERATIONS getCurrentNetworkOperation() {
        return currentNetworkOperation;
    }

    public NetworkHandler (Context context , NetworkResultInterface networkResultInterface) {
        this.context = context;
        networkUI_Interface = networkResultInterface;
        manager = new UserSessionManager(context);

    };

    public void addNetworkRequest(NETWORK_OPERATIONS network_operations) {
        networkSequenceQueue.add(network_operations);
    }

    public NetworkHandler setOrUpdateSession(short sesssion) {
        this.session = sesssion;
        return this;
    }

    public short getSession(){
        return session;
    }

    public NetworkHandler setNetworkOperationQueue(Queue<NETWORK_OPERATIONS> queue){
        networkSequenceQueue.clear();
        networkSequenceQueue.addAll(queue);
        return this;
    }

    public NetworkHandler setNetworkOperationRequestBody(HashMap<NETWORK_OPERATIONS,Object> networkOperationRequestBody) {
        this.networkOperationRequestBody = networkOperationRequestBody;
        return this;
    }

    public NetworkHandler startThread(){
        executeNext();
        return this;
    }

    private NETWORK_OPERATIONS executeNextNetworkThread(){
        return networkSequenceQueue.poll();
    }

    public void clearNetworkQueue(){
        networkSequenceQueue.clear();
    }

    public void executeNext(){
        NETWORK_OPERATIONS operationMode = executeNextNetworkThread();
        if(operationMode == null ){
            networkUI_Interface.networkOperationsFinished(true , session);
            return;
        }

        currentNetworkOperation = operationMode;

        networkUI_Interface.onApiRequestStarted(operationMode);
        networkUI_Interface.prepareRequestBody(operationMode , this);

        switch (operationMode) {
            case GET_FP_DETAILS:
                getFpDetails(networkOperationRequestBody.get(operationMode)+"");
                break;
            case GET_PACKAGES:
                getPackages();
                break;
            case PROCESS_PERFORMA_DATA:
                processPerformaData((List<ProcessPerformaDataRequest>)networkOperationRequestBody.get(operationMode));
                break;
            case CHECK_IF_LEAD_HAS_FP:
                checkIfFpHasLead();
                break;
            case GET_QUOTATION_ID:
                GetQuotationId(networkOperationRequestBody.get(operationMode)+"");
                break;
            case CREATE_EDIT_QUOTATION:
                createQuotation((HashMap)networkOperationRequestBody.get(CREATE_EDIT_QUOTATION));
                break;
            case PI_DETAILS:
                getPiDetails((HashMap)networkOperationRequestBody.get(PI_DETAILS));
                break;
            case ADD_DISCOUNT_DATA:
                uploadDiscountToWebaction((WebActionRequestGenericModel<AddDiscountRequest>)networkOperationRequestBody.get(ADD_DISCOUNT_DATA));
                break;
            case REDEEM_DISCOUNT_COUPON:
                redeemDiscount((HashMap)networkOperationRequestBody.get(REDEEM_DISCOUNT_COUPON));
                break;
            case IFSC_VALIDATION:
                verifyIFSCCode((String)networkOperationRequestBody.get(operationMode) , operationMode);
                break;
            case GET_ALL_LEADS:
                getAllLeads(operationMode);
                break;
            case FINALISE_PAYMENT:
                finalisePayment((FinalPaymentRequest)networkOperationRequestBody.get(operationMode) , operationMode);
                break;
            case GET_EMPLOYEE_DETAILS:
                getEmployeeDivision(operationMode);
                break;
            case INITIATE_PAYMENT:
                initialisePayment((InitiatePaymentRequest)networkOperationRequestBody.get(operationMode) , operationMode);
                break;
            case CLAIM_SALE_REQUEST:
                claimSale((HashMap)networkOperationRequestBody.get(operationMode));
                break;
            case UPLOAD_CLAIM_RECEIPT:
                uploadSoReceipt((HashMap)networkOperationRequestBody.get(operationMode));
                break;
            case SCHEDULE_MEETING:
                scheduleFOSMeeting((ScheduleMeetingRequest)networkOperationRequestBody.get(operationMode) , operationMode);
                break;
            case LOG_MEETING:
                logFOSMeeting((LogMeetingRequest)networkOperationRequestBody.get(operationMode) , operationMode);
                break;
            case VALIDATE_CLAIM_ID:
                validateClaimId(networkOperationRequestBody.get(operationMode).toString() , operationMode);
                break;
            case VERIFY_OTP_REQUEST:
                verifyOtp((HashMap)networkOperationRequestBody.get(operationMode) , operationMode);
                break;
            case SEND_OTP_REQUEST:
                sendOtp(networkOperationRequestBody.get(operationMode).toString() , operationMode);
                break;
            case VERIFY_MISSED_CALL_REQUEST:
                checkMissedCallVerificationStatus((HashMap)networkOperationRequestBody.get(operationMode) , operationMode);
                break;
            case INITIATE_MISSED_CALL_VERFICATION:
                requestMissedCallVerification((HashMap)networkOperationRequestBody.get(operationMode) ,
                        operationMode);
                break;
            default:
                throw new RuntimeException("No api operation as " +operationMode.toString());
        }
    }

    public void updateRequestBody(NETWORK_OPERATIONS network_operations , Object model){
        networkOperationRequestBody.clear();
        networkOperationRequestBody.put(network_operations,model);
    }

    private void GetQuotationId(String hpNumber){
       RestAdapter restAdapter = new RestAdapter.Builder()
               .setEndpoint(Constants.SALES_ASSISTANT_API_URL)
               .setLogLevel(RestAdapter.LogLevel.BASIC)
               .setClient(getHttclient(60))
               .setLog(new AndroidLog(GET_QUOTATION_ID.toString()))
               .build();

       ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

       CustomCallback<GenericApiResponseModel<Long>> customCallback = new CustomCallback<>(new Callback<GenericApiResponseModel<Long>>() {
           @Override
           public void success(GenericApiResponseModel<Long> getQuotationResponse, Response response) {

               if(response.getStatus() == 200 && getQuotationResponse != null){
                   if(getQuotationResponse.getServerObject() != null )
                    networkUI_Interface.onApiSuccessfull(GET_QUOTATION_ID  , getQuotationResponse,
                            "Fetch quotation details successfully" );
                   else
                       networkUI_Interface.onApiFail(GET_QUOTATION_ID ,
                               "Unable to get quotation id");
               }else{
                   networkUI_Interface.onApiFail(GET_QUOTATION_ID , "Unable to get quotation id");
               }

           }

           @Override
           public void failure(RetrofitError error) {
               networkUI_Interface.onApiFail(GET_QUOTATION_ID , error.getMessage());
           }
       } , GET_QUOTATION_ID);

        currentCallback = customCallback;

        HashMap userParams = new HashMap();
        userParams.put("salesId" , manager.getSalesId());
        userParams.put("hpNumber" , hpNumber);

        erpApiInterface.getQuotationId(userParams , customCallback);

    }



    private OkClient getHttclient(int timeout){

        final OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.setReadTimeout(timeout , TimeUnit.MINUTES);
        okHttpClient.setConnectTimeout(20 , TimeUnit.MINUTES);

        return new OkClient(okHttpClient);
    }


    private void getEmployeeDivision(NETWORK_OPERATIONS operations) {

        String email = manager.getSalesId();

        String errorMessage = "Invalid Data! Please try again";

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        GetEmployeeDetailsRequest model = new GetEmployeeDetailsRequest();
        model.setClientId(Constants.ERPClientId);
        model.setEmail(email);

        currentCallback = new CustomCallback<>(new Callback<List<GetEmployeeDetailsResponse>>() {
            @Override
            public void success(List<GetEmployeeDetailsResponse> dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error
                    networkUI_Interface.onApiFail(operations, errorMessage);
                    return;
                }
                if (response.getStatus() == 200) {
                    //onApiSuccessfull
                    for (GetEmployeeDetailsResponse b : dataResponse) {
                        if (b.getEmail().equals(email)) {

                            manager.setCFUsername(b.getCFT());
                            manager.setEmployeeId(b.getEmployeeId());

                            switch (b.getDivision()) {
                                case "FOS-CF":
                                    manager.setIsFOSLoggedIn(true);
                                    manager.setFlowId(Constants.LANDING_PAGE_FLOW_ID);
                                    break;
                                case "FOS":
                                    manager.setIsFOSLoggedIn(true);
                                    manager.setFlowId(Constants.LANDING_PAGE_FLOW_ID);
                                    break;
                                default:
                                    manager.setIsFOSLoggedIn(true);
                                    manager.setFlowId(Constants.LANDING_PAGE_FLOW_ID);
                                    break;
                            }
                            networkUI_Interface.onApiSuccessfull(operations, "Got employee details");
                        }
                    }
                } else {

                    networkUI_Interface.onApiFail(operations, errorMessage);

                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(operations, errorMessage + "(" + error.getMessage() + ")");
                //error
            }
        }, operations);

        signupInterface.checkEmployeeDivision(model, currentCallback);
    }

    private void checkIfFpHasLead() {

        final OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.setReadTimeout(60, TimeUnit.SECONDS);
        okHttpClient.setConnectTimeout(60, TimeUnit.SECONDS);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .setLog(new AndroidLog(TAG+CHECK_IF_LEAD_HAS_FP.toString()))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .setClient(new OkClient(okHttpClient))
                .build();

        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        CustomCallback<CheckIfFpHasLeadResponse> checkIfFpHasLeadResponseCustomCallback = new CustomCallback<>(
                new Callback<CheckIfFpHasLeadResponse>() {
                    @Override
                    public void success(CheckIfFpHasLeadResponse checkIfFpHasLeadResponse, Response response) {
                        if(response.getStatus() == 200 ){
                            networkUI_Interface.onApiSuccessfull(CHECK_IF_LEAD_HAS_FP , checkIfFpHasLeadResponse , "Got your customer number details");
                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        networkUI_Interface.onApiFail(CHECK_IF_LEAD_HAS_FP , error.getMessage());
                    }
                } ,
                CHECK_IF_LEAD_HAS_FP
        );

        currentCallback = checkIfFpHasLeadResponseCustomCallback;

        HashMap<String,String> params = new HashMap<>();
        params.put("salesId" , manager.getSalesId());
        params.put("fp",new FPSessionManager(context).getFpTag());

        erpApiInterface.checkIfFPHasLead(params , checkIfFpHasLeadResponseCustomCallback);


    }

    public void processPerformaData(List<ProcessPerformaDataRequest> processPerformaDataRequests){

        Callback<Object> processPerformaDataResponseCallback = new Callback<Object>() {
            @Override
            public void success(Object stringResponse, Response response) {


                if(response.getStatus() == 200 && stringResponse != null){
                    ProcessPerformaDataResponse processPerformaDataResponse = (ProcessPerformaDataResponse)stringResponse;
                    networkUI_Interface.onApiSuccessfull(PROCESS_PERFORMA_DATA , processPerformaDataResponse , "Processed your discount successfully.");
                }else{
                    networkUI_Interface.onApiFail(PROCESS_PERFORMA_DATA , "Sorry, unable to process your discount");
                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(PROCESS_PERFORMA_DATA , error.getMessage());
            }
        };

        CustomCallback<Object> customCallback = new CustomCallback<>(processPerformaDataResponseCallback , PROCESS_PERFORMA_DATA);

        currentCallback = customCallback;

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .setLogLevel(RestAdapter.LogLevel.BASIC)
                .setLog(new AndroidLog(PROCESS_PERFORMA_DATA+"")).build();

        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

        erpApiInterface.processPerformaData(processPerformaDataRequests , customCallback);

    }



    public void removeNetworkOperation(NETWORK_OPERATIONS network_operation){
        networkSequenceQueue.remove(network_operation);
    }

    public void modifyRequestBody(NETWORK_OPERATIONS network_operations , Object model){
        networkOperationRequestBody.put(network_operations , model);
    }

    private void initialisePayment(InitiatePaymentRequest initiatePaymentRequest , NETWORK_OPERATIONS operations){

        String errorMessage = "Unable to initiate your payment";

        currentCallback = new CustomCallback<>(new Callback<String>() {
            @Override
            public void success(String s, Response response) {
                if(response.getStatus() == 200 ){
                    networkUI_Interface.onApiSuccessfull(operations , s , "Payment is initiated");
                }else{
                    networkUI_Interface.onApiFail(operations , errorMessage);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(operations , errorMessage+"\n"+error.getMessage());
            }
        } , INITIATE_PAYMENT);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.NOW_FLOATS_API2_URL)
                .setLog(new AndroidLog(operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();
        restAdapter.create(PaymentInterface.class).initialisePayment(initiatePaymentRequest , currentCallback);
    }

    private void claimSale(HashMap<String,String> hashMap){

        String errorMesssage = "Sorry unable to claim your sale";

        ClaimOrderRequest claimOrderRequest = new ClaimOrderRequest();
        claimOrderRequest.setEmailId(new UserSessionManager(context).getSalesId());
        claimOrderRequest.setHotProspect(hashMap.get("hotprospect"));
        claimOrderRequest.setClaimId(hashMap.get("claimId"));

        UpdateReceiptInSORequest updateReceiptInSORequest = new UpdateReceiptInSORequest();
        updateReceiptInSORequest.setMethod(Constants.ERP_METHOD);
        updateReceiptInSORequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        UpdateReceiptInSORequest.Params params = new UpdateReceiptInSORequest.Params();
        List<Object> args = new ArrayList<>();

        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);
        args.add("claimOrder");
        args.add(claimOrderRequest);

        params.setArgs(args);
        params.setService(Constants.ERP_PARAM_SERVICE);
        params.setMethod(Constants.ERP_PARAM_METHOD);
        updateReceiptInSORequest.setParams(params);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

        currentCallback = new CustomCallback<Response>(new Callback<Response>() {
            @Override
            public void success(Response requestResponse, Response response) {
                if(response.getStatus() == 200){
                    JSONObject jsonResponse = ExternalProcessManager
                            .getJsonFromTypedInput(requestResponse.getBody());

                    if(jsonResponse != null &&
                            jsonResponse.toString()
                                    .toLowerCase()
                                    .contains("error")) {

                        ERPErrorModel erpErrorModel = new Gson().fromJson(
                                jsonResponse.toString(),
                                ERPErrorModel.class
                        );

                        networkUI_Interface.onApiFail(CLAIM_SALE_REQUEST , erpErrorModel.getError()
                                .getData().getArguments().get(0));
                    }else{
                        networkUI_Interface.onApiSuccessfull(CLAIM_SALE_REQUEST , "Sale has been claimed");
                    }


                }else{
                    networkUI_Interface.onApiFail(CLAIM_SALE_REQUEST , errorMesssage);
                }

            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(CLAIM_SALE_REQUEST , errorMesssage +
                        "("+error.getMessage()+")");
            }
        } , CLAIM_SALE_REQUEST);

        erpApiInterface.UpdateReceiptInSO(updateReceiptInSORequest, currentCallback);
    }

    private void uploadSoReceipt(HashMap<String,String> hashMap){

        String errorMesssage = "Sorry unable to upload error message";

        String transactionId = hashMap.get("transactionId");
        String receiptBase64 = hashMap.get("base64");
        String imageName = hashMap.get("imageName");
        UpdateReceiptInSORequest updateReceiptInSORequest = new UpdateReceiptInSORequest();
        updateReceiptInSORequest.setMethod(Constants.ERP_METHOD);
        updateReceiptInSORequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        UpdateReceiptInSORequest.Params params = new UpdateReceiptInSORequest.Params();
        List<Object> args = new ArrayList<>();

        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);
        args.add("UpdateReceiptInSO");

        UpdateReceiptInSORequest.UserDetails userDetails = new UpdateReceiptInSORequest.UserDetails();
        userDetails.setEmailId(manager.getSalesId());
        userDetails.setSalesOrderId(null);
        userDetails.setClaimId(transactionId);
        userDetails.setReceiptPicBin(receiptBase64);
        userDetails.setReceiptPicName(imageName);
        args.add(userDetails);
        params.setArgs(args);
        params.setService(Constants.ERP_PARAM_SERVICE);
        params.setMethod(Constants.ERP_PARAM_METHOD);
        updateReceiptInSORequest.setParams(params);
        HashMap<String,String> userData = new HashMap<>();
        userData.put("receiptSuccess","false");
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

        currentCallback = new CustomCallback<>(new Callback<Response>() {
            @Override
            public void success(Response requestResponse, Response response) {
                if(response.getStatus() == 200){
                    JSONObject jsonResponse = ExternalProcessManager
                            .getJsonFromTypedInput(requestResponse.getBody());

                    if(jsonResponse != null &&
                            jsonResponse.toString()
                                    .toLowerCase()
                                    .contains("error")) {

                        ERPErrorModel erpErrorModel = new Gson().fromJson(
                                jsonResponse.toString(),
                                ERPErrorModel.class
                        );

                        networkUI_Interface.onApiFail(UPLOAD_CLAIM_RECEIPT , erpErrorModel.getError()
                                .getData().getArguments().get(0));
                    }else{
                        networkUI_Interface.onApiSuccessfull(UPLOAD_CLAIM_RECEIPT , "Receipt uploaded succesfully");
                    }


                }else{
                    networkUI_Interface.onApiFail(UPLOAD_CLAIM_RECEIPT , errorMesssage);
                }

            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(UPLOAD_CLAIM_RECEIPT , errorMesssage +
                        "("+error.getMessage()+")");
            }
        } , UPLOAD_CLAIM_RECEIPT);

        erpApiInterface.UpdateReceiptInSO(updateReceiptInSORequest, currentCallback);
    }


    private void validateClaimId(String claimId , NETWORK_OPERATIONS operations) {
        String errorMessage = "It seems that your claim id is invalid";

        currentCallback = new CustomCallback<>(new Callback<String>() {
            @Override
            public void success(String s, Response response) {
                if(response.getStatus() == 200 && s != null ){
                    networkUI_Interface.onApiSuccessfull(operations , "Claim ID is verified");
                }else{
                    networkUI_Interface.onApiFail(operations , errorMessage);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(operations , errorMessage+"\n"+error.getMessage());
            }
        } , operations);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .setLog(new AndroidLog(operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();
        restAdapter.create(PaymentInterface.class).validateClaimID(claimId , currentCallback);
    }

    private void finalisePayment(FinalPaymentRequest finalPaymentRequest , NETWORK_OPERATIONS operations){
        String errorMessage = "Unable to make your payment";

        currentCallback = new CustomCallback<>(new Callback<FinalisePaymentResponse>() {
            @Override
            public void success(FinalisePaymentResponse s, Response response) {
                if(response.getStatus() == 200 && s != null && s.getError().toLowerCase().equals("no")){
                    networkUI_Interface.onApiSuccessfull(operations , s.getMessage());
                }else{
                    networkUI_Interface.onApiFail(operations , errorMessage);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(operations , errorMessage+"\n"+error.getMessage());
            }
        } , operations);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .setLog(new AndroidLog(operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();
        restAdapter.create(PaymentInterface.class).finalisePayment(finalPaymentRequest , currentCallback);
    }

    private void verifyIFSCCode(String ifscCode , NETWORK_OPERATIONS operations){
        String errorMessage = "You have entered an invalid IFSC code";

        currentCallback = new CustomCallback<>(new Callback<IFSCPaymentResponse>() {
            @Override
            public void success(IFSCPaymentResponse s, Response response) {
                if(response.getStatus() == 200 && s != null ){
                    networkUI_Interface.onApiSuccessfull(operations , s , "Succesfully obtained bank details");
                }else{
                    networkUI_Interface.onApiFail(operations , errorMessage);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(operations , errorMessage+"\n"+error.getMessage());
            }
        } , INITIATE_PAYMENT);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.IFSC_VALIDATION_ENDPOINT)
                .setLog(new AndroidLog(operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();
        restAdapter.create(PaymentInterface.class).verifyIFSCode(ifscCode.toUpperCase() , currentCallback);

    }


    private void redeemDiscount(HashMap<String,String> userData){
        FPSessionManager fpSessionManager = new FPSessionManager(context);

        String discountCoupon = userData.get("discountCoupon");
        String redeemCoupon = userData.get("redeem");
        String fpTag = fpSessionManager.getFpTag();
        String fpId = fpSessionManager.getFpId();

        boolean redeem = redeemCoupon.equals("yes");

        CustomCallback<RedeemCouponResponse> redeemCouponResponseCustomCallback = new CustomCallback<>(
                new Callback<RedeemCouponResponse>() {
                    @Override
                    public void success(RedeemCouponResponse redeemCouponResponse, Response response) {
                        if(response.getStatus() == 200 ){
                            networkUI_Interface.onApiSuccessfull(REDEEM_DISCOUNT_COUPON , redeemCouponResponse , "Coupon verified successfully");
                        }else{
                            networkUI_Interface.onApiFail(REDEEM_DISCOUNT_COUPON , "Invalid coupon applied");
                        }
                    }

                    @Override
                    public void failure(RetrofitError error) {
                        networkUI_Interface.onApiFail(REDEEM_DISCOUNT_COUPON , "Invalid coupon applied");
                    }
                } , REDEEM_DISCOUNT_COUPON
        );

        currentCallback = redeemCouponResponseCustomCallback;

        RedeemCouponRequest redeemCouponRequest = new RedeemCouponRequest();
        redeemCouponRequest.setClientId(Constants.FOSClientId);
        redeemCouponRequest.setCouponCode(discountCoupon);
        redeemCouponRequest.setExternalSourceName(fpTag.toUpperCase());
        redeemCouponRequest.setExternalSourceId(fpId);
        redeemCouponRequest.setToRedeem(redeem);

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.NOW_FLOATS_API2_URL)
                .setLog(new AndroidLog(REDEEM_DISCOUNT_COUPON.toString()))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();

        InvoiceInterface invoiceInterface  = restAdapter.create(InvoiceInterface.class);
        invoiceInterface.redeemDiscountCoupon(redeemCouponRequest , redeemCouponResponseCustomCallback);
    }


    private  void getFpDetails(String FpTag){

        Callback<FpDetailResponse> getFpDetailsCallBack =  new Callback<FpDetailResponse>() {
            @Override
            public void success(FpDetailResponse fpDetailResponse, Response response) {

                if(response.getStatus() == 200 ){
                    FPSessionManager fpSessionManager  = new FPSessionManager(context);
                    fpSessionManager.setFpTag(fpDetailResponse.getTag());
                    fpSessionManager.setCountry(fpDetailResponse.getCountry());
                    fpSessionManager.setClientId(fpDetailResponse.getAccountManagerId() , fpDetailResponse.getApplicationId());
                    fpSessionManager.setPrimaryNumber(fpDetailResponse.getPrimaryNumber());
                    fpSessionManager.setCurrencyCode("INR");
                    if(fpDetailResponse.getCategory() != null && fpDetailResponse.getCategory().size() > 0)
                        fpSessionManager.setCategory(fpDetailResponse.getCategory().get(0));
                    fpSessionManager.setCountry(fpDetailResponse.getCountry());
                    fpSessionManager.setEmail(fpDetailResponse.getEmail());
                    fpSessionManager.setFpID(fpDetailResponse.getId());
                    fpSessionManager.setBusinessName(fpDetailResponse.getName());

                    networkUI_Interface.onApiSuccessfull(GET_FP_DETAILS , "Got your customer tag details");
                }else{
                    networkUI_Interface.onApiFail(GET_FP_DETAILS , "You have entered a invalid customer tag");
                }


            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(GET_FP_DETAILS ,error.getMessage());
            }
        };

        CustomCallback<FpDetailResponse> customCallback = new CustomCallback<FpDetailResponse>(getFpDetailsCallBack , GET_FP_DETAILS);
        currentCallback = customCallback;

                RestAdapter restAdapter = new RestAdapter.Builder().setLogLevel(RestAdapter.LogLevel.FULL)
                .setLog(new AndroidLog(TAG+GET_FP_DETAILS.toString())).setEndpoint(Constants.NOW_FLOATS_API2_URL).build();
        FPDetailsInterface fpDetailsInterface = restAdapter.create(FPDetailsInterface.class);

        fpDetailsInterface.getFpDetails(FpTag, Constants.CFClientId,customCallback);
    }

    private void uploadDiscountToWebaction(WebActionRequestGenericModel<AddDiscountRequest> webActionRequestGenericModel) {

        Callback<String> callback = new Callback<String>() {
            @Override
            public void success(String s, Response response) {
                if(response.getStatus() == 200 ){
                    if(TextUtils.isEmpty(s)){
                        networkUI_Interface.onApiFail(ADD_DISCOUNT_DATA , "Sorry unable to upload your discount ("+response.getStatus()+")");
                    }else if(s.toLowerCase().contains("error")){
                        networkUI_Interface.onApiFail(ADD_DISCOUNT_DATA , "Sorry some error occured while uploading your discount");
                    }else{
                        networkUI_Interface.onApiSuccessfull(ADD_DISCOUNT_DATA , "Your discount has been uploaded successfully");
                    }
                }else {
                    networkUI_Interface.onApiFail(ADD_DISCOUNT_DATA , "Sorry unable to upload your discount ("+response.getStatus()+")");
                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(ADD_DISCOUNT_DATA , error.getMessage());
            }
        };

        CustomCallback<String> customCallback = new CustomCallback<>(callback , ADD_DISCOUNT_DATA);
        currentCallback = customCallback;

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.WEB_ACTION_API_URL)
                .setLog(new AndroidLog(ADD_DISCOUNT_DATA.toString()))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();

        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

        erpApiInterface.pushToWebaction(webActionRequestGenericModel , currentCallback);

    }

    private void getPiDetails(HashMap<String,String> params){

        String clientId = params.get("clientId");
        String leadNumber = params.get("leadNumber");

        PIDetailsRequest request = new PIDetailsRequest();
        request.setClientId(clientId);
        request.setRefNumber(leadNumber);

        CustomCallback<List<PIDetailsResponse>> customCallback  = new CustomCallback<>(new Callback<List<PIDetailsResponse>>() {

            @Override
            public void success(List<PIDetailsResponse> piDetailsResponses, Response response) {
                if(response.getStatus() == 200 ){
                    if(piDetailsResponses.size() > 0){
                        networkUI_Interface.onApiSuccessfull(PI_DETAILS , piDetailsResponses.get(0),"Got your quotation details");
                    }else{
                        networkUI_Interface.onApiFail(PI_DETAILS , "Unable to get your quotation details");
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(PI_DETAILS ,error.getMessage());
            }
        } , PI_DETAILS);

        currentCallback = customCallback;

//        Callback<String> callback = new Callback<String>() {
//            @Override
//            public void onApiSuccessfull(String piDetailsResponses1, Response response) {
//                if(response.getStatus() == 200 ){
//                    if(piDetailsResponses1 == null ){
//                        networkUI_Interface.onApiFail(PI_DETAILS , "Quotation details not found");
//                        return;
//                    }
//
//                    Log.i("android23235616" , piDetailsResponses1);
//
//                    List<PIDetailsResponse> piDetailsResponses = new Gson().fromJson(piDetailsResponses1 ,ArrayList.class);
//                    if(piDetailsResponses.size() == 0 ){
//                        networkUI_Interface.onApiFail(PI_DETAILS ,"No quotation details found");
//                    }else{
//                        networkUI_Interface.onApiSuccessfull(PI_DETAILS  , piDetailsResponses.get(0), "Successfully fetched quoation details");
//                    }
//                }else{
//                    networkUI_Interface.onApiFail(PI_DETAILS , "Some problem occured, while getting your quotation details. Response code is "+response.getStatus());
//                }
//            }
//
//
//            @Override
//            public void failure(RetrofitError error) {
//                networkUI_Interface.onApiFail(PI_DETAILS , error.getMessage());
//            }
//        };
//
//
//        CustomCallback<String> customCallback = new CustomCallback<>(callback , PI_DETAILS);
//        currentCallback = customCallback;

        GsonConverter converter = new GsonConverter(new GsonBuilder().disableHtmlEscaping().create());

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_API_URL)
                .setLog(new AndroidLog(PI_DETAILS.toString()))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .setConverter(converter)
                .setClient(getHttclient(30))
                .build();



       // RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();

        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

        erpApiInterface.getQuotationDetails(request, currentCallback);
    }

    private void getPackages(){
        FPSessionManager fpSessionManager = new FPSessionManager(context);

        String fpId = fpSessionManager.getFpId();
        String clientId = fpSessionManager.getClientId();
        String country = fpSessionManager.getCountry();
        String category = fpSessionManager.getCategory();

        HashMap<String ,String> parameters = new HashMap<>();

        parameters.put("fpId" , fpId);
        parameters.put("clientId" , clientId);
        parameters.put("country" , country);
        parameters.put("identifier" , clientId);
        parameters.put("fpCategory" , category);

        Callback<GetPackageResponse> getPackageResponseCallback = new Callback<GetPackageResponse>() {
            @Override
            public void success(GetPackageResponse getPackageResponse, Response response) {

                if(response.getStatus() == 200 ){
                    for(GetPackageResponse.AllPackage allPackage : getPackageResponse.getAllPackages()) {
                        if(allPackage.getKey() != null ){
                            if(allPackage.getKey().toLowerCase().equals("base")) {

                                List<SingleProductModel> allProducts = new ArrayList<>();

                                for(GetPackageResponse.Value value: allPackage.getValue()) {

                                    SingleProductModel singleProductModel = new SingleProductModel();
                                    singleProductModel.setDescription(value.getDesc() == null  ? "" : value.getDesc()+"");
                                    singleProductModel.setName(value.getName());
                                    singleProductModel.setType(value.getType()+"");
                                    singleProductModel.setCashbackPercentage(0);
                                    singleProductModel.setDiscount(0);
                                    singleProductModel.setProductId(value.getId());
                                    singleProductModel.setPrice(value.getPrice());

                                    allProducts.add(singleProductModel);

                                }
                                fpSessionManager.setProducts(allProducts);
                                networkUI_Interface.onApiSuccessfull(GET_PACKAGES , allProducts , "Got your packages");
                                break;

                            }
                        }

                    }


                }else{
                    networkUI_Interface.onApiFail(GET_PACKAGES , "Sorry! You have no base packages");
                }

            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(GET_PACKAGES , "Sorry! You have no base packages");
            }
        } ;

        CustomCallback<GetPackageResponse> customCallback = new CustomCallback<>(getPackageResponseCallback , GET_PACKAGES);
        currentCallback = customCallback;

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.NOW_FLOATS_API2_URL)
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .setLog(new AndroidLog(TAG+NETWORK_OPERATIONS.GET_PACKAGES.toString()))
                .build();

        FPDetailsInterface fpDetailsInterface = restAdapter.create(FPDetailsInterface.class);

        fpDetailsInterface.getPackages(parameters, customCallback);

    }

    private void createQuotation(HashMap<String,String> params){

        String edit = params.get("edit");
        String leadNumber = params.get("leadNumber");
        String selectedProduct = params.get("productName");

        CreateQuotationRequest createQuotationRequest = new CreateQuotationRequest();
        createQuotationRequest.setSalesId(manager.getSalesId());
        createQuotationRequest.setFpTag(new FPSessionManager(context).getFpTag());
        createQuotationRequest.setEdit(edit);
        createQuotationRequest.setHpNumber(leadNumber);

        CreateQuotationRequest.CreateQuotationRequestModel createQuotationRequestModel = new CreateQuotationRequest.CreateQuotationRequestModel();
        createQuotationRequestModel.setHotProspectId(0);
        createQuotationRequestModel.setIsSingleStore(true);
        createQuotationRequestModel.setQuoteId(0);

        List<String> productNames = new ArrayList<>();
        productNames.add(selectedProduct);

        createQuotationRequestModel.setProductNames(productNames);

        createQuotationRequest.setCreateQuotationRequestModel(createQuotationRequestModel);

        Callback<GenericApiResponseModel<String>> callback = new Callback<GenericApiResponseModel<String>>() {
            @Override
            public void success(GenericApiResponseModel<String> stringGenericApiResponseModel, Response response) {
                if(response.getStatus() == 200){
                    if(stringGenericApiResponseModel != null ){
                        if(stringGenericApiResponseModel.getError().equals("yes")) {
                            networkUI_Interface.onApiFail(CREATE_EDIT_QUOTATION  , stringGenericApiResponseModel.getMessage());
                        }else{
                            networkUI_Interface.onApiSuccessfull(CREATE_EDIT_QUOTATION , stringGenericApiResponseModel.getMessage());
                        }
                    }
                }else{
                    networkUI_Interface.onApiFail(CREATE_EDIT_QUOTATION , "Sorry some problem occured, while "+(edit.toLowerCase().equals("yes")
                    ? "editing" : "creating") +" your quotation .");
                }
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(CREATE_EDIT_QUOTATION , error.getMessage());
            }
        };

        CustomCallback<GenericApiResponseModel<String>> customCallback = new CustomCallback<>(callback , CREATE_EDIT_QUOTATION);

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .setLog(new AndroidLog(CREATE_EDIT_QUOTATION.toString()))
                .setClient(getHttclient(60))
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .build();

        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

        erpApiInterface.createQuotation(createQuotationRequest , customCallback);


    }

    private void sendOtp(String number , NETWORK_OPERATIONS network_operations ){

        String successMessage = "Meeting ID send succesfully";
        String errorMessage = "Unable to send meeting ID . Please try again";

        currentCallback = new CustomCallback<>(new Callback<String>() {
            @Override
            public void success(String s, Response response) {
                if(response.getStatus() == 200)
                    networkUI_Interface.onApiSuccessfull(network_operations , successMessage);
                else
                    networkUI_Interface.onApiFail(network_operations , errorMessage);

            }

            @Override
            public void failure(RetrofitError error) {

                if(error.getResponse() != null && error.getResponse().getStatus() == 200)
                    networkUI_Interface.onApiSuccessfull(network_operations , successMessage);
                else
                    networkUI_Interface.onApiFail(network_operations , errorMessage);

            }
        } , network_operations);

        RestAdapter restAdapter = new RestAdapter.Builder()
                                    .setEndpoint(Constants.SUPPORT_API_URL)
                                    .setLog(new AndroidLog(network_operations.name()))
                                    .setLogLevel(RestAdapter.LogLevel.FULL).build();

        restAdapter.create(MeetingsInterface.class).sendOtpToPhoneNumber(number , currentCallback);
    }

    private void scheduleFOSMeeting(ScheduleMeetingRequest userData , NETWORK_OPERATIONS network_operations ){


        String successMessage = "Meeting scheduled successfully";
        String errorMessage = "Sorry unable to schedule your meeting";

        currentCallback = new CustomCallback<>(new Callback<ScheduleMeetingResponse>() {
            @Override
            public void success(ScheduleMeetingResponse s, Response response) {
                if(response.getStatus() == 200 && s != null && s.getError().equalsIgnoreCase("no"))
                    networkUI_Interface.onApiSuccessfull(network_operations , s, successMessage);
                else if(s == null )
                    networkUI_Interface.onApiFail(network_operations ,
                            errorMessage);
                else
                    networkUI_Interface.onApiFail(network_operations , s.getMessage());

            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(network_operations ,
                        errorMessage+"("+error.getMessage()+")");

            }
        } , network_operations);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .setLog(new AndroidLog(network_operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL).build();

        restAdapter.create(MeetingsInterface.class).scheduleMeeting(userData , currentCallback);
    }


    private void logFOSMeeting(LogMeetingRequest userData , NETWORK_OPERATIONS network_operations ){


        String successMessage = "Meeting logged successfully";
        String errorMessage = "Sorry unable to log your meeting";

        currentCallback = new CustomCallback<>(new Callback<LogMeetingResponse>() {
            @Override
            public void success(LogMeetingResponse s, Response response) {
                if(response.getStatus() == 200 && s != null && s.getError().equalsIgnoreCase("no"))
                    networkUI_Interface.onApiSuccessfull(network_operations , successMessage);
                else if(s == null )
                    networkUI_Interface.onApiFail(network_operations ,
                            errorMessage);
                else
                    networkUI_Interface.onApiFail(network_operations , s.getMessage());

            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(network_operations ,
                        errorMessage+"("+error.getMessage()+")");

            }
        } , network_operations);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .setLog(new AndroidLog(network_operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL).build();

        restAdapter.create(MeetingsInterface.class).LogMeeting(userData , currentCallback);
    }

    private void verifyOtp(HashMap<String,String> userData , NETWORK_OPERATIONS network_operations ){


        String successMessage = "Meeting ID verified successfully";
        String errorMessage = "Sorry unable to verify your OTP";

        currentCallback = new CustomCallback<>(new Callback<Boolean>() {
            @Override
            public void success(Boolean s, Response response) {
                if(response.getStatus() == 200 && s != null && s)
                    networkUI_Interface.onApiSuccessfull(network_operations , successMessage);
                else
                    networkUI_Interface.onApiFail(network_operations , "You have entered an invalid otp");
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(network_operations ,
                        errorMessage+"("+error.getMessage()+")");

            }
        } , network_operations);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.NOW_FLOATS_API2_URL)
                .setLog(new AndroidLog(network_operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL).build();

        restAdapter.create(MeetingsInterface.class).verifyOtp(userData , currentCallback);
    }


    private void getAllLeads(NETWORK_OPERATIONS network_operations) {


        String salesId = manager.getSalesId();
        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.ERP_EP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL)
                .setLog(new AndroidLog(network_operations.name()))
                .build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        GetLeadDetailsRequest request = new GetLeadDetailsRequest();
        request.setMethod("call");
        request.setJsonrpc("2.0");
        GetLeadDetailsRequest.Params params = new GetLeadDetailsRequest.Params();
        params.setMethod("execute");
        params.setService("object");
        List<Object> args = new ArrayList<>();
        args.add("NowFloatsV10");
        args.add(7976);
        args.add("ERPapi123");
        args.add("nf.api");
        args.add("getLeadDetails");
        GetLeadDetailsRequest.SetEmailForLeads setEmailForLeads = new GetLeadDetailsRequest.SetEmailForLeads();
        setEmailForLeads.setEmailId(salesId);
        args.add(setEmailForLeads);
        params.setArgs(args);
        request.setParams(params);

        currentCallback = new CustomCallback<>(new Callback<GetLeadDetailsResponse>() {
            @Override
            public void success(GetLeadDetailsResponse dataResponse, retrofit.client.Response response) {

                if (dataResponse == null || response.getStatus() != 200) {

                   networkUI_Interface.onApiFail(network_operations , "Something went wrong while getting your customers");
                    return;
                }
                if (response.getStatus() == 200) {
                    //onApiSuccessfull
                    if (dataResponse.getResult() != null) {

                        if (dataResponse.getResult().size() > 0)
                            networkUI_Interface.onApiSuccessfull(network_operations , dataResponse , "Got all your customers");
                        else {
                            Toast.makeText(context, "You don't have any customers!", Toast.LENGTH_SHORT).show();
                            networkUI_Interface.onApiFail(network_operations , "You don't have any customers");
                        }
                    }
                } else {

                    networkUI_Interface.onApiFail(network_operations , "Something went wrong while getting your customers");
                }
            }

            @Override
            public void failure(RetrofitError error) {

                networkUI_Interface.onApiFail(network_operations , "Something went wrong while getting your customers");
                //error
            }
        } , GET_ALL_LEADS);

        erpApiInterface.getLeadDetails(request, currentCallback);
    }

    private void requestMissedCallVerification(HashMap<String,String> userData , NETWORK_OPERATIONS network_operations ){


        String successMessage = "Missed call verification initiated";
        String errorMessage = "Sorry unable to verify your customer";

        currentCallback = new CustomCallback<>(new Callback<String>() {
            @Override
            public void success(String s, Response response) {
                if(response.getStatus() == 200 && s != null)
                    networkUI_Interface.onApiSuccessfull(network_operations , s ,successMessage);
                else
                    networkUI_Interface.onApiFail(network_operations , errorMessage);
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(network_operations ,
                        errorMessage+"("+error.getMessage()+")");

            }
        } , network_operations);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.NOW_FLOATS_API2_URL)
                .setLog(new AndroidLog(network_operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL).build();

        restAdapter.create(MeetingsInterface.class).sendMissedCallRequest(userData , currentCallback);
    }

    private void checkMissedCallVerificationStatus(HashMap<String,String> userData , NETWORK_OPERATIONS network_operations ){


        String successMessage = "Customer verified successfully";
        String errorMessage = "Sorry unable to verify your customer ";

        currentCallback = new CustomCallback<>(new Callback<Boolean>() {
            @Override
            public void success(Boolean s, Response response) {
                if(response.getStatus() == 200 && s != null && s)
                    networkUI_Interface.onApiSuccessfull(network_operations , successMessage);
                else
                    networkUI_Interface.onApiFail(network_operations ,
                            "We haven't received your customer's call yet");
            }

            @Override
            public void failure(RetrofitError error) {
                networkUI_Interface.onApiFail(network_operations ,
                        errorMessage+"("+error.getMessage()+")");

            }
        } , network_operations);

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setEndpoint(Constants.NOW_FLOATS_API2_URL)
                .setLog(new AndroidLog(network_operations.name()))
                .setLogLevel(RestAdapter.LogLevel.FULL).build();

        restAdapter.create(MeetingsInterface.class).checkVerificationStatus(userData , currentCallback);
    }

    public void stopNetworkExecution(){
        if(currentCallback != null ){
            currentCallback.cancel();
        }
        if(networkSequenceQueue != null ){
            clearNetworkQueue();
        }
    }

}
