package com.nowfloats.rocketsingh.nonassistantmode.Fragments;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.GetLeadDetailsResponse;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.NetworkResultInterface;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomEditText;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader.CustomLoaderDialog;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader.CustomLoaderModel;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NetworkHandler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import androidx.fragment.app.FragmentManager;
import br.com.simplepass.loading_button_lib.customViews.CircularProgressButton;
import br.com.simplepass.loading_button_lib.interfaces.OnAnimationEndListener;


public class GetFPDetailsFragment extends Fragment {


    private onFPDetailsSubmittedInterface mListener;
    private CustomEditText et_getFpTag;
    private CircularProgressButton circularProgressButton;
    public boolean isAttached = false;
    private List<CustomLoaderModel> customLoaderModels = new ArrayList<>();
    private HashMap<NETWORK_OPERATIONS, CustomLoaderModel> customLoaderModelHashMap = new HashMap<>();



    public GetFPDetailsFragment() {

    }

    public static GetFPDetailsFragment newInstance(onFPDetailsSubmittedInterface onFPDetailsSubmittedInterface) {

        GetFPDetailsFragment fragment = new GetFPDetailsFragment();
        fragment.mListener = onFPDetailsSubmittedInterface;

        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v =  inflater.inflate(R.layout.fragment_get_fp_details, container, false);

        et_getFpTag = v.findViewById(R.id.et_fpTag);
        circularProgressButton = v.findViewById(R.id.bt_getFpTag);

        circularProgressButton.setOnClickListener(view -> {

            mListener.onFpDetailsSubmitted(et_getFpTag.getText().toString());
            mListener.hideKeyboard(et_getFpTag);
        });

        return v;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof onFPDetailsSubmittedInterface) {
            mListener = (onFPDetailsSubmittedInterface) context;
            isAttached = true;
        } else {
            isAttached = false;
            throw new RuntimeException(context.toString()
                    + " must implement onFPDetailsSubmittedInterface");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        isAttached = false;
    }

    public void changeProgress(int progress) {
        if(progress == 0){
            circularProgressButton.startAnimation();
            circularProgressButton.setProgress(0);
        }else if(progress > 0){
            circularProgressButton.setProgress(progress);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

    }

    public void processFail(String message){
        if(!TextUtils.isEmpty(message)) {
            circularProgressButton.revertAnimation(new OnAnimationEndListener() {
                @Override
                public void onAnimationEnd() {
                    changeBackground(Color.RED);
                    circularProgressButton.setText(message);
                }
            });
        }
    }

    public void processSuccess(String message) {


//        if(! TextUtils.isEmpty(message)) {
//            circularProgressButton.revertAnimation(new OnAnimationEndListener() {
//                @Override
//                public void onAnimationEnd() {
//                    changeBackground(ContextCompat.getColor(getContext() , R.color.colorPrimary));
//                    circularProgressButton.setText(message);
//
//                }
//            });
//        }

    }

    public void changeBackground(int color){
        circularProgressButton.setBackgroundColor(color);
    }



    public interface onFPDetailsSubmittedInterface {
        // TODO: Update argument type and name
        void onFpDetailsSubmitted(String fpTag);
        void hideKeyboard(CustomEditText customEditText);
    }


}
