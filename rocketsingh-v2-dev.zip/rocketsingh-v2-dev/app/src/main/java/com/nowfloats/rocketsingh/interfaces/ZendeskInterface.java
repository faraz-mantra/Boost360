package com.nowfloats.rocketsingh.interfaces;

import com.nowfloats.rocketsingh.models.GetTicketsResponse;
import com.nowfloats.rocketsingh.models.GetUserdataFromZendeskRequest;
import com.nowfloats.rocketsingh.models.GetUserdataFromZendeskResponse;
import com.nowfloats.rocketsingh.utils.Constants;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.Headers;
import retrofit.http.POST;
import retrofit.http.Path;

public interface ZendeskInterface {
    @Headers({"Authorization: "+ Constants.ZENDESK_AUTHORIZATION})
    @GET("/api/v2/users/{userId}/tickets/requested.json")
    void getAllTicketsFromZendesk(@Path("userId") long userId , Callback<GetTicketsResponse> getTicketsResponseCallback);

    @POST("/api/Zendesk/GetTicketsBySalesId")
    void getUserDataFromZendesk(@Body GetUserdataFromZendeskRequest getUserdataFromZendeskRequest , Callback<GetUserdataFromZendeskResponse> getUserdataFromZendeskResponseCallback);
}
