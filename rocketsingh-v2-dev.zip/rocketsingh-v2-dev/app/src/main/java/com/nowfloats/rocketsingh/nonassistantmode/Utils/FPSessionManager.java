package com.nowfloats.rocketsingh.nonassistantmode.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.anachat.chatsdk.internal.database.PreferencesManager;
import com.google.gson.Gson;
import com.nowfloats.rocketsingh.models.SingleProductModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FPSessionManager {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;



    private final static String FP_TAG = "FPTag";
    private final static String COUNTRY = "COUNTRY";
    private final static String CLIENT_ID = "clientId";
    private final static String CURRENCY_CODE = "CURRENCY";
    private final static String BUSINESS_NAME = "BUSINESS_NAME";
    private final static String MOBILE = "MOBILE";
    private final static String EMAIL = "EMAIL";
    private final static String PACKAGES = "PACKAGES";
    private final static String PACKAGES_PRESENT = "PACKAGES_PRESENT";
    private final static String CATEGORY = "CATEGORY";
    private final static String FP_ID = "FP_ID";



    public FPSessionManager(Context context){
        sharedPreferences = context.getSharedPreferences(PreferencesManager.class.getSimpleName() , Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void setFpTag(String fpTag) {
        if(!TextUtils.isEmpty(fpTag))
            editor.putString(FP_TAG,fpTag).apply();
    }

    public String getFpTag(){
        return sharedPreferences.getString(FP_TAG, "NA");
    }

    public void setCountry(String country) {
        if(TextUtils.isEmpty(country)) {
            country = "India";
        }
        editor.putString(COUNTRY , country);
    }

    public void setBusinessName(String businessName){
        editor.putString(BUSINESS_NAME , businessName).apply();
    }

    public String getBusinessName(){
        return sharedPreferences.getString(BUSINESS_NAME , "NA");
    }

    public String getCountry(){
       return sharedPreferences.getString(COUNTRY , "India");
    }

    public void setClientId(String accountManager , String applicationId){
        String clientId = accountManager;
        if(TextUtils.isEmpty(accountManager)) {
            clientId = applicationId;
        }
        editor.putString(CLIENT_ID , clientId).apply();
    }

    public void setCurrencyCode(String currencyCode){
        if(TextUtils.isEmpty(currencyCode)) {
            editor.putString(CURRENCY_CODE , "INR").apply();
        }else{
            editor.putString(CURRENCY_CODE , currencyCode).apply();
        }
    }

    public String getCurrencyCode(){
        return sharedPreferences.getString(CURRENCY_CODE , "INR");
    }

    public void setPrimaryNumber(String phone) {

        if(TextUtils.isEmpty(phone)) {
            editor.putString(MOBILE , "").apply();
        }else{
            editor.putString(MOBILE , phone).apply();
        }

    }

    public String getPrimaryNumber(){
        return sharedPreferences.getString(MOBILE , "");
    }

    public void setEmail(String email) {
        editor.putString(EMAIL , email).apply();
    }

    public String getEmail(){
        return sharedPreferences.getString(EMAIL , "");
    }

    public String getClientId(){
        return sharedPreferences.getString(CLIENT_ID , "");
    }

    public void setCategory(String category){
        editor.putString(CATEGORY , category).apply();
    }

    public String getCategory(){
        return sharedPreferences.getString(CATEGORY , "");
    }

    private void setPackagesPresent(boolean present){
        editor.putBoolean(PACKAGES_PRESENT , present).apply();
    }

    public boolean getPackagesPresent(){
        return sharedPreferences.getBoolean(PACKAGES_PRESENT , false);
    }

    public void setProducts(List<SingleProductModel> products){
        setPackagesPresent(products.size() > 0);
        editor.putString(PACKAGES , new Gson().toJson(products));
    }

    public List<SingleProductModel> getProducts(){
       return new Gson().fromJson(
               sharedPreferences.getString(
                       PACKAGES , new Gson().toJson(new ArrayList<SingleProductModel>()
                       )
               ) ,
               List.class) ;

    }

    public void setFpID(String fpId){
        editor.putString(FP_ID , fpId).apply();
    }

    public String getFpId(){
        return sharedPreferences.getString(FP_ID , "");
    }


}
