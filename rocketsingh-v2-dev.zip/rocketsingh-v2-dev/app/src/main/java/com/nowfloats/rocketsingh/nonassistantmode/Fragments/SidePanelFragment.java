package com.nowfloats.rocketsingh.nonassistantmode.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.AboutActivity;
import com.nowfloats.rocketsingh.activity.AttendanceActivity;
import com.nowfloats.rocketsingh.activity.DiscountApprovalsActivity;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.nonassistantmode.activity.ClaimActivity;
import com.nowfloats.rocketsingh.nonassistantmode.activity.DiscountActivity;
import com.nowfloats.rocketsingh.nonassistantmode.activity.FOSMeetingActivity;
import com.nowfloats.rocketsingh.nonassistantmode.activity.ReportOrderPickupActivity;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

public class SidePanelFragment extends Fragment implements View.OnClickListener {

    View containerView;
    DrawerLayout mDrawerLayout;
    ActionBarDrawerToggle mDrawerToggle;
    boolean mUserLearnedDrawer;
    private EditText et_spEmailForAdmin;
    private LinearLayout ll_discountApprovalRequest , ll_about , ll_logout , ll_manageMeetings , ll_discountApprovalStatus , ll_manageAttendance ,ll_home, ll_claimSale , ll_reportOrderPickup;
    private boolean mFromSavedInstanceState;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = LayoutInflater.from(getContext()).inflate(R.layout.fragment_custom_navigation_drawer , container , false);
        UserSessionManager manager = new UserSessionManager(getContext());
        et_spEmailForAdmin = v.findViewById(R.id.et_emailSalesPersonAdmin);

        ll_discountApprovalRequest = v.findViewById(R.id.ll_discountApprovalRequest);
        ll_about = v.findViewById(R.id.ll_about);
        ll_logout = v.findViewById(R.id.ll_logout);
        ll_manageMeetings = v.findViewById(R.id.ll_manageMeetings);
        ll_discountApprovalStatus = v.findViewById(R.id.ll_discountApprovalStatus);
        ll_manageAttendance = v.findViewById(R.id.ll_manageAttendance);
        ll_claimSale = v.findViewById(R.id.ll_claimSale);
        ll_home = v.findViewById(R.id.ll_home);
        ll_reportOrderPickup = v.findViewById(R.id.ll_reportOrderPickup);

        ll_discountApprovalRequest.setOnClickListener(this);
        ll_about.setOnClickListener(this);
        ll_logout.setOnClickListener(this);
        ll_manageMeetings.setOnClickListener(this);
        ll_discountApprovalStatus.setOnClickListener(this);
        ll_manageAttendance.setOnClickListener(this);
        ll_claimSale.setOnClickListener(this);
        ll_reportOrderPickup.setOnClickListener(this);
        ll_home.setOnClickListener(this);

        TextView tv_spName = v.findViewById(R.id.tv_spname);
        TextView tv_spEmail = v.findViewById(R.id.tv_spEmail);

        tv_spName.setText(manager.getEmployeeId());
        tv_spEmail.setText(manager.getSalesId());

        if( !(getActivity() instanceof GoogleLoginActivity))
            ll_logout.setVisibility(View.GONE);

        if(!manager.isAdmin())
            et_spEmailForAdmin.setVisibility(View.GONE);

        et_spEmailForAdmin.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                manager.setSalesId(s.toString().toLowerCase());
            }
        });
        return v;
    }

    public void setUp(View containerView, DrawerLayout drawerLayout, final Toolbar toolbar) {
        this.containerView = containerView;
        mDrawerLayout = drawerLayout;
        mDrawerToggle = new ActionBarDrawerToggle(getActivity(), drawerLayout, toolbar, R.string.drawer_open, R.string.drawer_close) {
            @Override
            public void onDrawerOpened(View drawerView) {
                super.onDrawerOpened(drawerView);


                getActivity().invalidateOptionsMenu();
            }

            @Override
            public void syncState() {
                super.syncState();
            }

            @Override
            public void onDrawerClosed(View drawerView) {

                super.onDrawerClosed(drawerView);
                if (getActivity() != null)
                    getActivity().invalidateOptionsMenu();
            }

            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                super.onDrawerSlide(drawerView, slideOffset);

            }
        };
        if (!mUserLearnedDrawer && !mFromSavedInstanceState) {
            mDrawerLayout.openDrawer(containerView);
        }
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerLayout.post(new Runnable() {
            @Override
            public void run() {
                mDrawerToggle.syncState();
            }
        });

    }

    @Override
    public void onClick(View v) {

        Intent i = null;

        switch (v.getId()) {
            case R.id.ll_discountApprovalRequest:
                i = new Intent(getContext() , DiscountActivity.class);
                break;

            case R.id.ll_discountApprovalStatus:
                i = new Intent(getContext() , DiscountApprovalsActivity.class);
                break;

            case R.id.ll_reportOrderPickup:
                i = new Intent(getContext() , ReportOrderPickupActivity.class);
                break;

            case R.id.ll_claimSale:
                i = new Intent(getContext() , ClaimActivity.class);
                break;

            case R.id.ll_about:
                i = new Intent(getContext() , AboutActivity.class);
                break;

            case R.id.ll_home:
                i = new Intent(getContext() , GoogleLoginActivity.class);
                break;

            case R.id.ll_manageMeetings:
                i = new Intent(getContext() , FOSMeetingActivity.class);
                break;

            case R.id.ll_manageAttendance:
                i = new Intent(getContext() , AttendanceActivity.class);
                break;

            case R.id.ll_logout:
                break;

        }

        if(i != null ){
            Intent finalI = i;
            new Handler().postDelayed(() -> {
                startActivity(finalI);
            },250);
            mDrawerLayout.closeDrawer(Gravity.LEFT);
        }
    }
}
