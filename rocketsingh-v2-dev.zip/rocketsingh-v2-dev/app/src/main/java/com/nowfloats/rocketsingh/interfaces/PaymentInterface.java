package com.nowfloats.rocketsingh.interfaces;

import com.nowfloats.rocketsingh.models.ERPGenericRequestModel;
import com.nowfloats.rocketsingh.models.ERPGenericResponseModel;
import com.nowfloats.rocketsingh.models.FinalPaymentRequest;
import com.nowfloats.rocketsingh.models.FinalisePaymentResponse;
import com.nowfloats.rocketsingh.models.IFSCPaymentResponse;
import com.nowfloats.rocketsingh.models.InitiatePaymentRequest;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.CustomCallback;

import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Path;
import retrofit.http.Query;

public interface PaymentInterface {
    @GET("/{IFSC}")
    void verifyIFSCode(@Path("IFSC") String ifsc , CustomCallback<IFSCPaymentResponse> callback);

    @POST("/Payment/v1/floatingpoints/initiate/2FA76D4AFCD84494BD609FDB4B3D76782F56AE790A3744198E6F517708CAAA21")
    void initialisePayment(@Body InitiatePaymentRequest initiatePaymentRequest , CustomCallback<String> transactionId);

    @POST("/api/Payments/UpdateChequePayment")
    void finalisePayment(@Body FinalPaymentRequest finalPaymentRequest ,
                         CustomCallback<FinalisePaymentResponse> finalPaymentRequestCustomCallback);

    @GET("/api/User/CheckIfMarketPlace")
    void validateClaimID(@Query("transactionId") String transactionId , CustomCallback<String> customCallback);

    @GET("/jsonrpc")
    void uploadSOReceipt(@Body ERPGenericRequestModel erpGenericRequestModel ,
                         CustomCallback<ERPGenericResponseModel> customCallback);
}
