package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetLeadModelRequest {

    @SerializedName("emailId")
    @Expose
    private String emailId;

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
}