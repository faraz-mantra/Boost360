package com.nowfloats.rocketsingh.models;


import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;
import java.util.List;


public class VerticalPackageModel extends ExpandableGroup<PackageModel>{
    private String category;
    private List<PackageModel> products;

    public VerticalPackageModel(String title, List<PackageModel> items) {
        super(title, items);
        this.products = items;
        category = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
