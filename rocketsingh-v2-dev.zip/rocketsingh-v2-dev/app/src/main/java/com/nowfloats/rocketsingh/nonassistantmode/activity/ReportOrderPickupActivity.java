package com.nowfloats.rocketsingh.nonassistantmode.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

import com.google.android.gms.ads.formats.GoogleNativeAd;
import com.google.android.material.snackbar.Snackbar;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.models.FinalPaymentRequest;
import com.nowfloats.rocketsingh.models.IFSCPaymentResponse;
import com.nowfloats.rocketsingh.models.InitiatePaymentRequest;
import com.nowfloats.rocketsingh.models.RedeemCouponResponse;
import com.nowfloats.rocketsingh.models.SingleProductModel;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.CheckFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.GetFPDetailsFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.GetQuotationDetailsFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.InvoiceFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.SidePanelFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.FPDetailsInterface;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.NetworkResultInterface;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomEditText;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader.CustomLoaderDialog;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.FPSessionManager;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.FLOW_SESSIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NetworkHandler;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.nowfloats.rocketsingh.utils.InternalLocationManager;
import com.nowfloats.rocketsingh.utils.UserSessionManager;
import com.tanmay.nf.rocketimagepicker.RocketImageInterface;
import com.tanmay.nf.rocketimagepicker.RocketImagePicker;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class ReportOrderPickupActivity extends AppCompatActivity implements
        RocketImageInterface,NetworkResultInterface ,
        GetFPDetailsFragment.onFPDetailsSubmittedInterface  ,
        InvoiceFragment.onInvoiceUpdated,
        CheckFragment.CheckInterface {

    private NetworkHandler networkHandler;
    private String fpTag ;
    private CustomLoaderDialog customLoaderDialog;
    private ConstraintLayout constraintLayout;
    RocketImagePicker rocketImagePicker;
    private List<SingleProductModel> singleProductModelList;
    private InitiatePaymentRequest initiatePaymentRequest = new InitiatePaymentRequest();
    private FinalPaymentRequest finalPaymentRequest = new FinalPaymentRequest();
    private String discountCoupon ;
    private String finalMessage;
    private RedeemCouponResponse redeemCouponResponse;
    private InvoiceFragment invoiceFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_order_pickup);
        InternalLocationManager.startLocationTracking(this);
        initialieUIElements();
        setupDrawerLayout();
        gotTofirstFragment();
    }

    public void gotTofirstFragment(){
        GetFPDetailsFragment getFPDetailsFragment = new GetFPDetailsFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.cl_order_pickup_parentLayout , getFPDetailsFragment).commit();
    }

    private void initialieUIElements(){
        constraintLayout = findViewById(R.id.cl_order_pickup_parentLayout);
    }

    public void startNetworkSession(short session){

        Queue<NETWORK_OPERATIONS> networkOperations = new LinkedList<>();

        switch (session) {
            case FLOW_SESSIONS.ORDER_PICKUP.FP_DETAILS:
                networkOperations.add(NETWORK_OPERATIONS.GET_FP_DETAILS);
                networkOperations.add(NETWORK_OPERATIONS.GET_PACKAGES);
                break;
            case FLOW_SESSIONS.ORDER_PICKUP.VERIFY_COUPON:
                networkOperations.clear();
                networkOperations.add(NETWORK_OPERATIONS.REDEEM_DISCOUNT_COUPON);
                break;

            case FLOW_SESSIONS.ORDER_PICKUP.EXECUTE_PAYMENT:
                 if(! finalPaymentRequest.getRtgsPayment())
                    networkOperations.add(NETWORK_OPERATIONS.IFSC_VALIDATION);
                 networkOperations.add(NETWORK_OPERATIONS.GET_EMPLOYEE_DETAILS);
                 networkOperations.add(NETWORK_OPERATIONS.INITIATE_PAYMENT);
                 networkOperations.add(NETWORK_OPERATIONS.FINALISE_PAYMENT);break;
        }

        networkHandler = new NetworkHandler(this, this)
                .setNetworkOperationQueue(networkOperations)
                .setOrUpdateSession(session)
                .startThread();
    }

    @Override
    public void onApiRequestStarted(NETWORK_OPERATIONS network_operations) {
        initiateApiState(network_operations);
    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, String message) {
        updateApiStateInFpFragment(operationKey , message , true);
        finalMessage = message;
        if(operationKey == NETWORK_OPERATIONS.GET_EMPLOYEE_DETAILS)
            initiatePaymentRequest.setNFInternalSalesPersonId(new UserSessionManager(this).getEmployeeId());
        networkHandler.executeNext();
    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, Object model, String message) {
        updateApiStateInFpFragment(operationKey , message , true);

        switch (operationKey) {
            case GET_PACKAGES:
                singleProductModelList = (List<SingleProductModel>)model;
                break;
            case REDEEM_DISCOUNT_COUPON:
                redeemCouponResponse = (RedeemCouponResponse)model;
                updateNetAmount();
                break;
            case INITIATE_PAYMENT:
                finalPaymentRequest.setTransactionId(model.toString());
                break;
            case IFSC_VALIDATION:
                IFSCPaymentResponse response = (IFSCPaymentResponse)model;
                finalPaymentRequest.setBankName(response.getBANK());
                finalPaymentRequest.setIfscCode(response.getIFSC());
                break;
        }

        networkHandler.executeNext();
    }

    @Override
    public void onApiFail(NETWORK_OPERATIONS operationKey, String errorMessage) {
        updateApiStateInFpFragment(operationKey , errorMessage , false);
    }

    @Override
    public void networkOperationsFinished(boolean success, short session) {
        if(session == FLOW_SESSIONS.ORDER_PICKUP.FP_DETAILS) {
            showSnackbarMessage("Please fill the following details" , true);
            hideDialog(false);
            goToInvoicedetailsfragment(false);
        }else if(session == FLOW_SESSIONS.ORDER_PICKUP.VERIFY_COUPON)
        {
            hideDialog(true);
        }else if(session == FLOW_SESSIONS.ORDER_PICKUP.EXECUTE_PAYMENT) {
            finishApiProcessAnimation(finalMessage);
        }
    }

    @Override
    public void prepareRequestBody(NETWORK_OPERATIONS network_operations, NetworkHandler networkHandler) {
        switch (network_operations) {
            case GET_FP_DETAILS:
                networkHandler.updateRequestBody(network_operations , fpTag);
                break;
            case REDEEM_DISCOUNT_COUPON:
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("discountCoupon" , discountCoupon);
                hashMap.put("redeem" , "no");
                networkHandler.updateRequestBody(NETWORK_OPERATIONS.REDEEM_DISCOUNT_COUPON ,hashMap );
                break;
            case FINALISE_PAYMENT:
                networkHandler.updateRequestBody(network_operations , finalPaymentRequest);
                break;
            case INITIATE_PAYMENT:
                networkHandler.updateRequestBody(network_operations , initiatePaymentRequest);
                break;
            case IFSC_VALIDATION:
                networkHandler.updateRequestBody(network_operations , finalPaymentRequest.getIfscCode());
                break;
        }
    }

    private void initiateApiState(NETWORK_OPERATIONS network_operations) {
        if(dialogIsValid()) {
            customLoaderDialog.initiateApiState(network_operations);
            return;
        }else {
            showDialog();
            new Handler().postDelayed(() -> {customLoaderDialog.initiateApiState(network_operations);} , 0);
        }

    }


    public boolean dialogIsValid(){
        return customLoaderDialog != null  && customLoaderDialog.isVisible();
    }

    private void showDialog() {
        if (customLoaderDialog == null) {
            customLoaderDialog = new CustomLoaderDialog();
        }

        if(customLoaderDialog.isVisible())
            return;
        // Create and show the dialog.
        customLoaderDialog = CustomLoaderDialog.newInstance();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.executePendingTransactions();
        customLoaderDialog.show(fragmentManager.beginTransaction(), "dialog");
    }


    public void updateApiStateInFpFragment(NETWORK_OPERATIONS network_operations , String message , boolean success) {
        if (success) {
            updateApiForSuccess(network_operations, message);

        } else {
            updateApiForFailure(network_operations, message);
        }
    }

    private void hideDialog(boolean delay){
        // delay is just for the effect

        if(customLoaderDialog == null )
            return;
        if(! customLoaderDialog.isVisible())
            return;

        new Handler().postDelayed(() -> {customLoaderDialog.closeDialog();} , delay ? 2500: 0);


    }

    private void updateApiForSuccess(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForSuccess(network_operations , message);
        }
    }

    public void finishApiProcessAnimation(String message){
        if(customLoaderDialog != null ){
            if(customLoaderDialog.isVisible()) {
                customLoaderDialog.showSuccessfulDialog(message);
            }
            hideDialog(true);
        }
    }

    private void updateApiForFailure(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForFailure(network_operations, message);
            hideDialog(true);
        }
    }

    @Override
    public void onFpDetailsSubmitted(String fpTag) {
        this.fpTag = fpTag;
        if(ExternalProcessManager.stringIsNull(fpTag)) {
            showSnackbarMessage("Please enter a customer tag" , false);
            return;
        }
        startNetworkSession(FLOW_SESSIONS.ORDER_PICKUP.FP_DETAILS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(CheckFragment.rocketImagePicker != null )
            CheckFragment.rocketImagePicker.onActivityResult(requestCode , resultCode , data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(CheckFragment.rocketImagePicker != null )
            CheckFragment.rocketImagePicker.onRequestPermissionsResult(requestCode , grantResults);

    }

    @Override
    public void hideKeyboard(CustomEditText customEditText) {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        assert imm != null;
        imm.hideSoftInputFromWindow(customEditText.getApplicationWindowToken(), 0);
    }

    private void showSnackbarMessage(String message , boolean success){
        Snackbar snackbar =   Snackbar.make(constraintLayout , message , Snackbar.LENGTH_LONG);
        if( !success ) {
            snackbar.getView().setBackgroundColor(ContextCompat.getColor(this , R.color.red));
        }else{
            snackbar.getView().setBackgroundColor(ContextCompat.getColor(this , R.color.green));
        }
        snackbar.show();
    }

    public void goToInvoicedetailsfragment(boolean delay){
        invoiceFragment = InvoiceFragment.newInstance(singleProductModelList,this);

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.setCustomAnimations(R.anim.slide_in_left_dialog , R.anim.slide_out_left_dialog);
        fragmentTransaction.replace(R.id.cl_order_pickup_parentLayout , invoiceFragment);
        new Handler().postDelayed(() -> fragmentTransaction.commit() , delay ? 1000 : 0);
    }

    @Override
    public void onCouponApplied(String couponCode) {
        if(TextUtils.isEmpty(couponCode)) {
            showSnackbarMessage("Please enter a coupon first" , false);
            return;
        }
        discountCoupon = couponCode;
        startNetworkSession(FLOW_SESSIONS.ORDER_PICKUP.VERIFY_COUPON);
    }

    public void goToPaymentFragments(boolean checkPayment){
        CheckFragment checkFragment = CheckFragment.getInstance(this,checkPayment);
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.executePendingTransactions();
        checkFragment.show(fragmentManager , "CheckFragment");
    }

    @Override
    public void onInvoiceDetailsSubmitted(SingleProductModel singleProductModel ,
                                          int TDS,
                                          double tdsAmount,
                                          double baseAmount,
                                          double netAmount,
                                          double gstAmount ,
                                          boolean gstApplied ,
                                          String gstNumber , boolean checkPayment) {

        if(singleProductModel == null ){
            showSnackbarMessage("Please select a product" , false);
            return ;
        }

        if(gstApplied && ExternalProcessManager.stringIsNull(gstNumber)) {
            showSnackbarMessage("Please enter a GST number" , false);
            return;
        }

        List<InitiatePaymentRequest.Product> products = new LinkedList<>();
        InitiatePaymentRequest.Product product = new InitiatePaymentRequest.Product();
        product.setProductId(singleProductModel.getProductId());
        product.setName(singleProductModel.getName());
        product.setType(singleProductModel.getType());
        product.setPrice(singleProductModel.getPrice());
        product.setQuantity(1);
        product.setDescription(singleProductModel.getDescription());
        product.setDiscount(0);

        products.add(product);

        FPSessionManager fpSessionManager = new FPSessionManager(this);
        initiatePaymentRequest.setProducts(products);
        initiatePaymentRequest.setFpTag(fpSessionManager.getFpTag().toUpperCase());
        initiatePaymentRequest.setFpId(fpSessionManager.getFpId());
        initiatePaymentRequest.setPaymentTransactionChannel(1);
        initiatePaymentRequest.setEmail(fpSessionManager.getEmail());
        initiatePaymentRequest.setClientId(Constants.clientId);
        initiatePaymentRequest.setCustomerName(fpSessionManager.getBusinessName());
        initiatePaymentRequest.setPhoneNumberExtension("+91");
        initiatePaymentRequest.setRecurringMonths(0);
        initiatePaymentRequest.setTdsPercentage(TDS);
        initiatePaymentRequest.setGSTNumber(gstApplied ? gstNumber : "");
        initiatePaymentRequest.setPaymentMode(0);
        initiatePaymentRequest.setNFInternalSalesPersonId(new UserSessionManager(this).getEmployeeId());

        finalPaymentRequest.setProducts(initiatePaymentRequest.getProducts());
        finalPaymentRequest.setClientId(fpSessionManager.getClientId());
        finalPaymentRequest.setName(fpSessionManager.getBusinessName());
        finalPaymentRequest.setTotalPrice(netAmount);
        finalPaymentRequest.setEmail(fpSessionManager.getEmail());
        finalPaymentRequest.setCouponCode(discountCoupon);
        finalPaymentRequest.setFpId(fpSessionManager.getFpId());
        finalPaymentRequest.setTdsPercentage((double) TDS);
        finalPaymentRequest.setTaxAmount(gstAmount);
        finalPaymentRequest.setCurrencyCode("INR");
        finalPaymentRequest.setGstNumber(gstApplied ? "" : gstNumber);
        finalPaymentRequest.setFpTag(fpSessionManager.getFpTag());
        finalPaymentRequest.setEmployeeId(new UserSessionManager(this).getEmployeeId());
        finalPaymentRequest.setLat(new UserSessionManager(this).getLatitude()+"");
        finalPaymentRequest.setLng(new UserSessionManager(this).getLongitude()+"");
        finalPaymentRequest.setBaseAmount(baseAmount);
        finalPaymentRequest.setRtgsPayment(!checkPayment);

        goToPaymentFragments(checkPayment);
    }

    public void updateNetAmount(){
        if(invoiceFragment != null ){
            if(invoiceFragment.isVisible) {
                invoiceFragment.onDiscountApplied(redeemCouponResponse.getDiscountPercentage());
            }
        }
    }

    @Override
    public void onImagePickerPermissionDenied(int imageRequestCode) {
        showSnackbarMessage("Sorry, but we need this permission" , false);
    }

    @Override
    public void onImageSupplied(Bitmap bitmap , int imageRequestCode , String imageName) {
        showSnackbarMessage("Got the image" , true);
    }

    @Override
    public void onImagePickFail(int imageRequestCode) {
        showSnackbarMessage("Sorry some problem occured while getting your image"  ,false);
    }


    @Override
    public void onDetailsSubmitted(String accountNumber,
                                   String accountName,
                                   String ifscCode,
                                   String rtgs,
                                   Bitmap alternateImage,
                                   Bitmap primaryImage,
                                   Calendar calendar ,
                                   boolean checkPayment) {

        if(checkPayment && ExternalProcessManager.stringIsNull(accountName)) {
            showSnackbarMessage("Please enter the account name" , false);
            return;
        }

        if(ExternalProcessManager.stringIsNull(accountNumber)) {
            showSnackbarMessage("Please enter the account number" , false);
            return;
        }
        if(checkPayment && ExternalProcessManager.stringIsNull(ifscCode)) {
            showSnackbarMessage("Please enter the IFSC code" , false);
            return;
        }
        if(primaryImage == null) {
            showSnackbarMessage("Please upload a primary image" , false);
            return;
        }

        if(checkPayment && calendar == null) {
            showSnackbarMessage("Please enter the cheque date" , false);
            return;
        }

        if(!checkPayment && ExternalProcessManager.stringIsNull(rtgs)) {
            showSnackbarMessage("Please enter a transaction number",false);
            return;
        }

        finalPaymentRequest.setBankAccountNumber(accountNumber);
        finalPaymentRequest.setIfscCode(ifscCode);
        finalPaymentRequest.setImage(Constants.DUMMTY_IMAGE_URL);
        //finalPaymentRequest.setImage(ExternalProcessManager.getBase64StringFromImage(primaryImage));
        finalPaymentRequest.setAlternateImage(ExternalProcessManager.getBase64StringFromImage(alternateImage));
        finalPaymentRequest.setBase64Mode(false);
        finalPaymentRequest.setRtgsId(rtgs);

        if(checkPayment) {
            FinalPaymentRequest.ActivationDate activationDate = new FinalPaymentRequest.ActivationDate();
            activationDate.setMday(calendar.get(Calendar.DAY_OF_MONTH));
            activationDate.setMonth(calendar.get(Calendar.MONTH) + 1);
            activationDate.setYear(calendar.get(Calendar.YEAR));
            finalPaymentRequest.setActivationDate(activationDate);
        }

        startNetworkSession(FLOW_SESSIONS.ORDER_PICKUP.EXECUTE_PAYMENT);
    }

    private void setupDrawerLayout() {

        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        SidePanelFragment sidePanelFragment = new SidePanelFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.fm_fragment_navigation_drawer , sidePanelFragment).commitAllowingStateLoss();
        DrawerLayout mDrawerLayout = findViewById(R.id.drawer_layout);
        sidePanelFragment.setUp(findViewById(R.id.fm_fragment_navigation_drawer) , findViewById(R.id.drawer_layout) , toolbar);
        mDrawerLayout.closeDrawer(Gravity.LEFT);

        findViewById(R.id.im_selfMode).setOnClickListener(view -> {
            mDrawerLayout.openDrawer(findViewById(R.id.fm_fragment_navigation_drawer));
        });

        UserSessionManager manager = new UserSessionManager(this);

        HashMap<String,String> mDataMap = new HashMap<>();

        mDataMap.put("salesId", manager.getSalesId());//users email id
        mDataMap.put("fcmId", manager.getFcmId());
        mDataMap.put("division" , manager.getDivision());

        findViewById(R.id.im_startChat).setOnClickListener(view -> {
            Intent i = new Intent(view.getContext() , GoogleLoginActivity.class);
            i.setAction("startChat");
            startActivity(i);
        });
    }
}
