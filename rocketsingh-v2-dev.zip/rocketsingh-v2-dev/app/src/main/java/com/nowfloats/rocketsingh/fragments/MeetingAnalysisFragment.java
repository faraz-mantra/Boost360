package com.nowfloats.rocketsingh.fragments;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.adapters.MeetingAnalysisAdapter;
import com.nowfloats.rocketsingh.models.GetLatestMeetingsResponse;
import com.nowfloats.rocketsingh.utils.MeetingAnalysisUtils;

import java.util.ArrayList;
import java.util.List;


public class MeetingAnalysisFragment extends DialogFragment implements MeetingAnalysisAdapter.CheckIfListHasValues{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    private List<GetLatestMeetingsResponse> between30to45Days = new ArrayList<>();
    private List<GetLatestMeetingsResponse> moreThan45Days = new ArrayList<>();
    private RecyclerView recyclerView;
    private MeetingAnalysisUtils meetingAnalysisUtils;
    private MeetingAnalysisAdapter meetingAnalysisAdapter;

    private Button bt_moreThan45Days, bt_between30to45Days;
    private TextView tv_Header;
    private TextView tv_promtForEmptyList,tv_close;
    public MeetingAnalysisFragment() {
        // Required empty public constructor
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getDialog().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        //getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        //getDialog().getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        setCancelable(true);
        recyclerView = view.findViewById(R.id.meetingsAnalysisRecyclerView);
        meetingAnalysisUtils = new MeetingAnalysisUtils(getContext());
        bt_between30to45Days = view.findViewById(R.id.bt_30_45_days);
        bt_moreThan45Days = view.findViewById(R.id.bt_moreThan45);
        tv_promtForEmptyList = view.findViewById(R.id.promptForEmptyValues);
        tv_close = view.findViewById(R.id.tv_cancel);

        tv_Header = view.findViewById(R.id.tv_header);
        tv_Header.setText("Your overdue meetings as of "+meetingAnalysisUtils.getCurrentDate());
        meetingAnalysisAdapter = new MeetingAnalysisAdapter(this);
        if(between30to45Days.size()!=0) {
            enableButton30_45();
            meetingAnalysisAdapter.setData(between30to45Days);
        }
        else if(moreThan45Days.size()!=0) {
            enableButton45();
            meetingAnalysisAdapter.setData(moreThan45Days);
        }else {
            enableButton30_45();
            meetingAnalysisAdapter.setData(between30to45Days);
        }
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(meetingAnalysisAdapter);
        bt_between30to45Days.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enableButton30_45();
                meetingAnalysisAdapter.setData(between30to45Days);
            }
        });

        bt_moreThan45Days.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                enableButton45();
                meetingAnalysisAdapter.setData(moreThan45Days);

            }
        });

        tv_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
    }

    @SuppressLint("ValidFragment")
    public MeetingAnalysisFragment(List<GetLatestMeetingsResponse> between30to45Days, List<GetLatestMeetingsResponse> moreThan45Days){
        this.between30to45Days = between30to45Days;
        this.moreThan45Days = moreThan45Days;
    }

    private void enableButton30_45(){
       bt_moreThan45Days.setBackgroundResource(R.drawable.rounded_corner_white);
        bt_moreThan45Days.setTextColor(ContextCompat.getColor(getContext(),R.color.colorPrimary));
       bt_between30to45Days.setBackgroundResource(R.drawable.rounded_corner_yellow);
       bt_between30to45Days.setTextColor(ContextCompat.getColor(getContext(),R.color.white));

    }

    private void enableButton45(){
        bt_between30to45Days.setBackgroundResource(R.drawable.rounded_corner_white);
        bt_between30to45Days.setTextColor(ContextCompat.getColor(getContext(),R.color.colorPrimary));
        bt_moreThan45Days.setBackgroundResource(R.drawable.rounded_corner_yellow);
        bt_moreThan45Days.setTextColor(ContextCompat.getColor(getContext(),R.color.white));

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_meeting_analysis, container, false);
    }

    @Override
    public void listHasValues(boolean Flag) {
        if(Flag){
            tv_promtForEmptyList.setVisibility(View.INVISIBLE);
        }else{
            tv_promtForEmptyList.setVisibility(View.VISIBLE);
        }
    }

    // TODO: Rename method, update argument and hook method into UI event

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null)
        {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
        }

    }
}
