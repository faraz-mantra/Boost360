package com.nowfloats.rocketsingh.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import androidx.annotation.RequiresApi;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.interfaces.CFInterface;
import com.nowfloats.rocketsingh.models.GetFpTagsForMeetingsRequest;
import com.nowfloats.rocketsingh.models.GetLatestMeetingsResponse;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.MeetingAnalysisUtils;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * Created by NowFloats on 15-Feb-18.
 */

public class CfMeetingAnalysisService extends Service {
    private NotificationManager mCFNM;

    // Unique Identification Number for the Notification.
    // We use it on Notification start, and to cancel it.
    private int CF_NOTIFICATION = R.string.cf_meetings_analysis_notification;
    private UserSessionManager manager;
    private MeetingAnalysisUtils meetingAnalysisUtils;
    /**
     * Class for clients to access.  Because we know this service always
     * runs in the same process as its clients, we don't need to deal with
     * IPC.
     */
    public class LocalBinder extends Binder {
        CfMeetingAnalysisService getService() {
            return CfMeetingAnalysisService.this;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onCreate() {
        mCFNM = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        // Display a notification about us starting.  We put an icon in the status bar.
        manager = new UserSessionManager(this);
        meetingAnalysisUtils = new MeetingAnalysisUtils(this);
        if(!TextUtils.isEmpty(manager.getCFUsername()))
        {
            Log.i("amdroid23235616","got here");
            getFpTagsForMeetingAnalysis("","","");
            looperCall(manager.getCFUsername());
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_NOT_STICKY;
    }
    @Override
    public void onDestroy() {
        // Cancel the persistent notification.
        mCFNM.cancel(CF_NOTIFICATION);
        // Tell the user we stopped.
        Toast.makeText(this, "CF Local Service Stopped", Toast.LENGTH_SHORT).show();
    }
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    // This is the object that receives interactions from clients.  See
    // RemoteService for a more complete example.
    private final IBinder mBinder = new LocalBinder();

    /**
     * Show a notification while this service is running.
     */

    private void getLatestMeetings(JSONArray fpTagsJsonArray, String title, String body, String performance) throws JSONException {
        if(meetingAnalysisUtils ==null){
            meetingAnalysisUtils = new MeetingAnalysisUtils(this);
        }
        List<String> fpTags = new ArrayList<>();
        for(int i=0; i<fpTagsJsonArray.length(); i++) {
            fpTags.add(fpTagsJsonArray.getString(i));
        }
        RestAdapter restAdapter =  new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).build();
        Map<String,String> query = new HashMap();
        query.put("authClientId","A91B82DE3E93446A8141A52F288F69EFA1B09B1D13BB4E55BE743AB547B3489E");
        CFInterface cfInterface = restAdapter.create(CFInterface.class);
        cfInterface.getLatestMeetings(fpTags, new Callback<List<GetLatestMeetingsResponse>>() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void success(List<GetLatestMeetingsResponse> getLatestMeetingsResponses, Response response) {
                if(response.getStatus()==200){
                    List<GetLatestMeetingsResponse> moreThan45Days = new ArrayList<>();
                    List<GetLatestMeetingsResponse> between30And45Days = new ArrayList<>();
                    DateTime endTime = DateTime.now(DateTimeZone.UTC);
                    for(GetLatestMeetingsResponse meetingsResponse: getLatestMeetingsResponses){
                        if((meetingsResponse.getCreatedOn()!=null)) {
                            meetingAnalysisUtils.DisplayLog(meetingsResponse.getFPTag());
                            DateTime startTime = DateTime.parse(meetingsResponse.getCreatedOn());
                            long days = meetingAnalysisUtils.printDifference(startTime,endTime);
                            meetingsResponse.setLastMetDifference(days);
                            meetingAnalysisUtils.DisplayLog("difference is "+days);
                            int lowerLimit = 30; // in days
                            int upperLimit = 45; // in days
                            if(days > upperLimit){
                                moreThan45Days.add(meetingsResponse);
                            }else if(days >= lowerLimit && days <= upperLimit){
                                between30And45Days.add(meetingsResponse);
                            }
                        }
                    }
                    String tempTitle = "Your overdue meetings summary as of "+parseDate(meetingAnalysisUtils.getlatestTime());
                    String tempBody = body;
                    tempBody+="45+ days: "+ moreThan45Days.size()+"\n";
                    tempBody+="30-45 days: "+ between30And45Days.size();
                    showCFNotification(tempTitle,tempBody,performance);
                }else{
                    meetingAnalysisUtils.DisplayLog("failed");
                }
            }
            @Override
            public void failure(RetrofitError error) {
                meetingAnalysisUtils.DisplayLog("faled2 "+error.getMessage());
            }
        });
    }


    private void getFpTagsForMeetingAnalysis(String title, String body, String performance){
        if(meetingAnalysisUtils ==null){
            meetingAnalysisUtils = new MeetingAnalysisUtils(this);
        }
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.NOW_FLOATS_API2_URL).build();
        CFInterface cfInterface = restAdapter.create(CFInterface.class);
        GetFpTagsForMeetingsRequest getFpTagsForMeetingsRequest = new GetFpTagsForMeetingsRequest();
        getFpTagsForMeetingsRequest.setBranchIds(null);
        getFpTagsForMeetingsRequest.setCustomerCities(null);
        getFpTagsForMeetingsRequest.setSalesPersonIds(null);
        getFpTagsForMeetingsRequest.setFptags(null);
        meetingAnalysisUtils.DisplayLog(manager.getCFUsername());
        if(manager.getCFUsername()!=null){
            List<String> userName = new ArrayList<>();
            userName.add(manager.getCFUsername());
            getFpTagsForMeetingsRequest.setUsernames(userName);
        }
        cfInterface.getFpTagsForMeetingAnalysis(getFpTagsForMeetingsRequest, new Callback<Response>() {
            @Override
            public void success(Response response, Response response2) {
                if(response2.getStatus()==200){
                    JSONObject tempObject = meetingAnalysisUtils.getJsonFromTypedInput(response.getBody());
                    try {
                        JSONArray fpTags = tempObject.getJSONObject("Result").getJSONArray("FpTags");
                        getLatestMeetings(fpTags,title,body,performance);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }else{
                    meetingAnalysisUtils.DisplayLog("error" +response2.getReason());
                }

            }

            @Override
            public void failure(RetrofitError error) {
                meetingAnalysisUtils.DisplayLog(error.getMessage());
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void showCFNotification(String title, String body, String performance) {
        RemoteViews expandedView = new RemoteViews(getPackageName(), R.layout.notification_expanded);
        RemoteViews collapsedView = new RemoteViews(getPackageName(), R.layout.notification_collapsed);
        expandedView.setImageViewResource(R.id.big_icon, R.drawable.app_logo);
        expandedView.setTextViewText(R.id.timestamp, DateUtils.formatDateTime(this, System.currentTimeMillis(), DateUtils.FORMAT_SHOW_TIME));
        expandedView.setTextViewText(R.id.notification_message, body);
        expandedView.setTextViewText(R.id.content_title, title);
        expandedView.setTextViewText(R.id.content_text, body);
        collapsedView.setImageViewResource(R.id.big_icon, R.drawable.app_logo);
        collapsedView.setTextViewText(R.id.timestamp, DateUtils.formatDateTime(this, System.currentTimeMillis(), DateUtils.FORMAT_SHOW_TIME));
        collapsedView.setTextViewText(R.id.notification_message, body);
        collapsedView.setTextViewText(R.id.content_title, title);
        collapsedView.setTextViewText(R.id.content_text, body);
        switch (performance)
        {
            case "GOOD":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                break;
            case "AVERAGE":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.primary));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.primary));
                break;
            case "BAD":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                break;
            case "ABSENT":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                break;
            default:
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                break;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, GoogleLoginActivity.class), 0);
        String ChannelId = "channel_02";
        NotificationChannel channel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel(ChannelId, "RocketSinghCf", NotificationManager.IMPORTANCE_HIGH);
        }
        Notification.Builder mCFBuilder = new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_stat_logo_transparent)  // the status icon
                .setWhen(System.currentTimeMillis())  // the time stamp
                .setContentTitle(title)  // the label of the entry
                .setContentText(body)  // the contents of the entry
                .setContentIntent(contentIntent)  // The intent to send when the entry is clicked
                .setStyle(new Notification.BigTextStyle()
                        .bigText(body));
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mCFBuilder.setColor(getResources().getColor(R.color.primary));
        }
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mCFBuilder.setCustomBigContentView(expandedView);
            mCFBuilder.setCustomContentView(collapsedView);
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            mCFBuilder.setChannelId(ChannelId);
            mCFNM.createNotificationChannel(channel);
        }
        mCFNM.notify(CF_NOTIFICATION, mCFBuilder.build());
        startForeground(CF_NOTIFICATION, mCFBuilder.build());
    }

    public String parseDate(String inputDate) {
        String inputPattern = "yyyy-MM-dd";
        String outputPattern = "dd-MMM-yyyy";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);

        Date date = null;
        String str = null;

        try {
            date = inputFormat.parse(inputDate);
            str = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return str;
    }

    private void looperCall(final String cfUsername){
        new Handler().postDelayed(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void run() {
                if(!TextUtils.isEmpty(cfUsername))
                    getFpTagsForMeetingAnalysis("","","");
                looperCall(cfUsername);
            }
        },60*60*1000);
    }
}
