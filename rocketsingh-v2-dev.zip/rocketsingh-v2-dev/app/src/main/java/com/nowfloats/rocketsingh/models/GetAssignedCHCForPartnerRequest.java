package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 26-Mar-18.
 */
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetAssignedCHCForPartnerRequest {

    @SerializedName("usernames")
    @Expose
    private List<String> usernames = null;
    @SerializedName("fptags")
    @Expose
    private List<String> fptags = null;
    @SerializedName("branchIds")
    @Expose
    private List<String> branchIds = null;
    @SerializedName("customerCities")
    @Expose
    private List<String> customerCities = null;
    @SerializedName("salesPersonIds")
    @Expose
    private List<String> salesPersonIds = null;

    public List<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(List<String> usernames) {
        this.usernames = usernames;
    }

    public List<String> getFptags() {
        return fptags;
    }

    public void setFptags(List<String> fptags) {
        this.fptags = fptags;
    }

    public List<String> getBranchIds() {
        return branchIds;
    }

    public void setBranchIds(List<String> branchIds) {
        this.branchIds = branchIds;
    }

    public List<String> getCustomerCities() {
        return customerCities;
    }

    public void setCustomerCities(List<String> customerCities) {
        this.customerCities = customerCities;
    }

    public List<String> getSalesPersonIds() {
        return salesPersonIds;
    }

    public void setSalesPersonIds(List<String> salesPersonIds) {
        this.salesPersonIds = salesPersonIds;
    }

}
