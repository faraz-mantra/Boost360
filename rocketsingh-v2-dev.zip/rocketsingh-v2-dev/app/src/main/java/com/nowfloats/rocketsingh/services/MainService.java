package com.nowfloats.rocketsingh.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import androidx.annotation.RequiresApi;

import android.text.TextUtils;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.interfaces.DashboardInterface;
import com.nowfloats.rocketsingh.interfaces.SignupInterface;
import com.nowfloats.rocketsingh.models.EmployeesRankResponse;
import com.nowfloats.rocketsingh.models.GetCFPerformaceStatus;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.InternalLocationManager;
import com.nowfloats.rocketsingh.utils.MeetingAnalysisUtils;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

import java.util.HashMap;
import java.util.List;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;
import retrofit.client.Response;

/**
 * Created by NowFloats on 15-Feb-18.
 */

public class MainService extends Service {

    private NotificationManager mNM;
    private boolean notificationLive = false;
    private final long LOCATION_POLLING_PERIOD = 1000*12*60*60; // every 30 minutes
    private MeetingAnalysisUtils meetingAnalysisUtils;
    Notification.Builder mBuilder;
    private int NOTIFICATION = R.string.main_service_started;
    private UserSessionManager manager;

    public class LocalBinder extends Binder {
        MainService getService() {
            return MainService.this;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onCreate() {
        initiateService();
    }



    private void initiateService(){
        manager = new UserSessionManager(this);
        meetingAnalysisUtils = new MeetingAnalysisUtils(this);
        mNM = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        InternalLocationManager.startLocationTracking(this);
        getSalesPerformance(manager.getSalesId());
        looperCall();
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("MainService", "Received start id " + startId + ": " + intent);
        initiateService();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        // Cancel the persistent notification.
        mNM.cancel(NOTIFICATION);
        // Tell the user we stopped.
        Toast.makeText(this, "Local Service Stopped", Toast.LENGTH_SHORT).show();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    // This is the object that receives interactions from clients.  See
    // RemoteService for a more complete example.
    private final IBinder mBinder = new LocalBinder();

    /**
     * Show a notification while this service is running.
     */

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void showNotification(GetCFPerformaceStatus getCFPerformaceStatus) {

        String title="" , performance = "", body="";

        title = "Your performace as of "+ meetingAnalysisUtils.getCurrentDate();

        RemoteViews expandedView = new RemoteViews(getPackageName(), R.layout.notification_explandedv2);

        expandedView.setTextViewText(R.id.tv_loggedMeetings , getCFPerformaceStatus.getMeetingStatisticsCFResponse().getMeetingsLogged()+"");
        expandedView.setTextViewText(R.id.tv_pendingMeetings , getCFPerformaceStatus.getMeetingStatisticsCFResponse().getMeetingsPending()+"");
        expandedView.setTextViewText(R.id.tv_pending_tickets , getCFPerformaceStatus.getTotalTickets()+"");
        expandedView.setTextViewText(R.id.tv_revenue , getCFPerformaceStatus.getTotalRevenue());

        RemoteViews collapsedView = new RemoteViews(getPackageName(), R.layout.notification_collapsed);

        collapsedView.setTextViewText(R.id.content_text , title);

        if(performance==null){
            performance = "";
        }
        switch (performance)
        {
            case "GOOD":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                break;
            case "AVERAGE":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.primary));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.primary));
                break;
            case "BAD":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                break;
            case "ABSENT":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                break;
            default:
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                break;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, GoogleLoginActivity.class), 0);
        String ChannelId = "channel_01";
        NotificationChannel channel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel(ChannelId, "RocketSingh", NotificationManager.IMPORTANCE_LOW);
        }
         mBuilder = new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_stat_logo_transparent)  // the status icon
                .setWhen(System.currentTimeMillis())  // the time stamp
                .setContentTitle(title)  // the label of the entry
                .setContentText(body)  // the contents of the entry
                .setContentIntent(contentIntent)  // The intent to send when the entry is clicked
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setOnlyAlertOnce(true);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mBuilder.setColor(getResources().getColor(R.color.primary));
        }
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mBuilder.setCustomBigContentView(expandedView);
            mBuilder.setCustomContentView(collapsedView);
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            mBuilder.setChannelId(ChannelId);
            mNM.createNotificationChannel(channel);
        }

        //if(! notificationLive) {
            notificationLive = true;
            mNM.notify(NOTIFICATION, mBuilder.build());
   //   }
        startForeground(NOTIFICATION, mBuilder.build());
    }

    private void getSalesPerformance(String emailId) {

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.SALES_ASSISTANT_API_URL).setLog(new AndroidLog(MainService.class.getSimpleName())).build();

        DashboardInterface dashboardInterface = restAdapter.create(DashboardInterface.class);

        dashboardInterface.getMeetingsStatsForCf(emailId, new Callback<GetCFPerformaceStatus>() {
            @Override
            public void success(GetCFPerformaceStatus getCFPerformaceStatus, Response response) {

                if(response.getStatus() != 200){
                    showServiceLog("RESPONSE STATUS "+response.getStatus() + (TextUtils.isEmpty(response.getReason()) ? "" : response.getReason()));
                }else{

                    getEmployeeRank(getCFPerformaceStatus);
                    showObjectAsLog(getCFPerformaceStatus );

                }

            }

            @Override
            public void failure(RetrofitError error) {
                showServiceLog(error.getMessage());
            }
        });

    }

    private void showServiceLog(String message) {
        Log.d(MainService.class.getSimpleName() , TextUtils.isEmpty(message) ? "Message is null" : message);
    }

    private void getEmployeeRank(GetCFPerformaceStatus getCFPerformaceStatus) {

        String emailId = manager.getSalesId();

        HashMap<String, String> model = new HashMap<String, String>();
        model.put("clientId", Constants.ERPClientId);
        model.put("emailId", emailId);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        signupInterface.getEmployeeRank(model, new Callback<List<EmployeesRankResponse>>() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void success(List<EmployeesRankResponse> dataResponse, retrofit.client.Response response) {
                if(dataResponse == null || response.getStatus() != 200){
                    //error
                    return;
                }
                if(response.getStatus() == 200 && dataResponse.size() > 0){
                    //onApiSuccessfull
//                    Date todayDate = Calendar.getInstance().getTime();
//                    SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
//                    String todayString = formatter.format(todayDate);
//                    String body = "Your rank :  " + dataResponse.get(0).getNationalRank() + "\nGross revenue closed :  ₹" + dataResponse.get(0).getRevenue();
//                    String title = "Revenue performance as of " + todayString;

                    getCFPerformaceStatus.setTotalRevenue(dataResponse.get(0).getRevenue());


                }else{
                    //not successful
                    getCFPerformaceStatus.setTotalRevenue("0");
                }

                showObjectAsLog(getCFPerformaceStatus);

                showNotification(getCFPerformaceStatus);
            }

            @Override
            public void failure(RetrofitError error) {
                //error
                showServiceLog(error.getMessage() +" AT EMPLOYEE RANK");
                getEmployeeRank(getCFPerformaceStatus);
            }
        });
    }

    public void looperCall() {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getSalesPerformance(manager.getSalesId());
                looperCall();
            }
        } , LOCATION_POLLING_PERIOD);

    }


    private void showObjectAsLog(Object object){
        //showServiceLog(new Gson().toJson(object));
    }

}
