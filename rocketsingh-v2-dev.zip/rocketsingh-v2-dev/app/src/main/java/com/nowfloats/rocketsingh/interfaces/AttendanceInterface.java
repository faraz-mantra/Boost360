package com.nowfloats.rocketsingh.interfaces;

import android.telecom.Call;

import com.nowfloats.rocketsingh.models.LocationManagerRequest;
import com.nowfloats.rocketsingh.models.LocationManagerResponse;
import com.nowfloats.rocketsingh.models.LogLocationRequest;
import com.nowfloats.rocketsingh.models.WebActionRequestGenericModel;
import com.nowfloats.rocketsingh.models.WebActionResponseGenericModel;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.HEAD;
import retrofit.http.Headers;
import retrofit.http.POST;
import retrofit.http.PUT;
import retrofit.http.Query;
import retrofit.http.QueryMap;

public interface AttendanceInterface {


    @POST("/api/v1/locationmanager/add-data")
    @Headers({"Authorization: 59a7d4ad20320013d43d041d"})
    void addAttendanceStatus(@Body WebActionRequestGenericModel<LocationManagerRequest> locationManagerRequest ,
                             Callback<String> callback) ;

    @POST("/api/v1/locationmanager/update-data")
    void updateAttendanceStatus();

    @GET("/api/v1/locationmanager/get-data")
    void getAttendanceStatus(@Query("Query") String quer ,  Callback<WebActionResponseGenericModel<LocationManagerResponse>> callback);

    @PUT("/SupportMetrics/v1/SalesAssistant/LogLocationDetails")
    void uploadAttendanceLog(@Query("clientId") String clientId , @Body LogLocationRequest logLocationRequest , Callback<Boolean> attendanceUpload);

}
