package com.nowfloats.rocketsingh.services;

import android.content.Intent;
import android.content.SharedPreferences;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;

import com.anachat.chatsdk.AnaCore;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.nowfloats.rocketsingh.app.Config;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

/**
 * Created by NowFloats on 15-Jan-18.
 */


public class AnaChatBotInstanceIDService extends FirebaseInstanceIdService {
    private static final String TAG = AnaChatBotInstanceIDService.class.getSimpleName();

    @Override
    public void onTokenRefresh() {
        super.onTokenRefresh();
        UserSessionManager manager = new UserSessionManager(getApplicationContext());
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        if(TextUtils.isEmpty(manager.getSalesId()))
            AnaCore.saveFcmToken(this, refreshedToken);
        else
            AnaCore.saveFcmToken(this, refreshedToken, manager.getSalesId());
        // Saving reg id to shared preferences
        storeRegIdInPref(refreshedToken);

        // sending reg id to your server
        sendRegistrationToServer(refreshedToken);

        // Notify UI that registration has completed, so the progress indicator can be hidden.
        Intent registrationComplete = new Intent(Config.REGISTRATION_COMPLETE);
        registrationComplete.putExtra("token", refreshedToken);
        LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete);
    }

    private void sendRegistrationToServer(final String token) {
        // sending gcm token to server
        Log.e(TAG, "sendRegistrationToServer: " + token);
    }

    private void storeRegIdInPref(String token) {
        SharedPreferences pref = getApplicationContext().getSharedPreferences(Config.SHARED_PREF, 0);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("regId", token);
        editor.commit();
    }
}