package com.nowfloats.rocketsingh.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by NowFloats on 27-10-2017.
 */
public class Constants {
    public static String clientId = "2FA76D4AFCD84494BD609FDB4B3D76782F56AE790A3744198E6F517708CAAA21";
    public static String CFClientId = "5DD5965115884A2291B6A06C37B47F6AF0FAA628D40CD9814A794137F6A";
    public final static String PICK_LOCATION_ACTION = "com.example.pick_location_action";
    public final static int GET_CURRENT_LOCATION_PERMISSION = 439;
    public final static long UPDATE_LOCATION_LOG_FREQUENCY = 1000*30*60; // 30 minutes
    public final static String REQUEST_FAILED = "Request Failed";
    public  final static int GPS_STATUS_CODE = 2 ;
    public final static String WEBACTION_ID = "59a7d4ad20320013d43d041d";
    public final static int GET_EMPLOYEE_ID = 1010;
    public final static String GET_CURRENT_LOCATION = "com.example.get_location_action";
    public static String FOSClientId = "A91B82DE3E93446A8141A52F288F69EFA1B09B1D13BB4E55BE743AB547B3489E";
    public final static String GET_CATEGORIES_URL = "https://s3.ap-south-1.amazonaws.com/boost-content-cdn/reporting_framework_15_May/category_list.txt";
    public final static String GET_CATEGORIES_URL2 = "https://api2.withfloats.com/discover/v1/floatingPoint/categories?clientId=2FA76D4AFCD84494BD609FDB4B3D76782F56AE790A3744198E6F517708CAAA21";
    public final static String ERPClientId = "ERPWE0892F2F45388F439BDE9F6F3FB5C31F0FAA628D40CD2920A79D8841597B";
    public final static String REPORT_ORDER_PICKUP_URL = "logyoursalesdirect";
    public final static String DISCOUNT_APPROVALS_ACTION = "Constantss.discountapprovals";
    public final static String ZENDESK_AUTHORIZATION = "Basic Y3VzdG9tZXIuc3VwcG9ydEBub3dmbG9hdHMuY29tOm5vd2Zsb2F0c0BzdXBwb3J0";
    public static String CHEQUE_UPLOAD_ACTION = "cheque_receipt";
    public static String RECEIPT_UPLOAD_ACTION = "cheque_image";
    public final static String ZENDESK_ENDPOINT = "https://nowfloatshelp.zendesk.com";
    public final static String NOW_FLOATS_API_URL = "https://api.withfloats.com";
    public final static int SHOW_EXISTING_CUSTOMERS = 22;
    public final static String NOW_FLOATS_API2_URL = "https://api2.withfloats.com";
    public final static String ADMIN_FLOW_ID = "adminlandingpage";
    public final static String NOW_FLOATS_API_DEV_URL = "http://movingfloatsapidev.ap-southeast-1.elasticbeanstalk.com";
    public final static String RIA_API_URL = "https://ria.withfloats.com";
    public final static String SUPPORT_API_URL = "http://support.withfloats.com";
    public final static String SALES_ASSISTANT_API_URL = "http://sales-assist-api.withfloats.com";
    public final static String ERP_API_URL = "http://52.66.59.196";
    public final static int SHOW_CATEGORIES_LIST = 2334;
    public final static int SHOW_FP_TAGS_FOR_CF = 332;
    public final static int SHOW_HOT_PROSPECTS_ID = 32;
    public final static int SHOW_TEMPLATES=989;
    public final static String TAG = "android23235616";
    public final static String CUSTOMER_LANDING_PAGE_ID="customerlandingpage";
    public final static int SHOW_QUOTATION_NUMBER = 114;
    public final static String IFSC_VALIDATION_ENDPOINT = "https://ifsc.razorpay.com";
    public final static int GET_FP_TAGS_FOR_CF = 436;
    public final static String ERP_EP_API_URL = "http://erp.nowfloats.com";
    public final static String ANA_DEV_URL = "http://chat-dev.nowfloatsdev.com/";
    public final static int READ_STORAGE_PERMISSION_REQUEST_CODE=4444;
    public static final String MIXPANEL_TOKEN = "7bf3d3ff71bbee3e2a7b9d9441f2cb79";
    public final static String ANA_PROD_URL = "https://gateway.api.ana.chat/";
    public final static String ROCKET_SINGH_BUSINESS_ID = "rocketsingh";
    public final static String LANDING_PAGE_FLOW_ID = "landingpage";
    public final static String GET_VERTICAL_PACKAGES = Constants.class.getName()+".GetVerticalPackages";
    public final static String ERP_PI_API_URL = "http://52.66.59.196";
    public final static String WEB_ACTION_API_URL = "https://webactions.kitsune.tools";
    public final static String INVOKE_IMAGE_CHOOSER = "INVOKE_IMAGE_CHOOSER";
    public final static String MOVINGFLOAT_DEV_URL = "http://movingfloatsapidev.ap-southeast-1.elasticbeanstalk.com";
    public static final String RSMAP_KEY = "AIzaSyB5MDjpTcJCvQgegmIhU7PPRJ1sEeS4N-4";
    public static final String ERP_DEV_URL = "http://13.127.26.51:8069";
    public static final String ERP_PARAM_METHOD = "execute";
    public static final String ERP_PARAM_SERVICE = "object";
    public static final String DUMMTY_IMAGE_URL = "https://static.techspot.com/images2/news/bigimage/2018/09/2018-09-04-image-6.png";
    public static final String CALL_ACTION = "ASDASD333";
    public static final int CALL_PERMISSION_KEY =400 ;
    public static final String ERP_ARG0 = "NowFloatsV10";
    public static final int ERP_ARG1 = 7976;
    public static final String ERP_DEV_ARG0 = "nf_v10";
    public static final String APXOR_DEV_ID = "89c40375-801e-4bd5-85c4-cc64c90c6f5c";
    public static final String APXOR_PROD_ID = "d48c0e4f-948b-4c05-959c-1a7e68680a7d";
    public static final int ERP_DEV_ARG1 = 1;
    public static final String ERP_DEV_ARG2 = "a";
    public static final String ERP_DEV_ARG3 = "np.api";
    public static final String ERP_ARG2 = "ERPapi123";
    public static final String ERP_ARG3 = "nf.api";
    public static final String ERP_JSONRPC_VERSION = "2.0";
    public static final String ERP_METHOD = "call";
    public static final String GREY_COLOR = "#f1f1f1";
    public static final String COLOR_PRIMARY = "#ffb900";
    public static final String GET_QUOTATION_NUMBER_URL = "http://52.66.59.196/v1/getPIList";
    public static final String GET_QUOTATION_ID_URL = "http://52.66.59.196/v1/getSOErpId?";
    public static final String CHECKED_IN = "Checked In";
    public  static final String CHECKED_OUT = "Checked out";
}
