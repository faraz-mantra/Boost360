package com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader;


import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CustomLoaderDialog extends DialogFragment {

    private CustomLoaderAdapter customLoaderAdapter;
    private RecyclerView rv_loaderStates;
    private boolean dialogIsInitialised ;
    private List<CustomLoaderModel> customLoaderModels = new ArrayList<>();
    private HashMap<NETWORK_OPERATIONS, CustomLoaderModel> customLoaderModelHashMap = new HashMap<>();
    private LinearLayout ll_finisher , ll_loader;
    private TextView tv_apiFinalStatus;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public static CustomLoaderDialog newInstance(){
        return new CustomLoaderDialog();
    }

    public void initialiseCustomLoader(){

      if(customLoaderAdapter == null && dialogIsInitialised){
          customLoaderAdapter = new CustomLoaderAdapter();
          rv_loaderStates.setLayoutManager(new LinearLayoutManager(getActivity()));
          rv_loaderStates.setAdapter(customLoaderAdapter);
      }
    }

    public void updateApiForSuccess(NETWORK_OPERATIONS network_operations , String message){
        changeApiState(network_operations ,message , true);
    }

    public void updateApiForFailure(NETWORK_OPERATIONS network_operations , String message){
        changeApiState(network_operations ,message , false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rv_loaderStates = view.findViewById(R.id.rv_customLoader);
        dialogIsInitialised = true;
        initialiseCustomLoader();
    }

    public void closeDialog(){
        resetApiStates();
        if(getDialog() != null ){
            getDialog().dismiss();
        }
    }

    public void initiateApiState(NETWORK_OPERATIONS network_operations){
        Log.i("initiate : "+network_operations.toString() , network_operations.name());
        initialiseCustomLoader();
        CustomLoaderModel customLoaderModel = new CustomLoaderModel().setLoader_states(LOADER_STATES.LOADING);
        customLoaderModel.setNetwork_operations(network_operations);
        customLoaderModelHashMap.put(network_operations , customLoaderModel);
        customLoaderModels.add(customLoaderModel);
        customLoaderAdapter.changeData(customLoaderModelHashMap , customLoaderModels);
    }


    public void resetApiStates(){
        customLoaderModels.clear();
        customLoaderModelHashMap.clear();
        customLoaderAdapter.changeData(customLoaderModelHashMap , customLoaderModels);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.custom_loader_fragment, container);
        dialogIsInitialised = true;
        rv_loaderStates = v.findViewById(R.id.rv_customLoader);
        ll_loader = v.findViewById(R.id.ll_customLoader);
        tv_apiFinalStatus = v.findViewById(R.id.tv_status);
        ll_finisher = v.findViewById(R.id.ll_finalresultdialog);
        return v;
    }

    public void showSuccessfulDialog(String message){
        tv_apiFinalStatus.setText(message);
        ll_loader.setVisibility(View.GONE);
        ll_finisher.setVisibility(View.VISIBLE);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return super.onCreateDialog(savedInstanceState);

    }

    public void changeApiState(NETWORK_OPERATIONS network_operations , String message , boolean success){

        LOADER_STATES loader_states = success ? LOADER_STATES.SUCCESS : LOADER_STATES.FAIL;
        CustomLoaderModel customLoaderModel = new CustomLoaderModel().setLoader_states(loader_states);
        customLoaderModel.setNetwork_operations(network_operations);

        if(loader_states == LOADER_STATES.SUCCESS)
            customLoaderModel.setSuccessMessage(message);
        else
            customLoaderModel.setErrorMessage(message);

        customLoaderModels.remove(customLoaderModelHashMap.get(network_operations));
        customLoaderModels.add(customLoaderModel);
        customLoaderModelHashMap.put(network_operations , customLoaderModel);
        customLoaderAdapter.changeData(customLoaderModelHashMap , customLoaderModels);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null)
        {
            int width = ViewGroup.LayoutParams.WRAP_CONTENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            setCancelable(false);
        }

    }

}
