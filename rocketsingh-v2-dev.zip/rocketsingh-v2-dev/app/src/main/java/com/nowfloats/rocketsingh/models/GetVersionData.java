package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by NowFloats on 15-Feb-18.
 */

public class GetVersionData {

    @SerializedName("Data")
    @Expose
    private List<Datum> data = null;
    @SerializedName("Extra")
    @Expose
    private Extra extra;

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

    public Extra getExtra() {
        return extra;
    }

    public void setExtra(Extra extra) {
        this.extra = extra;
    }

    public class Datum {

        @SerializedName("_id")
        @Expose
        private String id;
        @SerializedName("newUpdateVersion")
        @Expose
        private String newUpdateVersion;
        @SerializedName("forcedUpdateFlag")
        @Expose
        private Boolean forcedUpdateFlag;
        @SerializedName("UserId")
        @Expose
        private String userId;
        @SerializedName("ActionId")
        @Expose
        private String actionId;
        @SerializedName("WebsiteId")
        @Expose
        private String websiteId;
        @SerializedName("CreatedOn")
        @Expose
        private String createdOn;
        @SerializedName("UpdatedOn")
        @Expose
        private String updatedOn;
        @SerializedName("IsArchived")
        @Expose
        private Boolean isArchived;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getNewUpdateVersion() {
            return newUpdateVersion;
        }

        public void setNewUpdateVersion(String newUpdateVersion) {
            this.newUpdateVersion = newUpdateVersion;
        }

        public Boolean getForcedUpdateFlag() {
            return forcedUpdateFlag;
        }

        public void setForcedUpdateFlag(Boolean forcedUpdateFlag) {
            this.forcedUpdateFlag = forcedUpdateFlag;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getActionId() {
            return actionId;
        }

        public void setActionId(String actionId) {
            this.actionId = actionId;
        }

        public String getWebsiteId() {
            return websiteId;
        }

        public void setWebsiteId(String websiteId) {
            this.websiteId = websiteId;
        }

        public String getCreatedOn() {
            return createdOn;
        }

        public void setCreatedOn(String createdOn) {
            this.createdOn = createdOn;
        }

        public String getUpdatedOn() {
            return updatedOn;
        }

        public void setUpdatedOn(String updatedOn) {
            this.updatedOn = updatedOn;
        }

        public Boolean getIsArchived() {
            return isArchived;
        }

        public void setIsArchived(Boolean isArchived) {
            this.isArchived = isArchived;
        }

    }


    public class Extra {

        @SerializedName("CurrentIndex")
        @Expose
        private Integer currentIndex;
        @SerializedName("TotalCount")
        @Expose
        private Integer totalCount;
        @SerializedName("PageSize")
        @Expose
        private Integer pageSize;

        public Integer getCurrentIndex() {
            return currentIndex;
        }

        public void setCurrentIndex(Integer currentIndex) {
            this.currentIndex = currentIndex;
        }

        public Integer getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(Integer totalCount) {
            this.totalCount = totalCount;
        }

        public Integer getPageSize() {
            return pageSize;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

    }

}

