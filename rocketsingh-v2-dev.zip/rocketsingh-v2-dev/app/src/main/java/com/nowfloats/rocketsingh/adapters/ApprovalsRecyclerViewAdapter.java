package com.nowfloats.rocketsingh.adapters;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.interfaces.AdapterInterface;
import com.nowfloats.rocketsingh.models.GetDafDataResponse;

import java.util.List;

/**
 * Created by NowFloats on 09-01-2018.
 */

public class ApprovalsRecyclerViewAdapter extends RecyclerView.Adapter<ApprovalsRecyclerViewAdapter.MyItemsViewHolder> {

    private List<GetDafDataResponse.Datum> mPackageItems;
    private AdapterInterface.approvalsInterface approvalsInterface;

    public ApprovalsRecyclerViewAdapter(List<GetDafDataResponse.Datum> purchaseItems , AdapterInterface.approvalsInterface approvalsInterface){
        this.mPackageItems = purchaseItems;
        this.approvalsInterface = approvalsInterface;
    }

    @Override
    public MyItemsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.approve_disc_row_layout, parent, false);
        return new MyItemsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyItemsViewHolder holder, int position) {
        GetDafDataResponse.Datum data = mPackageItems.get(position);
        holder.tvFPTag.setText(data.getFpTag());
        holder.tvPINumber.setText(data.getPINumber());
        holder.tvBizName.setText(data.getBizName());
        holder.tvSaleType.setText(data.getSaleType());
        holder.tvPackageDetails.setText(data.getProductsQtyD());
        holder.tvReason.setText(data.getReason());
        holder.tvApproval.setText(data.getApproval());
        holder.tvNetAmt.setText(data.getNetAmt());
        holder.tvRemarks.setText(data.getRemarks());
        holder.tvCoupon.setText(TextUtils.isEmpty(data.getCouponCode())? " NA " : data.getCouponCode() );
        holder.btSendQuoatation.setVisibility(getVisiblity(! data.getApproval().toLowerCase().contains("pending")));
        holder.ivCopy.setOnClickListener((view -> {
                copyToClipBoard("Coupon code" , holder.tvCoupon.getText().toString() , holder.ivCopy.getContext());
                displayToast("Copied to clipboard" , view.getContext());
        }));

    }

    public void copyToClipBoard(String label, String content , Context context){
        ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText(label , content);
        clipboard.setPrimaryClip(clip);

    }

    private void displayToast(String message , Context context){
        Toast.makeText(context , TextUtils.isEmpty(message) ? "NA" : message , Toast.LENGTH_LONG).show();
    }


    private int getVisiblity(boolean visibility) {
        return visibility ? View.VISIBLE : View.GONE ;}

    @Override
    public int getItemCount() {
        return mPackageItems.size();
    }

    public class MyItemsViewHolder extends RecyclerView.ViewHolder{
        TextView tvCoupon, tvFPTag, tvPINumber, tvBizName, tvSaleType, tvPackageDetails, tvReason, tvApproval, tvNetAmt, tvRemarks;
        private Button btSendQuoatation , btReportOrderPickup;
        public ImageView ivCopy;

        public MyItemsViewHolder(View itemView) {
            super(itemView);
            tvFPTag = itemView.findViewById(R.id.tv_fpTag);
            tvPINumber = itemView.findViewById(R.id.tv_PINumber);
            tvBizName = itemView.findViewById(R.id.tv_BizName);
            tvSaleType = itemView.findViewById(R.id.tv_SaleType);
            ivCopy = itemView.findViewById(R.id.iv_copy);
            tvPackageDetails = itemView.findViewById(R.id.tv_PackageDetails);
            tvReason = itemView.findViewById(R.id.tv_Reason);
            tvApproval = itemView.findViewById(R.id.tv_Approval);
            tvNetAmt = itemView.findViewById(R.id.tv_NetAmt);
            tvRemarks = itemView.findViewById(R.id.tv_remarks);
            tvCoupon = itemView.findViewById(R.id.tv_coupon);
            btSendQuoatation = itemView.findViewById(R.id.bt_send_quotation);
            btReportOrderPickup =itemView.findViewById(R.id.bt_report_order_pickup);
            btSendQuoatation.setOnClickListener((view -> {
                if(approvalsInterface != null ){
                    approvalsInterface.onSendQuotation(mPackageItems.get(getAdapterPosition()).getPINumber());
                }
            }));

            btReportOrderPickup.setOnClickListener((view -> {
                if(approvalsInterface != null ){
                    approvalsInterface.onOrderPickup(mPackageItems.get(getAdapterPosition()));
                }
            }));

        }
    }
}
