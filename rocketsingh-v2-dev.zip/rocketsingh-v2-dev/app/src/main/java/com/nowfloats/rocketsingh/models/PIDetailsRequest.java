
package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PIDetailsRequest {

    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("refNumber")
    @Expose
    private String refNumber;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getRefNumber() {
        return refNumber;
    }

    public void setRefNumber(String refNumber) {
        this.refNumber = refNumber;
    }

}