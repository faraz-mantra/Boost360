package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CreateQuotationRequest {

    @SerializedName("salesId")
    @Expose
    private String salesId;
    @SerializedName("fpTag")
    @Expose
    private String fpTag;
    @SerializedName("edit")
    @Expose
    private String edit;
    @SerializedName("hpNumber")
    @Expose
    private String hpNumber;
    @SerializedName("createQuotationRequestModel")
    @Expose
    private CreateQuotationRequestModel createQuotationRequestModel;

    public String getSalesId() {
        return salesId;
    }

    public void setSalesId(String salesId) {
        this.salesId = salesId;
    }

    public String getFpTag() {
        return fpTag;
    }

    public void setFpTag(String fpTag) {
        this.fpTag = fpTag;
    }

    public String getEdit() {
        return edit;
    }

    public void setEdit(String edit) {
        this.edit = edit;
    }

    public String getHpNumber() {
        return hpNumber;
    }

    public void setHpNumber(String hpNumber) {
        this.hpNumber = hpNumber;
    }

    public CreateQuotationRequestModel getCreateQuotationRequestModel() {
        return createQuotationRequestModel;
    }

    public void setCreateQuotationRequestModel(CreateQuotationRequestModel createQuotationRequestModel) {
        this.createQuotationRequestModel = createQuotationRequestModel;
    }

    public static class CreateQuotationRequestModel {

        @SerializedName("hotProspectId")
        @Expose
        private Integer hotProspectId;
        @SerializedName("quoteId")
        @Expose
        private Integer quoteId;
        @SerializedName("isSingleStore")
        @Expose
        private Boolean isSingleStore;
        @SerializedName("productNames")
        @Expose
        private List<String> productNames = null;

        public Integer getHotProspectId() {
            return hotProspectId;
        }

        public void setHotProspectId(Integer hotProspectId) {
            this.hotProspectId = hotProspectId;
        }

        public Integer getQuoteId() {
            return quoteId;
        }

        public void setQuoteId(Integer quoteId) {
            this.quoteId = quoteId;
        }

        public Boolean getIsSingleStore() {
            return isSingleStore;
        }

        public void setIsSingleStore(Boolean isSingleStore) {
            this.isSingleStore = isSingleStore;
        }

        public List<String> getProductNames() {
            return productNames;
        }

        public void setProductNames(List<String> productNames) {
            this.productNames = productNames;
        }

    }

}