package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 22-Jan-18.
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetEmployeeDetailsRequest {

    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("email")
    @Expose
    private String email;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}