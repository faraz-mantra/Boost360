package com.nowfloats.rocketsingh.interfaces;

public interface AttendanceAdapterInterface {
    void onShowLocationOnMap(double lat , double lng);
    void displayToast(String message);
}
