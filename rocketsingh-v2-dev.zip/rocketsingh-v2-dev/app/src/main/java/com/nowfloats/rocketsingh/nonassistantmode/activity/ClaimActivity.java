package com.nowfloats.rocketsingh.nonassistantmode.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.util.Pair;
import android.view.Gravity;

import com.google.android.material.snackbar.Snackbar;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.models.CheckIfFpHasLeadResponse;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.ClaimFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.GetFPDetailsFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.SidePanelFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.FPDetailsInterface;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.NetworkResultInterface;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomEditText;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader.CustomLoaderDialog;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.FLOW_SESSIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NetworkHandler;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.tfb.fbtoast.FBToast;

import java.util.HashMap;

import java.util.LinkedList;
import java.util.Queue;



public class ClaimActivity extends AppCompatActivity implements NetworkResultInterface,
        GetFPDetailsFragment.onFPDetailsSubmittedInterface ,
        ClaimFragment.ClaimInterface {

    private CustomLoaderDialog customLoaderDialog;
    private NetworkHandler networkHandler;
    private String fpTag;
    private CheckIfFpHasLeadResponse checkIfFpHasLeadResponse;
    private String claimId;
    private Bitmap receiptPic;
    private String imageName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_claim);
        gotTofirstFragment();
        setupDrawerLayout();

    }

    private void startNetworkSession(short session){
        Queue<NETWORK_OPERATIONS> queue = new LinkedList<>();
        switch (session) {
            case FLOW_SESSIONS.CLAIM_SALE.FP_DETAILS:
                queue.add(NETWORK_OPERATIONS.GET_FP_DETAILS);
                queue.add(NETWORK_OPERATIONS.CHECK_IF_LEAD_HAS_FP);
                break;
            case FLOW_SESSIONS.CLAIM_SALE.CLAIM_SALE:
                queue.add(NETWORK_OPERATIONS.VALIDATE_CLAIM_ID);
                queue.add(NETWORK_OPERATIONS.UPLOAD_CLAIM_RECEIPT);
                queue.add(NETWORK_OPERATIONS.CLAIM_SALE_REQUEST);
                break;
        }

        networkHandler = new NetworkHandler(this , this)
                .setNetworkOperationQueue(queue)
                .setOrUpdateSession(session)
                .startThread();
    }

    public void gotTofirstFragment(){
        GetFPDetailsFragment getFPDetailsFragment = new GetFPDetailsFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.cl_order_pickup_parentLayout , getFPDetailsFragment).commit();
    }

    @Override
    public void onApiRequestStarted(NETWORK_OPERATIONS network_operations) {
        initiateApiState(network_operations);

    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, String message) {
        updateApiStateInFpFragment(operationKey , message , true);
        networkHandler.executeNext();

    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, Object model, String message) {
        updateApiStateInFpFragment(operationKey , message , true);
        if(operationKey == NETWORK_OPERATIONS.CHECK_IF_LEAD_HAS_FP)
            checkIfFpHasLeadResponse = (CheckIfFpHasLeadResponse)model;
        networkHandler.executeNext();
    }

    @Override
    public void onApiFail(NETWORK_OPERATIONS operationKey, String errorMessage) {
        updateApiStateInFpFragment(operationKey , errorMessage , false);
    }

    @Override
    public void networkOperationsFinished(boolean success, short session) {
        if(session == FLOW_SESSIONS.CLAIM_SALE.FP_DETAILS){
            hideDialog(false);
            gotoClaimFragment();
        }else if(session == FLOW_SESSIONS.CLAIM_SALE.CLAIM_SALE) {
            finishApiProcessAnimation("Sale has been claimed succesfully");
        }
    }

    @Override
    public void prepareRequestBody(NETWORK_OPERATIONS network_operations, NetworkHandler networkHandler) {
        Pair<NETWORK_OPERATIONS , Object> pair = null;
        switch (network_operations) {
            case GET_FP_DETAILS:
                pair = new Pair<>(network_operations , fpTag);
                break;
            case CHECK_IF_LEAD_HAS_FP:
                pair = new Pair<>(network_operations , fpTag);
                break;
            case VALIDATE_CLAIM_ID:
                pair = new Pair<>(network_operations , claimId);
                break;
            case UPLOAD_CLAIM_RECEIPT:
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("transactionId" , claimId);
                hashMap.put("base64" , ExternalProcessManager.getBase64StringFromImage(receiptPic));
                hashMap.put("imageName" , imageName);
                pair = new Pair<>(network_operations , hashMap);
                break;

            case CLAIM_SALE_REQUEST:
                hashMap = new HashMap<>();
                hashMap.put("hotprospect" , checkIfFpHasLeadResponse.getLeadNumber());
                hashMap.put("claimId" , claimId);
                pair = new Pair<>(network_operations , hashMap);
                break;
        }

        networkHandler.updateRequestBody(network_operations , pair == null ? null : pair.second);
    }



    private void initiateApiState(NETWORK_OPERATIONS network_operations) {
        if(dialogIsValid()) {
            customLoaderDialog.initiateApiState(network_operations);
            return;
        }else {
            showDialog();
            new Handler().postDelayed(() -> {customLoaderDialog.initiateApiState(network_operations);} , 0);
        }

    }


    public boolean dialogIsValid(){
        return customLoaderDialog != null  && customLoaderDialog.isVisible();
    }

    private void showDialog() {
        if (customLoaderDialog == null) {
            customLoaderDialog = new CustomLoaderDialog();
        }

        if(customLoaderDialog.isVisible())
            return;
        // Create and show the dialog.
        customLoaderDialog = CustomLoaderDialog.newInstance();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.executePendingTransactions();
        customLoaderDialog.show(fragmentManager.beginTransaction(), "dialog");
    }


    public void updateApiStateInFpFragment(NETWORK_OPERATIONS network_operations , String message , boolean success) {
        if (success) {
            updateApiForSuccess(network_operations, message);

        } else {
            updateApiForFailure(network_operations, message);
        }
    }

    private void hideDialog(boolean delay){
        // delay is just for the effect

        if(customLoaderDialog == null )
            return;
        if(! customLoaderDialog.isVisible())
            return;

        new Handler().postDelayed(() -> {customLoaderDialog.closeDialog();} , delay ? 2500: 0);


    }

    private void updateApiForSuccess(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForSuccess(network_operations , message);
        }
    }

    public void finishApiProcessAnimation(String message){
        if(customLoaderDialog != null ){
            if(customLoaderDialog.isVisible()) {
                customLoaderDialog.showSuccessfulDialog(message);
            }
            hideDialog(true);
        }
    }

    private void updateApiForFailure(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForFailure(network_operations, message);
            hideDialog(true);
        }
    }

    private void showSnackbarMessage(String message , boolean success){
        if(success)
            FBToast.successToast(this,message,FBToast.LENGTH_SHORT);
        else
            FBToast.errorToast(this,message,FBToast.LENGTH_SHORT);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(ClaimFragment.rocketImagePicker != null)
            ClaimFragment.rocketImagePicker.onRequestPermissionsResult(requestCode , grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(ClaimFragment.rocketImagePicker != null)
            ClaimFragment.rocketImagePicker.onActivityResult(requestCode , resultCode , data);
    }

    @Override
    public void onFpDetailsSubmitted(String fpTag) {
        if(ExternalProcessManager.stringIsNull(fpTag) ){
            showSnackbarMessage("Please enter a customer tag" , false);
            return;
        }

        this.fpTag = fpTag;
        startNetworkSession(FLOW_SESSIONS.CLAIM_SALE.FP_DETAILS);
    }

    @Override
    public void hideKeyboard(CustomEditText customEditText) {

    }

    @Override
    public void getClaimId(String claimId, Bitmap receiptImage, String imageName) {
        this.claimId = claimId;
        this.receiptPic = receiptImage;
        this.imageName = imageName;
        startNetworkSession(FLOW_SESSIONS.CLAIM_SALE.CLAIM_SALE);
    }

    private void gotoClaimFragment(){
        ClaimFragment claimFragment = ClaimFragment.getInstance(this , checkIfFpHasLeadResponse);
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.executePendingTransactions();
        claimFragment.show(fragmentManager , "ClaimFragment");
    }
    private void setupDrawerLayout() {

        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        SidePanelFragment sidePanelFragment = new SidePanelFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.fm_fragment_navigation_drawer , sidePanelFragment).commitAllowingStateLoss();
        DrawerLayout mDrawerLayout = findViewById(R.id.drawer_layout);
        sidePanelFragment.setUp(findViewById(R.id.fm_fragment_navigation_drawer) , findViewById(R.id.drawer_layout) , toolbar);
        mDrawerLayout.closeDrawer(Gravity.LEFT);

        findViewById(R.id.im_selfMode).setOnClickListener(view -> {
            mDrawerLayout.openDrawer(findViewById(R.id.fm_fragment_navigation_drawer));
        });



        findViewById(R.id.im_startChat).setOnClickListener(view -> {
            Intent i = new Intent(view.getContext() , GoogleLoginActivity.class);
            i.setAction("startChat");
            startActivity(i);
        });
    }
}
