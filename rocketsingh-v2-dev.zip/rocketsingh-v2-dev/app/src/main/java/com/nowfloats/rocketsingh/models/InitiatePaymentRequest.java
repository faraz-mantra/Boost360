package com.nowfloats.rocketsingh.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InitiatePaymentRequest {

    @SerializedName("products")
    @Expose
    private List<Product> products = null;
    @SerializedName("fpId")
    @Expose
    private String fpId;
    @SerializedName("fpTag")
    @Expose
    private String fpTag;
    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("customerName")
    @Expose
    private String customerName;
    @SerializedName("phoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("phoneNumberExtension")
    @Expose
    private String phoneNumberExtension;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("recurringMonths")
    @Expose
    private Integer recurringMonths;
    @SerializedName("tdsPercentage")
    @Expose
    private Integer tdsPercentage;
    @SerializedName("paymentTransactionChannel")
    @Expose
    private Integer paymentTransactionChannel;
    @SerializedName("GSTNumber")
    @Expose
    private String gSTNumber;
    @SerializedName("rejectionReason")
    @Expose
    private String rejectionReason;
    @SerializedName("paymentMode")
    @Expose
    private Integer paymentMode;
    @SerializedName("_NFInternalSalesPersonId")
    @Expose
    private String nFInternalSalesPersonId;

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public String getFpId() {
        return fpId;
    }

    public void setFpId(String fpId) {
        this.fpId = fpId;
    }

    public String getFpTag() {
        return fpTag;
    }

    public void setFpTag(String fpTag) {
        this.fpTag = fpTag;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneNumberExtension() {
        return phoneNumberExtension;
    }

    public void setPhoneNumberExtension(String phoneNumberExtension) {
        this.phoneNumberExtension = phoneNumberExtension;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getRecurringMonths() {
        return recurringMonths;
    }

    public void setRecurringMonths(Integer recurringMonths) {
        this.recurringMonths = recurringMonths;
    }

    public Integer getTdsPercentage() {
        return tdsPercentage;
    }

    public void setTdsPercentage(Integer tdsPercentage) {
        this.tdsPercentage = tdsPercentage;
    }

    public Integer getPaymentTransactionChannel() {
        return paymentTransactionChannel;
    }

    public void setPaymentTransactionChannel(Integer paymentTransactionChannel) {
        this.paymentTransactionChannel = paymentTransactionChannel;
    }

    public String getGSTNumber() {
        return gSTNumber;
    }

    public void setGSTNumber(String gSTNumber) {
        this.gSTNumber = gSTNumber;
    }

    public String getRejectionReason() {
        return rejectionReason;
    }

    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
    }

    public Integer getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(Integer paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getNFInternalSalesPersonId() {
        return nFInternalSalesPersonId;
    }

    public void setNFInternalSalesPersonId(String nFInternalSalesPersonId) {
        this.nFInternalSalesPersonId = nFInternalSalesPersonId;
    }


    public static class Product {

        @SerializedName("cashback_percentage")
        @Expose
        private double cashbackPercentage;

        @SerializedName("type")
        @Expose
        private String type;
        @SerializedName("price")
        @Expose
        private Double price;
        @SerializedName("discount")
        @Expose
        private Integer discount;
        @SerializedName("name")
        @Expose
        private String name;
        @SerializedName("product_id")
        @Expose
        private String productId;
        @SerializedName("description")
        @Expose
        private String description;
        @SerializedName("quantity")
        @Expose
        private Integer quantity;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public Double getPrice() {
            return price;
        }

        public void setPrice(Double price) {
            this.price = price;
        }

        public Integer getDiscount() {
            return discount;
        }

        public void setDiscount(Integer discount) {
            this.discount = discount;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getProductId() {
            return productId;
        }

        public void setProductId(String productId) {
            this.productId = productId;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public Integer getQuantity() {
            return quantity;
        }

        public void setQuantity(Integer quantity) {
            this.quantity = quantity;
        }

        public double getCashbackPercentage() {
            return cashbackPercentage;
        }

        public void setCashbackPercentage(double cashbackPercentage) {
            this.cashbackPercentage = cashbackPercentage;
        }
    }

}