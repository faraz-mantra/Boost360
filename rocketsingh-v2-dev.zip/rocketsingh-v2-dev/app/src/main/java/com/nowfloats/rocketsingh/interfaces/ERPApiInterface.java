package com.nowfloats.rocketsingh.interfaces;

import com.google.gson.JsonObject;
import com.nowfloats.rocketsingh.models.AddDiscountRequest;
import com.nowfloats.rocketsingh.models.CheckIfFpHasLeadResponse;
import com.nowfloats.rocketsingh.models.CreateQuotationRequest;
import com.nowfloats.rocketsingh.models.ERPGenericRequestModel;
import com.nowfloats.rocketsingh.models.ERPGenericResponseModel;
import com.nowfloats.rocketsingh.models.GenericApiResponseModel;
import com.nowfloats.rocketsingh.models.GetAllEmployeeRequest;
import com.nowfloats.rocketsingh.models.GetAllEmployeeResponse;
import com.nowfloats.rocketsingh.models.GetDailyAttendanceRequest;
import com.nowfloats.rocketsingh.models.GetDailyAttendanceResponse;
import com.nowfloats.rocketsingh.models.GetExistingCustomerResponse;
import com.nowfloats.rocketsingh.models.GetLeadDetailsRequest;
import com.nowfloats.rocketsingh.models.GetLeadDetailsResponse;
import com.nowfloats.rocketsingh.models.GetLeadModelRequest;
import com.nowfloats.rocketsingh.models.GetLeadModelResponse;
import com.nowfloats.rocketsingh.models.GetProductsRequest;
import com.nowfloats.rocketsingh.models.GetProductsResponse;
import com.nowfloats.rocketsingh.models.GetQuotationIdResponse;
import com.nowfloats.rocketsingh.models.GetSwipeStatusRequest;
import com.nowfloats.rocketsingh.models.GetSwipeStatusResponse;
import com.nowfloats.rocketsingh.models.GetTemplateRequest;
import com.nowfloats.rocketsingh.models.GetTemplateResponse;
import com.nowfloats.rocketsingh.models.HotProspectRequest;
import com.nowfloats.rocketsingh.models.HotProspectResponse;
import com.nowfloats.rocketsingh.models.PIDetailsRequest;
import com.nowfloats.rocketsingh.models.PIDetailsResponse;
import com.nowfloats.rocketsingh.models.ProcessPerformaDataRequest;
import com.nowfloats.rocketsingh.models.ProcessPerformaDataResponse;
import com.nowfloats.rocketsingh.models.UpdateReceiptInSORequest;
import com.nowfloats.rocketsingh.models.UploadAttendanceRequest;
import com.nowfloats.rocketsingh.models.UploadAttendanceResponse;
import com.nowfloats.rocketsingh.models.WebActionRequestGenericModel;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.CustomCallback;
import com.nowfloats.rocketsingh.utils.Constants;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;

import retrofit.Callback;
import retrofit.client.Response;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Headers;
import retrofit.http.POST;
import retrofit.http.QueryMap;

/**
 * Created by NowFloats on 22-Mar-18.
 */

public interface ERPApiInterface {

    @POST("/jsonrpc")
    void getLeadDetails(@Body GetLeadDetailsRequest request, Callback<GetLeadDetailsResponse> response);

    @POST("/jsonrpc")
    void getHotprospect(@Body HotProspectRequest hotProspectRequest, Callback<HotProspectResponse> response);

    @Headers("Content-Type:application/json")
    @POST("/jsonrpc")
    void getProductTemplates(@Body GetTemplateRequest getTemplateRequest, Callback<GetTemplateResponse> getTemplateResponseCallback);

    @Headers("Content-Type:application/json")
    @POST("/jsonrpc")
    void getProducts(@Body GetProductsRequest getProductsRequest, Callback<GetProductsResponse> getProductsResponseCallback);

    @Headers("Content-Type:application/json")
    @POST("/jsonrpc")
    void UpdateReceiptInSO(@Body UpdateReceiptInSORequest getProductsRequest, Callback<Response> getProductsResponseCallback);

    @Headers("Content-Type:application/json")
    @GET("/v1/getBankDetails?clientId="+ Constants.ERPClientId)
     void GetBankList( Callback<List<String>> bankList);

    @POST("/jsonrpc")
    void GetAttendanceStatus(@Body GetSwipeStatusRequest getSwipeStatusRequest , Callback<GetSwipeStatusResponse> getSwipeStatus);

    @POST("/jsonrpc")
    void UploadAttendanceStatus(@Body UploadAttendanceRequest uploadAttendanceRequest , Callback<UploadAttendanceResponse> attendanceResponseCallback);

    @POST("/jsonrpc")
    void GetDailyAttendance(@Body GetDailyAttendanceRequest getDailyAttendanceRequest , Callback<GetDailyAttendanceResponse> getDailyAttendanceResponseCallback);

    @Headers({"Content-Type: application/json","Connection:close"})
    @POST("/v1/GetActiveEmployees")
    void GetAllEmployees(@Body GetAllEmployeeRequest  getAllEmployeeRequest , Callback<List<GetAllEmployeeResponse>> getAllEmployeesResponse);

    @Headers({"Content-Type: application/json" , "Connection:close"})
    @GET("/v1/getExistingCustomer?clientId=ERPWE0892F2F45388F439BDE9F6F3FB5C31F0FAA628D40CD2920A79D8841597B")
    void getExistingCusotomers(@QueryMap HashMap<String,String> params , Callback<List<GetExistingCustomerResponse>> getexistngCusomters);

    @GET("/api/SalesProcess/CheckIfFpHasLead")
    void checkIfFPHasLead(@QueryMap HashMap<String,String> params , CustomCallback<CheckIfFpHasLeadResponse> checkIfFpHasLeadResponseCustomCallback);

    @POST("/jsonrpc")
    void getAllLeads(@Body ERPGenericRequestModel request , CustomCallback<ERPGenericResponseModel<List<GetLeadModelResponse>>> customCallback);

    @GET("/api/SalesProcess/GetQuotationId")
    void getQuotationId(@QueryMap HashMap<String,String> params , Callback<GenericApiResponseModel<Long>> getQuotationIdResponseCallback);

    @POST("/api/SalesProcess/v3/CreateQuotationByFpTag")
    void createQuotation(@Body CreateQuotationRequest createQuotationRequest , Callback<GenericApiResponseModel<String>> createQutationResponse);

    @Headers({"Content-Type: application/json" , "Connection:close"})
    @POST("/v1/getPIDetails")
    void getQuotationDetails(@Body PIDetailsRequest piDetailsRequest , Callback<List<PIDetailsResponse>> pidetailsResponseCallback);

    @Headers({"Content-Type: application/json"})
    @POST("/api/DiscountApproval/ProcessPerformaData")
    void processPerformaData(@Body List<ProcessPerformaDataRequest> performaDataRequests , Callback<Object> processPerformaDataResponseCallback);

    @Headers({"Authorization: 59a7d4ad20320013d43d041d"})
    @POST("/api/v1/discountapprovalform/add-data")
    void pushToWebaction(@Body WebActionRequestGenericModel<AddDiscountRequest> request , Callback<String> callbackResponse);




}
