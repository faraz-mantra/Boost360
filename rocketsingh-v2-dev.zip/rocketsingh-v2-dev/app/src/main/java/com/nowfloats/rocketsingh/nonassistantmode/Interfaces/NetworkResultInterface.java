package com.nowfloats.rocketsingh.nonassistantmode.Interfaces;

import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NetworkHandler;

public interface NetworkResultInterface {
    void onApiRequestStarted(NETWORK_OPERATIONS network_operations);
    void onApiSuccessfull(NETWORK_OPERATIONS operationKey , String message);
    void onApiSuccessfull(NETWORK_OPERATIONS operationKey , Object model , String message);
    void onApiFail(NETWORK_OPERATIONS operationKey , String errorMessage);
    void networkOperationsFinished(boolean success , short session);
    void prepareRequestBody(NETWORK_OPERATIONS network_operations , NetworkHandler networkHandler);

}
