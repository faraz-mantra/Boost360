package com.nowfloats.rocketsingh.activity;
/**
 * Created by NowFloats on 27-10-2017.
 */

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetSequence;
import com.getkeepsafe.taptargetview.TapTargetView;
import com.kiit.tanmay.locationhelper.LocationHelper;
import com.nowfloats.rocketsingh.fragments.SelectPackageFragment;
import com.nowfloats.rocketsingh.interfaces.UIInterface;
import com.nowfloats.rocketsingh.interfaces.ZendeskInterface;
import com.nowfloats.rocketsingh.models.GetAllEmployeeRequest;
import com.nowfloats.rocketsingh.models.GetAllEmployeeResponse;
import com.nowfloats.rocketsingh.models.GetExistingCustomerResponse;
import com.nowfloats.rocketsingh.models.GetTicketsResponse;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.appcompat.widget.PopupMenu;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.anachat.chatsdk.AnaChatBuilder;
import com.anachat.chatsdk.AnaCore;
import com.anachat.chatsdk.CustomMethodListener;
import com.anachat.chatsdk.LocationPickListener;
import com.anachat.chatsdk.internal.database.PreferencesManager;
import com.android.volley.Cache;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Network;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
//import com.apxor.androidsdk.//ApxorSDK;
import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;
import com.mixpanel.android.mpmetrics.MixpanelAPI;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.adapters.RanksRecyclerViewAdapter;
import com.nowfloats.rocketsingh.app.Config;
import com.nowfloats.rocketsingh.fragments.CustomDialogQuestionsFragment;
import com.nowfloats.rocketsingh.fragments.MeetingAnalysisFragment;
import com.nowfloats.rocketsingh.fragments.OutcomeViewFragment;
import com.nowfloats.rocketsingh.fragments.PickAddressFragment;
import com.nowfloats.rocketsingh.interfaces.CFInterface;
import com.nowfloats.rocketsingh.interfaces.ERPApiInterface;
import com.nowfloats.rocketsingh.interfaces.FcmIdInterface;
import com.nowfloats.rocketsingh.interfaces.IQuesResponseCallback;
import com.nowfloats.rocketsingh.interfaces.SignupInterface;
import com.nowfloats.rocketsingh.models.AddFCMDataRequest;
import com.nowfloats.rocketsingh.models.ChequePaymentModel;
import com.nowfloats.rocketsingh.models.EmployeesRankResponse;
import com.nowfloats.rocketsingh.models.GetAssignedCHCForPartnerRequest;
import com.nowfloats.rocketsingh.models.GetAssignedCHCForPartnerResponse;
import com.nowfloats.rocketsingh.models.GetEmployeeDetailsRequest;
import com.nowfloats.rocketsingh.models.GetEmployeeDetailsResponse;
import com.nowfloats.rocketsingh.models.GetFCMDataResponse;
import com.nowfloats.rocketsingh.models.GetFPIdRequest;
import com.nowfloats.rocketsingh.models.GetFpTagsForMeetingsRequest;
import com.nowfloats.rocketsingh.models.GetFptagDetailsResponse;
import com.nowfloats.rocketsingh.models.GetLatestMeetingsResponse;
import com.nowfloats.rocketsingh.models.GetLeadDetailsRequest;
import com.nowfloats.rocketsingh.models.GetLeadDetailsResponse;
import com.nowfloats.rocketsingh.models.GetMeetingChecklistDataResponse;
import com.nowfloats.rocketsingh.models.GetProductByNameResponse;
import com.nowfloats.rocketsingh.models.GetProductsRequest;
import com.nowfloats.rocketsingh.models.GetProductsResponse;
import com.nowfloats.rocketsingh.models.GetQuotationNumberRequest;
import com.nowfloats.rocketsingh.models.GetTemplateRequest;
import com.nowfloats.rocketsingh.models.GetTemplateResponse;
import com.nowfloats.rocketsingh.models.GetUserdataFromZendeskRequest;
import com.nowfloats.rocketsingh.models.GetUserdataFromZendeskResponse;
import com.nowfloats.rocketsingh.models.GetVersionData;
import com.nowfloats.rocketsingh.models.HotProspectRequest;
import com.nowfloats.rocketsingh.models.HotProspectResponse;
import com.nowfloats.rocketsingh.models.MailRequest;
import com.nowfloats.rocketsingh.models.PackageModel;
import com.nowfloats.rocketsingh.models.ProductPaymentModel;
import com.nowfloats.rocketsingh.models.QuesResponse;
import com.nowfloats.rocketsingh.models.SetOutcomeResponse;
import com.nowfloats.rocketsingh.models.UpdateFcmDataRequest;
import com.nowfloats.rocketsingh.models.UpdateReceiptInSORequest;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.SidePanelFragment;
import com.nowfloats.rocketsingh.services.FOSMainService;
import com.nowfloats.rocketsingh.services.MainService;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.ListenersManager;
import com.nowfloats.rocketsingh.utils.MeetingAnalysisUtils;
import com.nowfloats.rocketsingh.utils.NFGeoCoder;
import com.nowfloats.rocketsingh.utils.NotificationUtils;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.nowfloats.rocketsingh.utils.UserSessionManager;
import com.squareup.okhttp.OkHttpClient;

import net.alexandroid.gps.GpsStatusDetector;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;
import retrofit.client.OkClient;
import retrofit.client.Response;
import retrofit.converter.GsonConverter;
import retrofit.mime.TypedByteArray;
import retrofit.mime.TypedInput;
import uk.co.deanwild.materialshowcaseview.MaterialShowcaseView;

import static android.view.View.GONE;
import static com.nowfloats.rocketsingh.utils.Constants.MIXPANEL_TOKEN;

public class GoogleLoginActivity extends AppCompatActivity implements
        View.OnClickListener,
        GoogleApiClient.OnConnectionFailedListener,
        LocationPickListener, CustomMethodListener,
        IQuesResponseCallback,
        ExternalProcessManager.ExternalProcessInterface,
        UIInterface,
        GpsStatusDetector.GpsStatusDetectorCallBack
    {

    private static final String TAG = GoogleLoginActivity.class.getSimpleName();
    private static final int RC_SIGN_IN = 007;
    private  SelectPackageFragment selectPackageFragment;
    private int mHideProgress = 0;
    private FrameLayout fm_bottomPanel;
    private Boolean dialogExists = false;
    private boolean dialogIsShown = false;
    private UserSessionManager manager;
    private RequestQueue mRequestQueue;
    private Dialog showlistDialog;
    private GoogleApiClient mGoogleApiClient;
    private PickAddressFragment pickAddressFragment;
    private NFGeoCoder nfGeoCoder;
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    private ExternalProcessManager externalProcessManager;
    private ProgressDialog mProgressDialog;
    private FirebaseAnalytics mFirebaseAnalytics;
    private List<QuesResponse.Item> itemQuestion;
    private Context mChatContext;
    private JSONObject paramsOb = new JSONObject();
    private boolean overlayShown = false;
    private MixpanelAPI mMixpanel;
    private LinearLayout llSignIn, llStartChat, llCFSignIn;
    public boolean hasInternet;
    private ImageView ivMainMenu;
    private HashMap<String, String> mDataMap = new HashMap<>();
    private List<EmployeesRankResponse> mCurrentEmployeeRankList = new ArrayList<>();
    private List<EmployeesRankResponse> mTopEmployeesRankList = new ArrayList<>();
    private String salesId = "";
    private String mRegId = "", mNewUpdateVersion = "";
    private List<QuesResponse.Item> itemQuesResponse;
    private Boolean mForcedUpdateFlag;
    private Bundle b = new Bundle();
    private JSONObject props = new JSONObject();
    public static LocationPickListener locationPickListener;
    public static CustomMethodListener customMethodListener;
    private Map<String, String> quesRes = new HashMap<>();
    private String mDeviceId;
    private FusedLocationProviderClient mFusedLocationClient;
    private PermissionListener mPermissionListener;
    private LocationManager locationManager;
    private DrawerLayout mDrawerLayout;
    private ImageView im_startChat , im_manualMode;
    private AlertDialog.Builder mBuilderSingle;
    private MeetingAnalysisUtils meetingAnalysisUtils;

    @SuppressLint("HardwareIds")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_google_login);
        setSupportActionBar(findViewById(R.id.custom_toolbar));
        findViewById(R.id.custom_toolbar).setVisibility(GONE);
        DisplayLog(ExternalProcessManager.getlatestTime());

        im_startChat = findViewById(R.id.im_startChat);
        im_manualMode = findViewById(R.id.im_selfMode);

        im_startChat.setOnClickListener(view -> {
            llStartChat.performClick();
        });

        im_manualMode.setOnClickListener(view -> {
            mDrawerLayout = findViewById(R.id.drawer_layout);
            mDrawerLayout.openDrawer(findViewById(R.id.fm_fragment_navigation_drawer));
        });

        locationPickListener = this;
        customMethodListener = this;

        manager = new UserSessionManager(this);
        meetingAnalysisUtils = new MeetingAnalysisUtils(this);
        LocationHelper.Initialise().updateStateAndCheckGPS(this).handlePermissions();
        GetVersionData();
        //ApxorSDK.initialize(Constants.APXOR_PROD_ID,this.getApplicationContext());
        mMixpanel = MixpanelAPI.getInstance(this, MIXPANEL_TOKEN);
        fm_bottomPanel= findViewById(R.id.fm_bottomPanel);
        fm_bottomPanel.setVisibility(View.GONE);

        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        mDeviceId = Settings.Secure.getString(this.getContentResolver(),
                Settings.Secure.ANDROID_ID);

        ListenersManager.getInstance().addQuesResFragmentListener(this);

        mPermissionListener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                getLocation();
            }

            @Override
            public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                askLocationPermission();
            }
        };

        mRegistrationBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(Config.REGISTRATION_COMPLETE)) {
                    FirebaseMessaging.getInstance().subscribeToTopic(Config.TOPIC_GLOBAL);
                    displayFirebaseRegId();
                } else if (intent.getAction().equals(Config.PUSH_NOTIFICATION)) {
                    String message = intent.getStringExtra("message");
                    Toast.makeText(getApplicationContext(), "Push notificati" +
                            "on: " + message, Toast.LENGTH_LONG).show();
                }
            }
        };

        Intent intentFromDiscountApprovals = getIntent();

        if(intentFromDiscountApprovals != null ){

         if(intentFromDiscountApprovals.getStringExtra("action")!= null) {

             if(intentFromDiscountApprovals.getStringExtra("action").equals(Constants.DISCOUNT_APPROVALS_ACTION)) {

                 mDataMap.put("productName", intentFromDiscountApprovals.getStringExtra("productName"));
                 mDataMap.put("discountApplied", intentFromDiscountApprovals.getStringExtra("discountApplied"));
                 mDataMap.put("discountCoupon", intentFromDiscountApprovals.getStringExtra("discountCoupon"));
                 mDataMap.put("packagetype", intentFromDiscountApprovals.getStringExtra("packagetype"));
                 mDataMap.put("fpTag", intentFromDiscountApprovals.getStringExtra("fpTag"));
                 mDataMap.put("points", intentFromDiscountApprovals.getStringExtra("points"));
                 mDataMap.put("salesId", manager.getSalesId());
                 mDataMap.put("fcmId", manager.getFcmId());

                 manager.setFlowId(Constants.REPORT_ORDER_PICKUP_URL);
                 manager.setBusinessId(Constants.ROCKET_SINGH_BUSINESS_ID);
                 manager.setBaseUrl(Constants.ANA_DEV_URL);

                 startChatScreen(manager.getBusinessId(), manager.getBaseUrl(), manager.getFlowId());
             }

     }
        }



        displayFirebaseRegId();
        Thread thread = new Thread(() -> {
            try {
                hasInternet = hasInternetAccess(GoogleLoginActivity.this);
                if (hasInternet) {

                } else {
                    Intent offIntent = new Intent(GoogleLoginActivity.this, OfflineActivity.class);
                    startActivity(offIntent);
                    finish();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        thread.start();
        llSignIn = findViewById(R.id.ll_login);
        llCFSignIn = findViewById(R.id.ll_loginCF);
        llStartChat = findViewById(R.id.ll_start_chat);
        ivMainMenu = findViewById(R.id.ivMainMenu);
        Cache cache = new DiskBasedCache(getCacheDir(), 1024 * 1024);
        Network network = new BasicNetwork(new HurlStack());
        mRequestQueue = new RequestQueue(cache, network);
        mRequestQueue.start();
        llSignIn.setOnClickListener(this);
        llCFSignIn.setOnClickListener(this);
        ivMainMenu.setOnClickListener(this);
        llStartChat.setOnClickListener(this);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    private void signOut() {
        Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(@NonNull Status status) {
                        mHideProgress = 2;
                        AnaCore.logoutUser(GoogleLoginActivity.this);
                        updateUI(false, 4000);
                    }
                });
    }

    private void revokeAccess() {

        Auth.GoogleSignInApi.revokeAccess(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(@NonNull Status status) {
                        updateUI(false, 0);
                    }
                });
    }

    private void handleSignInResult(GoogleSignInResult result) throws JSONException {
        if (result != null && result.isSuccess()) {
            HashMap<String,String> userInfoForApxor = new HashMap<>();
            // Signed in successfully, show authenticated UI.
            DisplayLog("onApiSuccessfull");
            GoogleSignInAccount acct = result.getSignInAccount();
            if (acct != null) {
                DisplayLog("onApiSuccessfull");
                if(acct.getEmail()!=null) {
                    //ApxorSDK.setUserIdentifier(acct.getEmail());
                }
                salesId = acct.getEmail();

                if(manager.getBaseUrl().contains("dev")) {
                 //salesId = "tapaswini.sahoo@nowfloats.com";
                }
                manager.setSalesId(salesId);

//                startService(new Intent(this, LocalService.class));
//                startService(new Intent(this, LeaderboardService.class));
                //ApxorSDK.setUserIdentifier(salesId);
                DisplayLog("service started");

            }
            if (salesId != null && salesId.endsWith("@nowfloats.com")) {

                Intent i = getIntent();

                if(i != null &&  i.getExtras() != null && i.getExtras().getBoolean("startChat")) {
                    if(im_startChat.getVisibility() == View.VISIBLE)
                        llStartChat.performClick();
                }else {
                    checkIfUserIsAdmin();
                }

            } else if (salesId != null) {

                userInfoForApxor.put("loggedInWithOtherId",salesId);
                mFirebaseAnalytics.logEvent("loggedInWithOtherId", b);
                //ApxorSDK.logAppEvent("loggedInWithOtherId");
                manager.setSalesId(salesId);
                mDataMap.put("salesId", salesId);
                mDataMap.put("fcmId", mRegId);
                props.put("SalesId", salesId);
                mMixpanel.registerSuperProperties(props);
                mMixpanel.track("loggedInWithOtherId");
                PackageInfo pInfo = null;
                try {
                    pInfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                }
                String version = null;
                if (pInfo != null) {
                    version = pInfo.versionName;
                }
                GetFCMDataResponse("emailID: '" + salesId.toLowerCase() + "',deviceID:'" + mDeviceId + "'", salesId.toLowerCase(), mRegId, version);
                manager.setFlowId( Constants.CUSTOMER_LANDING_PAGE_ID);
                manager.setBusinessId(Constants.ROCKET_SINGH_BUSINESS_ID);
                manager.setBaseUrl(Constants.ANA_DEV_URL);
                AnaCore.registerUser(GoogleLoginActivity.this, salesId, manager.getBusinessId(), manager.getBaseUrl());
                DisplayLog("at here");
                mHideProgress = 2;
                updateUI(true, 4000);
            } else {
                mHideProgress = 2;
                updateUI(false, 5000);
            }
            //ApxorSDK.logAppEvent("userLoggedIn",userInfoForApxor);
        } else {
            // Signed out, show unauthenticated UI.
            DisplayLog("Unauthenticated " + result.getStatus());
            mHideProgress = 2;
            updateUI(false, 5000);
        }
    }

    public static boolean hasInternetAccess(Context context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = null;
        if (cm != null) {
            activeNetwork = cm.getActiveNetworkInfo();
        }
        boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
        if (isConnected) {
            try {
                HttpURLConnection urlc = (HttpURLConnection)
                        (new URL("http://clients3.google.com/generate_204")
                                .openConnection());
                urlc.setRequestProperty("User-Agent", "Android");
                urlc.setRequestProperty("Connection", "close");
                urlc.setConnectTimeout(1500);
                urlc.connect();
                return (urlc.getResponseCode() == 204 &&
                        urlc.getContentLength() == 0);
            } catch (IOException e) {
                Log.e(TAG, "Error checking internet connection", e);
            }
        } else {
            Log.d(TAG, "No network available!");
        }
        return false;
    }

    public void GetVersionData() {
        showProgressDialog();
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.WEB_ACTION_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface getVersionData = restAdapter.create(SignupInterface.class);
        getVersionData.getVersionData(new Callback<GetVersionData>() {
            @Override
            public void success(GetVersionData getVersionData, retrofit.client.Response response) {
                if (getVersionData == null || response.getStatus() != 200) {
                    Toast.makeText(GoogleLoginActivity.this, "Invalid response", Toast.LENGTH_SHORT).show();
                } else {
                    GetVersionData.Datum data = getVersionData.getData().get(0);
                    mNewUpdateVersion = data.getNewUpdateVersion();
                    mForcedUpdateFlag = data.getForcedUpdateFlag();
                    checkAppVersion();
                }
                hideProgressDialog();
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                //error message
                hideProgressDialog();
                Toast.makeText(GoogleLoginActivity.this, "Something went wrong, please try again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkAppVersion() {
        try {
            PackageInfo pInfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
            String version = pInfo.versionName;
            if (version.compareTo(mNewUpdateVersion) < 0) {
                if (!GoogleLoginActivity.this.isFinishing())
                    showUpdateAlert(mForcedUpdateFlag);
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }


    private void checkIfUserIsAdmin(){

        showProgressDialog();

        Callback<String> callback = new Callback<String>() {
            @Override
            public void success(String s, Response response) {
                hideProgressDialog();
                if(response.getStatus() == 200 &&
                        !ExternalProcessManager.stringIsNull(s)
                        && s.equalsIgnoreCase("yes")) {
                    manager.setAdmin(true);
                }else{
                    manager.setAdmin(false);
                }

                try {
                    getData();
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.i("LoginException " , "Login exception occured");
                }
            }

            @Override
            public void failure(RetrofitError error) {
                hideProgressDialog();
                try {
                    getData();
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.i("LoginException " , "Login exception occured");

                }
            }
        };

        RestAdapter restAdapter = new RestAdapter.Builder()
                .setLogLevel(RestAdapter.LogLevel.FULL)
                .setLog(new AndroidLog("CHECK_USER_ADMIN"))
                .setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .build();
        restAdapter.create(SignupInterface.class).checkIfUserIsAdmin(manager.getSalesId() , callback);
    }


    private void showUpdateAlert(boolean forced) {
        AlertDialog.Builder builder = new AlertDialog.Builder(GoogleLoginActivity.this);
        builder.setCancelable(false);
        builder.setTitle("Update").setMessage("There is a new update available!").setPositiveButton("Update", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        if (!forced) {
            builder.setNegativeButton("Skip", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
        }
        AlertDialog dialog = builder.create();
        dialog.show();
        //Overriding the handler immediately after show is probably a better approach than OnShowListener as described below
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                downloadUpdate();
            }
        });
    }

    private void downloadUpdate() {
        //String url = "https://drive.google.com/file/d/0By-qDmTvjj2cWk5yUjZ2cXg1RUk/view";
        String url = "https://play.google.com/store/apps/details?id=com.nowfloats.rocketsingh";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }

    private void addFCMData(AddFCMDataRequest model) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.WEB_ACTION_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        FcmIdInterface fcmIdInterface = restAdapter.create(FcmIdInterface.class);
        fcmIdInterface.postFCMData(model, new Callback<String>() {
            @Override
            public void success(String dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    Toast.makeText(GoogleLoginActivity.this, "Please try again", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (response.getStatus() == 200) {

                } else {
                    Toast.makeText(GoogleLoginActivity.this, "Please try again", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Toast.makeText(GoogleLoginActivity.this, "Retrofit error", Toast.LENGTH_SHORT).show();
                //error
            }
        });
    }


    private void getData() throws JSONException {
      //  userInfoForApxor.put("loggedInWithNowfloatsId",salesId);
        mFirebaseAnalytics.logEvent("loggedInWithNowfloatsId", b);
        manager.setSalesId(salesId);
        manager.setFcmId(mRegId);
        mDataMap.put("salesId", salesId);//users email id
        mDataMap.put("fcmId", manager.getFcmId());
        manager.setBusinessId(Constants.ROCKET_SINGH_BUSINESS_ID);
        manager.setBaseUrl(Constants.ANA_DEV_URL);
        manager.setApxorAnalyticsAppId(manager.getBaseUrl().contains("dev") ? Constants.APXOR_DEV_ID : Constants.APXOR_PROD_ID);
        //ApxorSDK.initialize(manager.getApxorAnalyticsAppId(),this.getApplicationContext());
        AnaCore.registerUser(   GoogleLoginActivity.this, salesId, manager.getBusinessId(), manager.getBaseUrl());
        getEmployeeDivision(salesId, this);
        props.put("SalesId", salesId);
        mMixpanel.registerSuperProperties(props);
        mMixpanel.track("loggedInWithNowfloatsId");
        //ApxorSDK.logAppEvent("loggedInWithNowfloatsId");
        PackageInfo pInfo = null;
        try {
            pInfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        String version = null;
        if (pInfo != null) {
            version = pInfo.versionName;
        }
        GetFCMDataResponse("emailID: '" + salesId.toLowerCase() + "',deviceID:'" + mDeviceId + "'", salesId.toLowerCase(), mRegId, version);
    }


        public void GetFCMDataResponse(String query, final String emailId, final String fcmId, final String version) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.WEB_ACTION_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        FcmIdInterface getData = restAdapter.create(FcmIdInterface.class);
        DisplayLog(query);
        getData.getFCMData("{" + query + "}", new Callback<GetFCMDataResponse>() {
            @Override
            public void success(GetFCMDataResponse getFcmData, retrofit.client.Response response) {
                if (getFcmData == null || response.getStatus() != 200) {//error message
                    Toast.makeText(GoogleLoginActivity.this, "Invalid email!", Toast.LENGTH_SHORT).show();
                } else {
                    List<GetFCMDataResponse.Datum> datar = getFcmData.getData();
                    GetFCMDataResponse.Extra datae = getFcmData.getExtra();
                    if (datae.getTotalCount() == 0) {
                        //add data
                        AddFCMDataRequest model = new AddFCMDataRequest();
                        model.setWebsiteId("59a7d4ad20320013d43d041d");
                        AddFCMDataRequest.ActionData dataModel = new AddFCMDataRequest.ActionData();
                        dataModel.setEmailID(emailId);
                        dataModel.setFcmID(fcmId);
                        dataModel.setVersion(version);
                        dataModel.setDeviceID(mDeviceId);
                        model.setActionData(dataModel);
                        addFCMData(model);
                    } else {
                        //update data
                        UpdateFcmDataRequest model = new UpdateFcmDataRequest();
                        model.setUpdateValue("{$set : {fcmID: '" + fcmId + "', version: '" + version + "'}}");
                        updateFcmData(datar.get(0).getId(), model);
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                //error message
                Toast.makeText(GoogleLoginActivity.this, "Something went wrong, please try again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getExistingCustomers(){

        showProgressDialogByAna();

        String email = ExternalProcessManager.getInstance().getDeepLinkUrl().split("#")[1];
        String fpTag = ExternalProcessManager.getInstance().getDeepLinkUrl().split("#")[2];

        RestAdapter restAdapter = new RestAdapter.Builder().setLogLevel(RestAdapter.LogLevel.FULL).setEndpoint(Constants.ERP_API_URL).setLog(new AndroidLog("ddd")).build();

        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

        HashMap<String , String> queries = new HashMap<>();
        queries.put("fpTag" , fpTag.toUpperCase());

        erpApiInterface.getExistingCusotomers(queries, new Callback<List<GetExistingCustomerResponse>>() {
            @Override
            public void success(List<GetExistingCustomerResponse> getExistingCustomerResponses, Response response) {

                hideProgressDialog();

                HashMap<String , GetExistingCustomerResponse> customersMap = new HashMap<>();
                List<String> customersDetails = new ArrayList<>();


                for(GetExistingCustomerResponse getExistingCustomerResponse : getExistingCustomerResponses) {

                    String key = getExistingCustomerResponse.getEmail()+"\n" + getExistingCustomerResponse.getMobile()+" \n " +getExistingCustomerResponse.getName();
                    customersMap.put(key , getExistingCustomerResponse);
                    customersDetails.add(key) ;

                }

                if(getExistingCustomerResponses.size() > 0) {

                    showListDialog(customersDetails , externalProcessManager.getAnaChatContext() ,
                            externalProcessManager.getTitle() , externalProcessManager.getValue() , "Select you customer"
                     , "None" , Constants.SHOW_EXISTING_CUSTOMERS , customersMap);

                }else{
                    DisplayToast(getString(R.string.no_customers));
                }

            }

            @Override
            public void failure(RetrofitError error) {

                hideProgressDialog();

                DisplayLog(error.getMessage());

            }
        });

    }



    private void updateFcmData(String id, UpdateFcmDataRequest model) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.WEB_ACTION_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        FcmIdInterface fcmUpdateInterface = restAdapter.create(FcmIdInterface.class);
        fcmUpdateInterface.updateFCMData(id, model, new Callback<String>() {
            @Override
            public void success(String dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error
                    Toast.makeText(GoogleLoginActivity.this, "Invalid Data! Please try again", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (response.getStatus() == 200) {
                    //onApiSuccessfull
                } else {
                    Toast.makeText(GoogleLoginActivity.this, "Invalid Data! Please try again", Toast.LENGTH_SHORT).show();
                    //not successful
                }
            }

            @Override
            public void failure(RetrofitError error) {
                if ((error.getResponse() != null) && error.getResponse().getStatus() != 200) {
                    Toast.makeText(GoogleLoginActivity.this, "Retrofit error", Toast.LENGTH_SHORT).show();
                    //error
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        b.putInt("button_id", id);
        switch (id) {
            case R.id.ll_login:
                mFirebaseAnalytics.logEvent("login", b);
                mMixpanel.track("login");
                mHideProgress = 1;
                showProgressDialog();
                signIn();
                break;
            case R.id.ll_loginCF:
                mFirebaseAnalytics.logEvent("CFlogin", b);
                mMixpanel.track("CFlogin");
                mHideProgress = 1;
                /*signInCF();*/
                break;
            case R.id.ll_start_chat:
                mFirebaseAnalytics.logEvent("start_rocket_chat", b);
                mMixpanel.track("start_rocket_chat");
                DisplayLog(manager.getFlowId());
                manager.setFirstChatOpen(true);
                startChatScreen(manager.getBusinessId(), manager.getBaseUrl(), manager.getFlowId());
                break;
            case R.id.ivMainMenu:
                DisplayLog(manager.getCFUsername() + " hello");
                if (manager.getIsFOSLoggedIn()) {
                    if (!TextUtils.isEmpty(manager.getCFUsername())) {
                        showPopupCF(v);
                    }
                    else if (TextUtils.isEmpty(manager.getCFUsername())) {
                        showPopupFOS(v);
                    }
                } else
                    showPopup(v);
                break;
        }
    }




    private void showPopupFOS(View v) {
        DisplayLog("fos menu");
        PopupMenu popup = new PopupMenu(this, v);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.actions_fos, popup.getMenu());
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_fos_logout:
                        b.putString("salesID", salesId);
                        mFirebaseAnalytics.logEvent("logged_out", b);
                        mMixpanel.track("logged_out");
                        mHideProgress = 2;
                        manager.setIsFOSLoggedIn(false);
                        showProgressDialog();
                        signOut();
                        return true;
                    case R.id.action_attendace:
                        Intent i = new Intent(GoogleLoginActivity.this, AttendanceActivity.class);
                        startActivity(i);
                        return true;
                    case R.id.action_fos_da:
                        mFirebaseAnalytics.logEvent("checkedApprovalsList", b);
                        mMixpanel.track("checkedApprovalsList");
                        Intent approvals = new Intent(GoogleLoginActivity.this, DiscountApprovalsActivity.class);
                        startActivity(approvals);
                        return true;
                    case R.id.action_fos_about:
                        mFirebaseAnalytics.logEvent("aboutActivity", b);
                        mMixpanel.track("aboutActivity");
                        Intent about = new Intent(GoogleLoginActivity.this, AboutActivity.class);
                        startActivity(about);
                        return true;
                    case R.id.action_nf_leaderboard:
                        mFirebaseAnalytics.logEvent("CheckedRank", b);
                        mMixpanel.track("CheckedRank");
                        HashMap<String, String> model = new HashMap<String, String>();
                        model.put("clientId", Constants.ERPClientId);
                        getEmployeeRank(model, salesId);
                        return true;
                    default:
                        return false;
                }
            }
        });
        popup.show();
    }

    private void getEmployeeDivision(final String email, Context context) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        GetEmployeeDetailsRequest model = new GetEmployeeDetailsRequest();
        model.setClientId(Constants.ERPClientId);
        model.setEmail(email);
        signupInterface.checkEmployeeDivision(model, new Callback<List<GetEmployeeDetailsResponse>>() {
            @Override
            public void success(List<GetEmployeeDetailsResponse> dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error
                    hideProgressDialog();
                    Toast.makeText(GoogleLoginActivity.this, "Invalid Data! Please try again", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (response.getStatus() == 200) {
                    //onApiSuccessfull
                    for (GetEmployeeDetailsResponse b : dataResponse) {
                        if (b.getEmail().equals(email)) {

                            mDataMap.put("division", b.getDivision());
                            manager.setCFUsername(b.getCFT());
                            manager.setEmployeeId(b.getEmployeeId());
                            if (b.getCFT() != null) {
        //
                               // startCFService()
                                mDataMap.put("cfUsername", b.getCFT());
                            } else {
                               // startFOSService();
                                DisplayLog("cf is null");
                            }
                            switch (b.getDivision()) {
                                case "FOS-CF":
                                    manager.setIsFOSLoggedIn(true);
                                    manager.setFlowId(Constants.LANDING_PAGE_FLOW_ID);
                                    break;
                                case "FOS":
                                    manager.setIsFOSLoggedIn(true);
                                    manager.setFlowId(Constants.LANDING_PAGE_FLOW_ID);
                                    break;
                                default:
                                    manager.setIsFOSLoggedIn(true);
                                    manager.setFlowId(Constants.LANDING_PAGE_FLOW_ID);
                                    break;
                            }
                            updateUI(true, 4000);
                        }
                    }
                } else {
                    hideProgressDialog();
                    Toast.makeText(GoogleLoginActivity.this, "Invalid Data! Please try again", Toast.LENGTH_SHORT).show();
                    //not successful
                }
            }

            @Override
            public void failure(RetrofitError error) {
                getEmployeeDivision(email, context);
                //error
            }
        });
    }

    private void DisplayLog(String s) {
        if (s != null)
            Log.i("android232356162", s);
    }

    private void DisplayObject(Object g){
        if(g != null ){
            DisplayLog(new Gson().toJson(g));
        }else{
            DisplayLog("Object is NA");
        }
    }

    private void getEmployeeRank(final HashMap<String, String> model, final String emailId) {
        showProgressDialog();
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        signupInterface.getEmployeeRank(model, new Callback<List<EmployeesRankResponse>>() {
            @Override
            public void success(List<EmployeesRankResponse> dataResponse, retrofit.client.Response response) {
                hideProgressDialog();
                if (dataResponse == null || response.getStatus() != 200) {
                    //error
                    if (model.containsKey("emailId")) {
                        showRanksDialog();
                    }
                    hideProgressDialog();
                    return;
                }
                if (response.getStatus() == 200 && dataResponse.size() > 0) {
                    //onApiSuccessfull
                    if (model.containsKey("emailId")) {
                        mCurrentEmployeeRankList = dataResponse;
                        showRanksDialog();
                    } else {
                        mTopEmployeesRankList = dataResponse;
                        HashMap<String, String> requestMap = new HashMap<>();
                        requestMap.put("clientId", Constants.ERPClientId);
                        requestMap.put("emailId", emailId);
                        getEmployeeRank(requestMap, emailId);
                    }
                } else {
                    if (model.containsKey("emailId")) {
                        showRanksDialog();
                    }
                    hideProgressDialog();
                    //not successful
                }
            }

            @Override
            public void failure(RetrofitError error) {
                hideProgressDialog();
                //error
//                if (model.containsKey("emailId") && emailId.endsWith("@nowfloats.com")) {
//                    getEmployeeRank(model, emailId);
//                } else if(emailId.contains("@nowfloats.com"))
//                    getEmployeeRank(model, emailId);
//                else
//                    hideProgressDialog();
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        DisplayLog("got here7");
        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        LocationHelper.checkOnActivityResult(requestCode , resultCode);
       if(resultCode ==  RESULT_OK) {
           if (requestCode == RC_SIGN_IN) {
               GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
               try {
                   handleSignInResult(result);
               } catch (JSONException e) {
                   e.printStackTrace();
               }
           }else if(requestCode == Constants.GPS_STATUS_CODE) {

           }
       }
    }

    private void updateReceiptInSo(Bitmap receiptImage,String imageName,String title, String value, Context context) {
        DisplayLog("got here2");
        showProgressDialogByAna();
        String transactionId = externalProcessManager.getTransactionId();
        String receiptBase64 = ExternalProcessManager.getBase64StringFromImage(receiptImage);
        UpdateReceiptInSORequest updateReceiptInSORequest = new UpdateReceiptInSORequest();
        updateReceiptInSORequest.setMethod(Constants.ERP_METHOD);
        updateReceiptInSORequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        UpdateReceiptInSORequest.Params params = new UpdateReceiptInSORequest.Params();
        List<Object> args = new ArrayList<>();

        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);
        args.add("UpdateReceiptInSO");

        UpdateReceiptInSORequest.UserDetails userDetails = new UpdateReceiptInSORequest.UserDetails();
        userDetails.setEmailId(manager.getSalesId());
        userDetails.setSalesOrderId(null);
        userDetails.setClaimId(transactionId);
        userDetails.setReceiptPicBin(receiptBase64);
        userDetails.setReceiptPicName(imageName);
        args.add(userDetails);
        params.setArgs(args);
        params.setService(Constants.ERP_PARAM_SERVICE);
        params.setMethod(Constants.ERP_PARAM_METHOD);
        updateReceiptInSORequest.setParams(params);
        HashMap<String,String> userData = new HashMap<>();
        userData.put("receiptSuccess","false");
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        DisplayLog(new Gson().toJson(updateReceiptInSORequest));
        erpApiInterface.UpdateReceiptInSO(updateReceiptInSORequest, new Callback<Response>() {
            @Override
            public void success(Response requestResponse, Response response) {
                boolean requestResult = false;
                hideProgressDialog();
                if(response.getStatus()==200){
                    JSONObject jsonResponse = externalProcessManager.getJsonFromTypedInput(requestResponse.getBody());
                    try {
                        requestResult = jsonResponse.getBoolean("result");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    userData.put("receiptSuccess",requestResult+"");
                    DisplayLog(jsonResponse.toString());
                }else{
                    DisplayToast("Sorry some error occured.");
                }
                AnaCore.sendDeeplinkEventData(context,userData,title,value);
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayToast(error.getMessage());
                DisplayLog(error.toString());
                hideProgressDialog();
                AnaCore.sendDeeplinkEventData(context,userData,title,value);
            }
        });
    }




    private void displayFirebaseRegId() {
        SharedPreferences pref = getApplicationContext().getSharedPreferences(Config.SHARED_PREF, 0);
        mRegId = pref.getString("regId", null);
        Log.e(TAG, "Firebase reg id: " + mRegId);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // register GCM registration complete receiver
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(Config.REGISTRATION_COMPLETE));
        // register new push message receiver
        // by doing this, the activity will be notified each time a new message arrives
        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(Config.PUSH_NOTIFICATION));
        // clear the notification area when the app is opened
        NotificationUtils.clearNotifications(getApplicationContext());
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
        super.onPause();
    }

    @Override
    public void onStart() {
        super.onStart();
        OptionalPendingResult<GoogleSignInResult> opr = Auth.GoogleSignInApi.silentSignIn(mGoogleApiClient);
        if (opr.isDone()) {
            // If the user's cached credentials are valid, the OptionalPendingResult will be "done"
            // and the GoogleSignInResult will be available instantly.
            Log.d(TAG, "Got cached sign-in");
            GoogleSignInResult result = opr.get();
            try {
                handleSignInResult(result);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            // If the user has not previously signed in on this device or the sign-in has expired,
            // this asynchronous branch will attempt to sign in the user silently.  Cross-device
            // single sign-on will occur in this branch.
            opr.setResultCallback(new ResultCallback<GoogleSignInResult>() {
                @Override
                public void onResult(@NonNull GoogleSignInResult googleSignInResult) {
                    try {
                        handleSignInResult(googleSignInResult);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        // An unresolvable error has occurred and Google APIs (including Sign-In) will not
        // be available.
        Log.d(TAG, "onConnectionFailed:" + connectionResult);
    }

    public void showProgressDialog() {
        if (! (GoogleLoginActivity.this.isFinishing()) && this instanceof GoogleLoginActivity) {
            //show dialog
          try{
              if (mProgressDialog == null) {
                  mProgressDialog = new ProgressDialog(this);
                  mProgressDialog.setMessage(getString(R.string.please_wait));
                  mProgressDialog.setIndeterminate(true);
                  mProgressDialog.setCancelable(false);
              }
              if (!mProgressDialog.isShowing())
                  mProgressDialog.show();
          }catch(Exception e ){
                // error occured
          }
          }
    }

    private void getAllEmployees(){

        showProgressDialogByAna();

        GetAllEmployeeRequest getAllEmployeeRequest = new GetAllEmployeeRequest();
        getAllEmployeeRequest.setClientId(Constants.ERPClientId);

        RestAdapter restAdapter = new RestAdapter.Builder().setLog(new AndroidLog("Employee Details")).setEndpoint(Constants.ERP_API_URL).build();

        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);

        erpApiInterface.GetAllEmployees(getAllEmployeeRequest, new Callback<List<GetAllEmployeeResponse>>() {
            @Override
            public void success(List<GetAllEmployeeResponse> getAllEmployeeResponses, Response response) {
                hideProgressDialog();
                if(response.getStatus() != 200 ){
                    externalProcessManager.showToast("Sorry some error occured ");
                }else{
                    if(getAllEmployeeResponses == null ){
                        externalProcessManager.showToast("Sorry some error occured ");
                        return;
                    }

                    if(getAllEmployeeResponses.size() == 0){
                        externalProcessManager.showToast("Sorry some error occured ");
                        return;
                    }

                    List<String> listFomat = new ArrayList<>();
                    HashMap<String,String> map = new HashMap<>();

                    for(GetAllEmployeeResponse getAllEmployeeResponse : getAllEmployeeResponses){
                        listFomat.add(getAllEmployeeResponse.getEmail()+"\n"+getAllEmployeeResponse.getName());
                        map.put(getAllEmployeeResponse.getEmail()+"\n"+getAllEmployeeResponse.getName() , getAllEmployeeResponse.getEmail());

                    }

                   showAllEmployees(listFomat , map , externalProcessManager.getAnaChatContext() , externalProcessManager.getTitle() , externalProcessManager.getValue());
                }
            }

            @Override
            public void failure(RetrofitError error) {
                hideProgressDialog();
                externalProcessManager.showToast("Sorry some error occured "+error.getMessage());
            }
        });
    }

    public void hideProgressDialog() {
        if (mProgressDialog != null && mProgressDialog.isShowing()) {
            mProgressDialog.dismiss();
        }
    }

    private void updateUI(final boolean isSignedIn, final int time) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (isSignedIn) {
                            mFirebaseAnalytics.setUserId(salesId);
                           // llStartChat.setVisibility(View.VISIBLE);
                            llSignIn.setVisibility(GONE);
                            llCFSignIn.setVisibility(GONE);
                            //ivMainMenu.setVisibility(View.VISIBLE);
                            setupDrawerLayout();
                            ivMainMenu.setEnabled(true);
                            if (mHideProgress == 1)
                                hideProgressDialog();
                            if (manager.getLastRankNotifTime() == 0)
                                manager.setLastRankNotifTime(Long.parseLong("1507552248853"));
                            long tsLast = manager.getLastRankNotifTime();
                            long tsCurrent = System.currentTimeMillis();
                            String result = (String) DateUtils.getRelativeTimeSpanString(tsLast, tsCurrent, 0);
                            long diff = (tsCurrent - tsLast) / 1000;
                            if (diff > 43200) {
                                HashMap<String, String> model = new HashMap<>();
                                model.put("clientId", Constants.ERPClientId);
                                if(salesId.contains("@nowfloats.com"))
                                     getEmployeeRank(model, salesId);
                                manager.setLastRankNotifTime(tsCurrent);
                            }
                            if (manager.getSalesId() != null) {
                                if (!manager.getSalesId().contains("@nowfloats.com")) {
                                    if (mHideProgress == 2) {
                                        DisplayLog("progress bar hidden");
                                        hideProgressDialog();
                                    }
                                }
                            }
                            Log.d("timestampDiff:", result + " " + diff);
                        } else {
                            llSignIn.setVisibility(View.VISIBLE);
                            llCFSignIn.setVisibility(GONE);
                            llStartChat.setVisibility(GONE);
                            ivMainMenu.setVisibility(View.INVISIBLE);
                            ivMainMenu.setEnabled(false);
                            if (mHideProgress == 2) {
                                DisplayLog("progress bar hidden");
                                hideProgressDialog();
                            }
                        }
                    }
                }, time);
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        mMixpanel.flush();
        hideProgressDialog();
        super.onDestroy();
    }

    public void showPopupCF(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.action_cf, popup.getMenu());
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_fos_logout:
                        b.putString("salesID", salesId);
                        mFirebaseAnalytics.logEvent("logged_out", b);
                        mMixpanel.track("logged_out");
                        mHideProgress = 2;
                        manager.setIsFOSLoggedIn(false);
                        showProgressDialog();
                        signOut();
                        return true;
                    case R.id.action_fos_da:
                        mFirebaseAnalytics.logEvent("checkedApprovalsList", b);
                        mMixpanel.track("checkedApprovalsList");
                        Intent approvals = new Intent(GoogleLoginActivity.this, DiscountApprovalsActivity.class);
                        startActivity(approvals);
                        return true;
                    case R.id.action_fos_about:
                        mFirebaseAnalytics.logEvent("aboutActivity", b);
                        mMixpanel.track("aboutActivity");
                        Intent about = new Intent(GoogleLoginActivity.this, AboutActivity.class);
                        startActivity(about);
                        return true;
                    case R.id.action_nf_leaderboard:
                        mFirebaseAnalytics.logEvent("CheckedRank", b);
                        mMixpanel.track("CheckedRank");
                        HashMap<String, String> model = new HashMap<String, String>();
                        model.put("clientId", Constants.ERPClientId);
                        getEmployeeRank(model, salesId);
                        return true;
                    case R.id.action_meetingsAnalysis:
                        mFirebaseAnalytics.logEvent("CheckedmeetingAnalysis", b);
                        mMixpanel.track("CheckedRank");
                        getFpTagsForMeetingAnalysis();
                        return true;
                    case R.id.action_attendace:
                        Intent i = new Intent(GoogleLoginActivity.this, AttendanceActivity.class);
                        startActivity(i);
                        return true;
                    default:
                        return onMenuItemClick(item);
                }
            }
        });
        popup.show();
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        MenuInflater inflater = popup.getMenuInflater();
        inflater.inflate(R.menu.actions, popup.getMenu());
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_logout:
                        b.putString("salesID", salesId);
                        mFirebaseAnalytics.logEvent("cf_logged_out", b);
                        mMixpanel.track("cf_logged_out");
                        mHideProgress = 2;
                        showProgressDialog();
                        signOut();
                        return true;
                    case R.id.action_about:
                        mFirebaseAnalytics.logEvent("aboutActivity", b);
                        mMixpanel.track("aboutActivity");
                        Intent about = new Intent(GoogleLoginActivity.this, AboutActivity.class);
                        startActivity(about);
                        return true;
                    default:
                        return onMenuItemClick(item);
                }
            }
        });
        popup.show();
    }

        public void startChatToLogSale(String BusinessId, String BaseUrl, String FlowId) {
            new AnaChatBuilder(GoogleLoginActivity.this)
                    .setBusinessId(BusinessId)
                    .setBaseUrl(BaseUrl)
                    .setFlowId(FlowId)
                    .setThemeColor(R.color.colorPrimary)
                    .setToolBarDescription("Sales Assistant - Available")
                    .setToolBarTittle("Rocket Singh")
                    .setToolBarLogo(R.drawable.logo_transparent)
                    .registerLocationSelectListener(this)
                    .registerCustomMethodListener(this)
                    .setEvents(mDataMap)
                    .start();
            if (PreferencesManager.getsInstance(this).getUserName().isEmpty()) {
                Toast.makeText(this, "User not initialized", Toast.LENGTH_SHORT).show();
            }
        }

    public void startChatScreen(String BusinessId, String BaseUrl, String FlowId) {
        new AnaChatBuilder(GoogleLoginActivity.this)
                .setBusinessId(BusinessId)
                .setBaseUrl(BaseUrl)
                .setFlowId(FlowId)
                .setThemeColor(R.color.colorPrimary)
                .setToolBarDescription("Sales Assistant - Available")
                .setToolBarTittle("Rocket Singh")
                .setToolBarLogo(R.drawable.logo_transparent)
                .registerLocationSelectListener(this)
                .registerCustomMethodListener(this)
                .setChatAnimationDelay(1000)
                .setEvents(mDataMap)
                .start();
        if (PreferencesManager.getsInstance(this).getUserName().isEmpty()) {
            Toast.makeText(this, "User not initialized", Toast.LENGTH_SHORT).show();
        }
    }

    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (inputMethodManager != null) {
                inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
            }
        }
    }

    private void showRanksDialog() {
        hideProgressDialog();
        final Dialog mCustomDialog = new Dialog(this,
                R.style.CustomDialogTheme);
        mCustomDialog.setContentView(R.layout.dialog_ranks);
        mCustomDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        mCustomDialog.getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        LinearLayout llMyRank = mCustomDialog.findViewById(R.id.ll_my_rank);
        ImageView ivClose = mCustomDialog.findViewById(R.id.iv_close);
        TextView tvRank = mCustomDialog.findViewById(R.id.tv_rank);
        TextView tvName = mCustomDialog.findViewById(R.id.tv_name);
        TextView tvBranch = mCustomDialog.findViewById(R.id.tv_branch);
        TextView tvRevenue = mCustomDialog.findViewById(R.id.tv_revenue);
        TextView tvHeader = mCustomDialog.findViewById(R.id.tv_header);
        RecyclerView rvRanks = mCustomDialog.findViewById(R.id.rv_ranks);
        if (mCurrentEmployeeRankList == null || mCurrentEmployeeRankList.size() == 0) {
            llMyRank.setVisibility(GONE);
        } else {
            llMyRank.setVisibility(View.VISIBLE);
            tvBranch.setText(mCurrentEmployeeRankList.get(0).getBranch());
            tvRank.setText(mCurrentEmployeeRankList.get(0).getNationalRank());
            tvName.setText(mCurrentEmployeeRankList.get(0).getEmployee());
            tvRevenue.setText("₹" + mCurrentEmployeeRankList.get(0).getRevenue());
        }
        Date todayDate = Calendar.getInstance().getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
        String todayString = formatter.format(todayDate);
        tvHeader.setText("NowFloats Sales Leader Board as of " + todayString);
        rvRanks.setLayoutManager(new LinearLayoutManager(this));
        RanksRecyclerViewAdapter ranksAdapter = new RanksRecyclerViewAdapter(GoogleLoginActivity.this, mTopEmployeesRankList);
        rvRanks.setAdapter(ranksAdapter);
        ranksAdapter.notifyDataSetChanged();
        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mCustomDialog.dismiss();
            }
        });
        if (!this.isFinishing()) {
            mCustomDialog.show();
        }
    }

    @Override
    public Intent pickLocation(Activity activity) {
        try {
            PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
            Intent placePickerIntent = builder.build(activity);
            placePickerIntent.putExtra("primary_color",
                    Color.parseColor(PreferencesManager.getsInstance(activity).getThemeColor()));
            placePickerIntent.putExtra("primary_color_dark",
                    ContextCompat.getColor(activity, R.color.gray_light));
            return placePickerIntent;
        } catch (GooglePlayServicesRepairableException |
                GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void sendLocation(Intent data) {
        Place place = PlacePicker.getPlace(this, data);
        LatLng latLng = place.getLatLng();
        AnaCore.sendLocation(latLng.latitude, latLng.longitude, this);
    }

    private  boolean permissionForCall() {
        return ActivityCompat.checkSelfPermission(externalProcessManager.getAnaChatContext(), Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public void implementCustomMethod(Context context, String deeplinkUrl, String title, String value) {
        mChatContext = context;
        externalProcessManager = ExternalProcessManager.getInstance()
                .setAnaChatContext(context)
                .setExternalProcessInterface(this)
                .setTitle(title)
                .setValue(value)
                .setDeepLinkUrl(deeplinkUrl);

        HashMap<String, String> eventsData = new HashMap<>();
        if (deeplinkUrl.contains("ViewOutcome")) {
            getMeetingOutcome(context, deeplinkUrl);
            AnaCore.sendDeeplinkEventData(context, eventsData, title, value);
        }else if(deeplinkUrl.contains("ExistingCustomers")){
            getExistingCustomers();
        }
        else if(deeplinkUrl.contains("ExistingQuotations")){
            getNewQuotations(context , title , value , deeplinkUrl.split("#")[1]);
        }else if(deeplinkUrl.contains("getAllEmployees")){
            getAllEmployees();
        }
        else if(deeplinkUrl.contains("ViewCategories")){
                viewCategories(context , title,value,deeplinkUrl);
        }else if(deeplinkUrl.contains("GetAllPackages")){
            getAllPackages(context , title , value , deeplinkUrl);
        }
        else if (deeplinkUrl.contains("UpdateOutcome")) {
            getQuestions(deeplinkUrl, context);
            AnaCore.sendDeeplinkEventData(context, eventsData, title, value);
        } else if (deeplinkUrl.contains("GetTags")) {
            if (!dialogExists)
                getFpTagsForCF(context, title, value, Constants.SHOW_FP_TAGS_FOR_CF);
        } else if(deeplinkUrl.contains("GetAssignedLeads")){
            getAssignedLeads(context,title,value);
        }else if (deeplinkUrl.contains("GetUpgradePackages")) {
            if (!dialogExists)
                getUpgradePackages(context, title, value, deeplinkUrl);
        } else if (deeplinkUrl.contains("GetCategories")) {
                getCategories(context, title, value);
        } else if (deeplinkUrl.contains("GetLeadsList")) {
            if (!dialogExists)
                getLeadDetails(context, title, value);
        }else if(deeplinkUrl.contains("getAssignedLeads")){
          getAssignedLeads(context , title , value);
        }
        else if (deeplinkUrl.contains("GetCurrentLocation")) {
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(context);
            locationManager = (LocationManager) context
                    .getSystemService(LOCATION_SERVICE);
            askLocationPermission();
            checkLocationSettings();
            getLocation();
            AnaCore.sendDeeplinkEventData(context, eventsData, title, value);
        } else if (deeplinkUrl.contains("GetAddress")) {
            getLeadAddress(context, title, value);
        } else if (deeplinkUrl.contains("GetHotprospects")) {
            DisplayLog("got hot prospects");
            getHotprospects(context, title, value);
        } else if(deeplinkUrl.contains("getVerticalPackages")) {
            DisplayLog("get vertical packages");
            if (!dialogExists)
                getVerticalPackages(context, title, value, deeplinkUrl);
        }
        else if(deeplinkUrl.contains("getHorizontalPackages")) {
            DisplayLog("get horizontal packages");
            if (!dialogExists)
                getHorizontalPackages(context, title, value, deeplinkUrl);
        }
         else if (deeplinkUrl.contains("getTemplates")) {
            getTemplates(title, value, context);
        } else if (deeplinkUrl.contains("verifyFpTag")) {
            getFPTagsForQuotation(deeplinkUrl, context, title, value);
        } else if (deeplinkUrl.contains("ChooseQuotationNumber")) {
            getQuotationNumbers(context, title, value);
        } else if(deeplinkUrl.contains("getBankList")) {
            getBankList(deeplinkUrl,context,title,value);
        }else if(deeplinkUrl.contains("callPhone")) {
            DisplayLog("here");
            setupCallingUtils();
        }else if(deeplinkUrl.contains("GetVerticalPackage")){
         //   if (!dialogExists)
                getVerticalPackages(context, title, value, deeplinkUrl);
        }
        else if (deeplinkUrl.contains("UpdateReceiptInSORequest")) {
             invokeImageChooser(deeplinkUrl);
        }else if(deeplinkUrl.contains("updatePaymentLogs")) {
            showProgressDialogByAna();
            deeplinkUrl = cleanDeeplinkUrl(deeplinkUrl);
            getBase64FromImage(deeplinkUrl,false);
        }else if(deeplinkUrl.contains(Constants.CHEQUE_UPLOAD_ACTION) || deeplinkUrl.contains(Constants.RECEIPT_UPLOAD_ACTION)){
            invokeImageChooser(Constants.INVOKE_IMAGE_CHOOSER);
        }else if(deeplinkUrl.contains("showAllTickets")) {
            GetEmployeeDataFromZendesk(deeplinkUrl,title,value,context);
        }else if(deeplinkUrl.contains("invokeLocationPicker")) {
            externalProcessManager.setActions(Constants.PICK_LOCATION_ACTION).startExternalActivity();
        }else if(deeplinkUrl.contains("GetInternalLocation")) {
            externalProcessManager.setActions(Constants.GET_CURRENT_LOCATION).startExternalActivity();
        }
        else
            AnaCore.sendDeeplinkEventData(context, eventsData, title, value);
    }

    private void getBankList(String deeplinkUrl, Context context, String title, String value) {
        showProgressDialogByAna();
        RestAdapter restAdapter = new RestAdapter.Builder().setLog(new AndroidLog("BankDetailsApi")).setEndpoint(Constants.ERP_API_URL).build();
        ERPApiInterface erpApiInterface  = restAdapter.create(ERPApiInterface.class);
        erpApiInterface.GetBankList(new Callback<List<String>>() {
            @Override
            public void success(List<String> strings, Response response) {
                if(response.getStatus() !=200) {
                    sendBadRequestMessageToAna();
                }else{
                    hideProgressDialog();
                    showBankList(deeplinkUrl,context,title,value,strings);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                    sendBadRequestMessageToAna();
            }
        });
    }

    private void setupCallingUtils() {
        if(permissionForCall()) {
            callIntentForAna(externalProcessManager.getDeepLinkUrl().split("#")[1]);
        }else{
            Intent actionCall = new Intent(externalProcessManager.getAnaChatContext() , ExternalActivity.class);
            actionCall.putExtra("action" , Constants.CALL_ACTION);
            startActivity(actionCall);
        }
    }

    private void GetEmployeeDataFromZendesk(String deeplinkUrl, String title, String value, Context context) {
        showProgressDialogByAna();
        String userId = deeplinkUrl.split("#")[1];
        GetUserdataFromZendeskRequest getUserdataFromZendeskRequest = new GetUserdataFromZendeskRequest();
        getUserdataFromZendeskRequest.setSalesId(userId);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.SALES_ASSISTANT_API_URL).setLog(new AndroidLog(Constants.TAG)).build();
        ZendeskInterface zendeskInterface = restAdapter.create(ZendeskInterface.class);
        zendeskInterface.getUserDataFromZendesk(getUserdataFromZendeskRequest, new Callback<GetUserdataFromZendeskResponse>() {
            @Override
            public void success(GetUserdataFromZendeskResponse getUserdataFromZendeskResponse, Response response) {
                if(response.getStatus() != 200) {
                    sendBadRequestMessageToAna();
                    return;
                }else{
                    List<GetUserdataFromZendeskResponse.User> user = getUserdataFromZendeskResponse.getUsers();
                    if(user == null){
                        sendBadRequestMessageToAna();
                        return ;
                    }else if(user.size() == 0 ){
                        sendBadRequestMessageToAna();
                        return ;
                    }else{
                     long userId = user.get(0).getId();
                     getAllTicketsForPartner(deeplinkUrl , title,value,context , userId);

                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayLog(error.getMessage());
                sendBadRequestMessageToAna();
            }
        });
    }

    private void getAllTicketsForPartner(String deeplinkUrl, String title, String value, Context context, long userId) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ZENDESK_ENDPOINT ).setLog(new AndroidLog(Constants.TAG)).build();
        ZendeskInterface zendeskInterface = restAdapter.create(ZendeskInterface.class);
        zendeskInterface.getAllTicketsFromZendesk(userId, new Callback<GetTicketsResponse>() {
            @Override
            public void success(GetTicketsResponse getTicketsResponse, Response response) {
                if(response.getStatus() != 200) {
                    sendBadRequestMessageToAna();
                    return;
                }else{
                   if(getTicketsResponse.getCount() == 0) {
                       sendBadRequestMessageToAna();
                       return;
                   }else{
                       hideProgressDialog();
                       showTickets(getTicketsResponse ,title,value,context,deeplinkUrl );
                   }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayLog(error.getMessage());
                sendBadRequestMessageToAna();
                return;
            }
        });
    }

    private void showTickets(GetTicketsResponse getTicketsResponse, String title, String value, Context context, String deeplinkUrl) {

      List<String> idAndSubject  = new ArrayList<>();
      List<String> onlyIds = new ArrayList<>();
      for(GetTicketsResponse.Ticket ticket : getTicketsResponse.getTickets()) {
          idAndSubject.add(ticket.getId()+"  -  "+(TextUtils.isEmpty(ticket.getRawSubject()) ? " " : "Subject: "+ ExternalProcessManager.formatString(ticket.getRawSubject()))
          +" \nStatus : "+(TextUtils.isEmpty(ticket.getStatus()) ? "NA" : ticket.getStatus())
          +" - Priority : "+(TextUtils.isEmpty(ticket.getPriority()) ? "NA"  : ticket.getPriority()) );
          onlyIds.add(ticket.getId()+"");
      }
        new MaterialDialog.Builder(context)
                .title(title)
                .titleColorRes(R.color.light_gray)
                .items(convertListToArray(idAndSubject))
                .itemsCallbackSingleChoice(-1, new MaterialDialog.ListCallbackSingleChoice() {
                    @Override
                    public boolean onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                        HashMap<String,String> userData = new HashMap<>();
                        String id = onlyIds.get(idAndSubject.indexOf(text));
                        userData.put("ticketId" , id);
                        userData.put("onApiSuccessfull","1");
                        DisplayLog(id);
                        AnaCore.sendDeeplinkEventData(context , userData , title,value);
                        return true;
                    }
                })
                .show();
    }


    public String[] convertListToArray(List<String> data) {
        String[] stockArr = new String[data.size()];
        stockArr = data.toArray(stockArr);
        return stockArr;
    }

    private void showBankList(String deeplinkUrl, Context context, String title, String value , List<String> bankLists) {
        new MaterialDialog.Builder(context)
                .title("Select a Bank")
                .titleColorRes(R.color.light_gray)
                .items(convertListToArray(bankLists))
                .itemsCallbackSingleChoice(-1, new MaterialDialog.ListCallbackSingleChoice() {
                    @Override
                    public boolean onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                        HashMap<String,String> userData = new HashMap<>();
                        userData.put("BANK" , text.toString());
                        AnaCore.sendDeeplinkEventData(context , userData , title,value);
                        return true;
                    }
                })
                .show();
    }

    private void showCustomList(String deeplinkUrl, Context context, String title, String value , List<String> bankLists , String key) {
        new MaterialDialog.Builder(context)
                .title(title)
                .titleColorRes(R.color.light_gray)
                .items(convertListToArray(bankLists))
                .itemsCallbackSingleChoice(-1, new MaterialDialog.ListCallbackSingleChoice() {
                    @Override
                    public boolean onSelection(MaterialDialog dialog, View view, int which, CharSequence text) {
                        HashMap<String,String> userData = new HashMap<>();
                        userData.put(key , text.toString());
                        AnaCore.sendDeeplinkEventData(context , userData , text.toString(),value);
                        return true;
                    }
                })
                .show();
    }

    private String cleanDeeplinkUrl(String deeplinkUrl) {
       deeplinkUrl = deeplinkUrl.replace("{{RTGS}}","");
       deeplinkUrl = deeplinkUrl.replace("{{chequeNumber}}","");
       deeplinkUrl = deeplinkUrl.replace("{{IFSC}}","");
       deeplinkUrl = deeplinkUrl.replace("{{cheque_receipt}}","");
       return deeplinkUrl;
    }

    private void getBase64FromImage(String deeplinkUrl, boolean isLast) {
        String[] deepLinkData = deeplinkUrl.split("#");
        String mainImage = isLast ? deepLinkData[13] : deepLinkData[12];
       if(mainImage.equals("")) {
           if(! isLast){
               externalProcessManager.clearImageList();;
               externalProcessManager.addInImageList(null);
               getBase64FromImage(deeplinkUrl,true);
           }else{
               externalProcessManager.addInImageList(null);
               getFpTagDetails(deeplinkUrl, externalProcessManager.getTitle(), externalProcessManager.getValue(), externalProcessManager.getAnaChatContext());
           }
           return ;
       }
        DisplayLog(deeplinkUrl);
        try {
            JSONArray imageArray = new JSONArray(mainImage);
            JSONObject tempObject = imageArray.getJSONObject(0);
            String url = tempObject.getString("url").split("\\?")[0];
            DisplayLog(url);
            Glide.with(externalProcessManager.getAnaChatContext())
                    .asBitmap()
                    .load(url)
                    .into(new SimpleTarget<Bitmap>() {
                        @Override
                        public void onResourceReady(Bitmap bitmap, Transition<? super Bitmap> transition) {
                            if(! isLast){
                                DisplayLog("here2");
                                externalProcessManager.clearImageList();

                                externalProcessManager.addInImageList(bitmap);
                                getBase64FromImage(deeplinkUrl,true);
                            }else{
                                DisplayLog("here3");
                                externalProcessManager.addInImageList(bitmap);
                                getFpTagDetails(deeplinkUrl, externalProcessManager.getTitle(), externalProcessManager.getValue(), externalProcessManager.getAnaChatContext());
                            }
                        }
                    });
          //  Picasso.get().load(url).into(target);
        } catch (JSONException e) {
            e.printStackTrace();
            hideProgressDialog();
        }

    }

    private void getFpTagDetails(String deeplinkUrl, String title, String value, Context context) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.NOW_FLOATS_API2_URL).build();
        CFInterface cfInterface = restAdapter.create(CFInterface.class);
        String fpTag = deeplinkUrl.split("#")[1];
        HashMap<String,String> hashMap = new HashMap<>();
        hashMap.put("clientId", Constants.clientId);
        cfInterface.getFpTagDetails(fpTag, hashMap, new Callback<GetFptagDetailsResponse>() {
            @Override
            public void success(GetFptagDetailsResponse getFptagDetailsResponse, Response response) {
                if(response.getStatus()!=200) {
                    DisplayLog(""+"error");
                    sendBadRequestMessageToAna();
                    hideProgressDialog();
                }else{
                   getProductDetailsByName(getFptagDetailsResponse,deeplinkUrl,title,value,context);

                }
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayLog(error.toString());
            }
        });
    }

    private void showOverlay(){
        final TapTargetSequence targetSequence = new TapTargetSequence(this)
                .targets(TapTarget.forView(findViewById(R.id.im_startChat) , "Click here to chat with Rocket Singh" , "" +
                                "It will help you do your job faster, while guiding you at every step of the way through a chat bot").transparentTarget(true),
                        TapTarget.forView(findViewById(R.id.im_selfMode) , "Click here to open menu" , "Manage your discounts , Report your order pick up and much more").transparentTarget(false)

                        )
                .listener(new TapTargetSequence.Listener() {
                    @Override
                    public void onSequenceFinish() {
                        overlayShown = true;
                    }

                    @Override
                    public void onSequenceStep(TapTarget lastTarget, boolean targetClicked) {

                    }

                    @Override
                    public void onSequenceCanceled(TapTarget lastTarget) {

                    }
                });
        if(!overlayShown) {
            overlayShown = true;
            targetSequence.start();
        }
    }

    private void getProductDetailsByName(GetFptagDetailsResponse getFptagDetailsResponse, String deeplinkUrl, String title, String value, Context context) {
            RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.SALES_ASSISTANT_API_URL).build();
            CFInterface cfInterface = restAdapter.create(CFInterface.class);
            String[] deepLinkData = deeplinkUrl.split("#");
            String productName = deepLinkData[3];
            HashMap<String,String> map = new HashMap<>();
            map.put("clientId",deepLinkData[2]);
            map.put("identifier",deepLinkData[2]);
            map.put("fpId",getFptagDetailsResponse.getId());
            map.put("country",getFptagDetailsResponse.getCountry());
            map.put("fpCategory",getFptagDetailsResponse.getCategory().get(0));
            map.put("productName",productName);
            cfInterface.getPackageByName(map, new Callback<GetProductByNameResponse>() {
                @Override
                public void success(GetProductByNameResponse getProductByNameResponse, Response response) {
                    if(response.getStatus() == 200){
                        DisplayLog(new Gson().toJson(getProductByNameResponse));
                        updatePaymentLogs(deeplinkUrl,deepLinkData,getProductByNameResponse, getFptagDetailsResponse, title,value,context);
                    }else{
                        DisplayLog("error");
                        sendBadRequestMessageToAna();
                        hideProgressDialog();
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    hideProgressDialog();
                    DisplayLog(error.getMessage());
                    sendBadRequestMessageToAna();
                }
            });
    }

    private void updatePaymentLogs(String deeplinkUrl, String[] deepLinkData, GetProductByNameResponse getProductByNameResponse, GetFptagDetailsResponse getFptagDetailsResponse, String title, String value, Context context) {
        ChequePaymentModel chequeModel = new ChequePaymentModel();
        chequeModel.setIfscCode(deepLinkData[4]);
        chequeModel.setBankName(deepLinkData[5]);
        chequeModel.setFpTag(getFptagDetailsResponse.getTag());
        chequeModel.setTransactionId(deepLinkData[14]);
        chequeModel.setCurrencyCode("INR");
        chequeModel.setId(null);
        chequeModel.setClientId(deepLinkData[2]);
        chequeModel.setId(deepLinkData[14]);
        chequeModel.setMicrCode(null);
        chequeModel.setName(getFptagDetailsResponse.getName());
        chequeModel.setPaymentStatus(0);
        chequeModel.setPartnerType(null);
        chequeModel.setPaymentFor(null);
        chequeModel.setPaymentDate(ExternalProcessManager.getlatestTime());
        chequeModel.setPaymentTransactionChannel(1);
        ProductPaymentModel productPaymentModel = new ProductPaymentModel();
        productPaymentModel.setDescription(getProductByNameResponse.getDescrption());
        productPaymentModel.setType(getProductByNameResponse.getType());
        try{
            chequeModel.setTdsPercentage(Double.valueOf(deepLinkData[15]));
            chequeModel.setTotalPrice(Double.parseDouble(deepLinkData[6]));
            chequeModel.setTaxAmount(Double.parseDouble(deepLinkData[7]));
            productPaymentModel.setDiscount(Double.valueOf(deepLinkData[8]));
            productPaymentModel.setPrice(Double.parseDouble(deepLinkData[6]));
        }catch(Exception e ){
            hideProgressDialog();
            sendBadRequestMessageToAna();
            throw  e;
        }
        productPaymentModel.setName(getProductByNameResponse.getName());
        productPaymentModel.setProductId(getProductByNameResponse.getId());
        productPaymentModel.setQuantity(1);
        List<ProductPaymentModel> productPaymentModelList = new ArrayList<>();
        productPaymentModelList.add(productPaymentModel);
        chequeModel.setProducts(productPaymentModelList);
        chequeModel.setReferenceId(null);
        chequeModel.setRejectionReason(null);
        chequeModel.setChequeNumber(deepLinkData[9]);
        chequeModel.setRtgsId(deepLinkData[10]);
        chequeModel.setGSTNumber(deepLinkData[11]);
        chequeModel.setImage(externalProcessManager.getImageBase64s().get(0));
        chequeModel.setAlternateImage(externalProcessManager.getImageBase64s().get(1));
        if(deepLinkData[17].equals("1")) {
            deepLinkData[16]  = ExternalProcessManager.getlatestTime();
        }
        chequeModel.setActivationDate(deepLinkData[16]);
        DisplayLog(new Gson().toJson(chequeModel));
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.NOW_FLOATS_API2_URL).build();
        CFInterface cfInterface = restAdapter.create(CFInterface.class);
        cfInterface.updateChequeLog(chequeModel, new Callback<String>() {
            @Override
            public void success(String s, Response response) {
                hideProgressDialog();
                if(response.getStatus() == 200) {
                    DisplayLog(s);
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("onApiSuccessfull" ,"1");
                    hashMap.put("callmarkaspaid",getPDCValidation(deepLinkData[16], deepLinkData[17]));
                    AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext(),hashMap, title,value);
                }else{
                    hideProgressDialog();
                    DisplayLog("error");
                    sendBadRequestMessageToAna();
                }
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayLog(error.getMessage());
                hideProgressDialog();
                sendBadRequestMessageToAna();
            }
        });
    }

    private String getPDCValidation(String deepLinkDatum , String RTGS) {
        if(RTGS.equals("1") ) {
            DisplayLog("call");
            return "0";
        }else {
            String todayDate = ExternalProcessManager.getlatestTime().split("T")[0] ;
            DateTime dateTimeToday  = DateTime.parse(todayDate);
            DateTime dateTimeLater = DateTime.parse(ExternalProcessManager.getDateFromAna(deepLinkDatum));
            long difference = ExternalProcessManager.printDifference(dateTimeLater,dateTimeToday);
            if(difference > 0) {
                difference = 0;
            }
            DisplayLog( String.valueOf(difference));
            return String.valueOf(difference);
        }
    }

    private void sendBadRequestMessageToAna(){
        hideProgressDialog();
        HashMap <String,String> hashMap = new HashMap<>();
        hashMap.put("onApiSuccessfull","0");
        AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext() , hashMap, externalProcessManager.getTitle() , externalProcessManager.getValue());
    }

    private void sendBadRequestMessageToAna(String key){
        HashMap <String,String> hashMap = new HashMap<>();
        hashMap.put("key","0");
        AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext() , hashMap, externalProcessManager.getTitle() , externalProcessManager.getValue());
    }

    private void invokeImageChooser(String action) {
       ExternalProcessManager.getInstance().setActions(action).startExternalActivity();
    }


    private void getFpTagsForMeetingAnalysis() {
        showProgressDialog();
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.NOW_FLOATS_API2_URL).build();
        CFInterface cfInterface = restAdapter.create(CFInterface.class);
        GetFpTagsForMeetingsRequest getFpTagsForMeetingsRequest = new GetFpTagsForMeetingsRequest();
        getFpTagsForMeetingsRequest.setBranchIds(null);
        getFpTagsForMeetingsRequest.setCustomerCities(null);
        getFpTagsForMeetingsRequest.setSalesPersonIds(null);
        getFpTagsForMeetingsRequest.setFptags(null);
        DisplayLog(manager.getCFUsername());
        if (manager.getCFUsername() != null) {
            List<String> userName = new ArrayList<>();
            userName.add(manager.getCFUsername());
            getFpTagsForMeetingsRequest.setUsernames(userName);
        }
        cfInterface.getFpTagsForMeetingAnalysis(getFpTagsForMeetingsRequest, new Callback<Response>() {
            @Override
            public void success(Response response, Response response2) {
                if (response2.getStatus() == 200) {
                    JSONObject tempObject = meetingAnalysisUtils.getJsonFromTypedInput(response.getBody());
                    try {
                        JSONArray fpTags = tempObject.getJSONObject("Result").getJSONArray("FpTags");
                        getLatestMeetings(fpTags);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        hideProgressDialog();
                        meetingAnalysisUtils.DisplayToast(getString(R.string.cf_get_fp_tags_failed));
                    }
                } else {
                    DisplayLog("error" + response2.getReason());
                    hideProgressDialog();
                    meetingAnalysisUtils.DisplayToast(getString(R.string.cf_get_fp_tags_failed));
                }
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayLog(error.getMessage());
                hideProgressDialog();
                meetingAnalysisUtils.DisplayToast(getString(R.string.cf_get_fp_tags_failed));
            }
        });
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        LocationHelper.updatePermissionState(requestCode , permissions , grantResults);
    }

    private void getLatestMeetings(JSONArray fpTagsJsonArray) throws JSONException {
        List<String> fpTags = new ArrayList<>();
        for (int i = 0; i < fpTagsJsonArray.length(); i++) {
            fpTags.add(fpTagsJsonArray.getString(i));
        }
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).build();
        Map<String, String> query = new HashMap();
        query.put("authClientId", Constants.FOSClientId);
        CFInterface cfInterface = restAdapter.create(CFInterface.class);
        cfInterface.getLatestMeetings(fpTags, new Callback<List<GetLatestMeetingsResponse>>() {
            @Override
            public void success(List<GetLatestMeetingsResponse> getLatestMeetingsResponses, Response response) {
                if (response.getStatus() == 200) {
                    hideProgressDialog();
                    List<GetLatestMeetingsResponse> moreThan45Days = new ArrayList<>();
                    List<GetLatestMeetingsResponse> between30And45Days = new ArrayList<>();
                    DateTime endTime = DateTime.now(DateTimeZone.UTC);
                    for (GetLatestMeetingsResponse meetingsResponse : getLatestMeetingsResponses) {
                        if ((meetingsResponse.getCreatedOn() != null)) {
                            DisplayLog(meetingsResponse.getFPTag());
                            DateTime startTime = DateTime.parse(meetingsResponse.getCreatedOn());
                            long days = meetingAnalysisUtils.printDifference(startTime, endTime);
                            meetingsResponse.setLastMetDifference(days);
                            DisplayLog("difference is " + days);
                            /*Only there for testing purposes*/
                            int lowerLimit = 0;
                            int upperLimit = 7;
                            String latestMettingDate = meetingsResponse.getCreatedOn();
                            if (latestMettingDate != null) {
                                if (!latestMettingDate.contains("T")) {
                                    latestMettingDate = "";
                                } else {
                                    latestMettingDate = meetingAnalysisUtils.parseDate(latestMettingDate.split("T")[0]);
                                }
                            } else {
                                latestMettingDate = "";
                            }
                            meetingsResponse.setCreatedOn(latestMettingDate);

                            lowerLimit = 30;
                            upperLimit = 45;

                            if (days > upperLimit) {
                                moreThan45Days.add(meetingsResponse);
                            } else if (days >= lowerLimit && days <= upperLimit) {
                                between30And45Days.add(meetingsResponse);
                            }
                        }
                    }
                    try {
                        MeetingAnalysisFragment meetingAnalysisFragment = new MeetingAnalysisFragment(between30And45Days, moreThan45Days);
                        meetingAnalysisFragment.show(getSupportFragmentManager(), "getLatestMeetings");
                       // getSupportFragmentManager().beginTransaction().add(meetingAnalysisFragment,"");
                    } catch (Exception e) {
                        e.printStackTrace();
                        DisplayLog(e.toString());
                    }
                } else {
                    hideProgressDialog();
                    DisplayLog("failed");
                    meetingAnalysisUtils.DisplayToast(getString(R.string.cf_get_fp_tags_failed));
                }
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayLog("faled2 " + error.getMessage());
                meetingAnalysisUtils.DisplayToast(getString(R.string.cf_get_fp_tags_failed));
                hideProgressDialog();
            }
        });
    }

    private void getQuotationNumbers(Context context, String title, String value) {
        GetQuotationNumberRequest getQuotationNumberRequest = new GetQuotationNumberRequest();
        try {
            getQuotationNumberRequest.setClientId(Constants.ERPClientId);
            getQuotationNumberRequest.setEmail(manager.getSalesId());
            DisplayLog(new JSONObject(new Gson().toJson(getQuotationNumberRequest)).toString());
            JsonObjectRequest quotationRequest = new JsonObjectRequest(Request.Method.POST, Constants.GET_QUOTATION_NUMBER_URL,
                    new JSONObject(new Gson().toJson(getQuotationNumberRequest)),
                    new com.android.volley.Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            List<String> quotationNumbers = new ArrayList<>();
                            Iterator quotationNumberKeys = response.keys();
                            while (quotationNumberKeys.hasNext()) {
                                quotationNumbers.add(quotationNumberKeys.next().toString());
                            }
                            showListDialog(quotationNumbers, context, title, value, getString(R.string.choose_quotation), "ChooseQuotation", Constants.SHOW_QUOTATION_NUMBER, null);
                        }
                    }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    DisplayToast(getString(R.string.quotation_number_error));
                    DisplayToast(error.toString());
                    try {
                        DisplayLog(new JSONObject(new Gson().toJson(getQuotationNumberRequest)).toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }) {
                @Override
                public Map getHeaders() {
                    Map<String, String> map = new HashMap<>();
                    return map;
                }

                @Override
                public String getBodyContentType() {
                    return "application/json";
                }
            };
            Volley.newRequestQueue(this).add(quotationRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private boolean verifyGSTNumber(String gst, String title, String value, Context context) {
        boolean gstValidity = true;
        if (gst.length() == 15) {
            String state_code = gst.substring(0, 2);
            try {
                Integer.parseInt(state_code);
            } catch (Exception e) {
                gstValidity = false;
                return gstValidity;
            }
            String Pan1 = gst.substring(2, 7);
            for (int i = 0; i < Pan1.length(); i++) {
                if (Character.isDigit(Pan1.charAt(i))) {
                    gstValidity = false;
                    return gstValidity;
                }
            }
            String Pan2 = gst.substring(7, 11);
            try {
                Integer.parseInt(Pan2);
            } catch (Exception e) {
                gstValidity = false;
                DisplayLog("here3");
                return gstValidity;
            }
            if (!(Character.isAlphabetic(gst.charAt(11)) && Character.isAlphabetic(gst.charAt(13)))) {
                gstValidity = false;
                DisplayLog("here4");
                return gstValidity;
            }
            if (!Character.isDigit(gst.charAt(12))) {
                DisplayLog("here5");
                gstValidity = false;
                return gstValidity;
            }
            if ((Character.isDigit(gst.charAt(14)) || Character.isAlphabetic(gst.charAt(14)))) {
            } else {
                gstValidity = false;
            }
        } else {
            gstValidity = false;
        }
        return gstValidity;
    }

    private void getFPTagsForQuotation(String deeplinkUrl, Context context, String title, String value) {
        GetFPIdRequest getFPIdRequest = new GetFPIdRequest();
        getFPIdRequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        getFPIdRequest.setMethod(Constants.ERP_METHOD);
        GetFPIdRequest.Params params = new GetFPIdRequest.Params();
        params.setService(Constants.ERP_PARAM_SERVICE);
        params.setMethod(Constants.ERP_PARAM_METHOD);
        List<Object> args = new ArrayList<>();
        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);
        args.add("getFptags");
        GetFPIdRequest.Params.HotProspectId getHotProspectId = new GetFPIdRequest.Params.HotProspectId();
        String[] temp_keys = deeplinkUrl.split("#");
        getHotProspectId.setHotProspectId(Integer.parseInt(temp_keys[temp_keys.length - 1]));
        args.add(getHotProspectId);
        params.setArgs(args);
        getFPIdRequest.setParams(params);
        DisplayLog(new Gson().toJson(getFPIdRequest));
        try {
            JSONObject requestModel = new JSONObject(new Gson().toJson(getFPIdRequest));
            DisplayLog(requestModel.toString());
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, Constants.ERP_EP_API_URL + "/jsonrpc", requestModel, new com.android.volley.Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    DisplayLog(response.toString());
                    HashMap<String, Integer> hashMap = new HashMap<>();
                    try {
                        JSONArray temp = response.getJSONArray("result");
                        for (int i = 0; i < temp.length(); i++) {
                            JSONObject object = temp.getJSONObject(i);
                            Iterator keys = object.keys();
                            while (keys.hasNext()) {
                                String key = String.valueOf(keys.next());
                                hashMap.put(key.toLowerCase(), object.getInt(key));
                            }
                        }
                        HashMap<String, String> userData = new HashMap<>();
                        int startIndex = 1;
                        boolean gstIsVerified = true;
                        boolean gstIsTrue = false;
                        if (!temp_keys[0].equals("verifyFpTag")) {
                            startIndex = 2;
                            gstIsTrue = true;
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                                gstIsVerified = verifyGSTNumber(temp_keys[0], title, value, context);
                            }
                        } else {
                            // if there is no gst data
                            gstIsTrue = false;
                        }
                        userData.put("gstverified", gstIsVerified + "");
                        for (int j = startIndex; j < temp_keys.length - 1; j++) {
                            int index = j;
                            if (gstIsTrue) {
                                index--;
                            }
                            String fptag = temp_keys[j];
                            if (hashMap.containsKey(fptag.toLowerCase())) {
                                DisplayLog("g0t it " + fptag);
                                userData.put("productfptag" + index, hashMap.get(fptag.toLowerCase()) + "");
                            } else {
                                userData.put("productfptag" + index, "");
                                DisplayLog("not:  " + fptag);
                            }
                        }
                        AnaCore.sendDeeplinkEventData(context, userData, title, value);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    DisplayToast(getString(R.string.error_internet));
                }
            }) {
                @Override
                public Map getHeaders() {
                    Map<String, String> map = new HashMap<>();
                    map.put("Content-Type", "application/json");
                    return map;
                }
            };
            Volley.newRequestQueue(this).add(jsonObjectRequest);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void getProductsList(HashMap<String, String> userData, String title, String value, Context context) {
        GetProductsRequest getProductsRequest = new GetProductsRequest();
        getProductsRequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        getProductsRequest.setMethod(Constants.ERP_METHOD);
        GetProductsRequest.Params params = new GetProductsRequest.Params();
        List<Object> args = new ArrayList<>();
        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);
        args.add("getTemplateProduct");
        GetProductsRequest.Params.SetTemplateProduct templateProduct = new GetProductsRequest.Params.SetTemplateProduct();
        try {
            templateProduct.setTemplate_id(Integer.parseInt(userData.get("templateid")));
        } catch (Exception e) {
            DisplayLog("Sorry some problem occured. for choosing " + userData.get("templatename"));
        }
        args.add(templateProduct);
        params.setService(Constants.ERP_PARAM_SERVICE);
        params.setMethod(Constants.ERP_PARAM_METHOD);
        params.setArgs(args);
        getProductsRequest.setParams(params);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        erpApiInterface.getProducts(getProductsRequest, new Callback<GetProductsResponse>() {
            @Override
            public void success(GetProductsResponse getProductsResponse, Response response) {
                List<GetProductsResponse.Result> results = getProductsResponse.getResult();
                userData.put("productlength", results.size() + "");
                for (int i = 0; i < results.size(); i++) {
                    userData.put("productminimumquantity" + (i + 1), results.get(i).getDefaultMinimumQty() + "");
                    userData.put("Udiscount" + (i + 1), 0 + "");
                    userData.put("productmaximumdiscount" + (i + 1), results.get(i).getMaxDefaultDiscount() + "");
                    userData.put("productprice" + (i + 1), results.get(i).getUnitPrice() + "");
                    userData.put("productname" + (i + 1), results.get(i).getProduct());
                    userData.put("productid" + (i + 1), results.get(i).getProductId() + "");
                }
                AnaCore.sendDeeplinkEventData(context, userData, title, value);
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayLog(getString(R.string.product_response_error));
            }
        });
    }

    private void getHotprospects(final Context context, String title, String value) {
        showProgressDialogByAna();

        String[] deepLinkValues = ExternalProcessManager.getInstance().getDeepLinkUrl().split("#");

        String salesPersonEmail = deepLinkValues.length == 2 ? deepLinkValues[1] : manager.getSalesId();

        final HotProspectRequest hotProspectRequest = new HotProspectRequest();
        hotProspectRequest.setMethod(Constants.ERP_METHOD);
        hotProspectRequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        HotProspectRequest.Params params = new HotProspectRequest.Params();
        params.setMethod(Constants.ERP_PARAM_METHOD);

        List<Object> args = new ArrayList<>();
        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);

        HotProspectRequest.SetEmailForLeads setEmailForLeads = new HotProspectRequest.SetEmailForLeads();
        args.add("getLeadDetails");
        setEmailForLeads.setEmailId(salesPersonEmail);
        args.add(setEmailForLeads);
        params.setArgs(args);
        params.setService("object");
        hotProspectRequest.setParams(params);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLog(new AndroidLog("ggg")).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        erpApiInterface.getHotprospect(hotProspectRequest, new Callback<HotProspectResponse>() {
            @Override
            public void success(HotProspectResponse hotProspectResponse, Response response) {
                hideProgressDialog();
                if (response == null || response.getStatus() != 200) {
                    DisplayToast(getString(R.string.error_in_response));
                    return;
                }
                List<HotProspectResponse.Result> results = hotProspectResponse.getResult();
                List<String> HotProspect = new ArrayList<>();
                HashMap<String, HotProspectResponse.Result> map = new HashMap<>();
                for (HotProspectResponse.Result result : results) {
                    if (result.getCQuotationCreated() == null) {
                        result.setCQuotationCreated(false);
                    }
                    if (result.getType().equalsIgnoreCase("opportunity") && !result.getCQuotationCreated()&&(result.getCompanyName()!=null)) {
                        String bussinessName = TextUtils.isEmpty(result.getCompanyName()) ? "NA" : result.getCompanyName();
                        String mobileNumber = TextUtils.isEmpty(result.getMobile()) ? "NA" : result.getMobile();
                        String key = result.getName() + "\n" +bussinessName+"\n"+mobileNumber;
                        HotProspect.add(key);
                        map.put(key, result);
                    }
                }
                showGetHotProspectsDialog(HotProspect, map, context, title, value);
            }

            @Override
            public void failure(RetrofitError error) {
                hideProgressDialog();
                DisplayToast(getString(R.string.hot_prospect_error));
            }
        });
    }

        private void getNewQuotations(final Context context, String title, String value , String salesId) {
            showProgressDialogByAna();
            final HotProspectRequest hotProspectRequest = new HotProspectRequest();
            hotProspectRequest.setMethod(Constants.ERP_METHOD);
            hotProspectRequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
            HotProspectRequest.Params params = new HotProspectRequest.Params();
            params.setMethod(Constants.ERP_PARAM_METHOD);

            List<Object> args = new ArrayList<>();
            args.add(Constants.ERP_ARG0);
            args.add(Constants.ERP_ARG1);
            args.add(Constants.ERP_ARG2);
            args.add(Constants.ERP_ARG3);

            HotProspectRequest.SetEmailForLeads setEmailForLeads = new HotProspectRequest.SetEmailForLeads();
            args.add("getLeadDetails");
            setEmailForLeads.setEmailId(salesId.toLowerCase());
            args.add(setEmailForLeads);
            params.setArgs(args);
            params.setService("object");
            hotProspectRequest.setParams(params);
            RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLog(new AndroidLog("ggg")).build();
            ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
            erpApiInterface.getHotprospect(hotProspectRequest, new Callback<HotProspectResponse>() {
                @Override
                public void success(HotProspectResponse hotProspectResponse, Response response) {
                    hideProgressDialog();
                    if (response == null || response.getStatus() != 200) {
                        DisplayToast(getString(R.string.error_in_response));
                        return;
                    }
                    List<HotProspectResponse.Result> results = hotProspectResponse.getResult();
                    List<String> quotationList = new ArrayList<>();
                    HashMap<String, HotProspectResponse.Result> quotationMap = new HashMap<>();
                    for (HotProspectResponse.Result result : results) {
                        if (result.getCQuotationCreated() == null) {
                            result.setCQuotationCreated(false);
                        }

                        if(result.getNewQuoteCreated() == null ){
                            result.setNewQuoteCreated(false);
                        }

                        if(result.getFptag() == null ){
                            result.setFptag(" NA ");
                        }

                        if (result.getName() != null && result.getType().equalsIgnoreCase("opportunity") && result.getNewQuoteCreated()&&(result.getCompanyName()!=null)) {
                            quotationList.add(result.getCompanyName()+" \\ "+result.getName());
                          if(! quotationMap.containsKey(result.getFptag())) {
                             quotationMap.put(result.getCompanyName()+" \\ "+result.getName(), result);
                          }
                        }
                    }
                    showGetHotProspectsDialog(quotationList, quotationMap, context, title, value);
                }

                @Override
                public void failure(RetrofitError error) {
                    hideProgressDialog();
                    DisplayToast(getString(R.string.hot_prospect_error));
                }
            });
        }

        private void getAssignedLeads(final Context context, String title, String value , String salesId) {
            showProgressDialogByAna();
            final HotProspectRequest hotProspectRequest = new HotProspectRequest();
            hotProspectRequest.setMethod(Constants.ERP_METHOD);
            hotProspectRequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
            HotProspectRequest.Params params = new HotProspectRequest.Params();
            params.setMethod(Constants.ERP_PARAM_METHOD);

            List<Object> args = new ArrayList<>();
            args.add(Constants.ERP_ARG0);
            args.add(Constants.ERP_ARG1);
            args.add(Constants.ERP_ARG2);
            args.add(Constants.ERP_ARG3);

            HotProspectRequest.SetEmailForLeads setEmailForLeads = new HotProspectRequest.SetEmailForLeads();
            args.add("getLeadDetails");
            setEmailForLeads.setEmailId(salesId.toLowerCase());
            args.add(setEmailForLeads);
            params.setArgs(args);
            params.setService("object");
            hotProspectRequest.setParams(params);
            RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLog(new AndroidLog("ggg")).build();
            ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
            erpApiInterface.getHotprospect(hotProspectRequest, new Callback<HotProspectResponse>() {
                @Override
                public void success(HotProspectResponse hotProspectResponse, Response response) {
                    hideProgressDialog();
                    if (response == null || response.getStatus() != 200) {
                        DisplayToast(getString(R.string.error_in_response));
                        return;
                    }
                    List<HotProspectResponse.Result> results = hotProspectResponse.getResult();
                    List<String> assignedLeadsList = new ArrayList<>();
                    HashMap<String, HotProspectResponse.Result> quotationMap = new HashMap<>();
                    for (HotProspectResponse.Result result : results) {
                        if (result.getCQuotationCreated() == null) {
                            result.setCQuotationCreated(false);
                        }

                        if(result.getNewQuoteCreated() == null ){
                            result.setNewQuoteCreated(false);
                        }

                        if(result.getFptag() == null ){
                            result.setFptag(" NA ");
                        }

                        if (result.getName() != null && !result.getType().equalsIgnoreCase("opportunity") ) {
                            assignedLeadsList.add(result.getFptag()+" \n"+result.getCompanyName()+" \n "+result.getName());
                            if(! quotationMap.containsKey(result.getFptag())) {
                                quotationMap.put(" \n"+result.getCompanyName()+"\n"+result.getCompanyEmail()+" \n "+result.getName() , result);
                            }
                        }
                    }
                    showGetHotProspectsDialog(assignedLeadsList, quotationMap, context, title, value);
                }

                @Override
                public void failure(RetrofitError error) {
                    hideProgressDialog();
                    DisplayToast(getString(R.string.hot_prospect_error));
                }
            });
        }

    private void showGetHotProspectsDialog(List<String> hotprospects, HashMap<String, HotProspectResponse.Result> map, Context context, String title, String value) {
        if (hotprospects.size() > 0) {
            showListDialog(hotprospects, context, title, value, getString(R.string.select_hot_prospect), "hotprospect", Constants.SHOW_HOT_PROSPECTS_ID, map);
        } else {

            HashMap<String, String> userdata = new HashMap<>();
            userdata.put("hpsuccess", "0");
            DisplayToast("Sorry. But you need to create a new hot prospect");

        }
    }

        private void showAllEmployees(List<String> employeeNames, HashMap<String, String> map, Context context, String title, String value) {
            if (employeeNames.size() > 0) {
                showListDialog(employeeNames, context, title, value, "Select the employee", "anotherSalesId", Constants.GET_EMPLOYEE_ID, map);
            } else {
                HashMap<String, String> userdata = new HashMap<>();
                userdata.put("hpsuccess", "0");
                DisplayToast("Sorry. But you need to create a new hot prospect");
                //   AnaCore.sendDeeplinkEventData(context, userdata, title, value);
            }
        }

    private void DisplayToast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private void getMeetingOutcome(final Context context, String deepLinkUrl) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        CFInterface cfInterface = restAdapter.create(CFInterface.class);
        final List<String> deepLinkValues = Arrays.asList(deepLinkUrl.split("#"));
        Map<String, String> map = new HashMap<>();
        map.put("authclientId", deepLinkValues.get(1));
        map.put("engagementDay", deepLinkValues.get(2));
        map.put("meetingId", deepLinkValues.get(3));
        map.put("fpTag", deepLinkValues.get(4));
        map.put("meetingType", "ENGAGEMENT");
        cfInterface.getMeetingOutcome(map, new Callback<GetMeetingChecklistDataResponse>() {
            @Override
            public void success(GetMeetingChecklistDataResponse dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error message
                    Toast.makeText(context, "Invalid data!", Toast.LENGTH_SHORT).show();
                } else {
                    quesRes = dataResponse.getCapturedValues();
                    getQuestionsForResponse(context, String.valueOf(dataResponse.getEngagementDay()), deepLinkValues.get(1));
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                //error message
                Toast.makeText(context, "Something went wrong, please try again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getQuestionsForResponse(final Context context, final String engDay, String clientId) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        CFInterface showQues = restAdapter.create(CFInterface.class);
        Map<String, String> map = new HashMap<String, String>();
        map.put("authclientId", clientId);
        map.put("meetingType", "ENGAGEMENT");
        map.put("engagementDay", engDay);
        showQues.loadQues(map, new Callback<QuesResponse>() {
            @Override
            public void success(QuesResponse dataResponse, Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error message
                    Toast.makeText(context, "Invalid data!", Toast.LENGTH_SHORT).show();
                } else {
                    itemQuesResponse = dataResponse.getItems();
                    for (int i = 0; i < itemQuesResponse.size(); i++) {
                        itemQuesResponse.get(i).setRes(quesRes.get(itemQuesResponse.get(i).getIdTag()));
                    }
                    if (context instanceof Activity) {
                        OutcomeViewFragment outcomeViewFragment = OutcomeViewFragment.newInstance(context, itemQuesResponse.get(0), itemQuesResponse, R.style.CustomDialogNextTheme, R.anim.slide_in_left_dialog, R.anim.slide_out_left_dialog, engDay);
                        outcomeViewFragment.show(((Activity) context).getFragmentManager(), "fragment_res_ques");
                        outcomeViewFragment.setCancelable(true);
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                //error message
                Toast.makeText(context, "Something went wrong, please try again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getQuestions(String deepLinkUrl, Context context) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        CFInterface showQues = restAdapter.create(CFInterface.class);
        final List<String> deepLinkValues = Arrays.asList(deepLinkUrl.split("#"));
        Map<String, String> map = new HashMap<String, String>();
        map.put("authclientId", deepLinkValues.get(1));
        map.put("meetingType", "ENGAGEMENT");
        map.put("engagementDay", deepLinkValues.get(5));
        showQues.loadQues(map, new Callback<QuesResponse>() {
            @Override
            public void success(QuesResponse dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error message
                    Toast.makeText(context, "Invalid data!", Toast.LENGTH_SHORT).show();
                } else {
                    itemQuestion = dataResponse.getItems();
                    CustomDialogQuestionsFragment customDialogQuestionsFragment = CustomDialogQuestionsFragment.newInstance(itemQuestion.get(0), itemQuestion, context, R.style.CustomDialogNextTheme, R.anim.slide_in_left_dialog, R.anim.slide_out_left_dialog, deepLinkValues);
                    customDialogQuestionsFragment.show(((Activity) context).getFragmentManager(), "fragment_ques");
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                //error message
                Toast.makeText(context, "Something went wrong, please try again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void postQuesResponse(List<String> deepLinkValues, Context context) {
        OkHttpClient client = new OkHttpClient();
        client.setConnectTimeout(2, TimeUnit.MINUTES);
        client.setReadTimeout(2, TimeUnit.MINUTES);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).setClient(new OkClient(client)).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        CFInterface customerFirstInterface = restAdapter.create(CFInterface.class);
        Map<String, String> map = new HashMap<String, String>();
        map.put("authClientId", deepLinkValues.get(1));
        map.put("meetingType", "ENGAGEMENT");
        map.put("fpTag", deepLinkValues.get(4).toUpperCase());
        map.put("meetingId", deepLinkValues.get(3));
        map.put("engagementDay", deepLinkValues.get(5));
        loadQuesResJson();
        String json = paramsOb.toString();
        try {
            TypedInput in = new TypedByteArray("application/json", json.getBytes("UTF-8"));
            customerFirstInterface.postQuestionsResponse(map, in, new Callback<String>() {
                @Override
                public void success(String dataResponse, retrofit.client.Response response) {
                    if (dataResponse == null || response.getStatus() != 200) {
                        //error
                        Toast.makeText(context, "Invalid Data! Please try again", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (response.getStatus() == 200) {
                        //onApiSuccessfull
                        if (deepLinkValues.get(5).equals("2000"))
                            setMeetingOutcome(deepLinkValues, 0, "false", context);
                        else
                            setMeetingOutcome(deepLinkValues, 1, "false", context);
                        sendFeedbackEmail(deepLinkValues, context);
                        paramsOb = new JSONObject();
                    } else {
                        Toast.makeText(context, "Invalid Data! Please try again", Toast.LENGTH_SHORT).show();
                        //not successful
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
                    //error
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    private void loadQuesResJson() {
        for (QuesResponse.Item b : itemQuestion) {
            try {
                paramsOb.put(b.getIdTag(), b.getRes());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void setMeetingOutcome(List<String> deepLinkValues, final int outcome, String skipCalendar, Context context) {
        OkHttpClient client = new OkHttpClient();
        client.setConnectTimeout(2, TimeUnit.MINUTES);
        client.setReadTimeout(2, TimeUnit.MINUTES);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).setClient(new OkClient(client)).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        CFInterface customerFirstInterface = restAdapter.create(CFInterface.class);
        Map<String, String> map = new HashMap<String, String>();
        map.put("authClientId", deepLinkValues.get(1));
        map.put("meetingCustomId", deepLinkValues.get(2));
        map.put("outcome", String.valueOf(outcome));
        map.put("skipCalender", skipCalendar);
        customerFirstInterface.setMeetingOutcome(map, new Callback<SetOutcomeResponse>() {
            @Override
            public void success(SetOutcomeResponse dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error
                    if (skipCalendar.equalsIgnoreCase("false"))
                        setMeetingOutcome(deepLinkValues, outcome, "true", context);
                    else
                        Toast.makeText(context, "Invalid Data! Please try again", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (response.getStatus() == 200) {
                    //onApiSuccessfull
                    if (dataResponse.getMessage() != null) {
                    }
                    Toast.makeText(GoogleLoginActivity.this, "Successfully updated!", Toast.LENGTH_SHORT).show();
                } else {
                    if (skipCalendar.equalsIgnoreCase("false"))
                        setMeetingOutcome(deepLinkValues, outcome, "true", context);
                    else
                        Toast.makeText(context, "Invalid Data! Please try again", Toast.LENGTH_SHORT).show();
                    //not successful
                }
            }

            @Override
            public void failure(RetrofitError error) {
                if (skipCalendar.equalsIgnoreCase("false"))
                    setMeetingOutcome(deepLinkValues, outcome, "true", context);
                else
                    Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
                //error
            }
        });
    }

    private void sendFeedbackEmail(List<String> deepLinkValues, Context context) {
        List<String> to = new ArrayList<String>();
        String feedbackUrl = Constants.SUPPORT_API_URL + "/Home/CustomerMeetingFeedbackForm?";
        String feedbackUrl1 = "meetingId=" + deepLinkValues.get(3) + "&fpTag=" + deepLinkValues.get(4).toUpperCase() + "&meetingType=1&engagementDay=3000";
        to.add(deepLinkValues.get(6));
        String body = "<html style=\"min-width:465x;margin:0 auto\"><link href=\"http://fonts.googleapis.com/css?family=Lato:100,300,400,700\"rel=stylesheet><style>table{border-spacing:0}td{padding:0}@media only screen and (max-device-width:480px){.grey-border{display:none}}</style><body style=\"height:100%;margin:0 auto;background:#c8c8c8\"><table cellpadding=0 cellspacing=0 width=100% style=margin-left:auto;margin-right:auto;width:700px height=100%><tr><td width=7% style=\"box-shadow:inset -8px 0 8px -8px #000;width:4%;background-color:#c8c8c8\"bgcolor=#757575 class=grey-border><td width=86% valign=top><table cellpadding=0 cellspacing=0 width=100% style=background:#fff><tr><td><img src=http://nowfloats.com/MailerImages/Banner.png style=width:100%;max-height:200px;border:0></table><table cellpadding=0 cellspacing=0 width=100% style=background:#fff align=center><tr height=50><td><tr><td width=8% height=10><td width=84% style=\"border:solid 1px #ffb900;border-radius:12px\"valign=top><table cellpadding=0 cellspacing=0 width=100%><tr><td><tr><td><tr><td align=center><div style=text-align:left;font-family:Lato,sans-serif;font-size:1.2em;padding-top:20px;width:80%;line-height:22px;letter-spacing:.5px;color:#3c3c3c><br>Hello,<br/>Greetings from NowFloats. We hope that your last meeting with our Customer First Consultant went well. <br/><br> We request your valuable time to provide feedback. <br><br><a href=\"" + feedbackUrl + feedbackUrl1 + "\" style=text-decoration:none!important;color:#000;text-decoration:underline!important;font-size: 26px;color: white; target=_blank>Give Feedback</a><br><br></div><tr><td align=center><tr><td><table cellpadding=0 cellspacing=0 width=100% align=center height=0><tr><td width=300vw height=100%><div style=\"height:1px;border-top:solid 1px #ffb900\"></div><td width=300vw height=100%><div style=\"height:1px;border-top:solid 1px #ffb900\"></div></table><tr><td align=center><div style=text-align:left;font-family:Lato,sans-serif;font-size:1.2em;padding-top:20px;width:80%;line-height:22px;letter-spacing:.5px;color:#3c3c3c><br><br>Keep Floating,<br>Team NowFloats</div><tr height=50 width=100%><td></table><td width=8% height=10></table><div style=width:100%;height:40px;background-color:#fff></div><table cellpadding=0 cellspacing=0 width=100% style=\"box-shadow:6px 0 7px 2px #8c8c8c\"align=center bgcolor=#757575 height=80><tr height=80 width=100%><td width=10% height=80><td width=10% height=80></table><td width=7% style=\"box-shadow:inset 8px 0 8px -8px #000;width:4%;background-color:#c8c8c8\"bgcolor=#757575 class=grey-border></table>";
        sendEmail(deepLinkValues, body, to, "hello@nowfloats.com", "Customer Meeting Feedback From NowFloats", context);
    }

    private void sendEmail(List<String> deepLinkValues, String body, List<String> to, String from, String subject, Context context) {
        //migrated
        GsonConverter converter = new GsonConverter(new GsonBuilder().disableHtmlEscaping().create());
        OkHttpClient client = new OkHttpClient();
        client.setConnectTimeout(2, TimeUnit.MINUTES);
        client.setReadTimeout(2, TimeUnit.MINUTES);
        RestAdapter restAdapter = new RestAdapter.Builder().setClient(new OkClient(client)).setConverter(converter).setEndpoint(Constants.NOW_FLOATS_API2_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        CFInterface customerFirstInterface = restAdapter.create(CFInterface.class);
        MailRequest request = new MailRequest();
        MailRequest.CustomSMTPConfig customSMTPConfig = new MailRequest.CustomSMTPConfig();
        customSMTPConfig.setServerHost("email-smtp.us-east-1.amazonaws.com");
        customSMTPConfig.setServerPort("587");
        customSMTPConfig.setTimeOut(10000);
        customSMTPConfig.setEnableSsl(true);
        customSMTPConfig.setSMTPUserName("AKIAJIZK7A2HCGKQ7FRQ");
        customSMTPConfig.setSMTPUserPassword("Ai+hbCZCBT8kl76sMdQ7AkQXzgxxOXDL1Uw860WVHbFn");
        request.setCustomSMTPConfig(customSMTPConfig);
        request.setClientId(deepLinkValues.get(1));
        request.setEmailBody(body);
        request.setFrom(from);
        request.setSubject(subject);
        request.setTo(to);
        request.setType(0);
        customerFirstInterface.sendEmail(deepLinkValues.get(1), request, new Callback<String>() {
            @Override
            public void success(String dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error
                    Toast.makeText(context, "Email not sent!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (response.getStatus() == 200) {
                    //onApiSuccessfull
                } else {
                    Toast.makeText(context, "Email not sent!", Toast.LENGTH_SHORT).show();
                    //not successful
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Toast.makeText(context, "Email not sent!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showProgressDialogByAna(){
        mProgressDialog = new ProgressDialog(externalProcessManager.getAnaChatContext());
        mProgressDialog.setCancelable(false);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage(getString(R.string.please_wait));
        mProgressDialog.show();
    }

    private void getLeadDetails(Context context, String title, String value) {

        String[] deeplinkValues = ExternalProcessManager.getInstance().getDeepLinkUrl().split("#");

        String email = "";

        if(deeplinkValues.length > 1 ){
            email = deeplinkValues[1]; // this is to get the email directly from the flow, so that we can take advantage of the admin mode
        }else{
            email = manager.getSalesId();
        }

        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage(getString(R.string.please_wait));
        mProgressDialog.show();
        dialogExists = true;
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        GetLeadDetailsRequest request = new GetLeadDetailsRequest();
        request.setMethod("call");
        request.setJsonrpc("2.0");
        GetLeadDetailsRequest.Params params = new GetLeadDetailsRequest.Params();
        params.setMethod("execute");
        params.setService("object");
        List<Object> args = new ArrayList<>();
        args.add("NowFloatsV10");
        args.add(7976);
        args.add("ERPapi123");
        args.add("nf.api");
        args.add("getLeadDetails");
        GetLeadDetailsRequest.SetEmailForLeads setEmailForLeads = new GetLeadDetailsRequest.SetEmailForLeads();
        setEmailForLeads.setEmailId(email);
        args.add(setEmailForLeads);
        params.setArgs(args);
        request.setParams(params);
        List<String> leadList = new ArrayList<String>();
        erpApiInterface.getLeadDetails(request, new Callback<GetLeadDetailsResponse>() {
            @Override
            public void success(GetLeadDetailsResponse dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error
                    Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (response.getStatus() == 200) {
                    //onApiSuccessfull
                    if (dataResponse.getResult() != null) {
                        for (GetLeadDetailsResponse.Result item : dataResponse.getResult()) {
                            leadList.add(item.getName());
                        }
                        mProgressDialog.dismiss();
                        if (leadList.size() > 0)
                            showListLeadsDialog(leadList, context, title, value, dataResponse.getResult());
                        else {
                            Toast.makeText(context, "You don't have any customers!", Toast.LENGTH_SHORT).show();
                            dialogExists = false;
                        }
                    }
                } else {
                    Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
                    //not successful
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
                //error
            }
        });
    }

        private void getAssignedLeads(Context context, String title, String value) {
            showProgressDialogByAna();
            String salesId = externalProcessManager.getDeepLinkUrl().split("#")[1];
            RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
            ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
            GetLeadDetailsRequest request = new GetLeadDetailsRequest();
            request.setMethod("call");
            request.setJsonrpc("2.0");
            GetLeadDetailsRequest.Params params = new GetLeadDetailsRequest.Params();
            params.setMethod("execute");
            params.setService("object");
            List<Object> args = new ArrayList<>();
            args.add("NowFloatsV10");
            args.add(7976);
            args.add("ERPapi123");
            args.add("nf.api");
            args.add("getLeadDetails");
            GetLeadDetailsRequest.SetEmailForLeads setEmailForLeads = new GetLeadDetailsRequest.SetEmailForLeads();
            setEmailForLeads.setEmailId(salesId);
            args.add(setEmailForLeads);
            params.setArgs(args);
            request.setParams(params);
            List<String> leadList = new ArrayList<String>();
            erpApiInterface.getLeadDetails(request, new Callback<GetLeadDetailsResponse>() {
                @Override
                public void success(GetLeadDetailsResponse dataResponse, retrofit.client.Response response) {
                    List<GetLeadDetailsResponse.Result> newResults = new ArrayList<>();
                    hideProgressDialog();
                    if (dataResponse == null || response.getStatus() != 200) {
                        //error
                        Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (response.getStatus() == 200) {
                        //onApiSuccessfull
                        if (dataResponse.getResult() != null) {

                            for (GetLeadDetailsResponse.Result item : dataResponse.getResult()) {
                                item.setCompanyName(TextUtils.isEmpty(item.getCompanyName())?" NA " : item.getCompanyName());
                               if(item.getLc_email() != null ){
                                   if(! item.getLc_email().equalsIgnoreCase(salesId)) {
                                       leadList.add(item.getName() + "/" + item.getCompanyName());
                                       newResults.add(item);
                                   }
                               }
                            }
                            mProgressDialog.dismiss();
                            if (leadList.size() > 0)
                                showListLeadsDialog(leadList, context, title, value, newResults);
                            else {
                                Toast.makeText(context, "You don't have any customers!", Toast.LENGTH_SHORT).show();
                                dialogExists = false;
                            }
                        }
                    } else {
                        Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
                        //not successful
                    }
                }

                @Override
                public void failure(RetrofitError error) {
                    hideProgressDialog();
                    Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
                    //error
                }
            });
        }

    @Override
    public void questionDialogAction(int index, int actionStatus, List<String> deepLinkValues, Context context) {
        if (actionStatus == 2) {
            postQuesResponse(deepLinkValues, context);
        } else if (actionStatus == 1) {
            if (context instanceof Activity) {
                CustomDialogQuestionsFragment customDialogQuestionsFragment = CustomDialogQuestionsFragment.newInstance(itemQuestion.get(index), itemQuestion, context, R.style.CustomDialogNextTheme, R.anim.slide_in_left_dialog, R.anim.slide_out_left_dialog, deepLinkValues);
                customDialogQuestionsFragment.show(((Activity) context).getFragmentManager(), "fragment_ques");
            }
        } else {
            if (context instanceof Activity) {
                CustomDialogQuestionsFragment customDialogQuestionsFragment = CustomDialogQuestionsFragment.newInstance(itemQuestion.get(index), itemQuestion, context, R.style.CustomDialogPrevTheme, R.anim.slide_in_right_dialog, R.anim.slide_out_right_dialog, deepLinkValues);
                customDialogQuestionsFragment.show(((Activity) context).getFragmentManager(), "fragment_ques");
            }
        }
    }

    @Override
    public void questionResDialogAction(int index, int actionStatus, String engDay, Context context) {
        if (actionStatus == 1) {
            if (context instanceof Activity) {
                OutcomeViewFragment outcomeViewFragment = OutcomeViewFragment.newInstance(context, itemQuesResponse.get(index), itemQuesResponse, R.style.CustomDialogNextTheme, R.anim.slide_in_left_dialog, R.anim.slide_out_left_dialog, engDay);
                outcomeViewFragment.show(((Activity) context).getFragmentManager(), "fragment_res_ques");
            }
        } else {
            if (context instanceof Activity) {
                OutcomeViewFragment outcomeViewFragment = OutcomeViewFragment.newInstance(context, itemQuesResponse.get(index), itemQuesResponse, R.style.CustomDialogPrevTheme, R.anim.slide_in_right_dialog, R.anim.slide_out_right_dialog, engDay);
                outcomeViewFragment.show(((Activity) context).getFragmentManager(), "fragment_res_ques");
            }
        }
    }

    private void checkLocationSettings() {
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean network_enabled = false;
        AlertDialog.Builder dialog = new AlertDialog.Builder(mChatContext);
        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
        }
        try {
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception ex) {
        }
        if (!gps_enabled && !network_enabled) {
            // notify user
            dialog.setCancelable(false);
            dialog.setMessage(this.getResources().getString(R.string.gps_network_not_enabled));
            dialog.setPositiveButton(this.getResources().getString(R.string.open_location_settings), (paramDialogInterface, paramInt) -> {
                // TODO Auto-generated method stub
                Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(myIntent);
                //get gps
            });
            dialog.show();
        }
    }

    private void getLocation() {
        try {
            if (ActivityCompat.checkSelfPermission(mChatContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(mChatContext, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            if (locationManager != null) {
                List<String> providers = locationManager.getProviders(true);
                Location bestLocation = null;
                for (String provider : providers) {
                    locationManager.requestLocationUpdates(provider, 1000, 0, new LocationListener() {
                        @Override
                        public void onLocationChanged(Location location) {
                        }

                        @Override
                        public void onStatusChanged(String s, int i, Bundle bundle) {
                        }

                        @Override
                        public void onProviderEnabled(String s) {
                        }

                        @Override
                        public void onProviderDisabled(String s) {
                        }
                    });
                    Location l = locationManager.getLastKnownLocation(provider);
                    if (l == null) {
                        continue;
                    }
                    if (bestLocation == null
                            || l.getAccuracy() < bestLocation.getAccuracy()) {
                        bestLocation = l;
                    }
                }
                Location location = locationManager
                        .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (bestLocation != null) {
                    //use location
                    Toast.makeText(mChatContext, "lat:" + location.getLatitude() + " lng:" + location.getLongitude(), Toast.LENGTH_SHORT).show();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void askLocationPermission() {
        new TedPermission(mChatContext)
                .setPermissionListener(mPermissionListener)
                .setDeniedMessage("If you reject permission, you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                .check();
    }

    private void getFpTagsForCF(Context context, String title, String value, int action) {
        //migrated
        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage(getString(R.string.please_wait));
        mProgressDialog.show();
        dialogExists = true;
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.NOW_FLOATS_API2_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        HashMap<String, String> request = new HashMap<>();
        request.put("clientId", Constants.FOSClientId);
        request.put("offset", "0");
        request.put("FpStatus", "0");
        request.put("isCHCAssigned", "true");

        GetAssignedCHCForPartnerRequest model = new GetAssignedCHCForPartnerRequest();
        model.setFptags(null);
        model.setBranchIds(null);
        model.setCustomerCities(null);
        model.setSalesPersonIds(null);
        List<String> usernames = new ArrayList<String>();
        usernames.add(manager.getCFUsername());
        model.setUsernames(usernames);
        signupInterface.getAssignedCHC(request, model, new Callback<GetAssignedCHCForPartnerResponse>() {
            @Override
            public void success(GetAssignedCHCForPartnerResponse dataResponse, retrofit.client.Response response) {
                if (dataResponse == null || response.getStatus() != 200) {
                    //error message
                    DisplayLog("ggg : error occured");
                } else {
                    DisplayLog(new Gson().toJson(dataResponse));
                    mProgressDialog.dismiss();
                    if (action == Constants.SHOW_FP_TAGS_FOR_CF) {
                        showListDialog(dataResponse.getResult().getFpTags(), context, title, value, "Select customer tag", "fpTag", Constants.SHOW_FP_TAGS_FOR_CF, null);
                    } else {
                    }
                }
            }

            @Override
            public void failure(RetrofitError error) {
            //    Log.d("", "" + error.getMessage());
                //error message
                DisplayLog("ggg : "+error.getMessage());
            }
        });
    }

    private void getUpgradePackages(Context context, String title, String value, String deepLinkUrl) {
        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage(getString(R.string.please_wait));
        mProgressDialog.show();
        dialogExists = true;
        final List<String> deepLinkValues = Arrays.asList(deepLinkUrl.split("#"));
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, replaceSpace("http://sales-assist-api.withfloats.com/api/SalesProcess/GetUpgradePackages?fpTag=" + deepLinkValues.get(1)), null,
                new com.android.volley.Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Iterator<?> keys = response.keys();
                        List<String> mAutoComplRes = new ArrayList<>();
                        while (keys.hasNext()) {
                            String key = (String) keys.next();
                            mAutoComplRes.add(key);
                        }
                        mProgressDialog.dismiss();
                        if (mAutoComplRes.size() > 0)
                            showUpgradePackagesListDialog(mAutoComplRes, context, title, value, response);
                        else {
                            dialogExists = false;
                            Toast.makeText(context, "There are no upgrade Packages for this customer.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(40000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        mRequestQueue.add(request);
    }

    private void getVerticalPackages(Context context, String title, String value, String deepLinkUrl) {

        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage(getString(R.string.please_wait));
        mProgressDialog.show();
        dialogExists = true;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "http://sales-assist-api.withfloats.com/api/Packages/GetAllVerticalsByCategories?fpTag="+externalProcessManager.getDeepLinkUrl().split("#")[1], null,
                new com.android.volley.Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        hideProgressDialog();
                        dialogExists = false;
                       try {

                           JSONArray categoriesArray = response.getJSONArray("categories");

                           if(categoriesArray.length() == 0) {
                               externalProcessManager.showToast("No products to display");
                           }

                           HashMap<String, List<String>> data = new HashMap<>();

                           for(int cateogryIndex = 0; cateogryIndex < categoriesArray.length() ; cateogryIndex ++ ){
                               String categoryName = categoriesArray.getString(cateogryIndex);
                               JSONArray tempCategoryProducts = response.getJSONObject("packages").getJSONArray(categoryName);
                               List<String> categoryProducts = new Gson().fromJson(tempCategoryProducts.toString() , ArrayList.class);
                               data.put(categoryName , categoryProducts);
                           }

                             selectPackageFragment = SelectPackageFragment.newInstance(data );
                             selectPackageFragment.show(externalProcessManager.getANAActivity().getSupportFragmentManager() , "selectPackage");

                        } catch (JSONException e) {
                            e.printStackTrace();
                            dialogExists = false;
                            sendBadRequestMessageToAna();
                        }
                    }

                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialogExists = false;
                mProgressDialog.dismiss();
                Toast.makeText(context, "There are no upgrade Packages for this customer.", Toast.LENGTH_SHORT).show();
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(40000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        mRequestQueue.add(request);
    }

        private void getAllPackages(Context context, String title, String value, String deepLinkUrl) {

            mProgressDialog = new ProgressDialog(context);
            mProgressDialog.setCancelable(false);
            mProgressDialog.setIndeterminate(true);
            mProgressDialog.setMessage(getString(R.string.please_wait));
            mProgressDialog.show();
            dialogExists = true;

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, "http://sales-assist-api.withfloats.com/api/Packages/GetAllPackagesByCategory?fpTag="+externalProcessManager.getDeepLinkUrl().split("#")[1], null,
                    new com.android.volley.Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            hideProgressDialog();
                            dialogExists = false;
                            try {

                                JSONArray categoriesArray = response.getJSONArray("categories");

                                if(categoriesArray.length() == 0) {
                                    externalProcessManager.showToast("No products to display");
                                }

                                HashMap<String, List<String>> data = new HashMap<>();

                                for(int cateogryIndex = 0; cateogryIndex < categoriesArray.length() ; cateogryIndex ++ ){
                                    String categoryName = categoriesArray.getString(cateogryIndex);
                                    JSONArray tempCategoryProducts = response.getJSONObject("packages").getJSONArray(categoryName);
                                    List<String> categoryProducts = new Gson().fromJson(tempCategoryProducts.toString() , ArrayList.class);
                                    data.put(categoryName , categoryProducts);
                                }

                                selectPackageFragment = SelectPackageFragment.newInstance(data );
                                selectPackageFragment.show(externalProcessManager.getANAActivity().getSupportFragmentManager() , "selectPackage");

                            } catch (JSONException e) {
                                e.printStackTrace();
                                dialogExists = false;
                                sendBadRequestMessageToAna();
                            }
                        }

                    }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialogExists = false;
                    mProgressDialog.dismiss();
                    Toast.makeText(context, "There are no upgrade Packages for this customer.", Toast.LENGTH_SHORT).show();
                }
            });
            request.setRetryPolicy(new DefaultRetryPolicy(40000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            mRequestQueue.add(request);
        }

    private List<PackageModel> convertPackages(JSONArray packages) {
        List<PackageModel> packageModels = new ArrayList<>();
        for(int index = 0; index < packages.length() ; index++) {
            try {
                PackageModel packageModel = new PackageModel(packages.getString(index));
                packageModels.add(packageModel);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return packageModels;
    }

    private void getHorizontalPackages(Context context, String title, String value, String deepLinkUrl) {

        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage(getString(R.string.please_wait));
        mProgressDialog.show();
        dialogExists = true;
        final List<String> deepLinkValues = Arrays.asList(deepLinkUrl.split("#"));
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, replaceSpace("http://sales-assist-api.withfloats.com/api/Payments/GetAllProductsByFp?fpTag=" + deepLinkValues.get(1)
                +"&allCategories=no&count=false"), null,
                new com.android.volley.Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Iterator<?> keys = response.keys();
                        List<String> mAutoComplRes = new ArrayList<>();
                        while (keys.hasNext()) {
                            String key = (String) keys.next();
                            mAutoComplRes.add(key);
                        }
                        mProgressDialog.dismiss();
                        if (mAutoComplRes.size() > 0)
                            showUpgradePackagesListDialog(mAutoComplRes, context, "Current available base packs", value, response);
                        else {
                            mProgressDialog.dismiss();
                            dialogExists = false;
                            Toast.makeText(context, "There are no base Packages for this customer.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                dialogExists = false;
                Toast.makeText(context, "There are no base Packages for this customer.", Toast.LENGTH_SHORT).show();
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(40000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        mRequestQueue.add(request);
    }

    private void viewCategories(Context context, String title, String value, String deepLinkUrl) {

        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage(getString(R.string.please_wait));
        mProgressDialog.show();
        dialogExists = true;
        final List<String> deepLinkValues = Arrays.asList(deepLinkUrl.split("#"));
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, replaceSpace(Constants.GET_CATEGORIES_URL2), null,
                new com.android.volley.Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        dialogExists = false;
//                        Iterator<?> keys = response.keys();
//                        List<String> mAutoComplRes = new ArrayList<>();
//                        while (keys.hasNext()) {
//                            String key = (String) keys.next();
//                            mAutoComplRes.add(key);
//                        }
                        List<String> mAutoComplRes = new ArrayList<>();
                        for(int index = 0 ; index < response.length(); index++){
                            try {
                                mAutoComplRes.add(response.getString(index));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        mProgressDialog.dismiss();
                        if (mAutoComplRes.size() > 0)
                            showCustomList( deepLinkUrl, context, title, value, mAutoComplRes , "category");
                        else {
                            mProgressDialog.dismiss();
                            dialogExists = false;
                            Toast.makeText(context, "There are no categories for this customer.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                mProgressDialog.dismiss();
                dialogExists = false;
                Toast.makeText(context, "There are no categories for this customer.", Toast.LENGTH_SHORT).show();
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(40000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        mRequestQueue.add(request);
    }

    private void getLeadAddress(Context context, String title, String value) {
        pickAddressFragment = PickAddressFragment.newInstance(PickAddressFragment.PICK_TYPE.MANUAL, mDataMap);
        pickAddressFragment.setResultListener((address, area, city, state, country, lat, lon, pin, housePlotNum, landmark) -> {
            //TODO: saveREsult

            if(! country.equalsIgnoreCase("india")) {
                externalProcessManager.showToast("You need to select an Indian address");
                pickAddressFragment.dismiss();
                return ;
            }

            String landmarkMap = TextUtils.isEmpty(landmark) ? "" : ", " + landmark;
            String locality = TextUtils.isEmpty(area) ? "" : ", " + area;
            HashMap<String, String> userData = new HashMap<>();
            userData.put("CITY", city);
            userData.put("COUNTRY", country);
            userData.put("PICK_HOUSEPLOTNO", housePlotNum);
            userData.put("PICK_AREA", area);
            userData.put("PICK_ADDRESS", address);
            userData.put("PICK_LANDMARK", landmark);
            userData.put("STREET_ADDRESS",
                    housePlotNum + locality + ", " + address + landmarkMap);
            userData.put("PINCODE", pin);
            userData.put("zip",pin);
            userData.put("address" , address +" , "+landmark);
            userData.put("LAT", lat + "");
            userData.put("LNG", lon + "");
            userData.put("ADDRESSMAP_IMAGE", getMapUrlFromLocation(lat + "", lon + ""));
            AnaCore.sendDeeplinkEventData(context, userData, title, value);
            pickAddressFragment.setResultListener(null);
            pickAddressFragment.dismiss();
            pickAddressFragment = null;
        });
        pickAddressFragment.show(((Activity) context).getFragmentManager(), "Test");

    }

    public static String getMapUrlFromLocation(String lattitude, String longitude) {
        String url = "http://maps.google.com/maps/api/staticmap?center=" + lattitude + ","
                + longitude + "&zoom=19&size=1000x300&sensor=false" + "&key="
                + Constants.RSMAP_KEY;
        Log.d("LatLong", url);
        return url;
    }

    private void getCategories(Context context, String title, String value) {
        mProgressDialog = new ProgressDialog(context);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setIndeterminate(true);
        mProgressDialog.setMessage(getString(R.string.please_wait));
        mProgressDialog.show();
        dialogExists = true;
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, replaceSpace("https://s3.ap-south-1.amazonaws.com/boost-content-cdn/reporting_framework_15_May/category_list.txt"), null,
                new com.android.volley.Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Iterator<?> keys = response.keys();
                        List<String> mAutoComplRes = new ArrayList<>();
                        while (keys.hasNext()) {
                            try {
                                String key = (String) keys.next();
                                mAutoComplRes.add(response.getString(key));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        mProgressDialog.dismiss();
                        showListDialog(mAutoComplRes, context, title, value, "select category", "category", Constants.SHOW_CATEGORIES_LIST, null);
                    }
                }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Something went wrong!", Toast.LENGTH_SHORT).show();
            }
        });
        request.setRetryPolicy(new DefaultRetryPolicy(40000, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        mRequestQueue.add(request);
    }

    private String replaceSpace(String parsedPrefixPostfixText) {
        parsedPrefixPostfixText = parsedPrefixPostfixText.replaceAll(" ", "%20");
        return (parsedPrefixPostfixText);
    }

    private void showListDialog(List<String> mAutoComplRes, Context context, String title, String value, String dialogTitle, String key, int action, Object customObject) {

        dialogIsShown = true;


        final ArrayAdapter<String> showListAdapter = new ArrayAdapter<>(context,
                R.layout.search_list_item_layout, mAutoComplRes);
        AlertDialog.Builder builderSingle = new AlertDialog.Builder(context);
        builderSingle.setTitle(title);
        View view = LayoutInflater.from(context).inflate(R.layout.search_list_layout, null);
        builderSingle.setView(view);
        EditText edtSearch = view.findViewById(R.id.edtSearch);
        ListView lvItems = view.findViewById(R.id.lvItems);
        lvItems.setAdapter(showListAdapter);
        builderSingle.setCancelable(true);
        showlistDialog = builderSingle.create();
        showlistDialog.setCancelable(true);
        showlistDialog.setCanceledOnTouchOutside(true);
        showlistDialog.show();
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                dialogIsShown = false;

                String strVal = showListAdapter.getItem(position);
                HashMap<String, String> eventData = new HashMap<String, String>();
                if (action == Constants.SHOW_FP_TAGS_FOR_CF || action == Constants.SHOW_CATEGORIES_LIST) {
                    eventData.put(key, strVal);
                    AnaCore.sendDeeplinkEventData(context, eventData, strVal, value);
                }else if(action == Constants.GET_EMPLOYEE_ID) {
                    HashMap<String, String> employeeMap = (HashMap<String, String>) customObject;
                    String employeeEmail = employeeMap.get(strVal);
                    HashMap<String,String> userData = new HashMap<>();
                    userData.put(key , employeeEmail);
                    AnaCore.sendDeeplinkEventData(context , userData , title , value);
                }else if(action == Constants.SHOW_EXISTING_CUSTOMERS) {

                    HashMap<String,GetExistingCustomerResponse> customerMap = (HashMap<String, GetExistingCustomerResponse>) customObject;

                    GetExistingCustomerResponse getExistingCustomerResponse = customerMap.get(strVal);

                    HashMap<String,String> userData = new HashMap<>();
                    userData.put("mobile" , getExistingCustomerResponse.getMobile());
                    userData.put("id" , getExistingCustomerResponse.getId()+"");
                    userData.put("email" , getExistingCustomerResponse.getEmail());
                    userData.put("name" , getExistingCustomerResponse.getName());

                    AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext() , userData , title , value);

                }
                else if (action == Constants.SHOW_HOT_PROSPECTS_ID && customObject != null) {
                    HashMap<String, HotProspectResponse.Result> HPMap = (HashMap<String, HotProspectResponse.Result>) customObject;
                    HotProspectResponse.Result selectedhotprospect = HPMap.get(mAutoComplRes.get(position));
                    DisplayLog(selectedhotprospect.getCity());
                    eventData.put("hotprospect" , selectedhotprospect.getName());
                    eventData.put("hpsuccess", "1");
                    eventData.put("company_name" , selectedhotprospect.getCompanyName() == null ? "NA" : selectedhotprospect.getCompanyName() );
                    eventData.put("business_category", selectedhotprospect.getBusinessCategory());
                    eventData.put("city", selectedhotprospect.getCity());
                    eventData.put("email", selectedhotprospect.getCompanyEmail());
                    eventData.put("fptag" , selectedhotprospect.getFptag());
                    if (selectedhotprospect.getCompanyName() == null) {
                        selectedhotprospect.setCompanyEmail("Not Available");
                        selectedhotprospect.setCity("Not Available");
                        selectedhotprospect.setPincode("");
                    } else {
                        if (selectedhotprospect.getCompanyName().length() < 1) {
                            selectedhotprospect.setCompanyEmail("Not Available");
                            selectedhotprospect.setCity("Not Available");
                            selectedhotprospect.setPincode("");
                        }
                    }
                    eventData.put("company_name", selectedhotprospect.getCompanyName());
                    if (selectedhotprospect.getFptag() == null) {
                        selectedhotprospect.setFptag("");
                    }
                    eventData.put("FpTag", selectedhotprospect.getFptag());
                    if (selectedhotprospect.getMobile() == null)
                        selectedhotprospect.setMobile("Not Available");
                    eventData.put("mobile", selectedhotprospect.getMobile());
                    eventData.put("Name", selectedhotprospect.getName());
                    eventData.put("op_id", selectedhotprospect.getOppId().toString());
                    eventData.put("gstn", "None");
                    eventData.put("address", selectedhotprospect.getCity() + "," + selectedhotprospect.getPincode());
                    AnaCore.sendDeeplinkEventData(context, eventData, title, value);
                } else if (action == Constants.SHOW_TEMPLATES) {
                    DisplayLog(strVal);
                    List<GetTemplateResponse.Result> results = (List<GetTemplateResponse.Result>) customObject;
                    GetTemplateResponse.Result tempObject = new GetTemplateResponse.Result();
                    for (GetTemplateResponse.Result result : results) {
                        if (strVal.contains(result.getName())) {
                            tempObject = result;
                            break;
                        }
                    }
                    eventData.put("templatecode", tempObject.getCode() + "");
                    eventData.put("templateid", tempObject.getId() + "");
                    eventData.put("create_fptag", tempObject.getCAutoCreateFptag() + "");
                    eventData.put("templatename", tempObject.getName());
                    getProductsList(eventData, title, value, context);
                } else if (action == Constants.SHOW_QUOTATION_NUMBER) {
                    for (String mainQuotationNumber : mAutoComplRes) {
                        if (mainQuotationNumber.equals(strVal)) {
                            eventData.put("quotationNumber", mainQuotationNumber);
                            getQuotationIdWithQuotationNumber(eventData, context, title, value);
                            DisplayLog("matched");
                            break;
                        } else
                            DisplayLog("Did not match");
                    }
                }
                dialogExists = false;
                showlistDialog.dismiss();
            }
        });
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                showListAdapter.getFilter().filter(s.toString().toLowerCase());
            }
        });
    }

    private void getQuotationIdWithQuotationNumber(HashMap<String, String> eventData, Context context, String title, String value) {
        DisplayLog(Constants.GET_QUOTATION_ID_URL + Constants.ERPClientId + "&&soRef=" + eventData.get("quotationNumber"));
        StringRequest getQuotationIdRequest = new StringRequest(Request.Method.GET, Constants.GET_QUOTATION_ID_URL + "clientId=" + Constants.ERPClientId + "&&soRef=" + eventData.get("quotationNumber")
                , new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                DisplayLog(response);
                eventData.put("quotationId", response);
                AnaCore.sendDeeplinkEventData(context, eventData, title, value);
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                DisplayLog(error.toString());
                DisplayToast(getString(R.string.quotation_number_error));
            }
        });
        Volley.newRequestQueue(this).add(getQuotationIdRequest);
    }

    private void getTemplates(String title, String value, Context context) {
        GetTemplateRequest getTemplateRequest = new GetTemplateRequest();
        getTemplateRequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        getTemplateRequest.setMethod(Constants.ERP_METHOD);
        GetTemplateRequest.Params params = new GetTemplateRequest.Params();
        List<Object> args = new ArrayList<>();
        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);
        args.add("getSubcriptionTemplate");
        params.setService(Constants.ERP_PARAM_SERVICE);
        params.setMethod(Constants.ERP_PARAM_METHOD);
        params.setArgs(args);
        getTemplateRequest.setParams(params);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("android23235616")).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        erpApiInterface.getProductTemplates(getTemplateRequest, new Callback<GetTemplateResponse>() {
            @Override
            public void success(GetTemplateResponse getLeadDetailsResponse, Response response) {
                if (response.getStatus() == 200) {
                    DisplayLog(new Gson().toJson(getLeadDetailsResponse));
                    List<GetTemplateResponse.Result> results = getLeadDetailsResponse.getResult();
                    List<String> Names = new ArrayList<>();
                    for (GetTemplateResponse.Result result : results) {
                        if (result != null) {
                            if (result.getId() != null) {
                                Names.add("[ " + result.getCode() + " ] " + result.getName());
                            } else {
                                results.remove(result);
                            }
                        } else {
                            results.remove(result);
                        }
                    }
                    showListDialog(Names, context, title, value, getString(R.string.select_package), "templates", Constants.SHOW_TEMPLATES, results);
                } else {
                    DisplayLog(getString(R.string.template_error_response));
                }
            }

            @Override
            public void failure(RetrofitError error) {
                DisplayLog(getString(R.string.template_error_response));
            }
        });
    }

    private void showUpgradePackagesListDialog(List<String> mAutoComplRes, Context context, String title, String value, JSONObject dataResponse) {
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(context,
                R.layout.search_list_item_layout, mAutoComplRes);
        mBuilderSingle = new AlertDialog.Builder(context);
        mBuilderSingle.setTitle(title);
        View view = LayoutInflater.from(context).inflate(R.layout.search_list_layout, null);
        mBuilderSingle.setView(view);
        EditText edtSearch = view.findViewById(R.id.edtSearch);
        ListView lvItems = view.findViewById(R.id.lvItems);
        lvItems.setAdapter(adapter);
        final Dialog dialog = mBuilderSingle.show();
        dialog.show();
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String strVal = adapter.getItem(position);
                HashMap<String, String> eventData = new HashMap<>();
                eventData.put("selectedPackage", strVal);
                eventData.put("productName", strVal);
                DisplayLog(strVal);
                try {
                    eventData.put("selectedPackageId", dataResponse.getString(strVal));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                AnaCore.sendDeeplinkEventData(context, eventData, title, value);
                dialogExists = false;
                dialog.dismiss();
            }
        });
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                adapter.getFilter().filter(s.toString().toLowerCase());
            }
        });
        dialog.setCancelable(false);
    }

    private void showListLeadsDialog(List<String> mAutoComplRes, Context context, String title, String value, List<GetLeadDetailsResponse.Result> results) {
        final ArrayAdapter<String> adapter = new ArrayAdapter<>(context,
                R.layout.search_list_item_layout, mAutoComplRes);
        mBuilderSingle = new AlertDialog.Builder(context);
        mBuilderSingle.setTitle("Select customer");
        nfGeoCoder = new NFGeoCoder(context);
        View view = LayoutInflater.from(context).inflate(R.layout.search_list_layout, null);
        mBuilderSingle.setView(view);
        EditText edtSearch = view.findViewById(R.id.edtSearch);
        ListView lvItems = view.findViewById(R.id.lvItems);
        lvItems.setAdapter(adapter);
        final Dialog dialog = mBuilderSingle.show();
        dialog.show();
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String strVal = adapter.getItem(position);
                int pos = mAutoComplRes.indexOf(strVal);
                HashMap<String, String> eventData = new HashMap<>();
                eventData.put("selectedLead", results.get(pos).getName());
                eventData.put("leadCategory", results.get(pos).getBusinessCategory());
                eventData.put("leadTag", results.get(pos).getFptag());
                eventData.put("leadMobile", results.get(pos).getMobile());
                eventData.put("leadEmail", results.get(pos).getCompanyEmail());
                eventData.put("leadStreet", results.get(pos).getStreet());
                eventData.put("leadStreet2", results.get(pos).getStreet2());
                eventData.put("leadName", results.get(pos).getCompanyName());
                eventData.put("leadCity", results.get(pos).getCity());
                eventData.put("leadCountry", results.get(pos).getCountry());
                eventData.put("leadPincode", results.get(pos).getPincode());
                eventData.put("leadType", results.get(pos).getType());
                if ((results.get(pos).getMobile() == null) || (results.get(pos).getCompanyEmail() == null) || (results.get(pos).getCompanyName() == null) || (results.get(pos).getCity() == null) || (results.get(pos).getPincode() == null) || (results.get(pos).getCountry() == null) || (results.get(pos).getStreet() == null)) {
                    eventData.put("leadDataExists", "No");
                    eventData.put("leadLat", "");
                    eventData.put("leadLng", "");
                } else {
                    LatLng latLng = nfGeoCoder.reverseGeoCode(results.get(pos).getStreet(), results.get(pos).getCity(), results.get(pos).getCountry(), results.get(pos).getPincode());
                    if (latLng != null) {
                        eventData.put("leadDataExists", "Yes");
                        eventData.put("leadLat", String.valueOf(latLng.latitude));
                        eventData.put("leadLng", String.valueOf(latLng.longitude));
                    } else {
                        eventData.put("leadDataExists", "No");
                        eventData.put("leadLat", "");
                        eventData.put("leadLng", "");
                    }
                }
                AnaCore.sendDeeplinkEventData(context, eventData, title, value);
                dialogExists = false;
                dialog.dismiss();
            }
        });
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                adapter.getFilter().filter(s.toString().toLowerCase());
            }
        });
        dialog.setCancelable(false);
    }

    private void startPersistentService(Service service){

        if(service != null ){

            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                startForegroundService(new Intent(this , service.getClass()));

            }else{

                startService(new Intent(this , service.getClass()));

            }
        }

    }

    private void startCFService(){

        startPersistentService(new MainService() );

    }

    private void startFOSService(){
        startPersistentService(new FOSMainService());
    }


    @Override
    public void onSalesOrderImageUploaded(Bitmap receiptImage,String imageName) {
        updateReceiptInSo(receiptImage,imageName, externalProcessManager.getTitle(), externalProcessManager.getValue(), externalProcessManager.getAnaChatContext());
    }

    @Override
    public void sendImageFileToAna(String filename , String key) {
        HashMap<String,String> map = new HashMap<>();
        map.put(key,filename);
        AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext(), map , externalProcessManager.getTitle(), externalProcessManager.getValue());
    }

    @SuppressLint("MissingPermission")
    @Override
    public void callIntentForAna(String number) {
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number));
       startActivity(intent);
       HashMap userData = new HashMap();
       userData.put("call" , "1");
       AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext() , userData , externalProcessManager.getTitle(), externalProcessManager.getValue());
    }


        @Override
        public void onGpsSettingStatus(boolean enabled) {

        }

        @Override
        public void onGpsAlertCanceledByUser() {

        }

        @Override
        public void onBackPressed() {
            super.onBackPressed();

            if(dialogIsShown && showlistDialog != null ){
                showlistDialog.dismiss();
            }

        }

        private void setupDrawerLayout() {
            showOverlay();
            fm_bottomPanel.setVisibility(View.VISIBLE);
            Toolbar toolbar = findViewById(R.id.custom_toolbar);
            setSupportActionBar(toolbar);
            getSupportActionBar().setHomeButtonEnabled(true);
            SidePanelFragment sidePanelFragment = new SidePanelFragment();
            getSupportFragmentManager().beginTransaction().add(R.id.fm_fragment_navigation_drawer , sidePanelFragment).commitAllowingStateLoss();
            mDrawerLayout = findViewById(R.id.drawer_layout);
            sidePanelFragment.setUp(findViewById(R.id.fm_fragment_navigation_drawer) , findViewById(R.id.drawer_layout) , toolbar);
            mDrawerLayout.closeDrawer(Gravity.LEFT);
        }
    }