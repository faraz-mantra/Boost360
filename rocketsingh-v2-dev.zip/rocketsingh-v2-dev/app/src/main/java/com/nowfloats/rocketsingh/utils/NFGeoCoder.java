package com.nowfloats.rocketsingh.utils;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;

import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.util.List;

/**
 * Created by NowFloats on 01/30/2018.
 */

public class NFGeoCoder {

    private Context mContext;

    public NFGeoCoder(Context mContext) {
        this.mContext = mContext;
    }

    public LatLng reverseGeoCode(String... param) {

        Geocoder gc = new Geocoder(mContext);
        LatLng latLong = null;
        if (gc.isPresent()) {
            List<Address> list = null;
            try {
                Address address = null;
                list = gc.getFromLocationName(param[0] + ","
                        + param[1] + "," + param[2] + "," + param[3], 10);

                double lat = 0, lng = 0;
                if (list != null && list.size() > 0) {

                    address = list.get(list.size() - 1);
                    lat = address.getLatitude();
                    lng = address.getLongitude();
                    latLong = new LatLng(lat, lng);
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return latLong;
    }
}

