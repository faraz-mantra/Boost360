package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SendQuotationResponseModel {

    @SerializedName("serverObject")
    @Expose
    private String serverObject;
    @SerializedName("serverMessage")
    @Expose
    private String serverMessage;
    @SerializedName("error")
    @Expose
    private String error;
    @SerializedName("count")
    @Expose
    private Integer count;
    @SerializedName("message")
    @Expose
    private String message;

    public String getServerObject() {
        return serverObject;
    }

    public void setServerObject(String serverObject) {
        this.serverObject = serverObject;
    }

    public String getServerMessage() {
        return serverMessage;
    }

    public void setServerMessage(String serverMessage) {
        this.serverMessage = serverMessage;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}