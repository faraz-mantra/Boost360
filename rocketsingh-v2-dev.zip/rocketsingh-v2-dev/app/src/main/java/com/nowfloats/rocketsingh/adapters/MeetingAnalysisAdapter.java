package com.nowfloats.rocketsingh.adapters;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.GetLatestMeetingsResponse;

import java.util.ArrayList;
import java.util.List;

public class MeetingAnalysisAdapter extends RecyclerView.Adapter<MeetingAnalysisAdapter.MyViewHolder> {


    List<GetLatestMeetingsResponse> getLatestMeetingsResponses = new ArrayList<>();
    CheckIfListHasValues checkIfListHasValues;

    public MeetingAnalysisAdapter(CheckIfListHasValues checkIfListHasValues){
        this.checkIfListHasValues = checkIfListHasValues;
    }

    public void setData(List<GetLatestMeetingsResponse> getLatestMeetingsResponses){
        this.getLatestMeetingsResponses = getLatestMeetingsResponses;
        notifyDataSetChanged();
        if(getLatestMeetingsResponses.size()==0){
            checkIfListHasValues.listHasValues(false);
        }else{
            checkIfListHasValues.listHasValues(true);
        }
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.meeting_analysis_row,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        GetLatestMeetingsResponse getLatestMeetingsResponse = getLatestMeetingsResponses.get(holder.getAdapterPosition());
        holder.tv_Days.setText("Last Meeting "+getLatestMeetingsResponse.getLastMetDifference()+" days before.");
        if(getLatestMeetingsResponse.getCreatedOn()!=null&&getLatestMeetingsResponse.getCreatedOn().length()>1)
            holder.tv_lastMet.setText("Last Meeting :\n "+getLatestMeetingsResponse.getCreatedOn());
        else
            holder.tv_lastMet.setText("Last Meeting:\n Not Available");
        holder.tv_FpTags.setText(getLatestMeetingsResponse.getFPTag());
        holder.tv_Count.setText((holder.getAdapterPosition()+1)+"");

    }

    @Override
    public int getItemCount() {
        return getLatestMeetingsResponses.size();
    }

    protected class MyViewHolder extends RecyclerView.ViewHolder{
        TextView tv_FpTags,tv_Count,tv_Days,tv_lastMet;
        public MyViewHolder(View itemView) {
            super(itemView);
            tv_FpTags = itemView.findViewById(R.id.tv_Fptag);
            tv_Count = itemView.findViewById(R.id.tv_count);
            tv_Days = itemView.findViewById(R.id.tv_created_on);
            tv_lastMet = itemView.findViewById(R.id.tv_days);
        }
    }

    public interface CheckIfListHasValues{
        void listHasValues(boolean Flag);
    }
}
