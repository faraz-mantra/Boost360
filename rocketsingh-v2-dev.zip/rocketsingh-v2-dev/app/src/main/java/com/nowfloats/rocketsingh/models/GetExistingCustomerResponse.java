package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetExistingCustomerResponse {

    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;

    public String getMobile() {
        return mobile;
    }


    public String getEmail() {
        return email;
    }



    public Integer getId() {
        return id;
    }


    public String getName() {
        return name;
    }



}