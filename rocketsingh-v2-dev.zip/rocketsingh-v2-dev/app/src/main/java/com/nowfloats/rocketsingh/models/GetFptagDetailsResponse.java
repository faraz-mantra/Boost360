package com.nowfloats.rocketsingh.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetFptagDetailsResponse {

    @SerializedName("IsSMSSubscriptionEnabled")
    @Expose
    private Boolean isSMSSubscriptionEnabled;
    @SerializedName("IsEmailSubscriptionEnabled")
    @Expose
    private Boolean isEmailSubscriptionEnabled;
    @SerializedName("AccountManagerId")
    @Expose
    private String accountManagerId;
    @SerializedName("ExpiryDate")
    @Expose
    private String expiryDate;
    @SerializedName("ProductCategoryVerb")
    @Expose
    private Object productCategoryVerb;
    @SerializedName("WebTemplateId")
    @Expose
    private String webTemplateId;
    @SerializedName("_id")
    @Expose
    private String id;
    @SerializedName("Name")
    @Expose
    private String name;
    @SerializedName("Tag")
    @Expose
    private String tag;
    @SerializedName("AliasTag")
    @Expose
    private Object aliasTag;
    @SerializedName("ImageUri")
    @Expose
    private String imageUri;
    @SerializedName("TileImageUri")
    @Expose
    private String tileImageUri;
    @SerializedName("City")
    @Expose
    private String city;
    @SerializedName("ExternalSourceId")
    @Expose
    private String externalSourceId;
    @SerializedName("ContactName")
    @Expose
    private Object contactName;
    @SerializedName("ExternalSourceName")
    @Expose
    private Object externalSourceName;
    @SerializedName("ParentId")
    @Expose
    private Object parentId;
    @SerializedName("IsVerified")
    @Expose
    private Boolean isVerified;
    @SerializedName("PrimaryNumber")
    @Expose
    private String primaryNumber;
    @SerializedName("Email")
    @Expose
    private String email;
    @SerializedName("CountryPhoneCode")
    @Expose
    private String countryPhoneCode;
    @SerializedName("Pwd")
    @Expose
    private Object pwd;
    @SerializedName("Description")
    @Expose
    private String description;
    @SerializedName("lat")
    @Expose
    private Float lat;
    @SerializedName("lng")
    @Expose
    private Float lng;
    @SerializedName("errorRadius")
    @Expose
    private Float errorRadius;
    @SerializedName("height")
    @Expose
    private Float height;
    @SerializedName("Category")
    @Expose
    private List<String> category = null;
    @SerializedName("SearchTags")
    @Expose
    private Object searchTags;
    @SerializedName("Address")
    @Expose
    private String address;
    @SerializedName("Uri")
    @Expose
    private String uri;
    @SerializedName("UriDescription")
    @Expose
    private Object uriDescription;
    @SerializedName("PanaromaId")
    @Expose
    private Object panaromaId;
    @SerializedName("SecondaryImages")
    @Expose
    private Object secondaryImages;
    @SerializedName("SecondaryTileImages")
    @Expose
    private Object secondaryTileImages;
    @SerializedName("FBPageName")
    @Expose
    private String fBPageName;
    @SerializedName("Contact")
    @Expose
    private Object contact;
    @SerializedName("Contacts")
    @Expose
    private List<Contact> contacts = null;
    @SerializedName("Timings")
    @Expose
    private Object timings;
    @SerializedName("Ratings")
    @Expose
    private Object ratings;
    @SerializedName("OverallRating")
    @Expose
    private Float overallRating;
    @SerializedName("WebTemplateType")
    @Expose
    private Float webTemplateType;
    @SerializedName("IsStoreFront")
    @Expose
    private Boolean isStoreFront;
    @SerializedName("RootAliasUri")
    @Expose
    private Object rootAliasUri;
    @SerializedName("ParentPrimaryNumber")
    @Expose
    private Object parentPrimaryNumber;
    @SerializedName("EnterpriseEmailContact")
    @Expose
    private Object enterpriseEmailContact;
    @SerializedName("EnterpriseName")
    @Expose
    private Object enterpriseName;
    @SerializedName("LogoUrl")
    @Expose
    private Object logoUrl;
    @SerializedName("TinyLogoUrl")
    @Expose
    private Object tinyLogoUrl;
    @SerializedName("WebKeywords")
    @Expose
    private List<String> webKeywords = null;
    @SerializedName("FPWebWidgets")
    @Expose
    private List<String> fPWebWidgets = null;
    @SerializedName("FPLocalWidgets")
    @Expose
    private List<FPLocalWidget> fPLocalWidgets = null;
    @SerializedName("PackageIds")
    @Expose
    private Object packageIds;
    @SerializedName("PaymentState")
    @Expose
    private Integer paymentState;
    @SerializedName("PaymentLevel")
    @Expose
    private Integer paymentLevel;
    @SerializedName("FaviconUrl")
    @Expose
    private Object faviconUrl;
    @SerializedName("IsBulkSubscription")
    @Expose
    private Boolean isBulkSubscription;
    @SerializedName("Country")
    @Expose
    private String country;
    @SerializedName("PinCode")
    @Expose
    private String pinCode;
    @SerializedName("CreatedOn")
    @Expose
    private String createdOn;
    @SerializedName("NFXAccessTokens")
    @Expose
    private Object nFXAccessTokens;
    @SerializedName("LanguageCode")
    @Expose
    private String languageCode;
    @SerializedName("ApplicationId")
    @Expose
    private String applicationId;
    @SerializedName("GAToken")
    @Expose
    private String gAToken;
    @SerializedName("GADomain")
    @Expose
    private String gADomain;
    @SerializedName("SMSGatewayUri")
    @Expose
    private Object sMSGatewayUri;

    public Boolean getIsSMSSubscriptionEnabled() {
        return isSMSSubscriptionEnabled;
    }

    public void setIsSMSSubscriptionEnabled(Boolean isSMSSubscriptionEnabled) {
        this.isSMSSubscriptionEnabled = isSMSSubscriptionEnabled;
    }

    public GetFptagDetailsResponse withIsSMSSubscriptionEnabled(Boolean isSMSSubscriptionEnabled) {
        this.isSMSSubscriptionEnabled = isSMSSubscriptionEnabled;
        return this;
    }

    public Boolean getIsEmailSubscriptionEnabled() {
        return isEmailSubscriptionEnabled;
    }

    public void setIsEmailSubscriptionEnabled(Boolean isEmailSubscriptionEnabled) {
        this.isEmailSubscriptionEnabled = isEmailSubscriptionEnabled;
    }

    public GetFptagDetailsResponse withIsEmailSubscriptionEnabled(Boolean isEmailSubscriptionEnabled) {
        this.isEmailSubscriptionEnabled = isEmailSubscriptionEnabled;
        return this;
    }

    public String getAccountManagerId() {
        return accountManagerId;
    }

    public void setAccountManagerId(String accountManagerId) {
        this.accountManagerId = accountManagerId;
    }

    public GetFptagDetailsResponse withAccountManagerId(String accountManagerId) {
        this.accountManagerId = accountManagerId;
        return this;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public GetFptagDetailsResponse withExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
        return this;
    }

    public Object getProductCategoryVerb() {
        return productCategoryVerb;
    }

    public void setProductCategoryVerb(Object productCategoryVerb) {
        this.productCategoryVerb = productCategoryVerb;
    }

    public GetFptagDetailsResponse withProductCategoryVerb(Object productCategoryVerb) {
        this.productCategoryVerb = productCategoryVerb;
        return this;
    }

    public String getWebTemplateId() {
        return webTemplateId;
    }

    public void setWebTemplateId(String webTemplateId) {
        this.webTemplateId = webTemplateId;
    }

    public GetFptagDetailsResponse withWebTemplateId(String webTemplateId) {
        this.webTemplateId = webTemplateId;
        return this;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public GetFptagDetailsResponse withId(String id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public GetFptagDetailsResponse withName(String name) {
        this.name = name;
        return this;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public GetFptagDetailsResponse withTag(String tag) {
        this.tag = tag;
        return this;
    }

    public Object getAliasTag() {
        return aliasTag;
    }

    public void setAliasTag(Object aliasTag) {
        this.aliasTag = aliasTag;
    }

    public GetFptagDetailsResponse withAliasTag(Object aliasTag) {
        this.aliasTag = aliasTag;
        return this;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    public GetFptagDetailsResponse withImageUri(String imageUri) {
        this.imageUri = imageUri;
        return this;
    }

    public String getTileImageUri() {
        return tileImageUri;
    }

    public void setTileImageUri(String tileImageUri) {
        this.tileImageUri = tileImageUri;
    }

    public GetFptagDetailsResponse withTileImageUri(String tileImageUri) {
        this.tileImageUri = tileImageUri;
        return this;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public GetFptagDetailsResponse withCity(String city) {
        this.city = city;
        return this;
    }

    public String getExternalSourceId() {
        return externalSourceId;
    }

    public void setExternalSourceId(String externalSourceId) {
        this.externalSourceId = externalSourceId;
    }

    public GetFptagDetailsResponse withExternalSourceId(String externalSourceId) {
        this.externalSourceId = externalSourceId;
        return this;
    }

    public Object getContactName() {
        return contactName;
    }

    public void setContactName(Object contactName) {
        this.contactName = contactName;
    }

    public GetFptagDetailsResponse withContactName(Object contactName) {
        this.contactName = contactName;
        return this;
    }

    public Object getExternalSourceName() {
        return externalSourceName;
    }

    public void setExternalSourceName(Object externalSourceName) {
        this.externalSourceName = externalSourceName;
    }

    public GetFptagDetailsResponse withExternalSourceName(Object externalSourceName) {
        this.externalSourceName = externalSourceName;
        return this;
    }

    public Object getParentId() {
        return parentId;
    }

    public void setParentId(Object parentId) {
        this.parentId = parentId;
    }

    public GetFptagDetailsResponse withParentId(Object parentId) {
        this.parentId = parentId;
        return this;
    }

    public Boolean getIsVerified() {
        return isVerified;
    }

    public void setIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
    }

    public GetFptagDetailsResponse withIsVerified(Boolean isVerified) {
        this.isVerified = isVerified;
        return this;
    }

    public String getPrimaryNumber() {
        return primaryNumber;
    }

    public void setPrimaryNumber(String primaryNumber) {
        this.primaryNumber = primaryNumber;
    }

    public GetFptagDetailsResponse withPrimaryNumber(String primaryNumber) {
        this.primaryNumber = primaryNumber;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public GetFptagDetailsResponse withEmail(String email) {
        this.email = email;
        return this;
    }

    public String getCountryPhoneCode() {
        return countryPhoneCode;
    }

    public void setCountryPhoneCode(String countryPhoneCode) {
        this.countryPhoneCode = countryPhoneCode;
    }

    public GetFptagDetailsResponse withCountryPhoneCode(String countryPhoneCode) {
        this.countryPhoneCode = countryPhoneCode;
        return this;
    }

    public Object getPwd() {
        return pwd;
    }

    public void setPwd(Object pwd) {
        this.pwd = pwd;
    }

    public GetFptagDetailsResponse withPwd(Object pwd) {
        this.pwd = pwd;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public GetFptagDetailsResponse withDescription(String description) {
        this.description = description;
        return this;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public GetFptagDetailsResponse withLat(Float lat) {
        this.lat = lat;
        return this;
    }

    public Float getLng() {
        return lng;
    }

    public void setLng(Float lng) {
        this.lng = lng;
    }

    public GetFptagDetailsResponse withLng(Float lng) {
        this.lng = lng;
        return this;
    }

    public Float getErrorRadius() {
        return errorRadius;
    }

    public void setErrorRadius(Float errorRadius) {
        this.errorRadius = errorRadius;
    }

    public GetFptagDetailsResponse withErrorRadius(Float errorRadius) {
        this.errorRadius = errorRadius;
        return this;
    }

    public Float getHeight() {
        return height;
    }

    public void setHeight(Float height) {
        this.height = height;
    }

    public GetFptagDetailsResponse withHeight(Float height) {
        this.height = height;
        return this;
    }

    public List<String> getCategory() {
        return category;
    }

    public void setCategory(List<String> category) {
        this.category = category;
    }

    public GetFptagDetailsResponse withCategory(List<String> category) {
        this.category = category;
        return this;
    }

    public Object getSearchTags() {
        return searchTags;
    }

    public void setSearchTags(Object searchTags) {
        this.searchTags = searchTags;
    }

    public GetFptagDetailsResponse withSearchTags(Object searchTags) {
        this.searchTags = searchTags;
        return this;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public GetFptagDetailsResponse withAddress(String address) {
        this.address = address;
        return this;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public GetFptagDetailsResponse withUri(String uri) {
        this.uri = uri;
        return this;
    }

    public Object getUriDescription() {
        return uriDescription;
    }

    public void setUriDescription(Object uriDescription) {
        this.uriDescription = uriDescription;
    }

    public GetFptagDetailsResponse withUriDescription(Object uriDescription) {
        this.uriDescription = uriDescription;
        return this;
    }

    public Object getPanaromaId() {
        return panaromaId;
    }

    public void setPanaromaId(Object panaromaId) {
        this.panaromaId = panaromaId;
    }

    public GetFptagDetailsResponse withPanaromaId(Object panaromaId) {
        this.panaromaId = panaromaId;
        return this;
    }

    public Object getSecondaryImages() {
        return secondaryImages;
    }

    public void setSecondaryImages(Object secondaryImages) {
        this.secondaryImages = secondaryImages;
    }

    public GetFptagDetailsResponse withSecondaryImages(Object secondaryImages) {
        this.secondaryImages = secondaryImages;
        return this;
    }

    public Object getSecondaryTileImages() {
        return secondaryTileImages;
    }

    public void setSecondaryTileImages(Object secondaryTileImages) {
        this.secondaryTileImages = secondaryTileImages;
    }

    public GetFptagDetailsResponse withSecondaryTileImages(Object secondaryTileImages) {
        this.secondaryTileImages = secondaryTileImages;
        return this;
    }

    public String getFBPageName() {
        return fBPageName;
    }

    public void setFBPageName(String fBPageName) {
        this.fBPageName = fBPageName;
    }

    public GetFptagDetailsResponse withFBPageName(String fBPageName) {
        this.fBPageName = fBPageName;
        return this;
    }

    public Object getContact() {
        return contact;
    }

    public void setContact(Object contact) {
        this.contact = contact;
    }

    public GetFptagDetailsResponse withContact(Object contact) {
        this.contact = contact;
        return this;
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    public GetFptagDetailsResponse withContacts(List<Contact> contacts) {
        this.contacts = contacts;
        return this;
    }

    public Object getTimings() {
        return timings;
    }

    public void setTimings(Object timings) {
        this.timings = timings;
    }

    public GetFptagDetailsResponse withTimings(Object timings) {
        this.timings = timings;
        return this;
    }

    public Object getRatings() {
        return ratings;
    }

    public void setRatings(Object ratings) {
        this.ratings = ratings;
    }

    public GetFptagDetailsResponse withRatings(Object ratings) {
        this.ratings = ratings;
        return this;
    }

    public Float getOverallRating() {
        return overallRating;
    }

    public void setOverallRating(Float overallRating) {
        this.overallRating = overallRating;
    }

    public GetFptagDetailsResponse withOverallRating(Float overallRating) {
        this.overallRating = overallRating;
        return this;
    }

    public Float getWebTemplateType() {
        return webTemplateType;
    }

    public void setWebTemplateType(Float webTemplateType) {
        this.webTemplateType = webTemplateType;
    }

    public GetFptagDetailsResponse withWebTemplateType(Float webTemplateType) {
        this.webTemplateType = webTemplateType;
        return this;
    }

    public Boolean getIsStoreFront() {
        return isStoreFront;
    }

    public void setIsStoreFront(Boolean isStoreFront) {
        this.isStoreFront = isStoreFront;
    }

    public GetFptagDetailsResponse withIsStoreFront(Boolean isStoreFront) {
        this.isStoreFront = isStoreFront;
        return this;
    }

    public Object getRootAliasUri() {
        return rootAliasUri;
    }

    public void setRootAliasUri(Object rootAliasUri) {
        this.rootAliasUri = rootAliasUri;
    }

    public GetFptagDetailsResponse withRootAliasUri(Object rootAliasUri) {
        this.rootAliasUri = rootAliasUri;
        return this;
    }

    public Object getParentPrimaryNumber() {
        return parentPrimaryNumber;
    }

    public void setParentPrimaryNumber(Object parentPrimaryNumber) {
        this.parentPrimaryNumber = parentPrimaryNumber;
    }

    public GetFptagDetailsResponse withParentPrimaryNumber(Object parentPrimaryNumber) {
        this.parentPrimaryNumber = parentPrimaryNumber;
        return this;
    }

    public Object getEnterpriseEmailContact() {
        return enterpriseEmailContact;
    }

    public void setEnterpriseEmailContact(Object enterpriseEmailContact) {
        this.enterpriseEmailContact = enterpriseEmailContact;
    }

    public GetFptagDetailsResponse withEnterpriseEmailContact(Object enterpriseEmailContact) {
        this.enterpriseEmailContact = enterpriseEmailContact;
        return this;
    }

    public Object getEnterpriseName() {
        return enterpriseName;
    }

    public void setEnterpriseName(Object enterpriseName) {
        this.enterpriseName = enterpriseName;
    }

    public GetFptagDetailsResponse withEnterpriseName(Object enterpriseName) {
        this.enterpriseName = enterpriseName;
        return this;
    }

    public Object getLogoUrl() {
        return logoUrl;
    }

    public void setLogoUrl(Object logoUrl) {
        this.logoUrl = logoUrl;
    }

    public GetFptagDetailsResponse withLogoUrl(Object logoUrl) {
        this.logoUrl = logoUrl;
        return this;
    }

    public Object getTinyLogoUrl() {
        return tinyLogoUrl;
    }

    public void setTinyLogoUrl(Object tinyLogoUrl) {
        this.tinyLogoUrl = tinyLogoUrl;
    }

    public GetFptagDetailsResponse withTinyLogoUrl(Object tinyLogoUrl) {
        this.tinyLogoUrl = tinyLogoUrl;
        return this;
    }

    public List<String> getWebKeywords() {
        return webKeywords;
    }

    public void setWebKeywords(List<String> webKeywords) {
        this.webKeywords = webKeywords;
    }

    public GetFptagDetailsResponse withWebKeywords(List<String> webKeywords) {
        this.webKeywords = webKeywords;
        return this;
    }

    public List<String> getFPWebWidgets() {
        return fPWebWidgets;
    }

    public void setFPWebWidgets(List<String> fPWebWidgets) {
        this.fPWebWidgets = fPWebWidgets;
    }

    public GetFptagDetailsResponse withFPWebWidgets(List<String> fPWebWidgets) {
        this.fPWebWidgets = fPWebWidgets;
        return this;
    }

    public List<FPLocalWidget> getFPLocalWidgets() {
        return fPLocalWidgets;
    }

    public void setFPLocalWidgets(List<FPLocalWidget> fPLocalWidgets) {
        this.fPLocalWidgets = fPLocalWidgets;
    }

    public GetFptagDetailsResponse withFPLocalWidgets(List<FPLocalWidget> fPLocalWidgets) {
        this.fPLocalWidgets = fPLocalWidgets;
        return this;
    }

    public Object getPackageIds() {
        return packageIds;
    }

    public void setPackageIds(Object packageIds) {
        this.packageIds = packageIds;
    }

    public GetFptagDetailsResponse withPackageIds(Object packageIds) {
        this.packageIds = packageIds;
        return this;
    }

    public Integer getPaymentState() {
        return paymentState;
    }

    public void setPaymentState(Integer paymentState) {
        this.paymentState = paymentState;
    }

    public GetFptagDetailsResponse withPaymentState(Integer paymentState) {
        this.paymentState = paymentState;
        return this;
    }

    public Integer getPaymentLevel() {
        return paymentLevel;
    }

    public void setPaymentLevel(Integer paymentLevel) {
        this.paymentLevel = paymentLevel;
    }

    public GetFptagDetailsResponse withPaymentLevel(Integer paymentLevel) {
        this.paymentLevel = paymentLevel;
        return this;
    }

    public Object getFaviconUrl() {
        return faviconUrl;
    }

    public void setFaviconUrl(Object faviconUrl) {
        this.faviconUrl = faviconUrl;
    }

    public GetFptagDetailsResponse withFaviconUrl(Object faviconUrl) {
        this.faviconUrl = faviconUrl;
        return this;
    }

    public Boolean getIsBulkSubscription() {
        return isBulkSubscription;
    }

    public void setIsBulkSubscription(Boolean isBulkSubscription) {
        this.isBulkSubscription = isBulkSubscription;
    }

    public GetFptagDetailsResponse withIsBulkSubscription(Boolean isBulkSubscription) {
        this.isBulkSubscription = isBulkSubscription;
        return this;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public GetFptagDetailsResponse withCountry(String country) {
        this.country = country;
        return this;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public GetFptagDetailsResponse withPinCode(String pinCode) {
        this.pinCode = pinCode;
        return this;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public GetFptagDetailsResponse withCreatedOn(String createdOn) {
        this.createdOn = createdOn;
        return this;
    }

    public Object getNFXAccessTokens() {
        return nFXAccessTokens;
    }

    public void setNFXAccessTokens(Object nFXAccessTokens) {
        this.nFXAccessTokens = nFXAccessTokens;
    }

    public GetFptagDetailsResponse withNFXAccessTokens(Object nFXAccessTokens) {
        this.nFXAccessTokens = nFXAccessTokens;
        return this;
    }

    public String getLanguageCode() {
        return languageCode;
    }

    public void setLanguageCode(String languageCode) {
        this.languageCode = languageCode;
    }

    public GetFptagDetailsResponse withLanguageCode(String languageCode) {
        this.languageCode = languageCode;
        return this;
    }

    public String getApplicationId() {
        return applicationId;
    }

    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    public GetFptagDetailsResponse withApplicationId(String applicationId) {
        this.applicationId = applicationId;
        return this;
    }

    public String getGAToken() {
        return gAToken;
    }

    public void setGAToken(String gAToken) {
        this.gAToken = gAToken;
    }

    public GetFptagDetailsResponse withGAToken(String gAToken) {
        this.gAToken = gAToken;
        return this;
    }

    public String getGADomain() {
        return gADomain;
    }

    public void setGADomain(String gADomain) {
        this.gADomain = gADomain;
    }

    public GetFptagDetailsResponse withGADomain(String gADomain) {
        this.gADomain = gADomain;
        return this;
    }

    public Object getSMSGatewayUri() {
        return sMSGatewayUri;
    }

    public void setSMSGatewayUri(Object sMSGatewayUri) {
        this.sMSGatewayUri = sMSGatewayUri;
    }

    public GetFptagDetailsResponse withSMSGatewayUri(Object sMSGatewayUri) {
        this.sMSGatewayUri = sMSGatewayUri;
        return this;
    }

}