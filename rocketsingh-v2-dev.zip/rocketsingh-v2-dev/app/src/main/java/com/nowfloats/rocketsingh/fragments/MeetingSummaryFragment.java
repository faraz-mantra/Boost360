package com.nowfloats.rocketsingh.fragments;


import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import androidx.fragment.app.DialogFragment;

import androidx.core.content.ContextCompat;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;

import com.nowfloats.rocketsingh.interfaces.UIInterface;

import com.nowfloats.rocketsingh.models.MeetingsStatsForCFResponse;

import com.nowfloats.rocketsingh.utils.MeetingSummaryUtils;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class MeetingSummaryFragment extends DialogFragment implements MeetingSummaryUtils.MeetingSummaryInterface{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private TextView tv_header , tv_close;
    private  UIInterface uiInterface;
    private ProgressBar progressDialog;
    private RelativeLayout rl_root;
    private Button bt_missedMeetings , bt_rescheduledMeetings , bt_updatedMeetings;
    private RecyclerView recyclerView;
    private MeetingsSummaryAdapter meetingsSummaryAdapter;
    private MeetingSummaryUtils meetingSummaryUtils;
    List<Object> rescheduledFptags , updatedFps , missedFps;
    UserSessionManager manager;
    public MeetingSummaryFragment() {
        // Required empty public constructor
    }

    public static MeetingSummaryFragment getInstance(UIInterface uiInterface) {
        MeetingSummaryFragment instance = new MeetingSummaryFragment();
        instance.uiInterface = uiInterface;
        return instance;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        setCancelable(true);

        manager = new UserSessionManager(Objects.requireNonNull(getContext()));
        progressDialog  = view.findViewById(R.id.progressDialog);
        tv_close = view.findViewById(R.id.tv_close);
        tv_header = view.findViewById(R.id.tv_header);
        rl_root = view.findViewById(R.id.root_layout);
        bt_missedMeetings = view.findViewById(R.id.bt_missedMeetings);
        bt_rescheduledMeetings = view.findViewById(R.id.bt_rescheduledMeetings);
        bt_updatedMeetings = view.findViewById(R.id.bt_updatedMeetings);
        recyclerView = view.findViewById(R.id.meetingsSummaryRecyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        tv_close.setOnClickListener(((View view1) -> {getDialog().dismiss();}));
        bt_missedMeetings.setOnClickListener((view1 -> {showMissedFps();}));
        bt_rescheduledMeetings.setOnClickListener((view1 -> {showRescheduledFp();}));
        bt_updatedMeetings.setOnClickListener((view1 -> {showUpdatedFp();}));

       showProgressbar();

        meetingSummaryUtils = MeetingSummaryUtils.getInstance().setMeetingSummaryInterface(this).startGettingData(manager.getCFUsername());

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_meeting_summary, container, false);
    }

    public void showProgressbar(){
//        if(progressDialog == null ){
//
//             //   progressDialog = new ProgressDialog(getContext());
////                progressDialog.setMessage("Please wait....");
////                progressDialog.setTitle("Loading");
////                progressDialog.show();
//            progressDialog.set
//
//        }else if(! progressDialog.isShowing()){
//                progressDialog = null;
//                showProgressbar();
//        }
        rl_root.setAlpha(.2f);
        progressDialog.setVisibility(View.VISIBLE);
    }

    private void hideProgressDialog(){
//        if(progressDialog != null){
//            if(progressDialog.isShowing()){
//                progressDialog.dismiss();
//            }
//        }
        progressDialog.setVisibility(View.GONE);
        rl_root.setAlpha(1);
    }

    @Override
    public void onEmptyMeetingsData(boolean b) {
        tv_header.setVisibility(b ? View.GONE : View.VISIBLE);
        setAdapter();
    }

    @Override
    public void onMeetingsDataResponse(MeetingsStatsForCFResponse dataResponse , String title) {
        hideProgressDialog();
        tv_header.setText(title);
        if(dataResponse != null ){

            updatedFps = dataResponse.getUpdatedMeetingsFpTags();
            missedFps = dataResponse.getMissedMeetingsFpTags();
            rescheduledFptags = dataResponse.getRescheduledMeetingsFpTags();

        }else{
            updatedFps = missedFps = rescheduledFptags = new ArrayList<>();
        }
        meetingsSummaryAdapter = new MeetingsSummaryAdapter(updatedFps ,  this);
        setAdapter();
    }

    @Override
    public void setRecyclerViewAdapter() {
        setAdapter();
    }

    private void showButton(Button b ,boolean show){
        if(show) {
            b.setBackgroundResource(R.drawable.rounded_corner_yellow);
            b.setTextColor(ContextCompat.getColor(Objects.requireNonNull(getContext()),R.color.white));
        }else{
            b.setBackgroundResource(R.drawable.rounded_corner_white);
            b.setTextColor(ContextCompat.getColor(getActivity(),R.color.colorPrimary));
        }
   }

   private void enableMissedMeetingsButton(boolean show ){
        showButton(bt_missedMeetings , show);
   }

   private void enableRescheduledMeetingsButton(boolean show) {
        showButton(bt_rescheduledMeetings , show);
   }

   private void enableUpdatedMeetingsButton(boolean show) {
       showButton(bt_updatedMeetings, show);
   }

    private  void showUpdatedFp(){
        enableUpdatedMeetingsButton(true);
        enableMissedMeetingsButton(false);
        enableRescheduledMeetingsButton(false);
        meetingsSummaryAdapter.setData(updatedFps);
    }

    private  void showMissedFps(){
        enableUpdatedMeetingsButton(false);
        enableMissedMeetingsButton(true);
        enableRescheduledMeetingsButton(false);
        meetingsSummaryAdapter.setData(missedFps);
    }

    private  void showRescheduledFp(){
        enableUpdatedMeetingsButton(false);
        enableMissedMeetingsButton(false);
        enableRescheduledMeetingsButton(true);
        meetingsSummaryAdapter.setData(rescheduledFptags);
    }

    private  void setAdapter(){
        recyclerView.setAdapter(meetingsSummaryAdapter);
//        meetingsSummaryAdapter.notifyDataSetChanged();
    }

    // TODO: Rename method, update argument and hook method into UI event

}
