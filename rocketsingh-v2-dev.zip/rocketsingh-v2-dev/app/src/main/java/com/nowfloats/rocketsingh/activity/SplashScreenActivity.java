package com.nowfloats.rocketsingh.activity;

/**
 * Created by NowFloats on 10-12-2017.
 */

import android.content.Intent;
import android.graphics.Color;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.utils.UserSessionManager;
import com.ramotion.paperonboarding.PaperOnboardingFragment;
import com.ramotion.paperonboarding.PaperOnboardingPage;
import com.ramotion.paperonboarding.listeners.PaperOnboardingOnRightOutListener;

import java.util.ArrayList;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class SplashScreenActivity extends AppCompatActivity {
    UserSessionManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        manager = new UserSessionManager(this);
        if(!manager.getFirstOpen()) {
            Intent intent = new Intent(SplashScreenActivity.this, GoogleLoginActivity.class);
            startActivity(intent);
            finish();
        }
        PaperOnboardingPage scr1 = new PaperOnboardingPage("Sales Assistant",
                "Aho, I'm Rocket Singh, your sales concierge. I am here to help you manage your daily tasks and improve your sales efficiency.",
                Color.parseColor("#678FB4"), R.drawable.app_logo, R.drawable.app_logo);
        PaperOnboardingPage scr2 = new PaperOnboardingPage("Manage Meetings",
                "You can create,reschedule and update your meetings from Rocket Singh.",
                Color.parseColor("#65B0B4"), R.drawable.app_logo, R.drawable.app_logo);
        PaperOnboardingPage scr3 = new PaperOnboardingPage("Manage Sales",
                "You can now log your sales directly from Rocket Singh.",
                Color.parseColor("#1ABC9C"), R.drawable.app_logo, R.drawable.app_logo);
        PaperOnboardingPage scr4 = new PaperOnboardingPage("View Performance Report",
                "You can now view your daily performance summary report from Rocket Singh.",
                Color.parseColor("#9B90BC"), R.drawable.app_logo, R.drawable.app_logo);
        ArrayList<PaperOnboardingPage> elements = new ArrayList<>();
        elements.add(scr1);
        elements.add(scr2);
        elements.add(scr3);
        elements.add(scr4);
        FragmentManager fragmentManager = getSupportFragmentManager();
        PaperOnboardingFragment onBoardingFragment = PaperOnboardingFragment.newInstance(elements);
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.fragment_container, onBoardingFragment);
        fragmentTransaction.commit();
        onBoardingFragment.setOnRightOutListener(new PaperOnboardingOnRightOutListener() {
            @Override
            public void onRightOut() {
                manager.setFirstOpen(false);
                Intent intent = new Intent(SplashScreenActivity.this, GoogleLoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

}
