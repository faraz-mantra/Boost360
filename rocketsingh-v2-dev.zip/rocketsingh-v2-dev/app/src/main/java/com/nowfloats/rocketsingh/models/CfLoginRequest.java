package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 21-Nov-17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CfLoginRequest {

    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("loginKey")
    @Expose
    private String loginKey;
    @SerializedName("loginSecret")
    @Expose
    private String loginSecret;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getLoginKey() {
        return loginKey;
    }

    public void setLoginKey(String loginKey) {
        this.loginKey = loginKey;
    }

    public String getLoginSecret() {
        return loginSecret;
    }

    public void setLoginSecret(String loginSecret) {
        this.loginSecret = loginSecret;
    }

}
