package com.nowfloats.rocketsingh.models;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.List;
public class UpdateReceiptInSORequest {

    @SerializedName("method")
    @Expose
    private String method;
    @SerializedName("jsonrpc")
    @Expose
    private String jsonrpc;
    @SerializedName("params")
    @Expose
    private Params params;

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public UpdateReceiptInSORequest withMethod(String method) {
        this.method = method;
        return this;
    }

    public String getJsonrpc() {
        return jsonrpc;
    }

    public void setJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
    }

    public UpdateReceiptInSORequest withJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
        return this;
    }

    public Params getParams() {
        return params;
    }

    public void setParams(Params params) {
        this.params = params;
    }

    public UpdateReceiptInSORequest withParams(Params params) {
        this.params = params;
        return this;
    }

    public static class Params {

        @SerializedName("service")
        @Expose
        private String service;
        @SerializedName("method")
        @Expose
        private String method;
        @SerializedName("args")
        @Expose
        private List<Object> args = null;

        public String getService() {
            return service;
        }

        public void setService(String service) {
            this.service = service;
        }

        public Params withService(String service) {
            this.service = service;
            return this;
        }

        public String getMethod() {
            return method;
        }

        public void setMethod(String method) {
            this.method = method;
        }

        public Params withMethod(String method) {
            this.method = method;
            return this;
        }

        public List<Object> getArgs() {
            return args;
        }

        public void setArgs(List<Object> args) {
            this.args = args;
        }

        public Params withArgs(List<Object> args) {
            this.args = args;
            return this;
        }
    }



    public static class UserDetails {
        @SerializedName("claimId")
        @Expose
        private String claimId;

        @SerializedName("emailId")
        @Expose
        private String emailId;
        @SerializedName("salesOrderId")
        @Expose
        private Integer salesOrderId;
        @SerializedName("receiptPicBin")
        @Expose
        private String receiptPicBin;
        @SerializedName("receiptPicName")
        @Expose
        private String receiptPicName;

        public String getEmailId() {
            return emailId;
        }

        public void setEmailId(String emailId) {
            this.emailId = emailId;
        }

        public UserDetails withEmailId(String emailId) {
            this.emailId = emailId;
            return this;
        }

        public Integer getSalesOrderId() {
            return salesOrderId;
        }

        public void setSalesOrderId(Integer salesOrderId) {
            this.salesOrderId = salesOrderId;
        }

        public UserDetails withSalesOrderId(Integer salesOrderId) {
            this.salesOrderId = salesOrderId;
            return this;
        }

        public String getReceiptPicBin() {
            return receiptPicBin;
        }

        public void setReceiptPicBin(String receiptPicBin) {
            this.receiptPicBin = receiptPicBin;
        }

        public UserDetails withReceiptPicBin(String receiptPicBin) {
            this.receiptPicBin = receiptPicBin;
            return this;
        }

        public String getReceiptPicName() {
            return receiptPicName;
        }

        public void setReceiptPicName(String receiptPicName) {
            this.receiptPicName = receiptPicName;
        }

        public UserDetails withReceiptPicName(String receiptPicName) {
            this.receiptPicName = receiptPicName;
            return this;
        }

        public String getClaimId() {
            return claimId;
        }

        public void setClaimId(String claimId) {
            this.claimId = claimId;
        }
    }
}


