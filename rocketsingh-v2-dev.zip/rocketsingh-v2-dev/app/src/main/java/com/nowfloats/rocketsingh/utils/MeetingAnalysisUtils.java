package com.nowfloats.rocketsingh.utils;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import org.joda.time.DateTime;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import retrofit.mime.TypedInput;

public class MeetingAnalysisUtils {

    private Context currentActivityContext;

    public MeetingAnalysisUtils(Context context) {
        currentActivityContext = context;
    }

    public long printDifference(DateTime startDate, DateTime endDate) {
        //milliseconds
        long different = endDate.getMillis() - startDate.getMillis();

        System.out.println("startDate : " + startDate);
        System.out.println("endDate : " + endDate);
        System.out.println("different : " + different);

        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;

        return different / daysInMilli;
    }



    public void DisplayLog(String s) {
        if (s != null) {
            Log.i(Constants.TAG, s);
        }
    }

    public String getlatestTime(){
        Date todayDate = Calendar.getInstance().getTime();
        Calendar cl = Calendar. getInstance();
        cl.setTime(todayDate);
        cl.add(Calendar.HOUR, -24);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String todayString = formatter.format(todayDate);
        String inputFormat = "yyyy-MM-dd HH:mm:ss";
        String outputFormat = "yyyy-MM-dd";
        String outputTodayDate;
        SimpleDateFormat sdfInput = new SimpleDateFormat(inputFormat, Locale.ENGLISH);
        SimpleDateFormat sdfOutput = new SimpleDateFormat(outputFormat,Locale.ENGLISH);

        // Convert to local time zone
        sdfInput.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));
        sdfOutput.setTimeZone(TimeZone.getTimeZone("GMT"));

        try {

            Date parsedToday = sdfInput.parse(todayString);
            outputTodayDate = sdfOutput.format(parsedToday);

            return outputTodayDate;
        } catch (Exception e) {
            Log.e("formattedDateFromString", "Exception in formateDateFromstring(): " + e.getMessage());
        }
        return "";
    }

    public String getCurrentDate(){
        Date todayDate = Calendar.getInstance().getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
        String todayString = formatter.format(todayDate);
        return todayString;
    }


    public String parseDate(String inputDate) {
        String inputPattern = "yyyy-dd-MM";
        String outputPattern = "dd-MMMM-yyyy";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);
        Date date ;
        String str = null;

        try {
            date = inputFormat.parse(inputDate);
            str = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return str;
    }


    public JSONObject getJsonFromTypedInput(TypedInput Body) {

        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(Body.in()));
            StringBuilder out = new StringBuilder();
            String newLine = System.getProperty("line.separator");
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line);
                out.append(newLine);
            }

            return new JSONObject(out.toString());
        } catch (IOException e) {
            e.printStackTrace();
            // return new JSONObject();
        } catch (JSONException e) {
            e.printStackTrace();
            //new JSONObject();
        }
        return new JSONObject();
    }

    public void DisplayToast(String message){
        Toast.makeText(currentActivityContext,message,Toast.LENGTH_LONG).show();
    }
}
