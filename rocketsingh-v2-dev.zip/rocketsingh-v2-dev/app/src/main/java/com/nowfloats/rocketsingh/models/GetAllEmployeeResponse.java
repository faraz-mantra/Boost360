package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetAllEmployeeResponse {

    @SerializedName("division")
    @Expose
    private String division;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("designation")
    @Expose
    private String designation;
    @SerializedName("employeeId")
    @Expose
    private String employeeId;
    @SerializedName("CFT")
    @Expose
    private Object cFT;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("fosHandle")
    @Expose
    private Object fosHandle;

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public Object getCFT() {
        return cFT;
    }

    public void setCFT(Object cFT) {
        this.cFT = cFT;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Object getFosHandle() {
        return fosHandle;
    }

    public void setFosHandle(Object fosHandle) {
        this.fosHandle = fosHandle;
    }

}