package com.nowfloats.rocketsingh.utils;

import android.os.Build;
import androidx.annotation.RequiresApi;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.nowfloats.rocketsingh.interfaces.SignupInterface;
import com.nowfloats.rocketsingh.models.GetAssignedCHCForPartnerRequest;
import com.nowfloats.rocketsingh.models.GetAssignedCHCForPartnerResponse;
import com.nowfloats.rocketsingh.models.MeetingsStatsForCFResponse;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;

public class MeetingSummaryUtils {

    private static MeetingSummaryUtils meetingSummaryUtils;
    private MeetingSummaryInterface meetingSummaryInterface;

    private MeetingSummaryUtils(){

    }

    public static MeetingSummaryUtils getInstance(){
        if(meetingSummaryUtils == null ){
            synchronized (MeetingSummaryUtils.class) {
                if(meetingSummaryUtils == null ){
                    meetingSummaryUtils = new MeetingSummaryUtils();
                }
            }
        }
        return meetingSummaryUtils;
    }

//    public MeetingSummaryInterface getMeetingSummaryInterface() {
//        return meetingSummaryInterface;
//    }

    public MeetingSummaryUtils setMeetingSummaryInterface(MeetingSummaryInterface meetingSummaryInterface) {
        this.meetingSummaryInterface = meetingSummaryInterface;
        return this;
    }

    public interface  MeetingSummaryInterface {

        void onEmptyMeetingsData(boolean b);
        void onMeetingsDataResponse(MeetingsStatsForCFResponse dataResponse , String title);
        void setRecyclerViewAdapter();
        void showProgressbar();

    }

    public MeetingSummaryUtils startGettingData(String cfUsername ){
        meetingSummaryInterface.showProgressbar();
        getFpTagsForCF(cfUsername);
        return this;
    }

    private void getFpTagsForCF(String cfUsername) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.NOW_FLOATS_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("cfmeetings23235616")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        HashMap<String,String> request = new HashMap<>();
        request.put("clientId", Constants.FOSClientId);
        request.put("offset","0");
        request.put("FpStatus","0");
        request.put("isCHCAssigned","true");
        GetAssignedCHCForPartnerRequest model = new GetAssignedCHCForPartnerRequest();
        model.setFptags(null);
        model.setBranchIds(null);
        model.setCustomerCities(null);
        model.setSalesPersonIds(null);
        List<String> usernames = new ArrayList<>();
        usernames.add(cfUsername);
        model.setUsernames(usernames);
        signupInterface.getAssignedCHC(request, model,  new Callback<GetAssignedCHCForPartnerResponse>() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void success(GetAssignedCHCForPartnerResponse dataResponse, retrofit.client.Response response) {

                if (dataResponse == null || response.getStatus() != 200) {
                    //error message
                    showLog("problem while getting fp");
                }else
                {
                   // showLog();
                    getCFMeetingStats(dataResponse.getResult().getFpTags());
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                showLog(error.getMessage());
                //error message
            }
        });
    }

    private void getCFMeetingStats(List<String> fpTags) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        HashMap<String,String> request = new HashMap<>();
        request.put("authClientId", Constants.FOSClientId);
        Date todayDate = Calendar.getInstance().getTime();
        Calendar cl = Calendar. getInstance();
        cl.setTime(todayDate);
        cl.add(Calendar.HOUR, -24*30);
        Date prevDate = cl.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String todayString = formatter.format(todayDate);
        String prevDayString = formatter.format(prevDate);
        String inputFormat = "yyyy-MM-dd HH:mm:ss";
        String outputFormat = "yyyy-MM-dd";
        String outputTodayDate = "", outputPrevDayDate = "";
        SimpleDateFormat sdfInput = new SimpleDateFormat(inputFormat, Locale.ENGLISH);
        SimpleDateFormat sdfOutput = new SimpleDateFormat(outputFormat,Locale.ENGLISH);

        // Convert to local time zone
        sdfInput.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));
        sdfOutput.setTimeZone(TimeZone.getTimeZone("GMT"));

        try {
            Date parsedToday = sdfInput.parse(todayString);
            Date parsedPrevDay = sdfInput.parse(prevDayString);
            outputTodayDate = sdfOutput.format(parsedToday);
            outputPrevDayDate = sdfOutput.format(parsedPrevDay);
        } catch (Exception e) {
            Log.e("formattedDateFromString", "Exception in formateDateFromstring(): " + e.getMessage());
        }
        request.put("startDateTime",outputPrevDayDate);
        request.put("endDateTime",outputTodayDate);
        String finalOutputPrevDayDate = outputPrevDayDate;
        signupInterface.getCFMeetingSummary(request, fpTags, new Callback<MeetingsStatsForCFResponse>() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void success(MeetingsStatsForCFResponse dataResponse, retrofit.client.Response response) {

                showLog(new Gson().toJson(dataResponse));

                if (dataResponse == null || response.getStatus() != 200) {
                    //error message
                    showLog("some error  occured");
                }else
                {
                    String title = "Meeting summary as of " + parseDate(finalOutputPrevDayDate);
                   meetingSummaryInterface.onMeetingsDataResponse(dataResponse , title);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                showLog(error.getMessage());
                //error message
            }
        });
    }

    private String parseDate(String inputDate) {
        String inputPattern = "yyyy-MM-dd";
        String outputPattern = "dd-MMM-yyyy";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);

        Date date ;
        String str = null;

        try {
            date = inputFormat.parse(inputDate);
            str = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return str;
    }

    private void showLog(String message ){
        Log.i("meetingscf2323" , TextUtils.isEmpty(message) ? "null message " : message);
    }

}
