package com.nowfloats.rocketsingh.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.anachat.chatsdk.AnaCore;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.kbeanie.multipicker.api.CacheLocation;
import com.kbeanie.multipicker.api.ImagePicker;
import com.kbeanie.multipicker.api.Picker;
import com.kbeanie.multipicker.api.callbacks.ImagePickerCallback;
import com.kbeanie.multipicker.api.entity.ChosenImage;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;


import net.alexandroid.gps.GpsStatusDetector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import pub.devrel.easypermissions.EasyPermissions;


import static com.nowfloats.rocketsingh.utils.ExternalProcessManager.showLog;


//import static com.example.//.//.LOCATION_SETTING_REQUEST_CODE;

public class ExternalActivity extends AppCompatActivity implements ImagePickerCallback,  EasyPermissions.PermissionCallbacks  , GpsStatusDetector.GpsStatusDetectorCallBack{

    private ImagePicker imagePicker;
    private ExternalProcessManager externalProcessManager;
    private final int LONG_TIME_INTERVAL_LOCATION = 10000;
    private final int GPS_STATUS_CODE = 2 ;
    private final int SHORT_TIME_INTERVAL_LOCATION = 5000;
    private double latitude = -1, longitude = -1;
    private LocationManager locationManager;
    private int PLACE_PICKER_REQUEST = 1238;
    private String activityAction = "";
    private GpsStatusDetector gpsStatusDetector;


    String action = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_upload);
        Intent i = getIntent();
        if (i != null) {
            action = i.getStringExtra("action");
        }

        externalProcessManager = ExternalProcessManager.getInstance();
        gpsStatusDetector = new GpsStatusDetector(this);
        if (action != null) {
            this.activityAction = action;
            if (action.equals(Constants.INVOKE_IMAGE_CHOOSER)) {

                if (userHasProvidedWithPermission()) {
                    pickImageSingle();
                } else {
                    askForStoragePermission();
                }
            } else if (Constants.PICK_LOCATION_ACTION.equalsIgnoreCase(action)) {
                startPlacePickerActivity();
            } else if (Constants.GET_CURRENT_LOCATION.equalsIgnoreCase(action)) {
                if (EasyPermissions.hasPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION})) {
                    getCurrentLocation();
                } else {
                    EasyPermissions.requestPermissions(this, getString(R.string.permission_rationale), Constants.GET_CURRENT_LOCATION_PERMISSION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION);
                }
            } else {
                askForCallPermission();
            }
        }
    }

    private void getCurrentLocation() {
        gpsStatusDetector.checkGpsStatus();
    }

    public void askForCallPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, Constants.CALL_PERMISSION_KEY);
    }

    private boolean userHasProvidedWithPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int result = this.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return result == PackageManager.PERMISSION_GRANTED;
        }
        return false;
    }

    private void askForStoragePermission() {
        try {
            ActivityCompat.requestPermissions(ExternalActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    Constants.READ_STORAGE_PERMISSION_REQUEST_CODE);
        } catch (Exception e) {
            e.printStackTrace();
            DisplayLog(e.toString());
            throw e;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == Constants.READ_STORAGE_PERMISSION_REQUEST_CODE) {
            for (int i = 0; i < permissions.length; i++) {
                String permission = permissions[i];
                int grantResult = grantResults[i];
                if (permission.equals(Manifest.permission.WRITE_EXTERNAL_STORAGE) && grantResult == PackageManager.PERMISSION_GRANTED) {
                    pickImageSingle();
                    break;
                } else if (permission.equals(Manifest.permission.WRITE_EXTERNAL_STORAGE) && grantResult == PackageManager.PERMISSION_DENIED) {
                    sendFailedMessageToANA();
                }
            }
        } else if (requestCode == Constants.CALL_PERMISSION_KEY) {
            for (int i = 0; i < permissions.length; i++) {
                String permission = permissions[i];
                int grantResult = grantResults[i];
                if (permission.equals(Manifest.permission.CALL_PHONE) && grantResult == PackageManager.PERMISSION_GRANTED) {
                    String phoneNumber = externalProcessManager.getDeepLinkUrl().split("#")[1];
                    externalProcessManager.getExternalProcessInterface().callIntentForAna(phoneNumber);
                    break;
                } else if (permission.equals(Manifest.permission.CALL_PHONE) && grantResult == PackageManager.PERMISSION_DENIED) {
                    sendFailedMessageToANA("call");
                }
            }
            finish();
        } else if (requestCode == Constants.GET_CURRENT_LOCATION_PERMISSION) {
            EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
        }
    }

    private void startPlacePickerActivity() {
        try {
            Intent placePickerActivity = new PlacePicker.IntentBuilder()
                    .build(this);
            startActivityForResult(placePickerActivity, PLACE_PICKER_REQUEST);
        } catch (GooglePlayServicesRepairableException e) {
            e.printStackTrace();
            sendFailedMessageToANA();
        } catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
            sendFailedMessageToANA();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        DisplayLog("called");

        if (resultCode == ExternalActivity.RESULT_OK) {
            if (requestCode == Picker.PICK_IMAGE_DEVICE) {
                if (imagePicker == null) {
                    imagePicker = new ImagePicker(this);
                    imagePicker.setImagePickerCallback(this);
                }
                imagePicker.submit(data);
            } else if(requestCode == GPS_STATUS_CODE ){
                gpsStatusDetector.checkOnActivityResult(requestCode , resultCode);
            }
            else if (requestCode == Picker.PICK_IMAGE_DEVICE) {
                sendFailedMessageToANA();
            } else if (requestCode == PLACE_PICKER_REQUEST) {
                Place place = PlacePicker.getPlace(data, this);
                showLog(getPinCode(place.getLatLng().latitude, place.getLatLng().longitude));
                if (place.getAddress().toString().toLowerCase().contains("india"))
                    sendSuccessMessageToAnaForLocation(place, getPinCode(place.getLatLng().latitude, place.getLatLng().longitude));
                else {
                    displayToast("Please enter an Indian address.");
                    finish();
                }
            }
        } else {
            if (activityAction.equalsIgnoreCase(Constants.PICK_LOCATION_ACTION)) {
                displayToast("Please enter a valid address");
            } else if (requestCode == Constants.GET_CURRENT_LOCATION_PERMISSION) {
                displayToast("Sorry we need your location.");
            } else if(requestCode == GPS_STATUS_CODE) {
                onGpsSettingStatus(false);
            }
            finish();
        }
    }

    private void sendSuccessMessageToAnaForLocation(Place place, String zip) {
        HashMap<String, String> userData = new HashMap<>();
        userData.put("zip", zip);
        String address = place.getName() + " , " + place.getAddress();
        address = address.replace("\"", "");
        userData.put("address", address);
        userData.put("lat", place.getLatLng().latitude + "");
        userData.put("lng", place.getLatLng().longitude + "");
        AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext(), userData, externalProcessManager.getTitle(), externalProcessManager.getValue());
        finish();
    }

    public void sendLocationToAna(double lat, double lng) {
        HashMap<String, String> userData = new HashMap<>();
        userData.put("lat", lat + "");
        userData.put("lng", lng + "");
        AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext(), userData, externalProcessManager.getTitle(), externalProcessManager.getValue());
        //easyWayLocation.endUpdates();
        finish();
    }

    private void displayToast(String message) {
        if (!TextUtils.isEmpty(message))
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private String getPinCode(double latitude, double longitude) {
        Geocoder geocoder;
        List<Address> addresses = new ArrayList<>();
        geocoder = new Geocoder(this, Locale.getDefault());

        try {
            addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
        } catch (IOException e) {
            e.printStackTrace();
        }

//        String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
//        String city = addresses.get(0).getLocality();
//        String state = addresses.get(0).getAdminArea();
//        String country = addresses.get(0).getCountryName();
        if (addresses.size() > 0)
            return addresses.get(0).getPostalCode();
        else {
            displayToast("Sorry. This is not a valid address");
            finish();
            return "invalid";
        }
    }

    private void sendFailedMessageToANA() {
        HashMap<String, String> userData = new HashMap<>();
        userData.put("receiptSuccess", "false");
        AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext(), userData, externalProcessManager.getTitle(), externalProcessManager.getValue());
        finish();
    }


    private void sendFailedMessageToANA(String key) {
        HashMap<String, String> userData = new HashMap<>();
        userData.put(key, "false");
        AnaCore.sendDeeplinkEventData(externalProcessManager.getAnaChatContext(), userData, externalProcessManager.getTitle(), externalProcessManager.getValue());
        finish();
    }

    public void pickImageSingle() {
        imagePicker = new ImagePicker(this);
        imagePicker.setDebugglable(true);
        imagePicker.setFolderName("Random");
        imagePicker.setRequestId(1234);
        imagePicker.ensureMaxSize(500, 500);
        imagePicker.shouldGenerateMetadata(true);
        imagePicker.shouldGenerateThumbnails(true);
        imagePicker.setImagePickerCallback(this);
        Bundle bundle = new Bundle();
        bundle.putInt("android.intent.extras.CAMERA_FACING", 1);
        imagePicker.setCacheLocation(CacheLocation.EXTERNAL_STORAGE_PUBLIC_DIR);
        imagePicker.pickImage();
    }

    @Override
    public void onImagesChosen(List<ChosenImage> list) {
        for (ChosenImage image : list) {
            if (!(action.contains(Constants.RECEIPT_UPLOAD_ACTION) || action.contains(Constants.CHEQUE_UPLOAD_ACTION))) {
                Bitmap receiptImage = BitmapFactory.decodeFile(image.getThumbnailPath());
                String imageName = image.getDisplayName();
                if (externalProcessManager.getExternalProcessInterface() != null)
                    externalProcessManager.getExternalProcessInterface().onSalesOrderImageUploaded(receiptImage, imageName);
                else
                    sendFailedMessageToANA();
            } else {
                if (externalProcessManager.getExternalProcessInterface() != null)
                    externalProcessManager
                            .getExternalProcessInterface()
                            .sendImageFileToAna(image.getThumbnailPath(), externalProcessManager.getDeepLinkUrl());
                else
                    sendFailedMessageToANA();
            }
            finish();
        }
    }

    private void DisplayLog(String s) {
        Log.i("image23235616", s);
    }

    @Override
    public void onError(String s) {
        sendFailedMessageToANA();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        //sendFailedMessageToANA();
    }


    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        getCurrentLocation();
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        displayToast(getString(R.string.permission_rationale));
        finish();
    }




    private void getLocation() {

        try {

            locationManager = (LocationManager) this
                    .getSystemService(LOCATION_SERVICE);

            if (locationManager != null) {
                List<String> providers = locationManager.getProviders(true);
                Location bestLocation = null;
                for (String provider : providers) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                            && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        return;
                    }
                    locationManager.requestLocationUpdates(provider, 1000, 0, new LocationListener() {
                        @Override
                        public void onLocationChanged(Location location) {
                            if(location != null ){
                               //sendLocationToAna(location.getLatitude() , location.getLongitude());
                            }
                        }

                        @Override
                        public void onStatusChanged(String s, int i, Bundle bundle) {
                        }

                        @Override
                        public void onProviderEnabled(String s) {

                        }

                        @Override
                        public void onProviderDisabled(String s) {

                        }
                    });
                    Location l = locationManager.getLastKnownLocation(provider);
                    if (l == null) {
                        continue;
                    }
                    if (bestLocation == null
                            || l.getAccuracy() < bestLocation.getAccuracy()) {
                        bestLocation = l;
                    }
                }
                Location location = locationManager
                        .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (bestLocation != null) {
                    //use location
                    latitude = bestLocation.getLatitude();
                    longitude = bestLocation.getLongitude();
                    showLog(latitude+" , "+longitude);
                    sendLocationToAna(bestLocation.getLatitude() , bestLocation.getLongitude());
                }else if(location != null ){
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                    showLog(latitude+" , "+longitude);
                    sendLocationToAna(location.getLatitude() , location.getLongitude());
                }else{
                    sendLocationToAna(0 ,0);
                    displayToast("please wait , we are setting up");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            displayToast("please wait , we are setting up");
        }
    }

    @Override
    public void onGpsSettingStatus(boolean enabled) {

        if(enabled) {
            getLocation();
        }else{
            displayToast("Please enable gps first");
            finish();
        }
    }

    @Override
    public void onGpsAlertCanceledByUser() {
            displayToast("Sorry you need to enable gps in order to proceed");
            finish();
    }
}


