package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class FinalPaymentRequest {

    @SerializedName("products")
    @Expose
    private List<InitiatePaymentRequest.Product> products;

    @SerializedName("transactionId")
    @Expose
    private String transactionId;
    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("base64Mode")
    @Expose
    private Boolean base64Mode;
    @SerializedName("alternateImage")
    @Expose
    private String alternateImage;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("totalPrice")
    @Expose
    private Double totalPrice;
    @SerializedName("chequeNumber")
    @Expose
    private String chequeNumber;
    @SerializedName("email")
    @Expose
    private String email;
    @SerializedName("bankName")
    @Expose
    private String bankName;
    @SerializedName("couponCode")
    @Expose
    private String couponCode;
    @SerializedName("fpId")
    @Expose
    private String fpId;
    @SerializedName("ifscCode")
    @Expose
    private String ifscCode;
    @SerializedName("rtgsId")
    @Expose
    private String rtgsId;
    @SerializedName("tdsPercentage")
    @Expose
    private Double tdsPercentage;
    @SerializedName("taxAmount")
    @Expose
    private Double taxAmount;
    @SerializedName("currencyCode")
    @Expose
    private String currencyCode;
    @SerializedName("gstNumber")
    @Expose
    private String gstNumber;
    @SerializedName("fpTag")
    @Expose
    private String fpTag;
    @SerializedName("bankAccountNumber")
    @Expose
    private String bankAccountNumber;
    @SerializedName("activationDate")
    @Expose
    private ActivationDate activationDate;
    @SerializedName("rtgsPayment")
    @Expose
    private Boolean rtgsPayment;
    @SerializedName("employeeId")
    @Expose
    private String employeeId;
    @SerializedName("lat")
    @Expose
    private String lat;
    @SerializedName("lng")
    @Expose
    private String lng;
    @SerializedName("baseAmount")
    @Expose
    private Double baseAmount;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Boolean getBase64Mode() {
        return base64Mode;
    }

    public void setBase64Mode(Boolean base64Mode) {
        this.base64Mode = base64Mode;
    }

    public String getAlternateImage() {
        return alternateImage;
    }

    public void setAlternateImage(String alternateImage) {
        this.alternateImage = alternateImage;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getChequeNumber() {
        return chequeNumber;
    }

    public void setChequeNumber(String chequeNumber) {
        this.chequeNumber = chequeNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public String getFpId() {
        return fpId;
    }

    public void setFpId(String fpId) {
        this.fpId = fpId;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getRtgsId() {
        return rtgsId;
    }

    public void setRtgsId(String rtgsId) {
        this.rtgsId = rtgsId;
    }

    public Double getTdsPercentage() {
        return tdsPercentage;
    }

    public void setTdsPercentage(Double tdsPercentage) {
        this.tdsPercentage = tdsPercentage;
    }

    public Double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(Double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getGstNumber() {
        return gstNumber;
    }

    public void setGstNumber(String gstNumber) {
        this.gstNumber = gstNumber;
    }

    public String getFpTag() {
        return fpTag;
    }

    public void setFpTag(String fpTag) {
        this.fpTag = fpTag;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public ActivationDate getActivationDate() {
        return activationDate;
    }

    public void setActivationDate(ActivationDate activationDate) {
        this.activationDate = activationDate;
    }

    public Boolean getRtgsPayment() {
        return rtgsPayment;
    }

    public void setRtgsPayment(Boolean rtgsPayment) {
        this.rtgsPayment = rtgsPayment;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public Double getBaseAmount() {
        return baseAmount;
    }

    public void setBaseAmount(Double baseAmount) {
        this.baseAmount = baseAmount;
    }

    public List<InitiatePaymentRequest.Product> getProducts() {
        return products;
    }

    public void setProducts(List<InitiatePaymentRequest.Product> products) {
        this.products = products;
    }

    public static class ActivationDate {

        @SerializedName("mday")
        @Expose
        private Integer mday;
        @SerializedName("month")
        @Expose
        private Integer month;
        @SerializedName("year")
        @Expose
        private Integer year;

        public Integer getMday() {
            return mday;
        }

        public void setMday(Integer mday) {
            this.mday = mday;
        }

        public Integer getMonth() {
            return month;
        }

        public void setMonth(Integer month) {
            this.month = month;
        }

        public Integer getYear() {
            return year;
        }

        public void setYear(Integer year) {
            this.year = year;
        }

    }

}