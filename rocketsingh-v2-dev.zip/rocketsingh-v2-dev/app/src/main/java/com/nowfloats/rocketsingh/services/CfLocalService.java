package com.nowfloats.rocketsingh.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import androidx.annotation.RequiresApi;

import android.text.TextUtils;
import android.text.format.DateUtils;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.google.gson.Gson;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.interfaces.SignupInterface;
import com.nowfloats.rocketsingh.models.GetAssignedCHCForPartnerRequest;
import com.nowfloats.rocketsingh.models.GetAssignedCHCForPartnerResponse;
import com.nowfloats.rocketsingh.models.MeetingsStatsForCFResponse;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;

/**
 * Created by NowFloats on 15-Feb-18.
 */

public class CfLocalService extends Service {
    private NotificationManager mCFNM;
    // Unique Identification Number for the Notification.
    // We use it on Notification start, and to cancel it.
    private int CF_NOTIFICATION = R.string.local_service_started_for_CFs;
    private long LOCATION_POLLING_PERIOD = 1000;
    private UserSessionManager manager;
    /**
     * Class for clients to access.  Because we know this service always
     * runs in the same process as its clients, we don't need to deal with
     * IPC.
     */
    public class LocalBinder extends Binder {
        CfLocalService getService() {
            return CfLocalService.this;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onCreate() {
        mCFNM = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        // Display a notification about us starting.  We put an icon in the status bar.
        manager = new UserSessionManager(this);
        //InternalLocationManager.startLocationTracking(this);
        if(!TextUtils.isEmpty(manager.getCFUsername()))
        {
            getFpTagsForCF(manager.getCFUsername());
            looperCall(manager.getCFUsername());
            //locationLogLooper();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("CfLocalService", "Received start id " + startId + ": " + intent);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        // Cancel the persistent notification.
        mCFNM.cancel(CF_NOTIFICATION);
        // Tell the user we stopped.
        Toast.makeText(this, "CF Local Service Stopped", Toast.LENGTH_SHORT).show();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    // This is the object that receives interactions from clients.  See
    // RemoteService for a more complete example.
    private final IBinder mBinder = new LocalBinder();

    /**
     * Show a notification while this service is running.
     */

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void showCFNotification(String title, String body, String performance) {
        RemoteViews expandedView = new RemoteViews(getPackageName(), R.layout.notification_expanded);
        RemoteViews collapsedView = new RemoteViews(getPackageName(), R.layout.notification_collapsed);
        expandedView.setImageViewResource(R.id.big_icon, R.drawable.app_logo);
        expandedView.setTextViewText(R.id.timestamp, DateUtils.formatDateTime(this, System.currentTimeMillis(), DateUtils.FORMAT_SHOW_TIME));
        expandedView.setTextViewText(R.id.notification_message, body);
        expandedView.setTextViewText(R.id.content_title, title);
        expandedView.setTextViewText(R.id.content_text, body);
        collapsedView.setImageViewResource(R.id.big_icon, R.drawable.app_logo);
        collapsedView.setTextViewText(R.id.timestamp, DateUtils.formatDateTime(this, System.currentTimeMillis(), DateUtils.FORMAT_SHOW_TIME));
        collapsedView.setTextViewText(R.id.notification_message, body);
        collapsedView.setTextViewText(R.id.content_title, title);
        collapsedView.setTextViewText(R.id.content_text, body);
        switch (performance)
        {
            case "GOOD":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                break;
            case "AVERAGE":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.primary));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.primary));
                break;
            case "BAD":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                break;
            case "ABSENT":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                break;
            default:
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                break;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, GoogleLoginActivity.class), 0);
        String ChannelId = "channel_02";
        NotificationChannel channel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel(ChannelId, "RocketSinghCf", NotificationManager.IMPORTANCE_HIGH);
        }
        Notification.Builder mCFBuilder = new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_stat_logo_transparent)  // the status icon
                .setWhen(System.currentTimeMillis())  // the time stamp
                .setContentTitle(title)  // the label of the entry
                .setContentText(body)  // the contents of the entry
                .setContentIntent(contentIntent)  // The intent to send when the entry is clicked
                .setStyle(new Notification.BigTextStyle()
                        .bigText(body));
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mCFBuilder.setColor(getResources().getColor(R.color.primary));
        }
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mCFBuilder.setCustomBigContentView(expandedView);
            mCFBuilder.setCustomContentView(collapsedView);
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            mCFBuilder.setChannelId(ChannelId);
            mCFNM.createNotificationChannel(channel);
        }
        mCFNM.notify(CF_NOTIFICATION, mCFBuilder.build());
        startForeground(CF_NOTIFICATION, mCFBuilder.build());
    }




    private void getFpTagsForCF(String cfUsername) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.NOW_FLOATS_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("cfmeetings23235616")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        HashMap<String,String> request = new HashMap<String, String>();
        request.put("clientId", Constants.FOSClientId);
        request.put("offset","0");
        request.put("FpStatus","0");
        request.put("isCHCAssigned","true");
        GetAssignedCHCForPartnerRequest model = new GetAssignedCHCForPartnerRequest();
        model.setFptags(null);
        model.setBranchIds(null);
        model.setCustomerCities(null);
        model.setSalesPersonIds(null);
        List<String> usernames = new ArrayList<String>();
        usernames.add(cfUsername);
        model.setUsernames(usernames);
        signupInterface.getAssignedCHC(request, model,  new Callback<GetAssignedCHCForPartnerResponse>() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void success(GetAssignedCHCForPartnerResponse dataResponse, retrofit.client.Response response) {

                if (dataResponse == null || response.getStatus() != 200) {
                    //error message
                }else
                {
                    getCFMeetingStats(dataResponse.getResult().getFpTags());
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                //error message
            }
        });
    }

    private void getCFMeetingStats(List<String> fpTags) {
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.RIA_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        HashMap<String,String> request = new HashMap<String, String>();
        request.put("authClientId", Constants.FOSClientId);
        Date todayDate = Calendar.getInstance().getTime();
        Calendar cl = Calendar. getInstance();
        cl.setTime(todayDate);
        cl.add(Calendar.HOUR, -24*30);
        Date prevDate = cl.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String todayString = formatter.format(todayDate);
        String prevDayString = formatter.format(prevDate);
        String inputFormat = "yyyy-MM-dd HH:mm:ss";
        String outputFormat = "yyyy-MM-dd";
        String outputTodayDate = "", outputPrevDayDate = "";
        SimpleDateFormat sdfInput = new SimpleDateFormat(inputFormat, Locale.ENGLISH);
        SimpleDateFormat sdfOutput = new SimpleDateFormat(outputFormat,Locale.ENGLISH);

        // Convert to local time zone
        sdfInput.setTimeZone(TimeZone.getTimeZone("Asia/Calcutta"));
        sdfOutput.setTimeZone(TimeZone.getTimeZone("GMT"));

        try {
            Date parsedToday = sdfInput.parse(todayString);
            Date parsedPrevDay = sdfInput.parse(prevDayString);
            outputTodayDate = sdfOutput.format(parsedToday);
            outputPrevDayDate = sdfOutput.format(parsedPrevDay);
        } catch (Exception e) {
            Log.e("formattedDateFromString", "Exception in formateDateFromstring(): " + e.getMessage());
        }
        request.put("startDateTime",outputPrevDayDate);
        request.put("endDateTime",outputTodayDate);
        String finalOutputPrevDayDate = outputPrevDayDate;
        signupInterface.getCFMeetingSummary(request, fpTags, new Callback<MeetingsStatsForCFResponse>() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void success(MeetingsStatsForCFResponse dataResponse, retrofit.client.Response response) {

                ExternalProcessManager.getInstance().showLog(new Gson().toJson(dataResponse));

                if (dataResponse == null || response.getStatus() != 200) {
                    //error message
                }else
                {
                    String body = "Updated meetings :  " + dataResponse.getUpdatedMeetingsCount().getCount() + "\nMissed meetings :  " + dataResponse.getMissedMeetingsCount().getCount() + "\nRescheduled meetings :  " + dataResponse.getRescheduledMeetingsCount().getCount();
                    String title = "Meeting summary as of " + parseDate(finalOutputPrevDayDate);
                    String performance = "";
                    if(dataResponse.getUpdatedMeetingsCount().getCount() >= 3)
                        performance = "GOOD";
                    else
                        performance = "BAD";
                    showCFNotification(title, body, performance);
                }
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                //error message
            }
        });
    }

    public String parseDate(String inputDate) {
        String inputPattern = "yyyy-MM-dd";
        String outputPattern = "dd-MMM-yyyy";
        SimpleDateFormat inputFormat = new SimpleDateFormat(inputPattern);
        SimpleDateFormat outputFormat = new SimpleDateFormat(outputPattern);

        Date date = null;
        String str = null;

        try {
            date = inputFormat.parse(inputDate);
            str = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return str;
    }

    private void looperCall(final String cfUsername){
        new Handler().postDelayed(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void run() {
                if(!TextUtils.isEmpty(cfUsername))
                    getFpTagsForCF(cfUsername);
                looperCall(cfUsername);
            }
        },60*60*1000);
    }

//    public void locationLogLooper(){
//        new Handler().postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                InternalLocationManager.updateLocationLogs();
//                locationLogLooper();
//            }
//        } , LOCATION_POLLING_PERIOD);
//    }
}
