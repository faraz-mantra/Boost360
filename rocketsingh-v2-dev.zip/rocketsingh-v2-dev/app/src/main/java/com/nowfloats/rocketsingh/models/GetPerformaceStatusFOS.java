package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetPerformaceStatusFOS {

    @SerializedName("tickets")
    @Expose
    private Integer tickets;
    @SerializedName("getPerformanceResponse")
    @Expose
    private GetPerformanceResponse getPerformanceResponse;

    public Integer getTickets() {
        return tickets;
    }

    public void setTickets(Integer tickets) {
        this.tickets = tickets;
    }

    public GetPerformanceResponse getGetPerformanceResponse() {
        return getPerformanceResponse;
    }

    public void setGetPerformanceResponse(GetPerformanceResponse getPerformanceResponse) {
        this.getPerformanceResponse = getPerformanceResponse;
    }

    public class GetPerformanceResponse {

        @SerializedName("lastDayPerformance")
        @Expose
        private String lastDayPerformance;
        @SerializedName("netRevenueTillDate")
        @Expose
        private String netRevenueTillDate;
        @SerializedName("numOfOrderTillDate")
        @Expose
        private Integer numOfOrderTillDate;
        @SerializedName("lastDayFolloupMeetingNum")
        @Expose
        private Integer lastDayFolloupMeetingNum;
        @SerializedName("lastDayNewMeetingNum")
        @Expose
        private Integer lastDayNewMeetingNum;
        @SerializedName("lastMeetingDate")
        @Expose
        private String lastMeetingDate;

        public String getLastDayPerformance() {
            return lastDayPerformance;
        }

        public void setLastDayPerformance(String lastDayPerformance) {
            this.lastDayPerformance = lastDayPerformance;
        }

        public String getNetRevenueTillDate() {
            return netRevenueTillDate;
        }

        public void setNetRevenueTillDate(String netRevenueTillDate) {
            this.netRevenueTillDate = netRevenueTillDate;
        }

        public Integer getNumOfOrderTillDate() {
            return numOfOrderTillDate;
        }

        public void setNumOfOrderTillDate(Integer numOfOrderTillDate) {
            this.numOfOrderTillDate = numOfOrderTillDate;
        }

        public Integer getLastDayFolloupMeetingNum() {
            return lastDayFolloupMeetingNum;
        }

        public void setLastDayFolloupMeetingNum(Integer lastDayFolloupMeetingNum) {
            this.lastDayFolloupMeetingNum = lastDayFolloupMeetingNum;
        }

        public Integer getLastDayNewMeetingNum() {
            return lastDayNewMeetingNum;
        }

        public void setLastDayNewMeetingNum(Integer lastDayNewMeetingNum) {
            this.lastDayNewMeetingNum = lastDayNewMeetingNum;
        }

        public String getLastMeetingDate() {
            return lastMeetingDate;
        }

        public void setLastMeetingDate(String lastMeetingDate) {
            this.lastMeetingDate = lastMeetingDate;
        }

    }

}
