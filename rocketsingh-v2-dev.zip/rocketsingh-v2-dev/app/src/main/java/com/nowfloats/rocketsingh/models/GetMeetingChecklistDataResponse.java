package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.Map;

/**
 * Created by NowFloats on 22-Mar-18.
 */

public class GetMeetingChecklistDataResponse {

    @SerializedName("FPTag")
    @Expose
    private String fPTag;
    @SerializedName("MeetingType")
    @Expose
    private String meetingType;
    @SerializedName("EngagementDay")
    @Expose
    private Integer engagementDay;
    @SerializedName("MeetingCustomId")
    @Expose
    private String meetingCustomId;
    @SerializedName("CapturedValues")
    @Expose
    private Map<String, String> capturedValues;
    @SerializedName("CreatedOn")
    @Expose
    private String createdOn;

    public String getFPTag() {
        return fPTag;
    }

    public void setFPTag(String fPTag) {
        this.fPTag = fPTag;
    }

    public String getMeetingType() {
        return meetingType;
    }

    public void setMeetingType(String meetingType) {
        this.meetingType = meetingType;
    }

    public Integer getEngagementDay() {
        return engagementDay;
    }

    public void setEngagementDay(Integer engagementDay) {
        this.engagementDay = engagementDay;
    }

    public String getMeetingCustomId() {
        return meetingCustomId;
    }

    public void setMeetingCustomId(String meetingCustomId) {
        this.meetingCustomId = meetingCustomId;
    }

    public Map<String, String> getCapturedValues() {
        return capturedValues;
    }

    public void setCapturedValues(Map<String, String> capturedValues) {
        this.capturedValues = capturedValues;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }


}
