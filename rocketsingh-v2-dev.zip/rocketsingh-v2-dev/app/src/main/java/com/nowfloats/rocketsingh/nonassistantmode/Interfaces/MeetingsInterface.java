package com.nowfloats.rocketsingh.nonassistantmode.Interfaces;

import com.nowfloats.rocketsingh.models.LogMeetingRequest;
import com.nowfloats.rocketsingh.models.LogMeetingResponse;
import com.nowfloats.rocketsingh.models.ScheduleMeetingRequest;
import com.nowfloats.rocketsingh.models.ScheduleMeetingResponse;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.CustomCallback;

import java.util.HashMap;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Query;
import retrofit.http.QueryMap;

public interface MeetingsInterface {
    @GET("/Home/SendMeetingEmailToCustomerWithOTPGeneration")
    void sendOtpToPhoneNumber(@Query("Number") String number  , CustomCallback<String> callback);

    @GET("/Discover/v1/floatingpoint/VerifyOTP")
    void verifyOtp(@QueryMap HashMap<String,String> map , CustomCallback<Boolean> callback);

    @GET("/Support/v1/MissedCallVerification/RequestMissedCallVerification")
    void sendMissedCallRequest(@QueryMap HashMap<String,String> map , CustomCallback<String> callback);

    @GET("/Support/v1/MissedCallVerification/CheckVerificationStatus")
    void checkVerificationStatus(@QueryMap HashMap<String,String> map , CustomCallback<Boolean> callback);

    @POST("/api/Meetings/v2/ScheduleFOSMeeting")
    void scheduleMeeting(@Body ScheduleMeetingRequest scheduleMeetingRequest ,
                         CustomCallback<ScheduleMeetingResponse> customCallback);

    @POST("/api/Meetings/LogFOSMeeting")
    void LogMeeting(@Body LogMeetingRequest logMeetingRequest ,
                         CustomCallback<LogMeetingResponse> customCallback);


}
