package com.nowfloats.rocketsingh.interfaces;

import com.nowfloats.rocketsingh.adapters.ApprovalsRecyclerViewAdapter;
import com.nowfloats.rocketsingh.models.GetDafDataResponse;

public class AdapterInterface {
    public interface approvalsInterface{
        void onSendQuotation( String quoatationNumber );
        void onOrderPickup(GetDafDataResponse.Datum data);

    }
}
