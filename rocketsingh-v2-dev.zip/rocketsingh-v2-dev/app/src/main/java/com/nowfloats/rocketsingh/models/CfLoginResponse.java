package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 21-Nov-17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CfLoginResponse {

    @SerializedName("IsAuthenticated")
    @Expose
    private Boolean isAuthenticated;
    @SerializedName("address")
    @Expose
    private String address;
    @SerializedName("clientId")
    @Expose
    private String clientId;
    @SerializedName("companyDesc")
    @Expose
    private String companyDesc;
    @SerializedName("companyName")
    @Expose
    private String companyName;
    @SerializedName("companyType")
    @Expose
    private String companyType;
    @SerializedName("companyUrl")
    @Expose
    private String companyUrl;
    @SerializedName("floatingPointTags")
    @Expose
    private Object floatingPointTags;
    @SerializedName("isAccountApproved")
    @Expose
    private Boolean isAccountApproved;
    @SerializedName("partnerStatusDesc")
    @Expose
    private Object partnerStatusDesc;
    @SerializedName("primaryEmail")
    @Expose
    private String primaryEmail;
    @SerializedName("primaryName")
    @Expose
    private String primaryName;
    @SerializedName("primaryPhone")
    @Expose
    private String primaryPhone;
    @SerializedName("profileAccessType")
    @Expose
    private String profileAccessType;
    @SerializedName("status")
    @Expose
    private Integer status;
    @SerializedName("type")
    @Expose
    private Integer type;

    public Boolean getIsAuthenticated() {
        return isAuthenticated;
    }

    public void setIsAuthenticated(Boolean isAuthenticated) {
        this.isAuthenticated = isAuthenticated;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getCompanyDesc() {
        return companyDesc;
    }

    public void setCompanyDesc(String companyDesc) {
        this.companyDesc = companyDesc;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyType() {
        return companyType;
    }

    public void setCompanyType(String companyType) {
        this.companyType = companyType;
    }

    public String getCompanyUrl() {
        return companyUrl;
    }

    public void setCompanyUrl(String companyUrl) {
        this.companyUrl = companyUrl;
    }

    public Object getFloatingPointTags() {
        return floatingPointTags;
    }

    public void setFloatingPointTags(Object floatingPointTags) {
        this.floatingPointTags = floatingPointTags;
    }

    public Boolean getIsAccountApproved() {
        return isAccountApproved;
    }

    public void setIsAccountApproved(Boolean isAccountApproved) {
        this.isAccountApproved = isAccountApproved;
    }

    public Object getPartnerStatusDesc() {
        return partnerStatusDesc;
    }

    public void setPartnerStatusDesc(Object partnerStatusDesc) {
        this.partnerStatusDesc = partnerStatusDesc;
    }

    public String getPrimaryEmail() {
        return primaryEmail;
    }

    public void setPrimaryEmail(String primaryEmail) {
        this.primaryEmail = primaryEmail;
    }

    public String getPrimaryName() {
        return primaryName;
    }

    public void setPrimaryName(String primaryName) {
        this.primaryName = primaryName;
    }

    public String getPrimaryPhone() {
        return primaryPhone;
    }

    public void setPrimaryPhone(String primaryPhone) {
        this.primaryPhone = primaryPhone;
    }

    public String getProfileAccessType() {
        return profileAccessType;
    }

    public void setProfileAccessType(String profileAccessType) {
        this.profileAccessType = profileAccessType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

}