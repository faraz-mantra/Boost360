package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 27-Feb-18.
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EmployeesRankResponse {

    @SerializedName("empID")
    @Expose
    private String empID;
    @SerializedName("revenue")
    @Expose
    private String revenue;
    @SerializedName("nationalRank")
    @Expose
    private String nationalRank;
    @SerializedName("branchRank")
    @Expose
    private String branchRank;
    @SerializedName("branch")
    @Expose
    private String branch;
    @SerializedName("employee")
    @Expose
    private String employee;
    @SerializedName("email")
    @Expose
    private String email;

    public String getEmpID() {
        return empID;
    }

    public void setEmpID(String empID) {
        this.empID = empID;
    }

    public String getRevenue() {
        return revenue;
    }

    public void setRevenue(String revenue) {
        this.revenue = revenue;
    }

    public String getNationalRank() {
        return nationalRank;
    }

    public void setNationalRank(String nationalRank) {
        this.nationalRank = nationalRank;
    }

    public String getBranchRank() {
        return branchRank;
    }

    public void setBranchRank(String branchRank) {
        this.branchRank = branchRank;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getEmployee() {
        return employee;
    }

    public void setEmployee(String employee) {
        this.employee = employee;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}