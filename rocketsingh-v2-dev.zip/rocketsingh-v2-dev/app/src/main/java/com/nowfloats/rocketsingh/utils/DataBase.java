package com.nowfloats.rocketsingh.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by NowFloats on 12/01/2018.
 */

public class DataBase extends SQLiteOpenHelper {
    final static int DB_VERSION = 3;
    final static String DB_NAME = "nowfloats.s3db";

    final static String tableCFIds = "CFLoginIds";

    //Login table Column names
    public static final String colCFID="cfid";
    public static final String colCFPwd="cfpwd";

    Context context;
    String createCFIDsTable="CREATE TABLE IF NOT EXISTS "+ tableCFIds +" ( " + colCFID + " TEXT PRIMARY KEY ,"+colCFPwd+" TEXT DEFAULT '0')";

    public DataBase(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(createCFIDsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + createCFIDsTable);
        onCreate(db);
    }

    //Login Methods
    public Cursor getCFLoginPwd(String username){
        SQLiteDatabase qdb = this.getWritableDatabase();
        Cursor cursor = qdb.rawQuery("SELECT * FROM "+ tableCFIds  +" WHERE " + colCFID + " = '" + username + "'", null);
        return cursor;
    }

    public Cursor getCFIds(){
        SQLiteDatabase qdb = this.getWritableDatabase();
        Cursor cursor = qdb.rawQuery("SELECT " + colCFID + " FROM "+ tableCFIds  + " ", null);
        return cursor;
    }

    public void insertCFLoginData(String username, String password) {
        SQLiteDatabase qdb = this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(colCFID,username);
        cv.put(colCFPwd,password);
        long chk = qdb.insertWithOnConflict(tableCFIds,null,cv, SQLiteDatabase.CONFLICT_IGNORE);
        Log.i("insertLoginStatus-fp",""+chk);
        qdb.close();
    }

    public void updateCFPassword(String username, String password) {
        SQLiteDatabase qdb = this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put(colCFPwd,password);
        qdb.update(tableCFIds,cv,colCFID + " = '" + username + "'",null);
        qdb.close();
    }
}
