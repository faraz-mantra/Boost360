package com.nowfloats.rocketsingh.utils;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import androidx.core.app.ActivityCompat;
import android.text.TextUtils;
import android.util.Log;

import com.google.gson.Gson;
import com.nowfloats.rocketsingh.interfaces.AttendanceInterface;
import com.nowfloats.rocketsingh.models.LogLocationRequest;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;
import retrofit.client.Response;

import static android.content.Context.LOCATION_SERVICE;

public class InternalLocationManager {

    private static InternalLocationManager internalLocationManager;
    private LocationManager locationManager;

    private Context context;
    private UserSessionManager session;


    public static void startLocationTracking(Context context) {

        if (internalLocationManager == null) {
            synchronized (InternalLocationManager.class) {
                if (internalLocationManager == null) {

                    internalLocationManager = new InternalLocationManager();
                    internalLocationManager.context = context;
                    internalLocationManager.session = new UserSessionManager(context);

                    internalLocationManager.locationManager = (LocationManager) context
                            .getSystemService(LOCATION_SERVICE);

                    internalLocationManager.getInternalLocation();

                }
            }
        }
    }

    private void updateLocationLogs(){
        RestAdapter restAdapter = new RestAdapter.Builder().setLog(new AndroidLog("locationManagerLogs")).setEndpoint(Constants.NOW_FLOATS_API2_URL).build();
        AttendanceInterface attendanceInterface = restAdapter.create(AttendanceInterface.class);

        LogLocationRequest logLocationRequest = new LogLocationRequest();
        logLocationRequest.setEmail(session.getSalesId());
        logLocationRequest.setEmployeeID(session.getEmployeeId());
        logLocationRequest.setEventType(0);
        logLocationRequest.setLatitude((double) session.getLatitude());
        logLocationRequest.setLongitude((double) session.getLongitude());

        internalLocationManager.showServiceLog(new Gson().toJson(logLocationRequest));

       attendanceInterface.uploadAttendanceLog(Constants.clientId, logLocationRequest, new Callback<Boolean>() {
           @Override
           public void success(Boolean aBoolean, Response response) {
               if(response.getStatus() == 200) {
                   showServiceLog(aBoolean + "");
               }else{
                   showServiceLog(Constants.REQUEST_FAILED);
               }
           }

           @Override
           public void failure(RetrofitError error) {
                showServiceLog(error.getMessage());
           }
       });
    }

    private void showServiceLog(String s) {
        Log.i(InternalLocationManager.class.getSimpleName() , TextUtils.isEmpty(s) ? "NA":s);
    }


    private void getInternalLocation() {

        final int LOCATION_UPDATE_TIME = 1000;

        if (locationManager != null) {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
               locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, LOCATION_UPDATE_TIME, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {

                    session.setLatitude(location.getLatitude());
                    session.setLongitude(location.getLongitude());

                    ExternalProcessManager.showLog(session.getLatitude()+" , "+ session.getLongitude());

                }

                @Override
                public void onStatusChanged(String s, int i, Bundle bundle) {

                }

                @Override
                public void onProviderEnabled(String s) {

                }

                @Override
                public void onProviderDisabled(String s) {

                }
            });
            }

            updateLocationLogs();
            pingLocation();
    }

    private void pingLocation(){
        new Handler().postDelayed(() -> {
            updateLocationLogs();
            pingLocation();
        },Constants.UPDATE_LOCATION_LOG_FREQUENCY);


    }

}
