package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LogMeetingRequest {

    @SerializedName("calendar_id")
    @Expose
    private Integer calendarId;
    @SerializedName("demo_type")
    @Expose
    private String demoType;
    @SerializedName("contact_status")
    @Expose
    private String contactStatus;
    @SerializedName("status_after_meeting")
    @Expose
    private String statusAfterMeeting;
    @SerializedName("meeting_with_bm")
    @Expose
    private String meetingWithBm;
    @SerializedName("fptag")
    @Expose
    private String fptag;
    @SerializedName("latitude")
    @Expose
    private Double latitude;
    @SerializedName("longitude")
    @Expose
    private Double longitude;
    @SerializedName("description")
    @Expose
    private String description;

    public Integer getCalendarId() {
        return calendarId;
    }

    public void setCalendarId(Integer calendarId) {
        this.calendarId = calendarId;
    }

    public String getDemoType() {
        return demoType;
    }

    public void setDemoType(String demoType) {
        this.demoType = demoType;
    }

    public String getContactStatus() {
        return contactStatus;
    }

    public void setContactStatus(String contactStatus) {
        this.contactStatus = contactStatus;
    }

    public String getStatusAfterMeeting() {
        return statusAfterMeeting;
    }

    public void setStatusAfterMeeting(String statusAfterMeeting) {
        this.statusAfterMeeting = statusAfterMeeting;
    }

    public String getMeetingWithBm() {
        return meetingWithBm;
    }

    public void setMeetingWithBm(String meetingWithBm) {
        this.meetingWithBm = meetingWithBm;
    }

    public String getFptag() {
        return fptag;
    }

    public void setFptag(String fptag) {
        this.fptag = fptag;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}