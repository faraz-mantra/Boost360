package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ScheduleMeetingRequest {

    @SerializedName("opportunityRef")
    @Expose
    private String opportunityRef;
    @SerializedName("subject")
    @Expose
    private String subject;
    @SerializedName("incrementInMinutes")
    @Expose
    private Integer incrementInMinutes;
    @SerializedName("subjectLimit")
    @Expose
    private Integer subjectLimit;
    @SerializedName("fpTag")
    @Expose
    private String fpTag;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("latitude")
    @Expose
    private Double latitude;
    @SerializedName("longitude")
    @Expose
    private Double longitude;

    public String getOpportunityRef() {
        return opportunityRef;
    }

    public void setOpportunityRef(String opportunityRef) {
        this.opportunityRef = opportunityRef;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Integer getIncrementInMinutes() {
        return incrementInMinutes;
    }

    public void setIncrementInMinutes(Integer incrementInMinutes) {
        this.incrementInMinutes = incrementInMinutes;
    }

    public Integer getSubjectLimit() {
        return subjectLimit;
    }

    public void setSubjectLimit(Integer subjectLimit) {
        this.subjectLimit = subjectLimit;
    }

    public String getFpTag() {
        return fpTag;
    }

    public void setFpTag(String fpTag) {
        this.fpTag = fpTag;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

}
