package com.nowfloats.rocketsingh.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetProductsResponse {



    @SerializedName("jsonrpc")
    @Expose
    private String jsonrpc;
    @SerializedName("id")
    @Expose
    private Object id;
    @SerializedName("result")
    @Expose
    private List<Result> result = null;

    public String getJsonrpc() {
        return jsonrpc;
    }

    public void setJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
    }

    public GetProductsResponse withJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
        return this;
    }

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public GetProductsResponse withId(Object id) {
        this.id = id;
        return this;
    }

    public List<Result> getResult() {
        return result;
    }

    public void setResult(List<Result> result) {
        this.result = result;
    }

    public GetProductsResponse withResult(List<Result> result) {
        this.result = result;
        return this;
    }

    public class Result {

        private String ProductFPId = "";

        @SerializedName("default_minimum_qty")
        @Expose
        private Integer defaultMinimumQty;
        @SerializedName("product")
        @Expose
        private String product;
        @SerializedName("unitPrice")
        @Expose
        private Integer unitPrice;
        @SerializedName("product_id")
        @Expose
        private Integer productId;
        @SerializedName("max_default_discount")
        @Expose
        private Integer maxDefaultDiscount;

        public Integer getDefaultMinimumQty() {
            return defaultMinimumQty;
        }

        public void setDefaultMinimumQty(Integer defaultMinimumQty) {
            this.defaultMinimumQty = defaultMinimumQty;
        }

        public Result withDefaultMinimumQty(Integer defaultMinimumQty) {
            this.defaultMinimumQty = defaultMinimumQty;
            return this;
        }

        public String getProduct() {
            return product;
        }

        public void setProduct(String product) {
            this.product = product;
        }

        public Result withProduct(String product) {
            this.product = product;
            return this;
        }

        public Integer getUnitPrice() {
            return unitPrice;
        }

        public void setUnitPrice(Integer unitPrice) {
            this.unitPrice = unitPrice;
        }

        public Result withUnitPrice(Integer unitPrice) {
            this.unitPrice = unitPrice;
            return this;
        }

        public Integer getProductId() {
            return productId;
        }

        public void setProductId(Integer productId) {
            this.productId = productId;
        }

        public Result withProductId(Integer productId) {
            this.productId = productId;
            return this;
        }

        public Integer getMaxDefaultDiscount() {
            return maxDefaultDiscount;
        }

        public void setMaxDefaultDiscount(Integer maxDefaultDiscount) {
            this.maxDefaultDiscount = maxDefaultDiscount;
        }

        public Result withMaxDefaultDiscount(Integer maxDefaultDiscount) {
            this.maxDefaultDiscount = maxDefaultDiscount;
            return this;
        }

        public String getProductFPId() {
            return ProductFPId;
        }

        public void setProductFPId(String productFPId) {
            ProductFPId = productFPId;
        }
    }

}