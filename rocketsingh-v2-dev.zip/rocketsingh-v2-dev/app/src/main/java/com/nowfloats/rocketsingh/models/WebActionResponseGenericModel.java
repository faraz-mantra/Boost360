package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class WebActionResponseGenericModel<T> {


    @SerializedName("Data")
     @Expose
    private List<T> Data ;

    public List<T> getData() {
        return Data;
    }

    public void setData(List<T> data) {
        Data = data;
    }

    public static class Extra {

        @SerializedName("CurrentIndex")
        @Expose
        private Integer currentIndex;
        @SerializedName("TotalCount")
        @Expose
        private Integer totalCount;
        @SerializedName("PageSize")
        @Expose
        private Integer pageSize;

        public Integer getCurrentIndex() {
            return currentIndex;
        }

        public void setCurrentIndex(Integer currentIndex) {
            this.currentIndex = currentIndex;
        }

        public Extra withCurrentIndex(Integer currentIndex) {
            this.currentIndex = currentIndex;
            return this;
        }

        public Integer getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(Integer totalCount) {
            this.totalCount = totalCount;
        }

        public Extra withTotalCount(Integer totalCount) {
            this.totalCount = totalCount;
            return this;
        }

        public Integer getPageSize() {
            return pageSize;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

        public Extra withPageSize(Integer pageSize) {
            this.pageSize = pageSize;
            return this;
        }

    }

}
