package com.nowfloats.rocketsingh.activity;

/**
 * Created by NowFloats on 27-11-2017.
 */

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.adapters.ApprovalsRecyclerViewAdapter;
import com.nowfloats.rocketsingh.interfaces.AdapterInterface;
import com.nowfloats.rocketsingh.interfaces.SignupInterface;
import com.nowfloats.rocketsingh.models.GetDafDataResponse;
import com.nowfloats.rocketsingh.models.SendQuotationResponseModel;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;
import retrofit.client.Response;

import static com.nowfloats.rocketsingh.utils.ExternalProcessManager.showLog;


public class DiscountApprovalsActivity extends AppCompatActivity implements AdapterInterface.approvalsInterface{

    RecyclerView rvApprovals;
    ProgressDialog progressDialog;
    ApprovalsRecyclerViewAdapter mAdapter;
    ImageView ivBack;
    private TextView tvNoReq;
    private Button bt_Pending, bt_Others;
    Toolbar mToolbar;
    private LinearLayoutManager mLayoutManager;
    UserSessionManager manager;
    List<GetDafDataResponse.Datum> otherList = new ArrayList<>(), pendingList = new ArrayList<>();
    public static final RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.WEB_ACTION_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discount_approvals);
        mToolbar = findViewById(R.id.toolbar);
        ivBack = findViewById(R.id.ivBack);
        tvNoReq = findViewById(R.id.tv_NoReq);
        bt_Pending = findViewById(R.id.bt_pending);
        bt_Others = findViewById(R.id.bt_others);
        manager = new UserSessionManager(this);
        rvApprovals = findViewById(R.id.rvDiscountApprovals);
        rvApprovals.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        mLayoutManager = new LinearLayoutManager(this);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        GetDafData(manager.getSalesId());
        bt_Others.setOnClickListener((view -> { sortOthers(); }));
        bt_Pending.setOnClickListener((view -> {sortPending() ;}));
    }

    private void sortPending() {
        changeButtonState(bt_Pending , true);
        changeButtonState(bt_Others , false);
      if(pendingList != null){
          if(pendingList .size() > 0){
              setUplList();
              mAdapter = new ApprovalsRecyclerViewAdapter(pendingList , this);
              rvApprovals.setAdapter(mAdapter);
              mAdapter.notifyDataSetChanged();
          }else{
              showEmptyList();
          }
      }else{
          showEmptyList();
      }
    }

    private void changeButtonState(Button button , boolean state) {
        if(state) {
            button.setBackgroundResource(R.drawable.background_selected);
            button.setTextColor(Color.WHITE);
        }else{
            button.setBackgroundResource(R.drawable.backgoround_not_selected);
            button.setTextColor(Color.BLACK);
        }
    }

    private void sortOthers() {
        changeButtonState(bt_Pending , false);
        changeButtonState(bt_Others , true);
       if(otherList != null ){
           if(otherList.size() > 0){
               setUplList();
               mAdapter = new ApprovalsRecyclerViewAdapter(otherList ,this);
               rvApprovals.setAdapter(mAdapter);
               mAdapter.notifyDataSetChanged();
           }else{
               showEmptyList();
           }
       }
    }

    private void setUplList() {
        tvNoReq.setVisibility(View.GONE);
        rvApprovals.setVisibility(View.VISIBLE);
    }

    private void showEmptyList(){
        tvNoReq.setVisibility(View.VISIBLE);
        rvApprovals.setVisibility(View.GONE);
    }

    private void showProgressDialog(){
        if(progressDialog == null ) {
            progressDialog = ProgressDialog.show(DiscountApprovalsActivity.this, "", getString(R.string.please_wait));
        }else if(! progressDialog.isShowing()){
            progressDialog = ProgressDialog.show(DiscountApprovalsActivity.this,"",getString(R.string.please_wait));
        }
    }

    private void hideProgressDialog(){
        if(progressDialog != null ){
            if(progressDialog.isShowing()) {
                progressDialog.dismiss();
            }
        }
    }


    public void GetDafData(String salesId) {
        progressDialog = ProgressDialog.show(DiscountApprovalsActivity.this,"",getString(R.string.please_wait));
        SignupInterface getData = restAdapter.create(SignupInterface.class);
        getData.getDafData("{salesId:\""+salesId+"\"}",new Callback<GetDafDataResponse>() {
            @Override
            public void success(GetDafDataResponse getDafData, retrofit.client.Response response) {

                if (getDafData == null || response.getStatus() != 200) {
                    //error message
                    Toast.makeText(DiscountApprovalsActivity.this,"Invalid email!", Toast.LENGTH_SHORT).show();
                }else
                {
                     List<GetDafDataResponse.Datum> datar = getDafData.getData();
                    GetDafDataResponse.Extra datae = getDafData.getExtra();

                    if(datae.getTotalCount()==0) {
                        showEmptyList();
                    }
                    else {
                        for(GetDafDataResponse.Datum data  : datar) {
                            if(! data.getApproval().toLowerCase().contains("pending")) {
                                otherList.add(data);
                            }else{
                                pendingList.add(data);
                            }
                        }

                        tvNoReq.setVisibility(View.GONE);
                        rvApprovals.setVisibility(View.VISIBLE);
//                        mAdapter = new ApprovalsRecyclerViewAdapter(datar);
//                        rvApprovals.setAdapter(mAdapter);
//                        mAdapter.notifyDataSetChanged();
                        sortOthers();
                    }
                }
                hideProgressDialogTag();
            }

            @Override
            public void failure(RetrofitError error) {
                Log.d("", "" + error.getMessage());
                //error message
                hideProgressDialogTag();
                Toast.makeText(DiscountApprovalsActivity.this,"Something went wrong, please try again", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void hideProgressDialogTag(){
        if(progressDialog.isShowing() && !isFinishing()){
            progressDialog.dismiss();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);

    }

    @Override
    public void onSendQuotation(String hpNumber) {

        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        sendQuotation(hpNumber);
                        break;
                    case DialogInterface.BUTTON_NEGATIVE:
                      dialog.dismiss();
                        break;
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(DiscountApprovalsActivity.this);
        builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();
    }

    private void displayToast(String message){
        Toast.makeText(this,TextUtils.isEmpty(message)?"NA":message ,Toast.LENGTH_LONG).show();
    }

    @Override
    public void onOrderPickup(GetDafDataResponse.Datum data) {

        if(TextUtils.isEmpty(data.getFpTag())){
            displayToast("Sorry ! You dont have a customer's fp tag. ");
            return;
        }

        if(data.getFpTag().equalsIgnoreCase("none")){
            displayToast("Sorry ! You dont have a customer's fp tag. ");
            return;
        }

        String productName = data.getProductsQtyD().split("\\(")[0];
        String newproductName = "";
        String points = data.getNetAmt();
        String fpTag = data.getFpTag();
        String  discountApplied = "";
        if(data.getCouponCode() == null ){
            discountApplied = "No";
        }else if(data.getCouponCode().trim().equalsIgnoreCase("na")){
            discountApplied = "No";
        }else{
            discountApplied = "Yes";
        }
        String discountCoupon = data.getCouponCode();
        String packagetype = "";

        if(productName.toLowerCase().contains("point")){
            packagetype = 3+"";
            productName = data.getProductsQtyD().split("\\(")[1];
        }else{
//
            if(data.getSaleType().toLowerCase().contains("upgrade") || data.getSaleType().toLowerCase().contains("renewal")) {
                packagetype = 2+"";
            }else {
                packagetype = 1+"";
            }

            if(productName.toLowerCase().contains("boost360") || productName.toLowerCase().contains("boost lite")){
                String[] productNamesArray = productName.split("-");
//                if(productNamesArray.length == 3) {
//                    productName = productNamesArray[1]+" - "+productNamesArray[2];
//                }else if(productName.length() > 3) {
//                    productName = productNamesArray[1]+" - "+productNamesArray[2]+" - "+productNamesArray[3];
//                }



                int index = 0;
                for(String product : productNamesArray) {

                    if(productName.toLowerCase().contains("boost lite")) {
                        try{
                            Integer.parseInt(product.trim());
                            break;
                        }catch (Exception e){

                        }
                    }

                    if(!product.toLowerCase().contains(data.getSaleType().toLowerCase())) {
                        if(index != 0) {
                            newproductName += product+"-";
                        }
                    }
                    if(productName.toLowerCase().contains("boost360")){
                        if(index == 2){
                            break;
                        }
                    }


                    index++;
                }
            }

            productName = newproductName.trim();
            if(! productName.toLowerCase().contains("point")){
                productName = productName.substring(0 , productName.length()-2);
            }
            showLog("Reporting order pickup for "+productName.trim());
        }

        Intent i = new Intent(this , GoogleLoginActivity.class);

        i.putExtra("productName",productName.trim());
        i.putExtra("discountApplied",discountApplied);
        i.putExtra("discountCoupon",discountCoupon);
        i.putExtra("packagetype",packagetype);
        i.putExtra("fpTag" , fpTag);
        i.putExtra("points",points);
        i.putExtra("action" , Constants.DISCOUNT_APPROVALS_ACTION);

        startActivity(i);

        finish();

    }

    private void sendQuotation(String hpNumber) {

        showProgressDialog();

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.SALES_ASSISTANT_API_URL)
                .setLog(new AndroidLog(DiscountApprovalsActivity.class.getSimpleName()))
                .build();

        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);

        Map<String , String > queryMap = new HashMap<>();
        queryMap.put("salesId" , manager.getSalesId());
        queryMap.put("hpNumber" ,  hpNumber);

        signupInterface.sendQuotation(queryMap, new Callback<SendQuotationResponseModel>() {
            @Override
            public void success(SendQuotationResponseModel sendQuotationResponseModel, Response response) {
                hideProgressDialog();
                if(sendQuotationResponseModel.getError().equalsIgnoreCase("yes")) {
                    DisplayToast(sendQuotationResponseModel.getMessage());
                }else{
                    DisplayToast("Quotation has been sent successfully");
                }
            }

            @Override
            public void failure(RetrofitError error) {
                hideProgressDialog();
                DisplayToast(error.getMessage());
            }
        });
    }

    private void DisplayToast (String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
