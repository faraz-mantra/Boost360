package com.nowfloats.rocketsingh.nonassistantmode.Fragments;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.SingleProductModel;
import com.nowfloats.rocketsingh.nonassistantmode.Adapter.ProductAdapter;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.FPSessionManager;

import java.util.Calendar;
import java.util.List;


public class InvoiceFragment extends Fragment implements ProductAdapter.OnProductSelectedInterface {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER


    // TODO: Rename and change types of parameters
    private SingleProductModel selectedProduct = null ;
    private TextView tv_productSelected;
    private ImageView im_downArrowForProduct;
    private boolean visibility;
    private int originHeightOfGstPanel ;
    private RecyclerView rv_productList;
    private float TDS =  0;
    public boolean isVisible;
    private RadioButton rb_Yes , rb_No;
    private Button bt_check , bt_rtgs;
    private EditText et_Gstn;
    private Double discountPercentage = 0.0 ;
    private Button bt_discountCoupon;
    private EditText et_couponCode;
    boolean couponApplied;
    private float taxPercentage = 18 ;
    private double netAmount , discountAmount , taxAmount , TDSAmount , baseAmount;
    private TextView tv_discountPercentage, tv_netAmount , tv_deducations , tv_gstAmount , tv_unitPrice; ;
    private List<SingleProductModel> singleProductModelList;

    private onInvoiceUpdated mListener;

    public InvoiceFragment() {
        // Required empty public constructor
    }


    public static InvoiceFragment newInstance(List<SingleProductModel> singleProductModels , onInvoiceUpdated onInvoiceUpdated) {
        InvoiceFragment fragment = new InvoiceFragment();
        fragment.singleProductModelList = singleProductModels;
        fragment.mListener = onInvoiceUpdated;
        return fragment;
    }

    public void setCustomerDetails(View v){
        FPSessionManager fpSessionManager = new FPSessionManager(getActivity());

        TextView tv_businessName = v.findViewById(R.id.tv_BusinessName);
        TextView tv_email = v.findViewById(R.id.tv_email);
        TextView tv_customerTag = v.findViewById(R.id.tv_customerTag);

        tv_businessName.setText(fpSessionManager.getBusinessName());
        tv_customerTag.setText(fpSessionManager.getFpTag());
        tv_email.setText(fpSessionManager.getEmail());

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_invoice, container, false);

        et_Gstn = v.findViewById(R.id.et_gst);

        initialiseProductView(v);
        setCustomerDetails(v);
        initialiseTDSCheckbox(v);
        setupNetAmountCard(v);
        initialiseCouponPanel(v);
        initialiseGSTPanel(v);
        initialiseButtons(v);

        return v;
    }

    public void initialiseGSTPanel(View v){
        et_Gstn = v.findViewById(R.id.et_gst);
        rb_No = v.findViewById(R.id.rb_no);
        rb_Yes = v.findViewById(R.id.rb_yes);
        et_Gstn.post(() -> originHeightOfGstPanel = et_Gstn.getMeasuredWidth());
        rb_Yes.setOnCheckedChangeListener((buttonView, isChecked) -> {
          if(isChecked)
              expandGSTField();
        });

        rb_No.setOnCheckedChangeListener(((buttonView, isChecked) -> {if(isChecked) collapseGSTField();}));
    }




    private void setupNetAmountCard(View v) {
        tv_discountPercentage = v.findViewById(R.id.tv_discountAmount);
        tv_gstAmount = v.findViewById(R.id.tv_tax);
        tv_netAmount = v.findViewById(R.id.tv_netAmount);
        tv_deducations = v.findViewById(R.id.tv_deducations);
        tv_unitPrice = v.findViewById(R.id.tv_unitPrice);
    }

    private void initialiseButtons(View v) {
        bt_check = v.findViewById(R.id.bt_check);
        bt_rtgs = v.findViewById(R.id.bt_RTGS);

        bt_rtgs.setOnClickListener(view -> {
            mListener.onInvoiceDetailsSubmitted(selectedProduct ,
                    (int) TDS,
                    TDSAmount ,
                    baseAmount ,
                    netAmount ,
                    taxAmount ,
                    rb_Yes.isChecked() ,
                    et_Gstn.getText().toString(),
                    false);
        });

        bt_check.setOnClickListener(view -> {
            mListener.onInvoiceDetailsSubmitted(selectedProduct ,
                    (int) TDS,
                    TDSAmount ,
                    baseAmount ,
                    netAmount ,
                    taxAmount ,
                    rb_Yes.isChecked() ,
                    et_Gstn.getText().toString(),
                    true);
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        isVisible = true;
    }

    private void initialiseTDSCheckbox(View v){
        CheckBox cb2 = v.findViewById(R.id.cb_2);
        CheckBox cb10 = v.findViewById(R.id.cb_10);
        cb2.setOnClickListener(v1 -> {
          if(cb2.isChecked()) {
              cb10.setChecked(false);
              TDS = 2 ;
          }else{
              TDS =  0;
          }
          updateNetAmount();
        });

        cb10.setOnClickListener(v1 -> {
            if(cb10.isChecked()) {
                cb2.setChecked(false);
                TDS = 10 ;
            }else{
                TDS = 0;
            }
            updateNetAmount();
        });
    }



    private void initialiseProductView(View v){
        rv_productList = v.findViewById(R.id.rv_productList);
        im_downArrowForProduct = v.findViewById(R.id.im_arrow);
        LinearLayout ll_productLayout = v.findViewById(R.id.ll_productSelected);
        tv_productSelected = v.findViewById(R.id.tv_productSelected);
        changeHeight(rv_productList , 0);
        ProductAdapter productAdapter = new ProductAdapter(singleProductModelList, this);
        rv_productList.setLayoutManager(new LinearLayoutManager(getContext()));
        rv_productList.setAdapter(productAdapter);
        im_downArrowForProduct.setOnClickListener((view)->{
            changeHeight(rv_productList ,visibility ? 0 : 50 * singleProductModelList.size());
            visibility = !visibility;
        });
        ll_productLayout.setOnClickListener(view -> im_downArrowForProduct.performClick());
    }

    private void changeHeight(View view , int height){

        ValueAnimator anim = ValueAnimator.ofInt(view.getMeasuredHeight(), height);
        anim.addUpdateListener(valueAnimator -> {
            int val = (Integer) valueAnimator.getAnimatedValue();
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            layoutParams.height = val;
            view.setLayoutParams(layoutParams);
        });
        anim.setDuration(600);
        anim.start();


    }

    private void updateNetAmount(){
        if(selectedProduct == null ) return;

        Double unitPrice = selectedProduct.getPrice();

        discountAmount = unitPrice * (discountPercentage/100);
        taxAmount = unitPrice * (taxPercentage / 100 );
        TDSAmount = (unitPrice - discountAmount) * (TDS / 100);

        netAmount = unitPrice - discountAmount + taxAmount;
        netAmount -= TDSAmount;

        baseAmount = unitPrice - discountAmount;

        tv_unitPrice.setText("Unit price : "+unitPrice);
        tv_deducations.setText("Deducations ("+TDS+"%) : "+round(TDSAmount));
        tv_gstAmount.setText("Goods and services tax ("+taxPercentage+")% : "+round(taxAmount));
        tv_netAmount.setText("Net amount " + round(netAmount));
        tv_discountPercentage.setText("Discount ("+discountPercentage+"%) : "+round(discountAmount));


    }

    private void changeWidth(View view , int width){

        int previousHeight = width == 0 ? originHeightOfGstPanel : view.getMeasuredHeight();

        if(width > 0)
            view.setVisibility(View.VISIBLE);

        ValueAnimator anim = ValueAnimator.ofInt(previousHeight, width);
        anim.addUpdateListener(valueAnimator -> {
            int val = (Integer) valueAnimator.getAnimatedValue();
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            layoutParams.width = val;
            view.setLayoutParams(layoutParams);
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                if(width == 0)
                    view.setVisibility(View.GONE);
            }
        });
        anim.setDuration(500/2);
        anim.start();

    }



    private void initialiseCouponPanel(View v){
        et_couponCode = v.findViewById(R.id.et_discountCoupon);
        bt_discountCoupon = v.findViewById(R.id.bt_apply_coupon);
        bt_discountCoupon.setOnClickListener((view) -> {
            if(! couponApplied)
                mListener.onCouponApplied(et_couponCode.getText().toString());
            else {
                et_couponCode.setText("");
                couponApplied = false ;
                discountPercentage = 0.0 ;
                updateNetAmount();
            }
        });
    }

    private double round(double a) {
        return Math.round(a*100)/100;
    }

    public void expandGSTField(){
        changeWidth(et_Gstn , originHeightOfGstPanel);
       // et_Gstn.setVisibility(View.VISIBLE);
    }




    public void collapseGSTField(){
        changeWidth(et_Gstn , 0);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
        isVisible = false;
    }

    @Override
    public void onProductSelected(SingleProductModel singleProductModel) {
        selectedProduct = singleProductModel;
        tv_productSelected.setText(selectedProduct.getName());
        visibility = !visibility;
        updateNetAmount();
        changeHeight(rv_productList , 0);
    }

    public void onDiscountApplied(Double discountPercentage){
        couponApplied = true;
        bt_discountCoupon.setText("Remove");
        this.discountPercentage = discountPercentage;
        updateNetAmount();
    }

    public interface onInvoiceUpdated {
        // TODO: Update argument type and name
        void onCouponApplied(String couponCode);
        void onInvoiceDetailsSubmitted(SingleProductModel singleProductModel ,
                                       int TDS , double tdsAmount ,
                                       double baseAmount , double netAmount ,
                                       double gstAmount , boolean gstApplied ,


                                       String gst , boolean checkPayment);
    }

}
