package com.nowfloats.rocketsingh.utils;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import com.nowfloats.rocketsingh.activity.ExternalActivity;

import org.joda.time.DateTime;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import retrofit.mime.TypedInput;
public class ExternalProcessManager {

    private String title,value,deepLinkUrl;
    private Context anaChatContext;
    private ExternalProcessInterface externalProcessInterface;
    private Intent externalActivityIntent ;
    private List<String> imageBase64s = new ArrayList<>();
    private static ExternalProcessManager instance ;


    public static ExternalProcessManager getInstance() {
        if (instance == null) {
            synchronized (ExternalProcessManager.class) {
                if (instance == null) {
                    instance = new ExternalProcessManager();
                }
            }
        }
        return instance;
    }

    public AppCompatActivity getANAActivity(){
        AppCompatActivity activity = (AppCompatActivity)anaChatContext;
        return activity;
    }
    public static long printDifference(DateTime startDate, DateTime endDate) {
        //milliseconds
        long different = endDate.getMillis() - startDate.getMillis();

        System.out.println("startDate : " + startDate);
        System.out.println("endDate : " + endDate);
        System.out.println("different : " + different);
        long secondsInMilli = 1000;
        long minutesInMilli = secondsInMilli * 60;
        long hoursInMilli = minutesInMilli * 60;
        long daysInMilli = hoursInMilli * 24;

        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        return elapsedDays;
    }

    public static String getDateFromAna(String date) {
        if(date.equals("{{DATE]}"))
            return getlatestTime();
        else {
            date = date.replace("\\u0027" , "");
            try {
                JSONObject tempObject = new JSONObject(date);
                long month = tempObject.getLong("month");
                long year = tempObject.getLong("year");
                long days = tempObject.getLong("mday");
                String yearString  = String.valueOf(year);
                String dayString = String.valueOf(days);
                String monthString  = String.valueOf(month);
                monthString = monthString.length() <2 ? "0" + monthString : monthString;
                dayString = dayString.length() <2 ? "0" + dayString : dayString;
                return yearString+"-"+monthString+"-"+dayString;
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return getlatestTime();
        }
    }

    public static String getlatestTime(){
        Date todayDate = Calendar.getInstance().getTime();
        Calendar cl = Calendar. getInstance();
        cl.setTime(todayDate);
        cl.add(Calendar.HOUR, -24);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String todayString = formatter.format(todayDate);
        String inputFormat = "yyyy-MM-dd HH:mm:ss";
        String outputFormat = "HH:mm:ss";
        String outputTodayDate = "";
        SimpleDateFormat sdfInput = new SimpleDateFormat(inputFormat, Locale.ENGLISH);
        SimpleDateFormat sdfOutput = new SimpleDateFormat(outputFormat,Locale.ENGLISH);
        // Convert to local time zone
        sdfInput.setTimeZone(TimeZone.getTimeZone("UTC"));

        try {
            Date parsedToday = sdfInput.parse(todayString);
            inputFormat = sdfInput.format(parsedToday);
            String dateString = inputFormat.substring(0,10);
            String timeString = inputFormat.substring(11);
            return dateString+"T"+timeString+"Z";
        } catch (Exception e) {
            Log.e("formattedDateFromString", "Exception in formateDateFromstring(): " + e.getMessage());
        }
        return "";
    }
    public String getCurrentDate(){
        Date todayDate = Calendar.getInstance().getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        String todayString = formatter.format(todayDate);
        return todayString;
    }
    public void addInImageList(Bitmap bitmap){
        if(bitmap !=null) {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            if( bitmap.getByteCount() > 10000000) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 30, outputStream);
            } else if (bitmap.getByteCount() > 7000000 ){
                bitmap.compress(Bitmap.CompressFormat.JPEG, 50, outputStream);
            }else{
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            }
            imageBase64s.add(Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT));
        }else{
            imageBase64s.add(null);
        }
    }

    public void clearImageList(){
        imageBase64s.clear();;
    }
    public static String getBase64StringFromImage(Bitmap bitmap){

        if(bitmap == null )
            return "";

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        byte[] byteFormat = stream.toByteArray();
        String imgString = Base64.encodeToString(byteFormat, Base64.NO_WRAP);
        return imgString;
    }
    public Context getAnaChatContext() throws NullPointerException{
        return anaChatContext;
    }

    public static boolean stringIsNull(String s) {
        if(s == null ){
            return false;
        }

        return s.trim().length() == 0;
    }

    public ExternalProcessManager setAnaChatContext(Context anaChatContext) {
        this.anaChatContext = anaChatContext;
        externalActivityIntent = new Intent(anaChatContext , ExternalActivity.class);
        return instance;
    }
    public String getValue() {
        return value;
    }
    public ExternalProcessManager setValue(String value) {
        this.value = value;
        return instance;
    }
    public String getTitle() {
        return title;
    }
    public ExternalProcessManager setTitle(String title) {
        this.title = title;
        return instance;
    }
    public String getDeepLinkUrl() {
        return deepLinkUrl;
    }
    public ExternalProcessManager(){}
    public static JSONObject getJsonFromTypedInput(TypedInput Body) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(Body.in()));
            StringBuilder out = new StringBuilder();
            String newLine = System.getProperty("line.separator");
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line);
                out.append(newLine);
            }
            return new JSONObject(out.toString());
        } catch (IOException e) {
            e.printStackTrace();
            // return new JSONObject();
        } catch (JSONException e) {
            e.printStackTrace();
            //new JSONObject();
        }
        return new JSONObject();
    }
    public String getTransactionId(){
        String transactionId = "";
        String[] payLoad = deepLinkUrl.split("#");
        if(payLoad.length>1){
            transactionId = payLoad[1];
        }
        return transactionId;
    }
    public ExternalProcessInterface getExternalProcessInterface() {
        return externalProcessInterface;
    }
    public ExternalProcessManager setExternalProcessInterface(ExternalProcessInterface externalProcessInterface) {
        this.externalProcessInterface = externalProcessInterface;
        return instance;
    }
    public ExternalProcessManager setDeepLinkUrl(String deepLinkUrl) {
        this.deepLinkUrl = deepLinkUrl;
        return instance;
    }

    public static void showLog(String message){
        Log.i(ExternalProcessManager.class.getSimpleName() , TextUtils.isEmpty(message) ?  " message is null" : message);
    }

    public List<String> getImageBase64s() {
        return imageBase64s;
    }

    public void showToast(String message){
        if(! TextUtils.isEmpty(message)) {
            Toast.makeText(getAnaChatContext() , message , Toast.LENGTH_LONG).show();
        }
    }

    public void setImageBase64s(List<String> imageBase64s) {
        this.imageBase64s = imageBase64s;
    }

    public interface ExternalProcessInterface {
        void onSalesOrderImageUploaded(Bitmap receiptImage,String imageName);
        void sendImageFileToAna(String filename , String key);
        void callIntentForAna(String number) ;

    }

    public String getBase64FromImage(String filename){
        Bitmap receiptImage = BitmapFactory.decodeFile(filename);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        receiptImage.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
        return Base64.encodeToString(outputStream.toByteArray(), Base64.DEFAULT);
    }

    public static String formatString(String message) {
        return TextUtils.isEmpty(message) ? "" : (message.length() == 1 ? message.toUpperCase() : (message.charAt(0)+"").toUpperCase()
        +message.substring(1, message.length() ));
    }

    public ExternalProcessManager startExternalActivity(){
        anaChatContext.startActivity(externalActivityIntent);
        return this;
    }

    public ExternalProcessManager setActions(String action){
        externalActivityIntent.putExtra("action",action);
        return this;
    }



}
