package com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils;

public class FLOW_SESSIONS {
    public static class DISCOUNT {
        public final static  short FP_DETAILS = 1 ;
        public final static short QUOTATION_DETAILS = 2 ;

    }

    public static class ORDER_PICKUP {
        public final static short FP_DETAILS = 1 ;
        public final static short VERIFY_COUPON = 2;
        public final static short EXECUTE_PAYMENT = 3 ;
    }

    public static class CLAIM_SALE {
        public final static short FP_DETAILS = 1;
        public final static short CLAIM_SALE = 2;
    }

    public static class CUSTOMER_VERIFICATION {
        public final static short SEND_OTP = 1 ;
        public final static short  VERIFY_OTP = 2 ;
        public final static short REQUEST_MISSED_CALL = 3;
        public final static short CHECK_MISSED_CALL = 4;
    }


}
