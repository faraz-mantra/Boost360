package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 21-Sep-17.
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetDafDataResponse {

    @SerializedName("Data")
    @Expose
    private List<Datum> data = null;
    @SerializedName("Extra")
    @Expose
    private Extra extra;

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

    public Extra getExtra() {
        return extra;
    }

    public void setExtra(Extra extra) {
        this.extra = extra;
    }

    public class Extra {

        @SerializedName("CurrentIndex")
        @Expose
        private Integer currentIndex;
        @SerializedName("TotalCount")
        @Expose
        private Integer totalCount;
        @SerializedName("PageSize")
        @Expose
        private Integer pageSize;

        public Integer getCurrentIndex() {
            return currentIndex;
        }

        public void setCurrentIndex(Integer currentIndex) {
            this.currentIndex = currentIndex;
        }

        public Integer getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(Integer totalCount) {
            this.totalCount = totalCount;
        }

        public Integer getPageSize() {
            return pageSize;
        }

        public void setPageSize(Integer pageSize) {
            this.pageSize = pageSize;
        }

    }

    public class Datum {

        @SerializedName("_id")
        @Expose
        private String id;
        @SerializedName("fcmId")
        @Expose
        private String fcmId;
        @SerializedName("salesId")
        @Expose
        private String salesId;
        @SerializedName("PINumber")
        @Expose
        private String pINumber;
        @SerializedName("fpTag")
        @Expose
        private String fpTag;
        @SerializedName("city")
        @Expose
        private String city;
        @SerializedName("salesName")
        @Expose
        private String salesName;
        @SerializedName("salesChannel")
        @Expose
        private String salesChannel;
        @SerializedName("saleType")
        @Expose
        private String saleType;
        @SerializedName("bizName")
        @Expose
        private String bizName;
        @SerializedName("products(qty)-d%")
        @Expose
        private String productsQtyD;
        @SerializedName("netAmt")
        @Expose
        private String netAmt;
        @SerializedName("nwRnwUpgr")
        @Expose
        private String nwRnwUpgr;
        @SerializedName("reason")
        @Expose
        private String reason;
        @SerializedName("lyson")
        @Expose
        private String lyson;
        @SerializedName("lyPrice")
        @Expose
        private String lyPrice;
        @SerializedName("approval")
        @Expose
        private String approval;
        @SerializedName("solNo")
        @Expose
        private String solNo;
        @SerializedName("fetchRequests")
        @Expose
        private String fetchRequests;
        @SerializedName("remarks")
        @Expose
        private String remarks;
        @SerializedName("customerSegment")
        @Expose
        private String customerSegment;
        @SerializedName("UserId")
        @Expose
        private String userId;
        @SerializedName("ActionId")
        @Expose
        private String actionId;
        @SerializedName("WebsiteId")
        @Expose
        private String websiteId;
        @SerializedName("CreatedOn")
        @Expose
        private String createdOn;
        @SerializedName("UpdatedOn")
        @Expose
        private String updatedOn;
        @SerializedName("IsArchived")
        @Expose
        private Boolean isArchived;

        @SerializedName("couponCode")
        @Expose
        private String couponCode;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getFcmId() {
            return fcmId;
        }

        public void setFcmId(String fcmId) {
            this.fcmId = fcmId;
        }

        public String getSolNo() {
            return solNo;
        }

        public void setSolNo(String solNo) {
            this.solNo = solNo;
        }

        public String getFetchRequests() {
            return fetchRequests;
        }

        public void setFetchRequests(String fetchRequests) {
            this.fetchRequests = fetchRequests;
        }

        public String getRemarks() {
            return remarks;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }

        public String getCustomerSegment() {
            return customerSegment;
        }

        public void setCustomerSegment(String customerSegment) {
            this.customerSegment = customerSegment;
        }

        public String getSalesId() {
            return salesId;
        }

        public void setSalesId(String salesId) {
            this.salesId = salesId;
        }

        public String getPINumber() {
            return pINumber;
        }

        public void setPINumber(String pINumber) {
            this.pINumber = pINumber;
        }

        public String getFpTag() {
            return fpTag;
        }

        public void setFpTag(String fpTag) {
            this.fpTag = fpTag;
        }

        public String getCity() {
            return city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getSalesName() {
            return salesName;
        }

        public void setSalesName(String salesName) {
            this.salesName = salesName;
        }

        public String getSalesChannel() {
            return salesChannel;
        }

        public void setSalesChannel(String salesChannel) {
            this.salesChannel = salesChannel;
        }

        public String getSaleType() {
            return saleType;
        }

        public void setSaleType(String saleType) {
            this.saleType = saleType;
        }

        public String getBizName() {
            return bizName;
        }

        public void setBizName(String bizName) {
            this.bizName = bizName;
        }

        public String getProductsQtyD() {
            return productsQtyD;
        }

        public void setProductsQtyD(String productsQtyD) {
            this.productsQtyD = productsQtyD;
        }

        public String getNetAmt() {
            return netAmt;
        }

        public void setNetAmt(String netAmt) {
            this.netAmt = netAmt;
        }

        public String getNwRnwUpgr() {
            return nwRnwUpgr;
        }

        public void setNwRnwUpgr(String nwRnwUpgr) {
            this.nwRnwUpgr = nwRnwUpgr;
        }

        public String getReason() {
            return reason;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }

        public String getLyson() {
            return lyson;
        }

        public void setLyson(String lyson) {
            this.lyson = lyson;
        }

        public String getLyPrice() {
            return lyPrice;
        }

        public void setLyPrice(String lyPrice) {
            this.lyPrice = lyPrice;
        }

        public String getApproval() {
            return approval;
        }

        public void setApproval(String approval) {
            this.approval = approval;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getActionId() {
            return actionId;
        }

        public void setActionId(String actionId) {
            this.actionId = actionId;
        }

        public String getWebsiteId() {
            return websiteId;
        }

        public void setWebsiteId(String websiteId) {
            this.websiteId = websiteId;
        }

        public String getCreatedOn() {
            return createdOn;
        }

        public void setCreatedOn(String createdOn) {
            this.createdOn = createdOn;
        }

        public String getUpdatedOn() {
            return updatedOn;
        }

        public void setUpdatedOn(String updatedOn) {
            this.updatedOn = updatedOn;
        }

        public Boolean getIsArchived() {
            return isArchived;
        }

        public void setIsArchived(Boolean isArchived) {
            this.isArchived = isArchived;
        }

        public String getCouponCode() {
            return couponCode;
        }

        public void setCouponCode(String couponCode) {
            this.couponCode = couponCode;
        }
    }

}

