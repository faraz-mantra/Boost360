package com.nowfloats.rocketsingh.interfaces;

import android.content.Context;

import java.util.List;

/**
 * Created by NowFloats on 22-Mar-18.
 */

public interface IQuesResponseCallback {

    void questionDialogAction(int index, int actionStatus, List<String> deepLinkValues, Context context);

    void questionResDialogAction(int index, int actionStatus, String engDay, Context context);
}
