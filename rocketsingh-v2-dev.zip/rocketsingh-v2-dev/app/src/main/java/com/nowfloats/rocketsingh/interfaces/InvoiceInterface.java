package com.nowfloats.rocketsingh.interfaces;

import com.nowfloats.rocketsingh.models.RedeemCouponRequest;
import com.nowfloats.rocketsingh.models.RedeemCouponResponse;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.POST;

public interface InvoiceInterface {

    @POST("/Payment/v1/Discount/RedeemDiscountCouponCode")
    void redeemDiscountCoupon(@Body RedeemCouponRequest redeemCouponRequest , Callback<RedeemCouponResponse> redeemCouponResponseCallback);
}
