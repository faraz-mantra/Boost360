package com.nowfloats.rocketsingh.nonassistantmode.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.SingleProductModel;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    private List<SingleProductModel> singleProductModelList;
    private OnProductSelectedInterface onProductSelectedInterface;

    private ProductAdapter(){}

    public  ProductAdapter(List<SingleProductModel> singleProductModels , OnProductSelectedInterface onProductSelectedInterface){
        this.singleProductModelList = singleProductModels;
        this.onProductSelectedInterface = onProductSelectedInterface;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ProductViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.package_list_row_v2 , parent , false));
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        SingleProductModel singleProductModel = singleProductModelList.get(holder.getAdapterPosition());
        holder.tv_productName.setText(singleProductModel.getName());
        holder.tv_price.setText("₹"+singleProductModel.getPrice());
    }

    @Override
    public int getItemCount() {
        return singleProductModelList.size();
    }


    protected class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView tv_price , tv_productName;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_price = itemView.findViewById(R.id.tv_price);
            tv_productName = itemView.findViewById(R.id.tv_productName);
            tv_productName.setOnClickListener(view -> onProductSelectedInterface.onProductSelected(
                    singleProductModelList.get(getAdapterPosition())
            ));
        }
    }

    public interface OnProductSelectedInterface {
        void onProductSelected(SingleProductModel singleProductModel);
    }
}
