package com.nowfloats.rocketsingh.nonassistantmode.Fragments;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.android.material.snackbar.Snackbar;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomEditText;
import com.tanmay.nf.rocketimagepicker.RocketImageInterface;
import com.tanmay.nf.rocketimagepicker.RocketImagePicker;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

public class CheckFragment extends DialogFragment implements RocketImageInterface {

    private View mainLayout;
    private CustomEditText et_accountNumber , et_accountName,et_ifscCode , et_rtgs;
    private Calendar choseDate = Calendar.getInstance();
    private Button bt_chequeDate , bt_payNow , bt_alternateImage , bt_primaryImage;
    private Bitmap primaryImage , alternateImage;
    private final int PRIMARY_IMAGE_UPLOAD = 1 ;
    private ImageView im_primaryImage , im_alternateImage;
    private final int ALTERNATE_IMAGE_UPLOAD = 2 ;
    private LinearLayout ll_alternateImage , ll_primaryImage;
    public static RocketImagePicker rocketImagePicker;
    private boolean checkPayment;
    private CheckInterface checkInterface;

    public static CheckFragment getInstance(CheckInterface checkInterface , boolean checkPayment) {
        CheckFragment checkFragment = new CheckFragment() ;
        checkFragment.checkPayment = checkPayment;
        checkFragment.checkInterface = checkInterface;
        return checkFragment;
    }



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_cheque , container , false);
        mainLayout = v;
        initialiseBankAccountDetails(v);
        setupOnClickListener();
        return v;
    }

    private void initialiseBankAccountDetails(View v){
        et_accountNumber = v.findViewById(R.id.et_accountNumber);
        et_accountName = v.findViewById(R.id.et_accountName);
        et_rtgs = v.findViewById(R.id.et_rtgs);
        et_ifscCode = v.findViewById(R.id.et_ifscCode);
        bt_chequeDate = v.findViewById(R.id.bt_checkDate);
        bt_payNow = v.findViewById(R.id.bt_payNow);
        im_primaryImage = v.findViewById(R.id.im_primaryImage);
        im_alternateImage = v.findViewById(R.id.im_alternateImage);
        bt_alternateImage = v.findViewById(R.id.bt_alternateImage);
        bt_primaryImage = v.findViewById(R.id.bt_primaryImage);
        ll_alternateImage = v.findViewById(R.id.ll_alternateImage);
        ll_primaryImage = v.findViewById(R.id.ll_primaryImage);

        et_accountName.setVisibility(returnVisibility(checkPayment));
        et_rtgs.setVisibility(returnVisibility(!checkPayment));
        et_ifscCode.setVisibility(returnVisibility(checkPayment));
        bt_chequeDate.setVisibility(returnVisibility(checkPayment));
        ll_alternateImage.setVisibility(returnVisibility(checkPayment));

    }

    private void setupOnClickListener() {
        DatePickerDialog.OnDateSetListener date = (view, year, monthOfYear, dayOfMonth) -> {
            // TODO Auto-generated method stub
            choseDate.set(Calendar.YEAR, year);
            choseDate.set(Calendar.MONTH, monthOfYear);
            choseDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        };

        bt_chequeDate.setOnClickListener(view -> {
            new DatePickerDialog(getContext(), date, choseDate
                    .get(Calendar.YEAR), choseDate.get(Calendar.MONTH),
                    choseDate.get(Calendar.DAY_OF_MONTH)).show();

            String myFormat = "MM/dd/yy";
            SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

            bt_chequeDate.setText(sdf.format(choseDate.getTime()));
        });

        bt_primaryImage.setOnClickListener( view -> {
            if(primaryImage == null ){
                invokeImagePicker(PRIMARY_IMAGE_UPLOAD);
            }else{
                primaryImage = null;
                im_primaryImage.setVisibility(View.GONE);
                bt_primaryImage.setText("Upload");
            }
        });

        bt_alternateImage.setOnClickListener( view -> {
            if(alternateImage == null ){
                invokeImagePicker(ALTERNATE_IMAGE_UPLOAD);
            }else{
                alternateImage = null;
                im_alternateImage.setVisibility(View.GONE);
                bt_alternateImage.setText("Upload");
            }
        });

        bt_payNow.setOnClickListener(view -> {
            checkInterface.onDetailsSubmitted(et_accountNumber.getText().toString() ,
                    et_accountName.getText().toString(),
                    et_ifscCode.getText().toString(),
                    et_rtgs.getText().toString(),
                    alternateImage ,
                    primaryImage ,

                    choseDate ,
                    checkPayment);
        });
    }

    private void invokeImagePicker(int requestCode) {
        rocketImagePicker = new RocketImagePicker((AppCompatActivity) getActivity() , this);
        rocketImagePicker.invokeImagePicker(requestCode);
    }


    @Override
    public void onImagePickerPermissionDenied(int imageRequestCode) {
        showSnackbarMessage("Sorry but we need this permission" , false);
    }

    @Override
    public void onImageSupplied(Bitmap bitmap, int imageRequestCode , String imageName) {
        switch (imageRequestCode) {
            case ALTERNATE_IMAGE_UPLOAD:
                alternateImage = bitmap;
                im_alternateImage.setVisibility(View.VISIBLE);
                im_alternateImage.setImageBitmap(alternateImage);
                bt_alternateImage.setText("Remove");
                break;
            case PRIMARY_IMAGE_UPLOAD:
                primaryImage = bitmap;
                im_primaryImage.setVisibility(View.VISIBLE);
                im_primaryImage.setImageBitmap(primaryImage);
                bt_primaryImage.setText("Remove");
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        rocketImagePicker.onRequestPermissionsResult(requestCode , grantResults);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        rocketImagePicker.onActivityResult(requestCode , resultCode , data);
    }

    @Override
    public void onImagePickFail(int imageRequestCode) {
        showSnackbarMessage("Sorry some problem occured, " +
                "while getting the image. Please try again" , false);
    }

    private void showSnackbarMessage(String message , boolean success){
        Snackbar snackbar =   Snackbar.make(mainLayout.findViewById(R.id.ll_parentLayoutcheck) , message , Snackbar.LENGTH_LONG);
        if( !success ) {
            snackbar.getView().setBackgroundColor(ContextCompat.getColor(getActivity() , R.color.red));
        }else{
            snackbar.getView().setBackgroundColor(ContextCompat.getColor(getActivity() , R.color.green));
        }
        snackbar.show();
    }

    public interface CheckInterface {
        void onDetailsSubmitted(String accountNumber ,
                                String accountName ,
                                String ifscCode ,
                                String rtgs ,
                                Bitmap alternateImage ,
                                Bitmap primaryImage,
                                Calendar calendar ,
                                boolean checkPayment);
    }

    private int returnVisibility(boolean r){
        return r ? View.VISIBLE : View.GONE;
    }


    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null)
        {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
        }

    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if(getDialog() != null)
            getDialog().getWindow()
                    .getAttributes().windowAnimations = R.style.DialogAnimation;
    }

}
