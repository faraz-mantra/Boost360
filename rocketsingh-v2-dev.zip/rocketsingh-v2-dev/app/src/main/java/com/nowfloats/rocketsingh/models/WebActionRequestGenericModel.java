package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class WebActionRequestGenericModel<T> {

    @SerializedName("ActionData")
    @Expose
    public T ActionData;

    @SerializedName("WebsiteId")
    @Expose
    public String WebsiteId;



}
