package com.nowfloats.rocketsingh.nonassistantmode.activity;

import android.content.Intent;
import android.os.Bundle;

import com.anachat.chatsdk.AnaChatBuilder;
import com.anachat.chatsdk.internal.database.PreferencesManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.os.Handler;
import android.util.Pair;
import android.view.Gravity;
import android.view.View;

import com.google.android.material.navigation.NavigationView;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.models.GetLeadDetailsResponse;
import com.nowfloats.rocketsingh.models.LogMeetingRequest;
import com.nowfloats.rocketsingh.models.ScheduleMeetingRequest;
import com.nowfloats.rocketsingh.models.ScheduleMeetingResponse;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.CustomerVerificationFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.SelectLeadFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Fragments.SidePanelFragment;
import com.nowfloats.rocketsingh.nonassistantmode.Interfaces.NetworkResultInterface;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomEditText;
import com.nowfloats.rocketsingh.nonassistantmode.UI.CustomLoader.CustomLoaderDialog;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NETWORK_OPERATIONS;
import com.nowfloats.rocketsingh.nonassistantmode.Utils.NeworksUtils.NetworkHandler;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.nowfloats.rocketsingh.utils.InternalLocationManager;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.LinkedList;
import java.util.Queue;

public class FOSMeetingActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener ,
        CustomerVerificationFragment.CustomerverficationInterface,
        SelectLeadFragment.SelectLeadInterface,
        NetworkResultInterface
        {

    private CustomEditText et_subject , et_description;
    private Button bt_logMeeting;
    private CustomLoaderDialog customLoaderDialog;
    private String customerPhoneNumber;
    private NetworkHandler networkHandler;
    LogMeetingRequest logMeetingRequest = new LogMeetingRequest();
    ScheduleMeetingRequest scheduleMeetingRequest = new ScheduleMeetingRequest();
    private RadioButton rb_question1 , rb_question2 , rb_question3 , rb_question4;
    private GetLeadDetailsResponse.Result selectedLead;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fosmeeting);
        setupDrawerLayout();


        logMeetingRequest.setContactStatus("yes");
        logMeetingRequest.setDemoType("Yes");
        logMeetingRequest.setStatusAfterMeeting("Interested");
        logMeetingRequest.setMeetingWithBm("Yes");

        et_subject = findViewById(R.id.et_subject);
        et_description = findViewById(R.id.et_description);

        rb_question1 = findViewById(R.id.rb1_yes); // were you able to meet the concerned person
        rb_question2 = findViewById(R.id.rb2_yes); // were you able to create a demo
        rb_question3 = findViewById(R.id.rb3_yes); // was teh customer interested
        rb_question4 = findViewById(R.id.rb4_yes); // did your BM assist you

        bt_logMeeting = findViewById(R.id.bt_logMeeting);

        rb_question2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked)
                logMeetingRequest.setDemoType("Yes");
            else
                logMeetingRequest.setDemoType("No");
        });

        rb_question1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked)
                logMeetingRequest.setContactStatus("yes");
            else
                logMeetingRequest.setContactStatus("no");
        });

        rb_question3.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked)
                logMeetingRequest.setStatusAfterMeeting("Interested");
            else
                logMeetingRequest.setContactStatus("Not Interested");
        });

        rb_question4.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked)
                logMeetingRequest.setMeetingWithBm("Yes");
            else
                logMeetingRequest.setContactStatus("No");
        });

        bt_logMeeting.setOnClickListener(view -> {

            if(selectedLead == null ){
                showSnackbarMessage(getString(R.string.select_customer_first) , false);
                return;
            }

            if(ExternalProcessManager.stringIsNull(et_description.getText().toString())) {
                showSnackbarMessage(getString(R.string.empty_meeting_description) , false);
                return;
            }

            if(ExternalProcessManager.stringIsNull(et_subject.getText().toString())) {
                showSnackbarMessage(getString(R.string.enter_meeting_subject), false);
                return;
            }


            if(et_description.getText().toString().trim().length() <= 100) {
                showSnackbarMessage(getString(R.string.invalid_meeting_description) , false);
                return;
            }

            scheduleMeetingRequest.setDescription(et_subject.getText().toString());
            scheduleMeetingRequest.setOpportunityRef(selectedLead.getName());
            scheduleMeetingRequest.setIncrementInMinutes(30);
            scheduleMeetingRequest.setSubjectLimit(0);
            scheduleMeetingRequest.setSubject(et_subject.getText().toString());
            scheduleMeetingRequest.setLatitude((double) new UserSessionManager(this).getLatitude());
            scheduleMeetingRequest.setLongitude((double) new UserSessionManager(this).getLongitude());

            logMeetingRequest.setDescription(et_description.getText().toString());
            logMeetingRequest.setLatitude((double) new UserSessionManager(this).getLatitude());
            logMeetingRequest.setLongitude((double) new UserSessionManager(this).getLongitude());

            startNetworkOperation();

        });

        InternalLocationManager.startLocationTracking(this);

        gotoFirstFragment();
    }


    private void gotoFirstFragment(){

        SelectLeadFragment selectLeadFragment = SelectLeadFragment.getInstance(customerPhoneNumber , this);
        getSupportFragmentManager().beginTransaction().add(R.id.meeting_parentLayout , selectLeadFragment).commit();

        CustomerVerificationFragment customerVerificationFragment = CustomerVerificationFragment.getInstance(this);
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction();
        customerVerificationFragment.show(fragmentManager , "customerVerificationDialog");
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.fosmeeting, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void startNetworkOperation(){
        networkHandler = new NetworkHandler(this , this);
        Queue<NETWORK_OPERATIONS> queue = new LinkedList<>();
        queue.add(NETWORK_OPERATIONS.SCHEDULE_MEETING);
        queue.add(NETWORK_OPERATIONS.LOG_MEETING);
        networkHandler.setNetworkOperationQueue(queue).startThread();
    }

    @Override
    public void onCustomerVerified(String number) {
        customerPhoneNumber = number;
    }

    @Override
    public void onLeadSelected(GetLeadDetailsResponse.Result result) {
        selectedLead = result;
    }

    @Override
    public void onApiRequestStarted(NETWORK_OPERATIONS network_operations) {
        initiateApiState(network_operations);
    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, String message) {
        updateApiStateInFpFragment(operationKey , message , true);
        networkHandler.executeNext();
    }

    @Override
    public void onApiSuccessfull(NETWORK_OPERATIONS operationKey, Object model, String message) {
        updateApiStateInFpFragment(operationKey , message , true);
        if(model instanceof ScheduleMeetingResponse) {
            ScheduleMeetingResponse temp = (ScheduleMeetingResponse)model;
            int calenderId = 0 ;
            try{
                calenderId = Integer.parseInt(temp.getServerObject()+"");
            }catch (NumberFormatException e) {
                networkHandler.clearNetworkQueue();
               onApiFail(operationKey , "Invalid calender ID");
               return;
            }
            logMeetingRequest.setCalendarId(calenderId);
        }
        networkHandler.executeNext();
    }

    @Override
    public void onApiFail(NETWORK_OPERATIONS operationKey, String errorMessage) {
        updateApiStateInFpFragment(operationKey , errorMessage , false);
    }

    @Override
    public void networkOperationsFinished(boolean success, short session) {
        finishApiProcessAnimation("Meeting logged successfully");
    }

    @Override
    public void prepareRequestBody(NETWORK_OPERATIONS network_operations, NetworkHandler networkHandler) {
        Pair<NETWORK_OPERATIONS ,Object> pair = null;
        switch (network_operations) {
            case SCHEDULE_MEETING:
                pair = new Pair<>(network_operations , scheduleMeetingRequest);
                break;
            case LOG_MEETING:
                pair = new Pair<>(network_operations , logMeetingRequest);
                break;
        }

        networkHandler.updateRequestBody(network_operations , pair !=null ? pair.second : null);
    }

    private void initiateApiState(NETWORK_OPERATIONS network_operations) {
        if(dialogIsValid()) {
            customLoaderDialog.initiateApiState(network_operations);
            return;
        }else {
            showDialog();
            new Handler().postDelayed(() -> {customLoaderDialog.initiateApiState(network_operations);} , 0);
        }

    }


    public boolean dialogIsValid(){
        return customLoaderDialog != null  && customLoaderDialog.isVisible();
    }

    private void showDialog() {
        if (customLoaderDialog == null) {
            customLoaderDialog = new CustomLoaderDialog();
        }

        if(customLoaderDialog.isVisible())
            return;
        // Create and show the dialog.
        customLoaderDialog = CustomLoaderDialog.newInstance();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.executePendingTransactions();
        customLoaderDialog.show(fragmentManager.beginTransaction(), "dialog");
    }


    public void updateApiStateInFpFragment(NETWORK_OPERATIONS network_operations , String message , boolean success) {
        if (success) {
            updateApiForSuccess(network_operations, message);

        } else {
            updateApiForFailure(network_operations, message);
        }
    }

    private void hideDialog(boolean delay){
        // delay is just for the effect

        if(customLoaderDialog == null )
            return;
        if(! customLoaderDialog.isVisible())
            return;

        new Handler().postDelayed(() -> {customLoaderDialog.closeDialog();} , delay ? 2500: 0);


    }

    private void updateApiForSuccess(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForSuccess(network_operations , message);
        }
    }

    public void finishApiProcessAnimation(String message){
        if(customLoaderDialog != null ){
            if(customLoaderDialog.isVisible()) {
                customLoaderDialog.showSuccessfulDialog(message);
            }
            hideDialog(true);
        }
    }

    private void updateApiForFailure(NETWORK_OPERATIONS network_operations, String message) {
        if(dialogIsValid()) {
            customLoaderDialog.updateApiForFailure(network_operations, message);
            hideDialog(true);
        }
    }

    private void showSnackbarMessage(String message , boolean success){
        Snackbar snackbar =   Snackbar.make(findViewById(R.id.meeting_parentLayout) , message , Snackbar.LENGTH_LONG);
        if( !success ) {
            snackbar.getView().setBackgroundColor(ContextCompat.getColor(this , R.color.red));
        }else{
            snackbar.getView().setBackgroundColor(ContextCompat.getColor(this , R.color.green));
        }
        snackbar.show();
    }

    private void setupDrawerLayout() {



        Toolbar toolbar = findViewById(R.id.custom_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setHomeButtonEnabled(true);
        SidePanelFragment sidePanelFragment = new SidePanelFragment();
        getSupportFragmentManager().beginTransaction().add(R.id.fm_fragment_navigation_drawer , sidePanelFragment).commitAllowingStateLoss();
        DrawerLayout mDrawerLayout = findViewById(R.id.drawer_layout);
        sidePanelFragment.setUp(findViewById(R.id.fm_fragment_navigation_drawer) , findViewById(R.id.drawer_layout) , toolbar);
        mDrawerLayout.closeDrawer(Gravity.LEFT);

        findViewById(R.id.im_selfMode).setOnClickListener(view -> {
            mDrawerLayout.openDrawer(findViewById(R.id.fm_fragment_navigation_drawer));
        });



        findViewById(R.id.im_startChat).setOnClickListener(view -> {
            Intent i = new Intent(view.getContext() , GoogleLoginActivity.class);
            i.setAction("startChat");
            startActivity(i);
        });
    }
}
