package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Contact {

    @SerializedName("ContactNumber")
    @Expose
    private String contactNumber;
    @SerializedName("ContactName")
    @Expose
    private String contactName;

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public Contact withContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
        return this;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public Contact withContactName(String contactName) {
        this.contactName = contactName;
        return this;
    }

}