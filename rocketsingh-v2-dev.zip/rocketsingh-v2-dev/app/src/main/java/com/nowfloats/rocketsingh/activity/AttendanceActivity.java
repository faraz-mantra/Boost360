package com.nowfloats.rocketsingh.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import com.google.android.material.snackbar.Snackbar;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.places.PlaceDetectionClient;
import com.google.android.gms.location.places.PlaceLikelihood;
import com.google.android.gms.location.places.PlaceLikelihoodBufferResponse;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.adapters.AttendanceAdapter;
import com.nowfloats.rocketsingh.interfaces.AttendanceAdapterInterface;
import com.nowfloats.rocketsingh.interfaces.ERPApiInterface;
import com.nowfloats.rocketsingh.models.GetDailyAttendanceRequest;
import com.nowfloats.rocketsingh.models.GetDailyAttendanceResponse;
import com.nowfloats.rocketsingh.models.GetSwipeStatusRequest;
import com.nowfloats.rocketsingh.models.GetSwipeStatusResponse;
import com.nowfloats.rocketsingh.models.UploadAttendanceRequest;
import com.nowfloats.rocketsingh.models.UploadAttendanceResponse;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.UserSessionManager;

import net.alexandroid.gps.GpsStatusDetector;

import java.util.ArrayList;
import java.util.List;

import pub.devrel.easypermissions.EasyPermissions;
import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;
import retrofit.client.Response;

public class AttendanceActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks, GpsStatusDetector.GpsStatusDetectorCallBack, AttendanceAdapterInterface {

    private Button bt_checkIn , bt_checkOut;

    private RecyclerView rv_attendaceDetails;

    private CheckBox cb_biomatricAttendance;

    private boolean locationDetected;

    private TextView tv_attendanceStatus, tv_attendanceDate, tv_address;

    private View parentLayout;

    private boolean attendanceStatus;
    //private boolean uploadAttendanceNow = false;
    private boolean checkBiometric = true;
    private GpsStatusDetector gpsStatusDetector;
    private ProgressDialog mProgressDialog;
    private double latitude = -1, longitude = -1;
    private LocationManager locationManager;
    private UserSessionManager manager;
    private LinearLayout ll_attendanceOptions;
    private ImageView iv_Info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendace);
        locationDetected = false;
        bt_checkIn = findViewById(R.id.bt_checkin);
        bt_checkOut = findViewById(R.id.bt_checkout);
        rv_attendaceDetails = findViewById(R.id.rv_attendanceDetails);
        cb_biomatricAttendance = findViewById(R.id.cb_biomatricNotWorking);
        tv_address = findViewById(R.id.tv_address);
        ll_attendanceOptions = findViewById(R.id.ll_attendanceOptions);
        parentLayout = findViewById(R.id.sv_parent_layout);
        tv_attendanceDate = findViewById(R.id.tv_attendanceDate);
        iv_Info = findViewById(R.id.iv_info);
        tv_attendanceStatus = findViewById(R.id.tv_attendance_status);
        gpsStatusDetector = new GpsStatusDetector(this);
        manager = new UserSessionManager(this);
        GetAllAttendanceDetails();
        getAttendanceStatus();
        cb_biomatricAttendance.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (attendanceStatus) {
                    displayToast("Sorry , this option is only available if you need to check IN ");
                    cb_biomatricAttendance.setChecked(!b);
                }
            }
        });


        bt_checkIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              /*  if (!checkBiometric && !cb_biomatricAttendance.isChecked()) {
                    displayToast("Please provide your biometric first");
                } else {
                    handlePermissions();
                }*/
                attendanceStatus = false; // while uploading the attendance , we will negate the attendance . Hence putting a 'false' here
              handlePermissions();

            }
        });

        bt_checkOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                attendanceStatus = true; // while uploading the attendance , we will negate the attendance . Hence putting a 'true' here
                handlePermissions();
            }
        });

        iv_Info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSnackBar(getString(R.string.refresh_report_statement));
            }
        });

    }

    private void uploadAttendance(boolean newAttendance) {

        //switchAttendance.setText(getSuitableText(!newAttendance));
        showProgressDialog();
        final UploadAttendanceRequest uploadAttendanceRequest = new UploadAttendanceRequest();
        uploadAttendanceRequest.setMethod(Constants.ERP_METHOD);
        uploadAttendanceRequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        UploadAttendanceRequest.Params params = new UploadAttendanceRequest.Params();
        params.setMethod(Constants.ERP_PARAM_METHOD);

        List<Object> args = new ArrayList<>();
        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);

        UploadAttendanceRequest.RequestObject requestObject = new UploadAttendanceRequest.RequestObject();
        args.add("actionPunchInOut");
        requestObject.setEmailId(manager.getSalesId());
        requestObject.setInOut(newAttendance ? 0 : 1);
        requestObject.setLatitude(latitude);
        requestObject.setLongitude(longitude);
        requestObject.setSwipeNW(cb_biomatricAttendance.isChecked());
        args.add(requestObject);
        params.setArgs(args);
        params.setService("object");
        uploadAttendanceRequest.setParams(params);

        showLog(new Gson().toJson(uploadAttendanceRequest));

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLog(new AndroidLog(AttendanceActivity.class.getSimpleName())).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        erpApiInterface.UploadAttendanceStatus(uploadAttendanceRequest, new Callback<UploadAttendanceResponse>() {
            @Override
            public void success(UploadAttendanceResponse attendanceResponse, Response response) {

                hideProgressDialog();
                if (response.getStatus() == 200) {
                    if (attendanceResponse != null) {
                        showLog(new Gson().toJson(attendanceResponse));
                        if (attendanceResponse.getResult() != null) {
                            if (attendanceResponse.getResult() > 0) {
                                //switchAttendance.setText(getSuitableText(!newAttendance));
                                attendanceStatus = newAttendance;
                                getAttendanceStatus();
                                //changeButtonStatus();

                            }
                        }
                    }
                    displayToast(getString(R.string.Attendance_uploaded));

                } else {
                    displayToast(getString(R.string.generic_error_message));
                }
            }

            @Override
            public void failure(RetrofitError error) {
                hideProgressDialog();
                displayToast(error.getMessage());
            }
        });

    }

    private void changeButtonStatus(){
        if(attendanceStatus){
            bt_checkOut.setVisibility(View.VISIBLE);
            bt_checkIn.setVisibility(View.GONE);
        }else{
            bt_checkIn.setVisibility(View.VISIBLE);
            bt_checkOut.setVisibility(View.GONE);
        }
    }

    private void handlePermissions() {
        if (!EasyPermissions.hasPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION})) {
            EasyPermissions.requestPermissions(this, getString(R.string.permission_rationale), Constants.GET_CURRENT_LOCATION_PERMISSION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION);
        } else {
            setupLocationGetter();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        gpsStatusDetector.checkOnActivityResult(requestCode, resultCode);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == Constants.GET_CURRENT_LOCATION_PERMISSION) {
            EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
        }
    }

    private void setupLocationGetter() {
        locationManager = (LocationManager) this
                .getSystemService(LOCATION_SERVICE);
        gpsStatusDetector.checkGpsStatus();

    }


    @Override
    public void onPermissionsGranted(int requestCode, List<String> perms) {
        displayToast(getString(R.string.generic_permission_granted_message));
        setupLocationGetter();
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {
        displayToast(getString(R.string.permission_rationale));
    }

    public void displayToast(String message) {
        Toast.makeText(this, TextUtils.isEmpty(message) ? getString(R.string.unavailable_message): message, Toast.LENGTH_LONG).show();
    }

    private void showLog(String message) {
        Log.i(AttendanceActivity.class.getSimpleName(), TextUtils.isEmpty(message) ? getString(R.string.unavailable_message) : message);
    }

    private void setUpTodaysAttendance(GetSwipeStatusResponse.Result result) {

        tv_attendanceStatus.setText(getSuitableText2(result.getIoType() == 0));
        tv_attendanceDate.setText(formatText(result.getAttendanceDate()));
        tv_address.setText(formatText(result.getAddress()));

    }

    public String getSuitableText2(boolean b) {
        if (b) {
            return Constants.CHECKED_IN;
        } else {
            return Constants.CHECKED_OUT;
        }
    }

    public String formatText(String s) {
        if (TextUtils.isEmpty(s)) {
            return "NA";
        } else {
            return s;
        }
    }

    @Override
    public void onGpsSettingStatus(boolean enabled) {
        if (!enabled) {
            displayToast(getString(R.string.gps_required));
            finish();
        } else {
            locationManager = (LocationManager) this
                    .getSystemService(LOCATION_SERVICE);
            getCurrentPlace();
            showLog(latitude + " , " + longitude);

        }
    }

    @Override
    public void onGpsAlertCanceledByUser() {
        displayToast(getString(R.string.gps_required));
        finish();
    }

    @SuppressLint("MissingPermission")
    private void getLocation() {

        try {

            if (locationManager != null) {
                List<String> providers = locationManager.getProviders(true);
                Location bestLocation = null;
                for (String provider : providers) {
                    locationManager.requestLocationUpdates(provider, 30 * 60 * 1000, 0, new LocationListener() {
                        @Override
                        public void onLocationChanged(Location location) {

                            if (location != null) {
                                if (!locationDetected) {
                                    locationDetected = true;
                                    latitude = location.getLatitude();
                                    longitude = location.getLongitude();
                                    uploadAttendance(!attendanceStatus);
                                    return;
                                } else {
                                    latitude = location.getLatitude();
                                    longitude = location.getLongitude();
                                }
                            }

                            locationManager.removeUpdates(this); // we need the location only once

                        }

                        @Override
                        public void onStatusChanged(String s, int i, Bundle bundle) {
                        }

                        @Override
                        public void onProviderEnabled(String s) {
                        }

                        @Override
                        public void onProviderDisabled(String s) {
                        }
                    });
                    Location l = locationManager.getLastKnownLocation(provider);
                    if (l == null) {
                        continue;
                    }
                    if (bestLocation == null) {
                        bestLocation = l;
                    } else {
                        if (bestLocation.getAccuracy() < l.getAccuracy()) {
                            bestLocation = l;
                        }
                    }
                }
                Location location = locationManager
                        .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (bestLocation != null) {
                    //use location
                    latitude = bestLocation.getLatitude();
                    longitude = bestLocation.getLongitude();

                    if (!locationDetected) {
                        locationDetected = true;
                        latitude = bestLocation.getLatitude();
                        longitude = bestLocation.getLongitude();
                        uploadAttendance(!attendanceStatus);
                        return;
                    } else {
                        uploadAttendance(!attendanceStatus);
                    }


                } else if (location != null) {


                    if (!locationDetected) {
                        locationDetected = true;
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                        uploadAttendance(!attendanceStatus);
                        return;
                    } else {
                        uploadAttendance(!attendanceStatus);
                    }

                } else {
                    // we are unable to find the location , hence sending 0,0
                    latitude = 0;
                    longitude = 0;
                    uploadAttendance(!attendanceStatus);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            // we are unable to find the location, hence sending 0,0
            latitude = 0;
            longitude = 0;
            uploadAttendance(!attendanceStatus);

        }
    }

    public void getAttendanceStatus() {
        showProgressDialog();
        final GetSwipeStatusRequest getSwipeStatus = new GetSwipeStatusRequest();
        getSwipeStatus.setMethod(Constants.ERP_METHOD);
        getSwipeStatus.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        GetSwipeStatusRequest.Params params = new GetSwipeStatusRequest.Params();
        params.setMethod(Constants.ERP_PARAM_METHOD);

        List<Object> args = new ArrayList<>();
        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);

        GetSwipeStatusRequest.SetEmailForLeads setEmailForLeads = new GetSwipeStatusRequest.SetEmailForLeads();
        args.add("getSwipeStatus");
        setEmailForLeads.setEmailId(manager.getSalesId());
        args.add(setEmailForLeads);
        params.setArgs(args);
        params.setService("object");

        getSwipeStatus.setParams(params);

        showLog(new Gson().toJson(getSwipeStatus));

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLog(new AndroidLog(AttendanceActivity.class.getSimpleName())).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        erpApiInterface.GetAttendanceStatus(getSwipeStatus, new Callback<GetSwipeStatusResponse>() {
            @Override
            public void success(GetSwipeStatusResponse requestResponse, Response response) {
                hideProgressDialog();
                if (response.getStatus() == 200) {
                    if (requestResponse != null) {
                        showLog(new Gson().toJson(requestResponse));
                        List<GetSwipeStatusResponse.Result> results = requestResponse.getResult();
                        if (results == null) {
                            attendanceStatus = false;
                        } else if (results.size() == 0) {
                            checkBiometric = false;
                            attendanceStatus = false;
                        } else {

                            setUpTodaysAttendance(results.get(results.size() - 1));
                            List<GetSwipeStatusResponse.Result> rocketSinghResults = new ArrayList<>();
                            for (GetSwipeStatusResponse.Result result : results) {
                                if (!TextUtils.isEmpty(result.getAddress())) {
                                    rocketSinghResults.add(result);
                                }
                            }

                            if (rocketSinghResults.size() == 0) {
                                attendanceStatus = false;
                            } else {
                                GetSwipeStatusResponse.Result latestResult = rocketSinghResults.get(rocketSinghResults.size() - 1);
                                attendanceStatus = latestResult.getIoType() == 0;
                            }

                        }


                        ll_attendanceOptions.setVisibility(View.VISIBLE); // showing options for attendance

                        if(attendanceStatus){
                            bt_checkOut.setVisibility(View.VISIBLE);
                            bt_checkIn.setVisibility(View.GONE);
                        }else{
                            bt_checkOut.setVisibility(View.GONE);
                            bt_checkIn.setVisibility(View.VISIBLE);
                        }

                    } else {
                        displayToast(getString(R.string.generic_error_message));
                    }
                } else {
                    displayToast(getString(R.string.generic_error_message));
                }
            }

            @Override
            public void failure(RetrofitError error) {
                hideProgressDialog();
                displayToast(error.getMessage());
            }
        });

    }

    private void showProgressDialog() {
        if (mProgressDialog == null) {
            mProgressDialog = new ProgressDialog(this);
            mProgressDialog.setMessage(getString(R.string.please_wait));
            mProgressDialog.setIndeterminate(true);
            mProgressDialog.setCancelable(false);
        }
        if (!mProgressDialog.isShowing()) {
            if (!this.isFinishing()) {
                //show dialog
                mProgressDialog.show();
            }

        }
    }


    private void hideProgressDialog() {
        if (mProgressDialog != null) {
            if (mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
        }
    }

    private String getSuitableText(boolean b) {
        return b ? "Click here to check out" : "Click here to check in";
    }

    private void GetAllAttendanceDetails() {

        showProgressDialog();
        final GetDailyAttendanceRequest getDailyAttendanceRequest = new GetDailyAttendanceRequest();
        getDailyAttendanceRequest.setMethod(Constants.ERP_METHOD);
        getDailyAttendanceRequest.setJsonrpc(Constants.ERP_JSONRPC_VERSION);
        GetDailyAttendanceRequest.Params params = new GetDailyAttendanceRequest.Params();
        params.setMethod(Constants.ERP_PARAM_METHOD);

        List<Object> args = new ArrayList<>();
        args.add(Constants.ERP_ARG0);
        args.add(Constants.ERP_ARG1);
        args.add(Constants.ERP_ARG2);
        args.add(Constants.ERP_ARG3);

        GetDailyAttendanceRequest.SetEmailModel setEmailForLeads = new GetDailyAttendanceRequest.SetEmailModel();
        args.add("getAttendanceDetails");
        setEmailForLeads.setEmailId(manager.getSalesId());
        args.add(setEmailForLeads);
        params.setArgs(args);
        params.setService("object");

        getDailyAttendanceRequest.setParams(params);

        showLog(new Gson().toJson(getDailyAttendanceRequest));

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_EP_API_URL).setLog(new AndroidLog(AttendanceActivity.class.getSimpleName())).build();
        ERPApiInterface erpApiInterface = restAdapter.create(ERPApiInterface.class);
        erpApiInterface.GetDailyAttendance(getDailyAttendanceRequest, new Callback<GetDailyAttendanceResponse>() {
            @Override
            public void success(GetDailyAttendanceResponse getDailyAttendanceResponse, Response response) {
                hideProgressDialog();
                if (response.getStatus() == 200) {

                    if (getDailyAttendanceResponse != null) {
                        if (getDailyAttendanceResponse.getResult() != null) {

                            List<GetDailyAttendanceResponse.Result> getlastsevenDaysReport = new ArrayList<>();
                            int index = 0;
                            for (GetDailyAttendanceResponse.Result result : getDailyAttendanceResponse.getResult()) {
                                getlastsevenDaysReport.add(result);
                                if (index == 6) {
                                    break;
                                }
                                index++;
                            }

                            AttendanceAdapter attendanceAdapter =
                                    new AttendanceAdapter(getlastsevenDaysReport, AttendanceActivity.this);
                            rv_attendaceDetails.setAdapter(attendanceAdapter);
                            rv_attendaceDetails.setLayoutManager(new LinearLayoutManager(AttendanceActivity.this));
                        } else {
                            //displayToast(getString(R.string.attendance_fetch_error));
                        }
                    } else {
                       // displayToast(getString(R.string.attendance_fetch_error));
                    }

                } else {

                    displayToast(getString(R.string.attendance_fetch_error));
                }
            }

            @Override
            public void failure(RetrofitError error) {
                hideProgressDialog();
                displayToast(error.getMessage());
            }
        });

    }

    @Override
    public void onShowLocationOnMap(double lat, double lng) {
        Uri gmmIntentUri = Uri.parse("google.streetview:cbll=" + lat + "," + lat);
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }

    @Override
    protected void onPause() {
        super.onPause();
        hideProgressDialog();
    }

    protected void getCurrentPlace() {

        PlaceDetectionClient placeDetectionClient = Places.getPlaceDetectionClient(this, null);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        showProgressDialog();

        Task<PlaceLikelihoodBufferResponse> placeResult = placeDetectionClient.getCurrentPlace(null);
        placeResult.addOnCompleteListener(new OnCompleteListener<PlaceLikelihoodBufferResponse>() {
            @Override
            public void onComplete(@NonNull Task<PlaceLikelihoodBufferResponse> task) {
                hideProgressDialog();
             try{
                 PlaceLikelihoodBufferResponse likelyPlaces = task.getResult();

                 for (PlaceLikelihood placeLikelihood : likelyPlaces) {
                     latitude = placeLikelihood.getPlace().getLatLng().latitude;
                     longitude = placeLikelihood.getPlace().getLatLng().longitude;
                     uploadAttendance(! attendanceStatus);
                     break;
                 }
                 likelyPlaces.release();
             }catch (Exception e ){
                 getLocation();
                 //displayToast(getString(R.string.gps_fail));
             }
            }
        });

        placeResult.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                getLocation();
            }
        });
    }

    private void showSnackBar(String message){
        if(! TextUtils.isEmpty(message) && parentLayout != null ){
                Snackbar.make(parentLayout , getString(R.string.refresh_report_statement) , Snackbar.LENGTH_LONG).show();
        }
    }

}
