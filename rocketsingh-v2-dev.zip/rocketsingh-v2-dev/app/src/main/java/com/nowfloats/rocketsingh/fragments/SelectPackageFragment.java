package com.nowfloats.rocketsingh.fragments;

import android.app.Dialog;
import android.os.Bundle;

import com.anachat.chatsdk.AnaCore;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.adapters.ProductListAdapter;
import com.nowfloats.rocketsingh.adapters.ProductListAdapter2;
import com.nowfloats.rocketsingh.models.VerticalPackageModel;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.nowfloats.rocketsingh.utils.UI.AnimatedExpandedListView;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SelectPackageFragment extends DialogFragment implements ProductListAdapter.ActionOnPageSelected{

    // TODO: Rename and change types of parameters

    //private RecyclerView recyclerView;
    //private  ProductListAdapter productListAdapter;
    private AnimatedExpandedListView expandedListView;
    private List<VerticalPackageModel> verticalPackageModels;
    List<String> categoryList;
    private HashMap<String , List<String>> categoryAndProductsData;

    public SelectPackageFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static SelectPackageFragment newInstance(HashMap<String , List<String>> categoryAndProductsData) {
        SelectPackageFragment fragment = new SelectPackageFragment();
        fragment.categoryAndProductsData = categoryAndProductsData;
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_select_package, container, false);
        expandedListView = v.findViewById(R.id.el_vertical_packages);
        categoryList =new ArrayList<>(categoryAndProductsData.keySet());
        ProductListAdapter2 productListAdapter2 = new ProductListAdapter2(categoryList , categoryAndProductsData);

        expandedListView.setAdapter(productListAdapter2);
        expandedListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                if (expandedListView.isGroupExpanded(groupPosition)) {
                    expandedListView.collapseGroupWithAnimation(groupPosition);
                } else {
                    expandedListView.expandGroupWithAnimation(groupPosition);
                }
                return true;
            }

        });

        expandedListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView expandableListView, View view, int i, int i1, long l) {
                ExternalProcessManager.getInstance().showLog(((TextView)view.findViewById(R.id.tv_package)).getText().toString());
                HashMap<String,String> userData = new HashMap<>();
                userData.put("productName" , categoryAndProductsData.get(categoryList.get(i)).get(i1));
                AnaCore.sendDeeplinkEventData(
                        ExternalProcessManager.getInstance().getAnaChatContext()
                        , userData
                        , ExternalProcessManager.getInstance().getTitle()
                        , ExternalProcessManager.getInstance().getValue());
                getDialog().dismiss();
                return false;
            }
        });
        return v;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
    }

    // TODO: Rename method, update argument and hook method into UI event


    @Override
    public void onPageSelected(String productName) {
        getDialog().dismiss();
        HashMap<String, String> userData = new HashMap<>();
        userData.put("productName", productName);
        ExternalProcessManager instance = ExternalProcessManager.getInstance();
        AnaCore.sendDeeplinkEventData(instance.getAnaChatContext(), userData, productName, instance.getValue());
    }
    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null)
        {
            int width = ViewGroup.LayoutParams.MATCH_PARENT;
            int height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
        }
    }
}
