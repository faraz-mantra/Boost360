package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PIDetailsResponse {

    @SerializedName("sol_id")
    @Expose
    private Integer solId;
    @SerializedName("so_state")
    @Expose
    private String soState;
    @SerializedName("product")
    @Expose
    private String product;
    @SerializedName("proforma_inv_number")
    @Expose
    private String proformaInvNumber;
    @SerializedName("sp_email")
    @Expose
    private String spEmail;
    @SerializedName("sp_city")
    @Expose
    private String spCity;
    @SerializedName("type_of_sale")
    @Expose
    private String typeOfSale;
    @SerializedName("tax_percentage")
    @Expose
    private Double taxPercentage;
    @SerializedName("sp_name")
    @Expose
    private String spName;
    @SerializedName("price_tax")
    @Expose
    private Double priceTax;
    @SerializedName("qty")
    @Expose
    private Integer qty;
    @SerializedName("discount")
    @Expose
    private Double discount;
    @SerializedName("package_id")
    @Expose
    private String packageId;
    @SerializedName("fptags")
    @Expose
    private Object fptags;
    @SerializedName("price_untax")
    @Expose
    private Double priceUntax;
    @SerializedName("sp_division")
    @Expose
    private String spDivision;
    @SerializedName("business_name")
    @Expose
    private String businessName;
    @SerializedName("unitprice")
    @Expose
    private Integer unitprice;
    @SerializedName("price_total")
    @Expose
    private Double priceTotal;

    public Integer getSolId() {
        return solId;
    }

    public void setSolId(Integer solId) {
        this.solId = solId;
    }

    public String getSoState() {
        return soState;
    }

    public void setSoState(String soState) {
        this.soState = soState;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProformaInvNumber() {
        return proformaInvNumber;
    }

    public void setProformaInvNumber(String proformaInvNumber) {
        this.proformaInvNumber = proformaInvNumber;
    }

    public String getSpEmail() {
        return spEmail;
    }

    public void setSpEmail(String spEmail) {
        this.spEmail = spEmail;
    }

    public String getSpCity() {
        return spCity;
    }

    public void setSpCity(String spCity) {
        this.spCity = spCity;
    }

    public String getTypeOfSale() {
        return typeOfSale;
    }

    public void setTypeOfSale(String typeOfSale) {
        this.typeOfSale = typeOfSale;
    }

    public Double getTaxPercentage() {
        return taxPercentage;
    }

    public void setTaxPercentage(Double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }

    public String getSpName() {
        return spName;
    }

    public void setSpName(String spName) {
        this.spName = spName;
    }

    public Double getPriceTax() {
        return priceTax;
    }

    public void setPriceTax(Double priceTax) {
        this.priceTax = priceTax;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public String getPackageId() {
        return packageId;
    }

    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    public Object getFptags() {
        return fptags;
    }

    public void setFptags(Object fptags) {
        this.fptags = fptags;
    }

    public Double getPriceUntax() {
        return priceUntax;
    }

    public void setPriceUntax(Double priceUntax) {
        this.priceUntax = priceUntax;
    }

    public String getSpDivision() {
        return spDivision;
    }

    public void setSpDivision(String spDivision) {
        this.spDivision = spDivision;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public Integer getUnitprice() {
        return unitprice;
    }

    public void setUnitprice(Integer unitprice) {
        this.unitprice = unitprice;
    }

    public Double getPriceTotal() {
        return priceTotal;
    }

    public void setPriceTotal(Double priceTotal) {
        this.priceTotal = priceTotal;
    }

}