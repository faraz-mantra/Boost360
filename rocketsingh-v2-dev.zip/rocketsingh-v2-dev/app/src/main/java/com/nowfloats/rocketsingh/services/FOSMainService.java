package com.nowfloats.rocketsingh.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import androidx.annotation.RequiresApi;
import android.text.TextUtils;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.activity.GoogleLoginActivity;
import com.nowfloats.rocketsingh.interfaces.DashboardInterface;
import com.nowfloats.rocketsingh.interfaces.SignupInterface;
import com.nowfloats.rocketsingh.models.EmployeesRankResponse;
import com.nowfloats.rocketsingh.models.GetPerformaceStatusFOS;
import com.nowfloats.rocketsingh.utils.Constants;
import com.nowfloats.rocketsingh.utils.ExternalProcessManager;
import com.nowfloats.rocketsingh.utils.InternalLocationManager;
import com.nowfloats.rocketsingh.utils.UserSessionManager;
import java.util.HashMap;
import java.util.List;

import retrofit.Callback;
import retrofit.RestAdapter;
import retrofit.RetrofitError;
import retrofit.android.AndroidLog;
import retrofit.client.Response;

/**
 * Created by NowFloats on 15-Feb-18.
 */

public class FOSMainService extends Service {

    private NotificationManager mNM;
    private boolean notificationLive = false;
    private final long LOCATION_POLLING_PERIOD = 1000*12*60*60; // THIS IS THE POLLING PERIOD FOR PERSON TRACKING
    private ExternalProcessManager externalProcessManager;
    Notification.Builder mBuilder;
    private int NOTIFICATION = R.string.fos_main_service_started;
    private UserSessionManager manager;

    public class LocalBinder extends Binder {
        FOSMainService getService() {
            return FOSMainService.this;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void onCreate() {
        initiateService();
    }



    private void initiateService(){
        manager = new UserSessionManager(this);
        externalProcessManager = ExternalProcessManager.getInstance();
        mNM = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        getSalesPerformance(manager.getSalesId());
        InternalLocationManager.startLocationTracking(this);
        looperCall();
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("FOSMainService", "Received start id " + startId + ": " + intent);
        initiateService();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        // Cancel the persistent notification.
        mNM.cancel(NOTIFICATION);
        // Tell the user we stopped.
        Toast.makeText(this, "Local Service Stopped", Toast.LENGTH_SHORT).show();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    // This is the object that receives interactions from clients.  See
    // RemoteService for a more complete example.
    private final IBinder mBinder = new LocalBinder();

    /**
     * Show a notification while this service is running.
     */

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    private void showNotification(GetPerformaceStatusFOS getPerformaceStatusFOS) {

        String title="" , performance = "", body="";
        int loggedMeetings;
        String netRevenueTillDate;

        if(getPerformaceStatusFOS.getGetPerformanceResponse() == null ) {
            performance = "NA";
            loggedMeetings = 0 ;
            netRevenueTillDate = 0.0+"";

        }else{
            loggedMeetings = getPerformaceStatusFOS.getGetPerformanceResponse().getLastDayFolloupMeetingNum()+getPerformaceStatusFOS.getGetPerformanceResponse().getLastDayNewMeetingNum();
            performance = getPerformaceStatusFOS.getGetPerformanceResponse().getLastDayPerformance();
            netRevenueTillDate = getPerformaceStatusFOS.getGetPerformanceResponse().getNetRevenueTillDate();
        }


        title = "Your performace as of "+ externalProcessManager.getCurrentDate();

        RemoteViews expandedView = new RemoteViews(getPackageName(), R.layout.notification_expandedv2fos);


        expandedView.setTextViewText(R.id.tv_loggedMeetings , loggedMeetings+"");
        expandedView.setTextViewText(R.id.tv_pending_tickets , getPerformaceStatusFOS.getTickets()+"");
        expandedView.setTextViewText(R.id.tv_revenue , netRevenueTillDate);

        RemoteViews collapsedView = new RemoteViews(getPackageName(), R.layout.notification_collapsed);

        collapsedView.setTextViewText(R.id.content_text , title);


        switch (performance)
        {
            case "GOOD":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                break;
            case "AVERAGE":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.primary));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.primary));
                break;
            case "BAD":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                break;
            case "ABSENT":
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.red_bad));
                break;
            default:
                expandedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                collapsedView.setInt(R.id.rl_notification, "setBackgroundColor", getResources().getColor(R.color.green_good));
                break;
        }
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
                new Intent(this, GoogleLoginActivity.class), 0);
        String ChannelId = "channel_01";
        NotificationChannel channel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel(ChannelId, "RocketSingh", NotificationManager.IMPORTANCE_LOW);
        }
        mBuilder = new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_stat_logo_transparent)  // the status icon
                .setWhen(System.currentTimeMillis())  // the time stamp
                .setContentTitle(title)  // the label of the entry
                .setContentText(body)  // the contents of the entry
                .setContentIntent(contentIntent)  // The intent to send when the entry is clicked
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setOnlyAlertOnce(true);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mBuilder.setColor(getResources().getColor(R.color.primary));
        }
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            mBuilder.setCustomBigContentView(expandedView);
            mBuilder.setCustomContentView(collapsedView);
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            mBuilder.setChannelId(ChannelId);
            mNM.createNotificationChannel(channel);
        }

        //if(! notificationLive) {
        notificationLive = true;
        mNM.notify(NOTIFICATION, mBuilder.build());
        //   }
        startForeground(NOTIFICATION, mBuilder.build());
    }

    private void getSalesPerformance(String emailId) {

        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.SALES_ASSISTANT_API_URL).setLog(new AndroidLog(FOSMainService.class.getSimpleName())).build();

        DashboardInterface dashboardInterface = restAdapter.create(DashboardInterface.class);

        dashboardInterface.getMeetingsStatsForFOS(emailId, new Callback<GetPerformaceStatusFOS>() {
            @Override
            public void success(GetPerformaceStatusFOS getPerformaceStatusFOS, Response response) {
                showObjectAsLog(getPerformaceStatusFOS);

                if(response.getStatus() == 200) {

                    getEmployeeRank(getPerformaceStatusFOS);

                }else{
                    showServiceLog("ERROR AT getsalesperformace "+response.getReason());
                }
            }

            @Override
            public void failure(RetrofitError error) {

                showObjectAsLog(error);

            }
        });

    }

    private void showServiceLog(String message) {
        Log.d(FOSMainService.class.getSimpleName() , TextUtils.isEmpty(message) ? "Message is null" : message);
    }

    private void getEmployeeRank(GetPerformaceStatusFOS getPerformaceStatusFOS) {

        String emailId = manager.getSalesId();

        HashMap<String, String> model = new HashMap<String, String>();
        model.put("clientId", Constants.ERPClientId);
        model.put("emailId", emailId);
        RestAdapter restAdapter = new RestAdapter.Builder().setEndpoint(Constants.ERP_API_URL).setLogLevel(RestAdapter.LogLevel.FULL).setLog(new AndroidLog("ggg")).build();
        SignupInterface signupInterface = restAdapter.create(SignupInterface.class);
        signupInterface.getEmployeeRank(model, new Callback<List<EmployeesRankResponse>>() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void success(List<EmployeesRankResponse> dataResponse, retrofit.client.Response response) {
                if(dataResponse == null || response.getStatus() != 200){
                    //error
                    return;
                }
                if(response.getStatus() == 200 && dataResponse.size() > 0){
                    //onApiSuccessfull

                    getPerformaceStatusFOS.getGetPerformanceResponse().setNetRevenueTillDate(dataResponse.get(0).getRevenue());


                }else{
                    //not successful
                    getPerformaceStatusFOS.getGetPerformanceResponse().setNetRevenueTillDate("0");
                }

                showObjectAsLog(getPerformaceStatusFOS);

                showNotification(getPerformaceStatusFOS);
            }

            @Override
            public void failure(RetrofitError error) {
                //error
                showServiceLog(error.getMessage() +" AT EMPLOYEE RANK");
                getEmployeeRank(getPerformaceStatusFOS);
            }
        });
    }

    public void looperCall() {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getSalesPerformance(manager.getSalesId());
                looperCall();
            }
        } , LOCATION_POLLING_PERIOD);

    }



    private void showObjectAsLog(Object object){

    }

}
