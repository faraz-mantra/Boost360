package com.nowfloats.rocketsingh.adapters;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.EmployeesRankResponse;

import java.util.List;

/**
 * Created by NowFloats on 27-Feb-18.
 */

public class RanksRecyclerViewAdapter extends RecyclerView.Adapter<RanksRecyclerViewAdapter.MyItemsViewHolder> {

    List<EmployeesRankResponse> mTopRanksList;

    public RanksRecyclerViewAdapter(Context context, List<EmployeesRankResponse> topRanksList){
        this.mTopRanksList = topRanksList;
    }

    @Override
    public MyItemsViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ranks_row_layout, parent, false);
        return new MyItemsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyItemsViewHolder holder, int position) {
        EmployeesRankResponse data = mTopRanksList.get(position);
        holder.tvRank.setText(data.getNationalRank());
        holder.tvName.setText(data.getEmployee());
        holder.tvBranch.setText(data.getBranch());
        holder.tvRevenue.setText("₹"+getFormattedString(data.getRevenue()));
    }

    private String getFormattedString(String message){
       try{
           double number = Double.parseDouble(message);
           return Math.round(number*100)/100+"";
       }catch(Exception e ){
           return message;
       }
    }

    @Override
    public int getItemCount() {
        return mTopRanksList.size();
    }

    public class MyItemsViewHolder extends RecyclerView.ViewHolder{
        TextView tvRank, tvName, tvBranch, tvRevenue;

        public MyItemsViewHolder(View itemView) {
            super(itemView);
            tvRank = itemView.findViewById(R.id.tv_rank);
            tvName = itemView.findViewById(R.id.tv_name);
            tvBranch = itemView.findViewById(R.id.tv_branch);
            tvRevenue = itemView.findViewById(R.id.tv_revenue);
        }
    }
}
