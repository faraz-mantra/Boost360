package com.nowfloats.rocketsingh.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetDailyAttendanceResponse {

    @SerializedName("jsonrpc")
    @Expose
    private String jsonrpc;
    @SerializedName("id")
    @Expose
    private Object id;
    @SerializedName("result")
    @Expose
    private List<Result> result = null;

    public String getJsonrpc() {
        return jsonrpc;
    }

    public void setJsonrpc(String jsonrpc) {
        this.jsonrpc = jsonrpc;
    }

    public Object getId() {
        return id;
    }

    public void setId(Object id) {
        this.id = id;
    }

    public List<Result> getResult() {
        return result;
    }

    public void setResult(List<Result> result) {
        this.result = result;
    }

    public class Result {

        @SerializedName("checkout_state")
        @Expose
        private Object checkoutState;
        @SerializedName("hr_emp_id")
        @Expose
        private Integer hrEmpId;
        @SerializedName("internal_designation")
        @Expose
        private String internalDesignation;
        @SerializedName("id")
        @Expose
        private Integer id;
        @SerializedName("user_id")
        @Expose
        private Integer userId;
        @SerializedName("checkout_city")
        @Expose
        private Object checkoutCity;
        @SerializedName("checkout_longitude")
        @Expose
        private Double checkoutLongitude;
        @SerializedName("checkin_city")
        @Expose
        private Object checkinCity;
        @SerializedName("swipe_status")
        @Expose
        private String swipeStatus;
        @SerializedName("first_swipe_in")
        @Expose
        private String firstSwipeIn;
        @SerializedName("division")
        @Expose
        private String division;
        @SerializedName("last_check_out")
        @Expose
        private String lastCheckOut;
        @SerializedName("number_of_meeting")
        @Expose
        private String numberOfMeeting;
        @SerializedName("checkout_address")
        @Expose
        private String checkoutAddress;
        @SerializedName("employee_name")
        @Expose
        private String employeeName;
        @SerializedName("date")
        @Expose
        private String date;
        @SerializedName("work_email")
        @Expose
        private String workEmail;
        @SerializedName("first_check_in")
        @Expose
        private String firstCheckIn;
        @SerializedName("checkout_latitude")
        @Expose
        private Double checkoutLatitude;
        @SerializedName("nf_emp")
        @Expose
        private String nfEmp;
        @SerializedName("attendance_branch")
        @Expose
        private Object attendanceBranch;
        @SerializedName("designation_type")
        @Expose
        private String designationType;
        @SerializedName("checkin_state")
        @Expose
        private Object checkinState;
        @SerializedName("attendance_status")
        @Expose
        private String attendanceStatus;
        @SerializedName("last_swipe_out")
        @Expose
        private String lastSwipeOut;
        @SerializedName("checkin_address")
        @Expose
        private String checkinAddress;
        @SerializedName("checkin_latitude")
        @Expose
        private Double checkinLatitude;
        @SerializedName("checkin_longitude")
        @Expose
        private Double checkinLongitude;

        public Object getCheckoutState() {
            return checkoutState;
        }

        public void setCheckoutState(Object checkoutState) {
            this.checkoutState = checkoutState;
        }

        public Integer getHrEmpId() {
            return hrEmpId;
        }

        public void setHrEmpId(Integer hrEmpId) {
            this.hrEmpId = hrEmpId;
        }

        public String getInternalDesignation() {
            return internalDesignation;
        }

        public void setInternalDesignation(String internalDesignation) {
            this.internalDesignation = internalDesignation;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public Integer getUserId() {
            return userId;
        }

        public void setUserId(Integer userId) {
            this.userId = userId;
        }

        public Object getCheckoutCity() {
            return checkoutCity;
        }

        public void setCheckoutCity(Object checkoutCity) {
            this.checkoutCity = checkoutCity;
        }

        public Double getCheckoutLongitude() {
            return checkoutLongitude;
        }

        public void setCheckoutLongitude(Double checkoutLongitude) {
            this.checkoutLongitude = checkoutLongitude;
        }

        public Object getCheckinCity() {
            return checkinCity;
        }

        public void setCheckinCity(Object checkinCity) {
            this.checkinCity = checkinCity;
        }

        public String getSwipeStatus() {
            return swipeStatus;
        }

        public void setSwipeStatus(String swipeStatus) {
            this.swipeStatus = swipeStatus;
        }

        public String getFirstSwipeIn() {
            return firstSwipeIn;
        }

        public void setFirstSwipeIn(String firstSwipeIn) {
            this.firstSwipeIn = firstSwipeIn;
        }

        public String getDivision() {
            return division;
        }

        public void setDivision(String division) {
            this.division = division;
        }

        public String getLastCheckOut() {
            return lastCheckOut;
        }

        public void setLastCheckOut(String lastCheckOut) {
            this.lastCheckOut = lastCheckOut;
        }

        public String getNumberOfMeeting() {
            return numberOfMeeting;
        }

        public void setNumberOfMeeting(String numberOfMeeting) {
            this.numberOfMeeting = numberOfMeeting;
        }

        public String getCheckoutAddress() {
            return checkoutAddress;
        }

        public void setCheckoutAddress(String checkoutAddress) {
            this.checkoutAddress = checkoutAddress;
        }

        public String getEmployeeName() {
            return employeeName;
        }

        public void setEmployeeName(String employeeName) {
            this.employeeName = employeeName;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getWorkEmail() {
            return workEmail;
        }

        public void setWorkEmail(String workEmail) {
            this.workEmail = workEmail;
        }

        public String getFirstCheckIn() {
            return firstCheckIn;
        }

        public void setFirstCheckIn(String firstCheckIn) {
            this.firstCheckIn = firstCheckIn;
        }

        public Double getCheckoutLatitude() {
            return checkoutLatitude;
        }

        public void setCheckoutLatitude(Double checkoutLatitude) {
            this.checkoutLatitude = checkoutLatitude;
        }

        public String getNfEmp() {
            return nfEmp;
        }

        public void setNfEmp(String nfEmp) {
            this.nfEmp = nfEmp;
        }

        public Object getAttendanceBranch() {
            return attendanceBranch;
        }

        public void setAttendanceBranch(Object attendanceBranch) {
            this.attendanceBranch = attendanceBranch;
        }

        public String getDesignationType() {
            return designationType;
        }

        public void setDesignationType(String designationType) {
            this.designationType = designationType;
        }

        public Object getCheckinState() {
            return checkinState;
        }

        public void setCheckinState(Object checkinState) {
            this.checkinState = checkinState;
        }

        public String getAttendanceStatus() {
            return attendanceStatus;
        }

        public void setAttendanceStatus(String attendanceStatus) {
            this.attendanceStatus = attendanceStatus;
        }

        public String getLastSwipeOut() {
            return lastSwipeOut;
        }

        public void setLastSwipeOut(String lastSwipeOut) {
            this.lastSwipeOut = lastSwipeOut;
        }

        public String getCheckinAddress() {
            return checkinAddress;
        }

        public void setCheckinAddress(String checkinAddress) {
            this.checkinAddress = checkinAddress;
        }

        public Double getCheckinLatitude() {
            return checkinLatitude;
        }

        public void setCheckinLatitude(Double checkinLatitude) {
            this.checkinLatitude = checkinLatitude;
        }

        public Double getCheckinLongitude() {
            return checkinLongitude;
        }

        public void setCheckinLongitude(Double checkinLongitude) {
            this.checkinLongitude = checkinLongitude;
        }

    }

}