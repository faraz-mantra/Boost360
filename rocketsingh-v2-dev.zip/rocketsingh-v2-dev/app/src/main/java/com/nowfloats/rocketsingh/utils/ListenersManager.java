package com.nowfloats.rocketsingh.utils;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.nowfloats.rocketsingh.interfaces.IQuesResponseCallback;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by NowFloats on 23-Mar-18.
 */

public class ListenersManager {
    private Set<IQuesResponseCallback> mQuesResFragmentListeners = new HashSet<>();
    private static volatile ListenersManager instance;
    private Handler mHandler = new Handler(Looper.getMainLooper());

    private ListenersManager() {
    }

    public static ListenersManager getInstance() {
        if (instance == null) { // first time lock
            synchronized (ListenersManager.class) {
                if (instance == null) {  // second time lock
                    instance = new ListenersManager();
                }
            }
        }
        return instance;
    }
    public void addQuesResFragmentListener(IQuesResponseCallback quesResFragmentListener) {
        mQuesResFragmentListeners.add(quesResFragmentListener);
    }

    public void callQuestionResFragmentDialogAction(int index, int actionStatus, String engDay, Context context) {
        mHandler.post(() -> {
            for (IQuesResponseCallback quesResFragmentListener : mQuesResFragmentListeners) {
                quesResFragmentListener.questionResDialogAction(index, actionStatus, engDay, context);
            }
        });
    }

    public void callQuestionFragmentDialogAction(int index, int actionStatus, List<String> deepLinkValues, Context context) {
        mHandler.post(() -> {
            for (IQuesResponseCallback quesFragmentListener : mQuesResFragmentListeners) {
                quesFragmentListener.questionDialogAction(index, actionStatus, deepLinkValues, context);
            }
        });
    }
}
