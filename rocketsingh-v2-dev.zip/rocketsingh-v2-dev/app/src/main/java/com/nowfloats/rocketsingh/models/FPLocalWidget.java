package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class FPLocalWidget {

    @SerializedName("_key")
    @Expose
    private String key;
    @SerializedName("html")
    @Expose
    private String html;
    @SerializedName("type")
    @Expose
    private String type;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public FPLocalWidget withKey(String key) {
        this.key = key;
        return this;
    }

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }

    public FPLocalWidget withHtml(String html) {
        this.html = html;
        return this;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public FPLocalWidget withType(String type) {
        this.type = type;
        return this;
    }

}