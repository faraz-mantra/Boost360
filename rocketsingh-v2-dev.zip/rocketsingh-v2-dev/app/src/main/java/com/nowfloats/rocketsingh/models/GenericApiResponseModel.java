package com.nowfloats.rocketsingh.models;

public class GenericApiResponseModel<T> {

    private T serverObject;

    private String serverMessage;

    private String error;

    private int count;

    private String message;

    public String getServerMessage() {
        return serverMessage;
    }

    public void setServerMessage(String serverMessage) {
        this.serverMessage = serverMessage;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getServerObject() {
        return serverObject;
    }

    public void setServerObject(T serverObject) {
        this.serverObject = serverObject;
    }
}
