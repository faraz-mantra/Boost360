package com.nowfloats.rocketsingh.interfaces;

import com.nowfloats.rocketsingh.models.ChequePaymentModel;
import com.nowfloats.rocketsingh.models.GetFpTagsForMeetingsRequest;
import com.nowfloats.rocketsingh.models.GetFptagDetailsResponse;
import com.nowfloats.rocketsingh.models.GetLatestMeetingsResponse;
import com.nowfloats.rocketsingh.models.GetMeetingChecklistDataResponse;
import com.nowfloats.rocketsingh.models.GetProductByNameResponse;
import com.nowfloats.rocketsingh.models.MailRequest;
import com.nowfloats.rocketsingh.models.QuesResponse;
import com.nowfloats.rocketsingh.models.SetOutcomeResponse;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Response;

import org.json.JSONArray;

import java.util.List;
import java.util.Map;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.GET;
import retrofit.http.Headers;
import retrofit.http.POST;
import retrofit.http.Path;
import retrofit.http.Query;
import retrofit.http.QueryMap;
import retrofit.mime.TypedInput;

/**
 * Created by NowFloats on 22-Mar-18.
 */

public interface CFInterface {

    @POST("/api/RIASupportTeam/SaveMeetingChecklistData")
    void postQuestionsResponse(@QueryMap Map<String, String> map , @Body TypedInput req, Callback<String> response);

    @GET("/api/RIASupportTeam/SetMeetingOutcome")
    void setMeetingOutcome(@QueryMap Map<String, String> map , Callback<SetOutcomeResponse> response);

    @POST("/Internal/v1/PushEmailToQueue/{clientId}")
    void sendEmail(@Path("clientId") String clientId , @Body MailRequest req, Callback<String> response);

    @GET("/api/RIASupportTeam/GetMeetingChecklist")
    void loadQues(@QueryMap Map<String, String> map, Callback<QuesResponse> response);

    @GET("/api/RIASupportTeam/GetMeetingChecklistData")
    void getMeetingOutcome(@QueryMap Map<String, String> map, Callback<GetMeetingChecklistDataResponse> response);
    @Headers("Content-Type: application/json")
    @POST("/api/RIASupportTeam/GetLatestCompletedMeetingsForFPTags?authClientId=A91B82DE3E93446A8141A52F288F69EFA1B09B1D13BB4E55BE743AB547B3489E")
    void getLatestMeetings(@Body List<String> fpTags, Callback<List<GetLatestMeetingsResponse>> getLatestMeetingsList);
    @POST("/Support/v1/CHC/GetCHCDetailsForPartner?clientId=A91B82DE3E93446A8141A52F288F69EFA1B09B1D13BB4E55BE743AB547B3489E&offset=0&FpStatus=0&isCHCAssigned=true&customerEngagementStatus=-1&accountManagerStatus=-1")
    void getFpTagsForMeetingAnalysis( @Body GetFpTagsForMeetingsRequest getFpTagsForMeetingsRequest,Callback<retrofit.client.Response> responseCallback);

    @GET("/discover/v2/floatingPoint/nf-web/{fpTag}")
    void getFpTagDetails(@Path("fpTag") String fpTag, @QueryMap Map<String,String> map, Callback<GetFptagDetailsResponse> getFptagDetailsResponseCallBack);

    @GET("/api/DiscountApproval/GetPackageByName")
    void getPackageByName(@QueryMap Map<String,String> map, Callback<GetProductByNameResponse> getProductByNameResponseCallback);

    @POST("/payment/v1/invoice/UpdateChequePaymentLog")
    void updateChequeLog(@Body ChequePaymentModel model, Callback<String> res);

}
