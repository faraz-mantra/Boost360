package com.nowfloats.rocketsingh.adapters;


import android.graphics.Typeface;
import androidx.core.content.ContextCompat;
import androidx.cardview.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.PackageModel;
import com.thoughtbot.expandablerecyclerview.ExpandableRecyclerViewAdapter;
import com.thoughtbot.expandablerecyclerview.models.ExpandableGroup;
import com.thoughtbot.expandablerecyclerview.viewholders.ChildViewHolder;
import com.thoughtbot.expandablerecyclerview.viewholders.GroupViewHolder;

import java.util.List;

public class ProductListAdapter extends ExpandableRecyclerViewAdapter<ProductListAdapter.CategoriesViewHolder , ProductListAdapter.PackagesViewHolder>{

    private String selectedProductName;
    private ActionOnPageSelected onPackageSelectedListener;

    public ProductListAdapter(List<? extends ExpandableGroup> groups) {
        super(groups);
    }

    public void setOnPackageSelectedListener(ActionOnPageSelected onPackageSelectedListener){
        this.onPackageSelectedListener = onPackageSelectedListener;
    }
    @Override
    public CategoriesViewHolder onCreateGroupViewHolder(ViewGroup parent, int viewType) {
        return new CategoriesViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.category_layout_row , parent,false));
    }

    @Override
    public PackagesViewHolder onCreateChildViewHolder(ViewGroup parent, int viewType) {
        return new PackagesViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.package_list_row , parent,false));
    }

    @Override
    public void onBindChildViewHolder(PackagesViewHolder holder, int flatPosition, ExpandableGroup group, int childIndex) {
       PackageModel packageModel =( (PackageModel)group.getItems().get(childIndex));
       holder.setPackageName(packageModel.getPackageName());
    }

    @Override
    public void onBindGroupViewHolder(CategoriesViewHolder holder, int flatPosition, ExpandableGroup group) {
        holder.setPackageCategory(group.getTitle());
        holder.changeLayoutDisplay();
    }

    public class CategoriesViewHolder extends GroupViewHolder {
        TextView tv_category;
        ImageView iv_arrow;
        CardView cv_root;
        int[] backgroundColors = {R.color.colorPrimary , R.color.colorPrimaryDark};
        float[] alphaRange = {0.7f ,1};

        private CategoriesViewHolder(View itemView) {
            super(itemView);
            tv_category = itemView.findViewById(R.id.tv_category);
            cv_root = itemView.findViewById(R.id.cv_root);
            //iv_arrow = itemView.findViewById(R.id.iv_arrow);
            tv_category.setTypeface(Typeface.createFromAsset(tv_category.getContext().getAssets(),"avenir.ttf"));
        }

        private void setPackageCategory(String category) {
            tv_category.setText(category);
        }

        private void changeLayoutDisplay(){
            cv_root.setBackgroundResource(backgroundColors[getAdapterPosition()%2]);
            cv_root.setAlpha(alphaRange[getAdapterPosition()%2]);
        }

        @Override
        public void expand() {
            super.expand();
            iv_arrow.setRotation(180f);
        }

        @Override
        public void collapse() {
            super.collapse();
            iv_arrow.setRotation(0f);
        }
    }


    protected class PackagesViewHolder extends ChildViewHolder{
        TextView tv_package;
        ImageView iv_checkbox;
        private PackagesViewHolder(View itemView) {
            super(itemView);

            tv_package = itemView.findViewById(R.id.tv_package);
            iv_checkbox = itemView.findViewById(R.id.iv_check_mark);
            iv_checkbox.setColorFilter(ContextCompat.getColor(iv_checkbox.getContext(),
                    com.anachat.chatsdk.library.R.color.grey_400));

            itemView.setOnClickListener((view -> {

                selectedProductName = tv_package.getText().toString();
                onPackageSelectedListener.onPageSelected(selectedProductName);

            }));

            tv_package.setTypeface(Typeface.createFromAsset(tv_package.getContext().getAssets(),"avenir.ttf"));
        }

        private void setPackageName(String packageName){
            tv_package.setText(packageName);
        }

    }
    public interface ActionOnPageSelected{
        void onPageSelected(String productName);
    }

}
