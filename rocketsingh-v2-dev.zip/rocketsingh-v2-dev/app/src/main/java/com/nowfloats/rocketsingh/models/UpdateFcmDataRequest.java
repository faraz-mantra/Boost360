package com.nowfloats.rocketsingh.models;

/**
 * Created by NowFloats on 18-Oct-17.
 */
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UpdateFcmDataRequest {

    @SerializedName("UpdateValue")
    @Expose
    private String updateValue;

    public String getUpdateValue() {
        return updateValue;
    }

    public void setUpdateValue(String updateValue) {
        this.updateValue = updateValue;
    }

}