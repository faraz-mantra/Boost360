package com.nowfloats.rocketsingh.fragments;

import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nowfloats.rocketsingh.R;
import com.nowfloats.rocketsingh.models.QuesResponse;
import com.nowfloats.rocketsingh.utils.ListenersManager;

import java.util.List;

/**
 * Created by NowFloats on 22-Mar-18.
 */

public class OutcomeViewFragment extends DialogFragment {

    private ImageView ivNext, ivPrev, ivMandatory;
    private Button btnSubmit;
    private TextView tvQues;
    private TextView tvRes;
    int anim, enter, exit;
    String engDay;
    QuesResponse.Item b;
    List<QuesResponse.Item> itemQuestion;
    Context mContext;

    public OutcomeViewFragment() {
        // Empty constructor is required for DialogFragment
        // Make sure not to add arguments to the constructor
        // Use `newInstance` instead as shown below
    }

    public static OutcomeViewFragment newInstance(Context context, QuesResponse.Item b, List<QuesResponse.Item> itemQuestion, int anim, int enter, int exit, String engDay) {
        OutcomeViewFragment frag = new OutcomeViewFragment();
        frag.setQuesData(b);
        frag.setQuesDataList(itemQuestion, context);
        frag.setAnimation(anim, enter, exit, engDay);
        return frag;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

    }

    public void setQuesData(QuesResponse.Item b) {
        this.b = b;
    }

    public void setQuesDataList(List<QuesResponse.Item> itemQuestion, Context context) {
        this.itemQuestion = itemQuestion;
        this.mContext = context;
    }

    public void setAnimation(int animation, int enter, int exit, String engDay) {
        this.anim = animation;
        this.enter = enter;
        this.exit = exit;
        this.engDay = engDay;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_view_outcome, container);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getDialog().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
        setCancelable(false);
        getDialog().getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        getDialog().getWindow().getAttributes().windowAnimations = anim;
        btnSubmit = view.findViewById(R.id.btn_submit);
        ivNext = view.findViewById(R.id.iv_next);
        ivPrev = view.findViewById(R.id.iv_prev);
        tvQues = view.findViewById(R.id.tv_ques);
        tvRes = view.findViewById(R.id.tv_res);
        ivMandatory = view.findViewById(R.id.iv_mandatory);
        final int index = itemQuestion.indexOf(b);
        int lastIndex = itemQuestion.size() - 1;
        tvQues.setText(index+1 + ". " + b.getDisplayText());
        if(index == 0) {
            ivPrev.setVisibility(View.INVISIBLE);
            ivPrev.setClickable(false);
            ivNext.setVisibility(View.VISIBLE);
            ivNext.setClickable(true);
            btnSubmit.setVisibility(View.GONE);
        }
        else if(index == lastIndex) {
            ivPrev.setVisibility(View.VISIBLE);
            ivPrev.setClickable(true);
            ivNext.setVisibility(View.INVISIBLE);
            ivNext.setClickable(false);
            btnSubmit.setVisibility(View.VISIBLE);
        }
        else {
            ivPrev.setVisibility(View.VISIBLE);
            ivPrev.setClickable(true);
            ivNext.setVisibility(View.VISIBLE);
            ivNext.setClickable(true);
            btnSubmit.setVisibility(View.GONE);
        }

        /*rgRes.setVisibility(View.GONE);*/
        tvRes.setVisibility(View.VISIBLE);
        ivMandatory.setVisibility(View.GONE);
        if(!TextUtils.isEmpty(b.getRes()))
            tvRes.setText(b.getRes());
        else
            tvRes.setText("-");

        ivNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                ListenersManager.getInstance().callQuestionResFragmentDialogAction(index+1, 1, engDay, mContext);
            }
        });

        ivPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                ListenersManager.getInstance().callQuestionResFragmentDialogAction(index-1, 0, engDay, mContext);
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        dismiss();
    }

}
