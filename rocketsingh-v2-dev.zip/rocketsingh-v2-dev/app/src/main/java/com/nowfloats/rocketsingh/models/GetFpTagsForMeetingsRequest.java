
package com.nowfloats.rocketsingh.models;

import java.util.ArrayList;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetFpTagsForMeetingsRequest {

    @SerializedName("usernames")
    @Expose
    private List<String> usernames = new ArrayList<>();
    @SerializedName("fptags")
    @Expose
    private Object fptags;
    @SerializedName("branchIds")
    @Expose
    private Object branchIds;
    @SerializedName("customerCities")
    @Expose
    private Object customerCities;
    @SerializedName("salesPersonIds")
    @Expose
    private Object salesPersonIds;

    public List<String> getUsernames() {
        return usernames;
    }

    public void setUsernames(List<String> usernames) {
        this.usernames = usernames;
    }

    public GetFpTagsForMeetingsRequest withUsernames(List<String> usernames) {
        this.usernames = usernames;
        return this;
    }

    public Object getFptags() {
        return fptags;
    }

    public void setFptags(Object fptags) {
        this.fptags = fptags;
    }

    public GetFpTagsForMeetingsRequest withFptags(Object fptags) {
        this.fptags = fptags;
        return this;
    }

    public Object getBranchIds() {
        return branchIds;
    }

    public void setBranchIds(Object branchIds) {
        this.branchIds = branchIds;
    }

    public GetFpTagsForMeetingsRequest withBranchIds(Object branchIds) {
        this.branchIds = branchIds;
        return this;
    }

    public Object getCustomerCities() {
        return customerCities;
    }

    public void setCustomerCities(Object customerCities) {
        this.customerCities = customerCities;
    }

    public GetFpTagsForMeetingsRequest withCustomerCities(Object customerCities) {
        this.customerCities = customerCities;
        return this;
    }

    public Object getSalesPersonIds() {
        return salesPersonIds;
    }

    public void setSalesPersonIds(Object salesPersonIds) {
        this.salesPersonIds = salesPersonIds;
    }

    public GetFpTagsForMeetingsRequest withSalesPersonIds(Object salesPersonIds) {
        this.salesPersonIds = salesPersonIds;
        return this;
    }

}