package com.nowfloats.rocketsingh.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by NowFloats on 27-Mar-18.
 */
public class MailRequest {

    @SerializedName("ClientId")
    @Expose
    private String clientId;
    @SerializedName("EmailBody")
    @Expose
    private String emailBody;
    @SerializedName("From")
    @Expose
    private String from;
    @SerializedName("Subject")
    @Expose
    private String subject;
    @SerializedName("To")
    @Expose
    private List<String> to = null;
    @SerializedName("CustomSMTPConfig")
    @Expose
    private CustomSMTPConfig customSMTPConfig;
    @SerializedName("Type")
    @Expose
    private Integer type;

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getEmailBody() {
        return emailBody;
    }

    public void setEmailBody(String emailBody) {
        this.emailBody = emailBody;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<String> getTo() {
        return to;
    }

    public void setTo(List<String> to) {
        this.to = to;
    }

    public CustomSMTPConfig getCustomSMTPConfig() {
        return customSMTPConfig;
    }

    public void setCustomSMTPConfig(CustomSMTPConfig customSMTPConfig) {
        this.customSMTPConfig = customSMTPConfig;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public static class CustomSMTPConfig {

        @SerializedName("ServerHost")
        @Expose
        private String serverHost;
        @SerializedName("ServerPort")
        @Expose
        private String serverPort;
        @SerializedName("TimeOut")
        @Expose
        private Integer timeOut;
        @SerializedName("EnableSsl")
        @Expose
        private Boolean enableSsl;
        @SerializedName("SMTPUserName")
        @Expose
        private String sMTPUserName;
        @SerializedName("SMTPUserPassword")
        @Expose
        private String sMTPUserPassword;

        public String getServerHost() {
            return serverHost;
        }

        public void setServerHost(String serverHost) {
            this.serverHost = serverHost;
        }

        public String getServerPort() {
            return serverPort;
        }

        public void setServerPort(String serverPort) {
            this.serverPort = serverPort;
        }

        public Integer getTimeOut() {
            return timeOut;
        }

        public void setTimeOut(Integer timeOut) {
            this.timeOut = timeOut;
        }

        public Boolean getEnableSsl() {
            return enableSsl;
        }

        public void setEnableSsl(Boolean enableSsl) {
            this.enableSsl = enableSsl;
        }

        public String getSMTPUserName() {
            return sMTPUserName;
        }

        public void setSMTPUserName(String sMTPUserName) {
            this.sMTPUserName = sMTPUserName;
        }

        public String getSMTPUserPassword() {
            return sMTPUserPassword;
        }

        public void setSMTPUserPassword(String sMTPUserPassword) {
            this.sMTPUserPassword = sMTPUserPassword;
        }

    }

}
