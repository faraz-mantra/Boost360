package com.anachat.chatsdk.internal.network;

import com.anachat.chatsdk.internal.utils.ExceptionType;

/**
 * Created by lookup on 09/10/17.
 */


public enum UnexpectedException implements ExceptionType {
    GENERIC;

    UnexpectedException() {
    }
}
