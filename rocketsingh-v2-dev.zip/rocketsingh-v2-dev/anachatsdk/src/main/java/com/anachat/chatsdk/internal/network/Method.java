package com.anachat.chatsdk.internal.network;

/**
 * Created by lookup on 09/10/17.
 */

public enum Method {
    POST,
    GET;

    private Method() {
    }
}
