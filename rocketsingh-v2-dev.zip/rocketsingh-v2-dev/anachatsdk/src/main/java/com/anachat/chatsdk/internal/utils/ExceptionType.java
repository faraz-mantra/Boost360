package com.anachat.chatsdk.internal.utils;

/**
 * Created by lookup on 09/10/17.
 */

public interface ExceptionType {
}
