package com.anachat.chatsdk.internal.network;

/**
 * Created by lookup on 09/10/17.
 */

public interface HTTPTransport {
    Response makeRequest(Request var1);
}