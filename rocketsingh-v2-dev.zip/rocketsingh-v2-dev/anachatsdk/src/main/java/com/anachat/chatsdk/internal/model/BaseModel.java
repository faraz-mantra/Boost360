package com.anachat.chatsdk.internal.model;

import java.io.Serializable;

public abstract class BaseModel implements Serializable {

    public BaseModel() {

    }

}
