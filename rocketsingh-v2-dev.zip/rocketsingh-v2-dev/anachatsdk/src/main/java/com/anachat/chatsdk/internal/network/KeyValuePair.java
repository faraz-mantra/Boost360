package com.anachat.chatsdk.internal.network;

/**
 * Created by lookup on 09/10/17.
 */

public class KeyValuePair {
    public final String key;
    public final String value;

    public KeyValuePair(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
