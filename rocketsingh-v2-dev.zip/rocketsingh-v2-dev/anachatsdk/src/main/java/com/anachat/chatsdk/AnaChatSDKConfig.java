package com.anachat.chatsdk;

import android.content.Context;

public interface AnaChatSDKConfig {
    Context getContext();
}
